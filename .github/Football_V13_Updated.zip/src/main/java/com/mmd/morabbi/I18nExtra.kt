package com.mmd.morabbi

// داده‌های ترجمه‌ی اضافه (نام باشگاه‌ها و متن‌های رابط)؛ توسط اسکریپت ساخته شده است.
internal const val X_LONG = """ساخت تیم اختصاصی؛ شروع از دسته دوم¦Create your own team (starts in Division 2)
رتبه‌بندی جهانی باشگاه‌ها¦World club rankings
رتبه‌بندی جهانی¦World rankings
ساخت تیم اختصاصی¦Create custom team
مثلاً ستاره تهران¦e.g. Setareh Tehran
سطح شروع¦Starting level
قدرت شروع حدود¦Starting strength about
تیم شما جایگزین ضعیف‌ترین تیم دسته دوم می‌شود؛ تعداد تیم‌های لیگ افزایش نمی‌یابد.¦Your team replaces the weakest Division 2 team; the number of league teams does not increase.
نام تیم را وارد کنید¦Enter a team name
این نام قبلاً استفاده شده است¦This name is already used
ساخت تیم و شروع بازی¦Create team & start playing
افتخارات لیگ برتر و جام حذفی؛ سپس قدرت تیم¦Top-flight league and cup titles, then team strength
بر اساس قدرت و اورال ترکیب¦Based on lineup strength & overall
مرکز مدیریت باشگاه¦Club management center
از نوار پایین برای ورود مستقیم به خانه، بازیکنان، بازار نقل‌وانتقالات، آکادمی و جدول لیگ استفاده کن.¦Use the bottom bar to jump straight to Home, Players, the Transfer market, the Academy and the league table.
رفتن به مسابقه¦Go to match
لیگ‌ها و رتبه‌بندی¦Leagues & rankings
آکادمی جوانان¦Youth academy
بازیکنان ۱۴ تا ۱۸ سال | هر فصل رشد می‌کنند و در ۱۸ سالگی به تیم اصلی می‌رسند.¦Players aged 14 to 18 | They grow every season and join the first team at 18.
تعداد استعدادها¦Number of talents
در حال حاضر بازیکنی در آکادمی نیست.¦There are no players in the academy right now.
استعداد ویژه¦Special talent
سیستم رشد¦Growth system
اورال شروع معمولاً ۵۵ تا ۷۰ است. بازیکن‌ها با هر فصل رشد می‌کنند؛ استعدادهای استثنایی ممکن است با اورال ۸۰ یا بیشتر وارد تیم اصلی شوند.¦Starting overall is usually 55 to 70. Players grow each season; exceptional talents may reach the first team with an overall of 80 or more.
ترکیب و بازیکنان¦Lineup & players
فیلتر پست¦Position filter
فیلتر سن¦Age filter
فیلتر اورال¦Rating filter
ترکیب و تاکتیک¦Lineup & tactics
بازیکن انتخاب‌شده¦Selected player
برای تغییر ترکیب، یک جایگاه روی زمین و سپس بازیکن ذخیره را لمس کن.¦To change the lineup, tap a spot on the pitch, then tap a substitute.
نمایش تیم‌ها¦Show teams
بستن لیست تیم‌ها¦Hide teams
نسل جدید¦New generation
فارغ‌التحصیل آکادمی¦Academy graduate
با اورال¦with OVR
جام حذفی انگلیس (FA Cup)¦English FA Cup
کوپا دل‌ری¦Copa del Rey
جام حذفی آلمان (DFB-Pokal)¦German Cup (DFB-Pokal)
کوپا ایتالیا¦Coppa Italia
جام حذفی فرانسه¦French Cup
جام حذفی پرتغال¦Portuguese Cup
جام حذفی هلند¦Dutch Cup (KNVB Cup)
کوپا دو برزیل¦Copa do Brasil
جام حذفی ترکیه¦Turkish Cup
کوپا آرژانتین¦Copa Argentina
جام حذفی ایران¦Hazfi Cup (Iran)
لیگ دو انگلیس¦League Two England
لیگ یک انگلیس¦League One England
لیگ یک ترکیه¦1. Lig Turkey
لیگ دو ترکیه¦2. Lig Turkey
سوپر لیگ ترکیه¦Turkish Super Lig
لیگا ۳¦3. Liga
سری بی برزیل¦Serie B Brazil
سری سی برزیل¦Serie C Brazil
ملی فرانسه¦National France
لیگ برتر پرتغال¦Primeira Liga
ارسته دیویسه¦Eerste Divisie
دسته سه اسپانیا¦Spain Tier 3
سری بی¦Serie B
سری سی¦Serie C"""
internal const val X_CLUBS1 = """پرسپولیس¦Persepolis
استقلال¦Esteghlal
سپاهان¦Sepahan
تراکتور¦Tractor
فولاد¦Foolad
گل‌گهر¦Gol Gohar
ملوان¦Malavan
ذوب‌آهن¦Zob Ahan
آلومینیوم اراک¦Aluminium Arak
شمس‌آذر¦Shams Azar
خیبر خرم‌آباد¦Khaybar Khorramabad
چادرملو¦Chadormalou
مس رفسنجان¦Mes Rafsanjan
نساجی¦Nassaji
پیکان¦Paykan
صنعت نفت آبادان¦Sanat Naft Abadan
سایپا¦Saipa
فجر سپاسی¦Fajr Sepasi
نفت مسجدسلیمان¦Naft Masjed Soleyman
هوادار¦Havadar
منچسترسیتی¦Manchester City
آرسنال¦Arsenal
لیورپول¦Liverpool
منچستریونایتد¦Manchester United
چلسی¦Chelsea
تاتنهام¦Tottenham
نیوکاسل یونایتد¦Newcastle United
استون ویلا¦Aston Villa
وستهم¦West Ham
برایتون¦Brighton
کریستال پالاس¦Crystal Palace
برنتفورد¦Brentford
فولام¦Fulham
اورتون¦Everton
ناتینگهام فارست¦Nottingham Forest
بورنموث¦Bournemouth
ولورهمپتون¦Wolverhampton
لسترسیتی¦Leicester City
ساوتهمپتون¦Southampton
ایپسویچ تاون¦Ipswich Town
رئال مادرید¦Real Madrid
بارسلونا¦Barcelona
اتلتیکو مادرید¦Atletico Madrid
اتلتیک بیلبائو¦Athletic Bilbao
رئال سوسیداد¦Real Sociedad
ویارئال¦Villarreal
رئال بتیس¦Real Betis
سویا¦Sevilla
والنسیا¦Valencia
خیرونا¦Girona
ختافه¦Getafe
اوساسونا¦Osasuna
سلتاویگو¦Celta Vigo
مایورکا¦Mallorca
لاس پالماس¦Las Palmas
رایو وایکانو¦Rayo Vallecano
آلاوس¦Alaves
گرانادا¦Granada
کادیس¦Cadiz
رئال وایادولید¦Real Valladolid
اینتر¦Inter
آث میلان¦AC Milan
یوونتوس¦Juventus
ناپولی¦Napoli
آتالانتا¦Atalanta
رم¦Roma
لاتزیو¦Lazio
فیورنتینا¦Fiorentina
بولونیا¦Bologna
تورینو¦Torino
مونزا¦Monza
اودینزه¦Udinese
جنوا¦Genoa
کالیاری¦Cagliari
امپولی¦Empoli
ورونا¦Verona
ساسولو¦Sassuolo
لچه¦Lecce
پارما¦Parma
کومو¦Como
بایرن مونیخ¦Bayern Munich
بروسیا دورتموند¦Borussia Dortmund
بایر لورکوزن¦Bayer Leverkusen
لایپزیگ¦RB Leipzig
اشتوتگارت¦Stuttgart
آینتراخت فرانکفورت¦Eintracht Frankfurt
وولفسبورگ¦Wolfsburg
فرایبورگ¦Freiburg
هوفنهایم¦Hoffenheim
وردربرمن¦Werder Bremen
آگزبورگ¦Augsburg
ماینتس¦Mainz
مونشن‌گلادباخ¦Monchengladbach
یونیون برلین¦Union Berlin
بوخوم¦Bochum
هایدنهایم¦Heidenheim
سن پائولی¦St. Pauli
هولشتاین کیل¦Holstein Kiel
هامبورگ¦Hamburg
هرتابرلین¦Hertha Berlin
پاری سن ژرمن¦Paris Saint-Germain
مارسی¦Marseille
موناکو¦Monaco
لیون¦Lyon
لیل¦Lille
نیس¦Nice
رن¦Rennes
لانس¦Lens
استراسبورگ¦Strasbourg
نانت¦Nantes
تولوز¦Toulouse
مون‌پلیه¦Montpellier
برست¦Brest
لوهاور¦Le Havre
متز¦Metz
لوریان¦Lorient
سن‌اتین¦Saint-Etienne
اوسر¦Auxerre
آنژه¦Angers
ریمز¦Reims
فلامینگو¦Flamengo
پالمیراس¦Palmeiras
سائوپائولو¦Sao Paulo
کورینتیانس¦Corinthians
سانتوس¦Santos
گرمیو¦Gremio
اینترناسیونال¦Internacional
اتلتیکو مینیرو¦Atletico Mineiro
فلومیننزه¦Fluminense
بوتافوگو¦Botafogo
کروزیرو¦Cruzeiro
واسکو دا گاما¦Vasco da Gama
باهیا¦Bahia
فورتالزا¦Fortaleza
براگانتی‌نو¦Bragantino
اتلتیکو پارانائنزه¦Athletico Paranaense
کویابا¦Cuiaba
ویتوریا¦Vitoria
گوییاس¦Goias
کوریتیبا¦Coritiba
گالاتاسرای¦Galatasaray
فنرباغچه¦Fenerbahce
بشیکتاش¦Besiktas
ترابزون‌اسپور¦Trabzonspor
باشاک‌شهیر¦Basaksehir
آدانا دمیرسپور¦Adana Demirspor
سیواس‌اسپور¦Sivasspor
کاسیم‌پاشا¦Kasimpasa
آلانیااسپور¦Alanyaspor
قونیه‌اسپور¦Konyaspor
قیصریه‌اسپور¦Kayserispor
آنتالیااسپور¦Antalyaspor
ریزه‌اسپور¦Rizespor
هاتای‌اسپور¦Hatayspor
غازی‌عنتاب¦Gaziantep FK
سامسون‌اسپور¦Samsunspor
ایوب‌اسپور¦Eyupspor
گوزتپه¦Goztepe
بودروم‌اسپور¦Bodrumspor
کوجائلی‌اسپور¦Kocaelispor
بوکا جونیورز¦Boca Juniors
ریور پلاته¦River Plate
ایندیپندینته¦Independiente
راسیینگ کلاب¦Racing Club
سن لورنزو¦San Lorenzo
استودیانتس¦Estudiantes
لانوس¦Lanus
ولز سارسفیلد¦Velez Sarsfield
روساریو سنترال¦Rosario Central
نیوولز اولد بویز¦Newell's Old Boys
تالرز¦Talleres
آرژنتینوس جونیورز¦Argentinos Juniors
دفاع و خوستیسیا¦Defensa y Justicia
بلگرانو¦Belgrano
هوراکان¦Huracan
پلاتنسه¦Platense
گودوی کروز¦Godoy Cruz
بانفیلد¦Banfield
تایرس¦Tigre
اتلتیکو توکومان¦Atletico Tucuman
بنفیکا¦Benfica
پورتو¦Porto
اسپورتینگ لیسبون¦Sporting CP
براگا¦Braga
ویتوریا گیمارش¦Vitoria Guimaraes
موریرنزه¦Moreirense
فامالیکائو¦Famalicao
آروکا¦Arouca
ژیل ویسنته¦Gil Vicente
ریو آوه¦Rio Ave
بوآویشتا¦Boavista
اشتوریل¦Estoril
کاسا پیا¦Casa Pia
فارنسه¦Farense
ناسیونال¦Nacional
سانتا کلارا¦Santa Clara
چاوز¦Chaves
پورتیموننزه¦Portimonense
پاکوش فریرا¦Pacos de Ferreira
توندلا¦Tondela
آژاکس¦Ajax
پی‌اس‌وی آیندهوون¦PSV Eindhoven
فاینورد¦Feyenoord
آلکمار¦AZ Alkmaar
توئنته¦Twente
اوترخت¦Utrecht
گو اهد ایگلز¦Go Ahead Eagles
اسپارتا روتردام¦Sparta Rotterdam
هیرنفین¦Heerenveen
نایمخن¦NEC Nijmegen
فورتونا سیتارد¦Fortuna Sittard
هراکلز¦Heracles
زووله¦Zwolle
ویلم دوم¦Willem II
گرونینگن¦Groningen
والویک¦Waalwijk
اکسلسیور¦Excelsior
کامبور¦Cambuur
دن هاخ¦Den Haag
بردا¦Breda
مس کرمان¦Mes Kerman
مس شهربابک¦Mes Shahr-e Babak
مس سونگون¦Mes Sungun
پارس جنوبی جم¦Pars Jonoubi Jam
داماش گیلان¦Damash Gilan
چوکا تالش¦Chooka Talesh
نیروی زمینی¦Niroye Zamini
استقلال ملاثانی¦Esteghlal Molasani
آریو اسلامشهر¦Arya Eslamshahr
سپیدرود رشت¦Sepidrood Rasht
پاس همدان¦Pas Hamedan
شاهین بوشهر¦Shahin Bushehr
ماشین‌سازی تبریز¦Machine Sazi Tabriz
گیتی‌پسند¦Gity Pasand
نفت و گاز گچساران¦Naft va Gaz Gachsaran
شهرداری آستارا¦Shahrdari Astara
فولاد نوین¦Foolad Novin
ایرانجوان بوشهر¦Iranjavan Bushehr
شهرداری نوشهر¦Shahrdari Nowshahr
لیدز یونایتد¦Leeds United
برنلی¦Burnley
شفیلد یونایتد¦Sheffield United
وست برومویچ¦West Bromwich
نوریچ سیتی¦Norwich City"""
internal const val X_CLUBS2 = """میدلزبرو¦Middlesbrough
کاونتری سیتی¦Coventry City
ساندرلند¦Sunderland
واتفورد¦Watford
بلاکبرن روورز¦Blackburn Rovers
بولتون واندررز¦Bolton Wanderers
چارلتون اتلتیک¦Charlton Athletic
دربی کانتی¦Derby County
پورتسموث¦Portsmouth
ردینگ¦Reading
ویگان اتلتیک¦Wigan Athletic
بارنزلی¦Barnsley
لوتون تاون¦Luton Town
هال سیتی¦Hull City
پلیموث آرگایل¦Plymouth Argyle
لگانس¦Leganes
اسپانیول¦Espanyol
رئال اویدو¦Real Oviedo
لوانته¦Levante
الچه¦Elche
ایبار¦Eibar
تنریف¦Tenerife
زاراگوزا¦Zaragoza
اسپورتینگ خیخون¦Sporting Gijon
بورگوس¦Burgos
آلباسته¦Albacete
هوئسکا¦Huesca
میراندس¦Mirandes
کوردوبا¦Cordoba
دپورتیوو لاکرونیا¦Deportivo La Coruna
مالاگا¦Malaga
کاستیون¦Castellon
راسینگ سانتاندر¦Racing Santander
ویارئال ب¦Villarreal B
آندورا¦Andorra
سمپدوریا¦Sampdoria
پالرمو¦Palermo
کرمونزه¦Cremonese
ونتزیا¦Venezia
پیزا¦Pisa
کاتانزارو¦Catanzaro
برشا¦Brescia
مودنا¦Modena
رجیانا¦Reggiana
باری¦Bari
چزنا¦Cesena
اسپتزیا¦Spezia
ترنانا¦Ternana
آسکولی¦Ascoli
پروجا¦Perugia
پادوا¦Padova
ویچنزا¦Vicenza
آولینو¦Avellino
کروتونه¦Crotone
مانتوا¦Mantova
شالکه ۰۴¦Schalke 04
هانوفر ۹۶¦Hannover 96
فورتونا دوسلدورف¦Fortuna Dusseldorf
پادربورن¦Paderborn
کارلسروهه¦Karlsruhe
نورنبرگ¦Nuremberg
کایزرسلاوترن¦Kaiserslautern
مگدبورگ¦Magdeburg
دارمشتات¦Darmstadt
دینامو درسدن¦Dynamo Dresden
آلمانیا آخن¦Alemannia Aachen
اسن¦Essen
وهن ویسبادن¦Wehen Wiesbaden
یان رگنسبورگ¦Jahn Regensburg
ساندهاوزن¦Sandhausen
انرژی کوتبوس¦Energie Cottbus
هانزا روستوک¦Hansa Rostock
بوردو¦Bordeaux
سنت‌اتین¦Saint-Etienne
اوکسر¦Auxerre
کاین¦Caen
گنگام¦Guingamp
آمیان¦Amiens
پاری اف‌سی¦Paris FC
گرونوبل¦Grenoble
بستیا¦Bastia
تروا¦Troyes
والنسین¦Valenciennes
دانکرک¦Dunkerque
رد استار¦Red Star
نانسی¦Nancy
سوشو¦Sochaux
لو مان¦Le Mans
اورلئان¦Orleans
بولون¦Boulogne
شاتورو¦Chateauroux
اسپورت رسیف¦Sport Recife
سیارا¦Ceara
آمریکا مینیرو¦America Mineiro
آوای¦Avai
پونته پرتا¦Ponte Preta
گوارانی¦Guarani
ویلا نوا¦Vila Nova
نووتیزونتینو¦Novorizontino
میراسول¦Mirassol
کریسیوما¦Criciuma
ژوونتوده¦Juventude
اتلتیکو گویانینسه¦Atletico Goianiense
ناوتیکو¦Nautico
پارانا¦Parana
لوندرینا¦Londrina
سنتا کروز¦Santa Cruz
اوپراتاریو¦Operario
ارزوروم‌اسپور¦Erzurumspor
آلتای¦Altay
گنچلربیرلیغی¦Genclerbirligi
بولوسپور¦Boluspor
آدناسپور¦Adanaspor
آمد اسپور¦Amed Spor
ساکاریاسپور¦Sakaryaspor
چوروم اف‌کی¦Corum FK
اومرانیه‌اسپور¦Umraniyespor
کچی‌اورنگوچو¦Keciorengucu
باندیرماسپور¦Bandirmaspor
شانلی‌اورفا¦Sanliurfaspor
دنیزلی‌اسپور¦Denizlispor
اسکی‌شهیرسپور¦Eskisehirspor
کاراگومروک¦Karagumruk
مانیساسپور¦Manisaspor
وان‌اسپور¦Vanspor
کویلمس¦Quilmes
فرروکاریل اوئسته¦Ferro Carril Oeste
چاکاریتا جونیورز¦Chacarita Juniors
سان مارتین توکومان¦San Martin de Tucuman
سان مارتین سن خوان¦San Martin de San Juan
آرسنال ساراندی¦Arsenal de Sarandi
آلماگرو¦Almagro
آتلتیکو رافائلا¦Atletico Rafaela
دپورتیوو مورون¦Deportivo Moron
پاتروناتو¦Patronato
آلدو‌سیوی¦Aldosivi
گیلرمو براون¦Guillermo Brown
آگروپکواریو¦Agropecuario
براون آدرگه¦Brown de Adrogue
تیمپلی¦Temperley
دیفنسورز¦Defensores
کلون سانتا فه¦Colon de Santa Fe
سنترال کوردوبا¦Central Cordoba
آکادمیکا کویمبرا¦Academica Coimbra
پنافیل¦Penafiel
لایشوئش¦Leixoes
فیرنزه¦Fiaes
ماریتیمو¦Maritimo
فارو¦Faro
ویلافرانکنزه¦Vilafranquense
پورتو بی¦Porto B
بنفیکا بی¦Benfica B
اسپورتینگ بی¦Sporting B
آکادمیکو ویزئو¦Academico Viseu
اولیوییرنزه¦Oliveirense
مافرا¦Mafra
وارزیم¦Varzim
فلگوئیراس¦Felgueiras
آلورکا¦Alverca
رودا جی‌سی¦Roda JC
دی گرافشاپ¦De Graafschap
ناک بردا¦NAC Breda
ام‌وی‌وی ماستریخت¦MVV Maastricht
تلستار¦Telstar
دوردراخت¦Dordrecht
اف‌سی آیندهوون¦FC Eindhoven
هلموند اسپورت¦Helmond Sport
دن بوش¦Den Bosch
آلمره سیتی¦Almere City
ونلو¦VVV-Venlo
اوس¦Oss
یانگ آژاکس¦Jong Ajax
یانگ پی‌اس‌وی¦Jong PSV
یانگ اوترخت¦Jong Utrecht
اسپورت¦Sport
اتلتیکو¦Atletico
آمریکا¦America
گوارانی¦Guarani
اونیاو¦Uniao
ایتوانو¦Ituano
ناسیونال¦Nacional
رئال¦Real
ریو¦Rio
سائوپائولو¦Sao Paulo
کوریتیبا¦Curitiba
سالوادور¦Salvador
رسیف¦Recife
بلو هوریزونته¦Belo Horizonte
مانائوس¦Manaus
بلم¦Belem
گویانیا¦Goiania
فلوریانوپولیس¦Florianopolis
ینی¦Yeni
بلدیه¦Belediye
گنج¦Genc
اتلتیک¦Atletik
آنادولو¦Anadolu
دمیر¦Demir
بورسا¦Bursa
ازمیر¦Izmir
مالاتیا¦Malatya
مرسین¦Mersin
دیاربکر¦Diyarbakir
ترابزون¦Trabzon
سامسون¦Samsun
اردو¦Ordu
ایسپارتا¦Isparta
آدیامان¦Adiyaman
سان¦San
کلوب¦Club
دپورتیوو¦Deportivo
سنترال¦Central
یونیون¦Union
مندوسا¦Mendoza
سالتا¦Salta
کوردوبا¦Cordoba
لاپلاتا¦La Plata
ویلا¦Villa
خوخوی¦Jujuy
نیوکن¦Neuquen
ریسیستنسیا¦Resistencia
اسپورتیو¦Sporting
گرمیو¦Gremio
یونیائو¦Uniao
ویزئو¦Viseu
لیریا¦Leiria
اوئیراش¦Oeiras
ماتوزینیوش¦Matosinhos
سیتوبال¦Setubal
پورتالگره¦Portalegre
لاگوش¦Lagos
آویرو¦Aveiro
اف‌سی¦FC
فورتونا¦Fortuna
ویتسه¦Vitesse
اس‌سی¦SC
وی‌وی‌وی¦VVV
لیدن¦Leiden
هارلم¦Haarlem
بریدا¦Breda
ماستریخت¦Maastricht
دلفت¦Delft
آمستردام¦Amsterdam
روتردام¦Rotterdam
زوله¦Zwolle"""
internal const val X_SHORT = """سال¦yrs
سالگی¦years old
تا¦to
زیر¦Under
به بالا¦and above
جوان¦Youth
بازگشت¦Back
خانه¦Home
بازار¦Market
آکادمی¦Academy
افتخارات¦Honours
ملیت¦Nationality
ملیت‌ها¦nationalities
قدرت‌ها¦ratings
سنین¦ages
همه¦All
اورال¦OVR
پتانسیل¦Potential
شد¦
جایگزین¦replaces
نمایش¦Showing
بازیکن¦players
نروژ¦Norway
بلژیک¦Belgium
مصر¦Egypt
لهستان¦Poland
پرتغال¦Portugal
هلند¦Netherlands
اروگوئه¦Uruguay
کرواسی¦Croatia
سوئد¦Sweden
مجارستان¦Hungary
کامرون¦Cameroon
اسلوونی¦Slovenia
اکوادور¦Ecuador
اسکاتلند¦Scotland
مراکش¦Morocco
کره جنوبی¦South Korea
کانادا¦Canada
اتریش¦Austria
کلمبیا¦Colombia
نیجریه¦Nigeria
گرجستان¦Georgia
صربستان¦Serbia
آمریکا¦USA
سوئیس¦Switzerland
غنا¦Ghana
گینه¦Guinea
ژاپن¦Japan
چک¦Czechia
گابن¦Gabon
روسیه¦Russia
یونان¦Greece
بورکینافاسو¦Burkina Faso
فنلاند¦Finland
ساحل عاج¦Ivory Coast
بوسنی¦Bosnia
اوکراین¦Ukraine
الجزایر¦Algeria
پاراگوئه¦Paraguay
سنگال¦Senegal
نیوزیلند¦New Zealand
ارمنستان¦Armenia
کوزوو¦Kosovo
اسلواکی¦Slovakia
دانمارک¦Denmark
ذخیره‌ها¦Substitutes
آرایش تیم¦Formation
فارسی¦Persian
جام حذفی¦Cup
کریستیانو¦Cristiano
برونو¦Bruno
ژوائو¦Joao
ممفیس¦Memphis
فریرا¦Ferreira
رافائل¦Rafael
گونچالو¦Goncalo
کاروالیو¦Carvalho
دیپای¦Depay
فن‌دایک¦Van Dijk
دی‌یونگ¦De Jong
گاکپو¦Gakpo
ژاوی¦Xavi
کودی¦Cody
آکه¦Ake
مالن¦Malen
بروبی¦Brobbey
سیمونز¦Simons
فرنکی¦Frenkie
ماتیاس¦Matthijs
دانی¦Danny
یورین¦Jurrien
استیون¦Steven
اردیویسه¦Eredivisie"""

internal const val X_CLUBS3 = """منچسترسیتی¦Manchester City
آرسنال¦Arsenal
لیورپول¦Liverpool
منچستریونایتد¦Manchester United
چلسی¦Chelsea
تاتنهام¦Tottenham
نیوکاسل یونایتد¦Newcastle United
استون ویلا¦Aston Villa
برایتون¦Brighton
کریستال پالاس¦Crystal Palace
برنتفورد¦Brentford
فولام¦Fulham
اورتون¦Everton
ناتینگهام فارست¦Nottingham Forest
بورنموث¦Bournemouth
لیدز یونایتد¦Leeds United
ساندرلند¦Sunderland
کاونتری سیتی¦Coventry City
ایپسویچ تاون¦Ipswich Town
هال سیتی¦Hull City
وستهم¦West Ham
ولورهمپتون¦Wolverhampton
ساوتهمپتون¦Southampton
برنلی¦Burnley
شفیلد یونایتد¦Sheffield United
میدلزبرو¦Middlesbrough
نوریچ سیتی¦Norwich City
وست برومویچ¦West Bromwich
واتفورد¦Watford
بیرمنگام سیتی¦Birmingham City
بلاکبرن روورز¦Blackburn Rovers
استوک سیتی¦Stoke City
دربی کانتی¦Derby County
بریستول سیتی¦Bristol City
سوانسی سیتی¦Swansea City
کاردیف سیتی¦Cardiff City
کوئینز پارک رنجرز¦Queens Park Rangers
پرستون نورث‌اند¦Preston North End
میلوال¦Millwall
پورتسموث¦Portsmouth
بولتون واندررز¦Bolton Wanderers
چارلتون اتلتیک¦Charlton Athletic
رکسهام¦Wrexham
لینکلن سیتی¦Lincoln City
لوتون تاون¦Luton Town
ردینگ¦Reading
ویگان اتلتیک¦Wigan Athletic
بارنزلی¦Barnsley
پلیموث آرگایل¦Plymouth Argyle
هادرزفیلد تاون¦Huddersfield Town
پیتربورو یونایتد¦Peterborough United
اکستر سیتی¦Exeter City
استاکپورت کانتی¦Stockport County
برادفورد سیتی¦Bradford City
منسفیلد تاون¦Mansfield Town
روترهام یونایتد¦Rotherham United
لیتون اورینت¦Leyton Orient
وایکامب واندررز¦Wycombe Wanderers
کمبریج یونایتد¦Cambridge United
نورثهمپتون تاون¦Northampton Town
استیونیج¦Stevenage
برتون آلبیون¦Burton Albion
بلکپول¦Blackpool
کرولی تاون¦Crawley Town
بریستول روورز¦Bristol Rovers
دانکستر روورز¦Doncaster Rovers
ای‌اف‌سی ویمبلدون¦AFC Wimbledon
ناتس کانتی¦Notts County
چسترفیلد¦Chesterfield
والسال¦Walsall
گریمزبی تاون¦Grimsby Town
کرو الکساندرا¦Crewe Alexandra
پورت ویل¦Port Vale
سالفورد سیتی¦Salford City
سویندون تاون¦Swindon Town
گیلینگهام¦Gillingham
کولچستر یونایتد¦Colchester United
برومیلی¦Bromley
بارو¦Barrow
هارگیت تاون¦Harrogate Town
ترانمیر روورز¦Tranmere Rovers
فلیت‌وود تاون¦Fleetwood Town
چلتنهام تاون¦Cheltenham Town
نیوپورت کانتی¦Newport County
رئال مادرید¦Real Madrid
بارسلونا¦Barcelona
اتلتیکو مادرید¦Atletico Madrid
اتلتیک بیلبائو¦Athletic Bilbao
رئال سوسیداد¦Real Sociedad
ویارئال¦Villarreal
رئال بتیس¦Real Betis
سویا¦Sevilla
والنسیا¦Valencia
سلتاویگو¦Celta Vigo
اوساسونا¦Osasuna
ختافه¦Getafe
رایو وایکانو¦Rayo Vallecano
اسپانیول¦Espanyol
دپورتیوو لاکرونیا¦Deportivo La Coruna
مالاگا¦Malaga
لوانته¦Levante
الچه¦Elche
راسینگ سانتاندر¦Racing Santander
آلاوس¦Alaves
خیرونا¦Girona
مایورکا¦Mallorca
لاس پالماس¦Las Palmas
گرانادا¦Granada
رئال وایادولید¦Real Valladolid
کادیس¦Cadiz
آلمریا¦Almeria
لگانس¦Leganes
رئال اویدو¦Real Oviedo
اسپورتینگ خیخون¦Sporting Gijon
تنریف¦Tenerife
ایبار¦Eibar
کاستیون¦Castellon
کوردوبا¦Cordoba
آندورا¦Andorra
بورگوس¦Burgos
آلباسته¦Albacete
سابادل¦Sabadell
الدنسه¦Eldense
سئوتا¦Ceuta
زاراگوزا¦Real Zaragoza
هوئسکا¦Huesca
میراندس¦Mirandes
راسینگ فرول¦Racing Ferrol
مورسیا¦Real Murcia
کولتورال لئونسا¦Cultural Leonesa
رئال سوسیداد ب¦Real Sociedad B
ویارئال ب¦Villarreal B
بارسلونا ب¦Barcelona Atletic
لوگو¦Lugo
پونفرادینا¦Ponferradina
الخسیراس¦Algeciras
آنتکرا¦Antequera
ترول¦Teruel
آرنتیرو¦Arenteiro
اونیونیستاس¦Unionistas
هرکولس¦Hercules
مریدا¦Merida
رئال اونیون¦Real Union
اتلتیکو مادرید ب¦Atletico Madrid B
اینتر¦Inter
آث میلان¦AC Milan
یوونتوس¦Juventus
ناپولی¦Napoli
آتالانتا¦Atalanta
رم¦Roma
لاتزیو¦Lazio
فیورنتینا¦Fiorentina
بولونیا¦Bologna
تورینو¦Torino
مونزا¦Monza
اودینزه¦Udinese
جنوا¦Genoa
کالیاری¦Cagliari
ساسولو¦Sassuolo
لچه¦Lecce
پارما¦Parma
کومو¦Como
ونتزیا¦Venezia
فروزینونه¦Frosinone
سمپدوریا¦Sampdoria
پالرمو¦Palermo
ورونا¦Verona
امپولی¦Empoli
کرمونزه¦Cremonese
پیزا¦Pisa
بنونتو¦Benevento
کاتانزارو¦Catanzaro
چزنا¦Cesena
مودنا¦Modena
آولینو¦Avellino
پادوا¦Padova
ویچنزا¦Vicenza
مانتوا¦Mantova
آرتزو¦Arezzo
آسکولی¦Ascoli
کارارزه¦Carrarese
یوونتوس استابیا¦Juve Stabia
ویرتوس انتلا¦Virtus Entella
سودتیرول¦Sudtirol
برشا¦Brescia
پروجا¦Perugia
باری¦Bari
ترنانا¦Ternana
رجیانا¦Reggiana
اسپتزیا¦Spezia
کروتونه¦Crotone
پسکارا¦Pescara
تریستینا¦Triestina
تورس¦Torres
لوکزه¦Lucchese
فوجا¦Foggia
لکو¦Lecco
تراپانی¦Trapani
مسینا¦Messina
چریگنولا¦Audace Cerignola
کازرتانا¦Casertana
لاتینا¦Latina
پونتدرا¦Pontedera
پیاچنزا¦Piacenza
بایرن مونیخ¦Bayern Munich
بروسیا دورتموند¦Borussia Dortmund
بایر لورکوزن¦Bayer Leverkusen
لایپزیگ¦RB Leipzig
اشتوتگارت¦VfB Stuttgart
آینتراخت فرانکفورت¦Eintracht Frankfurt
وولفسبورگ¦Wolfsburg
فرایبورگ¦Freiburg
هوفنهایم¦Hoffenheim
وردربرمن¦Werder Bremen
آگزبورگ¦Augsburg
ماینتس¦Mainz
مونشن‌گلادباخ¦Monchengladbach
یونیون برلین¦Union Berlin
هامبورگ¦Hamburg
شالکه ۰۴¦Schalke 04
کلن¦Cologne
پادربورن¦Paderborn
سن پائولی¦St. Pauli
السفرسبرگ¦Elversberg
هانوفر ۹۶¦Hannover 96
هرتابرلین¦Hertha Berlin
کایزرسلاوترن¦Kaiserslautern
نورنبرگ¦Nuremberg
بوخوم¦Bochum
هایدنهایم¦Heidenheim
هولشتاین کیل¦Holstein Kiel
دارمشتات¦Darmstadt
کارلسروهه¦Karlsruhe
مگدبورگ¦Magdeburg
دینامو درسدن¦Dynamo Dresden
براونشوایگ¦Braunschweig
ارمینیا بیلفلد¦Arminia Bielefeld
گروتر فورت¦Greuther Furth
انرژی کوتبوس¦Energie Cottbus
اوسنابروک¦Osnabruck
فورتونا دوسلدورف¦Fortuna Dusseldorf
اسن¦Rot-Weiss Essen
وهن ویسبادن¦Wehen Wiesbaden
یان رگنسبورگ¦Jahn Regensburg
ساندهاوزن¦Sandhausen
هانزا روستوک¦Hansa Rostock
پروسن مونستر¦Preussen Munster
مونیخ ۱۸۶۰¦1860 Munich
زاربروکن¦Saarbrucken
ویکتوریا کلن¦Viktoria Koln
والدهوف مانهایم¦Waldhof Mannheim
دویسبورگ¦Duisburg
اولم¦Ulm
اروتسگبیرگه آئو¦Erzgebirge Aue
فرل¦Verl
لوبک¦Lubeck
اونترهاخینگ¦Unterhaching
بایروت¦Bayreuth
اولدنبورگ¦Oldenburg
هاولسه¦Havelse
آلمانیا آخن¦Alemannia Aachen
بروسیا دورتموند ب¦Dortmund II
اشتوتگارت ب¦Stuttgart II
هوفنهایم ب¦Hoffenheim II
پاری سن ژرمن¦Paris Saint-Germain
مارسی¦Marseille
موناکو¦Monaco
لیون¦Lyon
لیل¦Lille
نیس¦Nice
رن¦Rennes
لانس¦Lens
استراسبورگ¦Strasbourg
نانت¦Nantes
تولوز¦Toulouse
برست¦Brest
لوهاور¦Le Havre
متز¦Metz
لوریان¦Lorient
اوسر¦Auxerre
آنژه¦Angers
پاری اف‌سی¦Paris FC
تروا¦Troyes
لومان¦Le Mans
سن‌اتین¦Saint-Etienne
مون‌پلیه¦Montpellier
ریمز¦Reims
کلرمون فوت¦Clermont Foot
گنگام¦Guingamp
گرونوبل¦Grenoble
سوشو¦Sochaux
دیژون¦Dijon
نانسی¦Nancy
دانکرک¦Dunkerque
آنسی¦Annecy
بولون¦Boulogne
پو¦Pau
رد استار¦Red Star
رودز¦Rodez
لاوال¦Laval
بوردو¦Bordeaux
کاین¦Caen
آمیان¦Amiens
بستیا¦Bastia
والنسین¦Valenciennes
نیور¦Niort
کوویی‌رون¦Quevilly-Rouen
ورسای¦Versailles
کنکارنو¦Concarneau
اورلئان¦Orleans
پاری ۱۳¦Paris 13 Atletico
شاتورو¦Chateauroux
ویلفرانش¦Villefranche
سدان¦Sedan
کن¦Cannes
نیم¦Nimes
مارتیگ¦Martigues
فلوری¦Fleury
بورگ‌آن‌برس¦Bourg-en-Bresse
لیون لا دوشر¦Lyon-La Duchere
لوپوی¦Le Puy
آنگولم¦Angouleme
شربورگ¦Cherbourg
سن‌مالو¦Saint-Malo
فلامینگو¦Flamengo
پالمیراس¦Palmeiras
سائوپائولو¦Sao Paulo
کورینتیانس¦Corinthians
سانتوس¦Santos
گرمیو¦Gremio
اینترناسیونال¦Internacional
اتلتیکو مینیرو¦Atletico Mineiro
فلومیننزه¦Fluminense
بوتافوگو¦Botafogo
کروزیرو¦Cruzeiro
واسکو دا گاما¦Vasco da Gama
باهیا¦Bahia
براگانتی‌نو¦RB Bragantino
اتلتیکو پارانائنزه¦Athletico Paranaense
ویتوریا¦Vitoria
کوریتیبا¦Coritiba
میراسول¦Mirassol
شاپکوئنسه¦Chapecoense
رمو¦Remo
فورتالزا¦Fortaleza
سیارا¦Ceara
کویابا¦Cuiaba
گوییاس¦Goias
اسپورت رسیف¦Sport Recife
آمریکا مینیرو¦America Mineiro
اتلتیکو گویانینسه¦Atletico Goianiense
ژوونتوده¦Juventude
کریسیوما¦Criciuma
پونته پرتا¦Ponte Preta
ناوتیکو¦Nautico
آوای¦Avai
ویلا نوا¦Vila Nova
نووریزونتینو¦Novorizontino
بوتافوگو اس‌پی¦Botafogo SP
اوپراریو¦Operario
سی‌آرب¦CRB
اتلتیک کلوبه¦Athletic Club
ساو برناردو¦Sao Bernardo
لوندرینا¦Londrina
ایپیرانگا¦Ypiranga
ولتا ردونده¦Volta Redonda
فیگوئیرنسه¦Figueirense
بوتافوگو پی‌بی¦Botafogo PB
پایسندو¦Paysandu
فروویاریا¦Ferroviaria
برسکه¦Brusque
آ‌ب‌ث¦ABC
کونفیانسا¦Confianca
مارینگا¦Maringa
سانتا کروز¦Santa Cruz
تومبنسه¦Tombense
فلورستا¦Floresta
کاشیاس¦Caxias
ایتابایانا¦Itabaiana
آپارسیدنسه¦Aparecidense
ساو خوزه¦Sao Jose
کامپینینسه¦Campinense
آناپولیس¦Anapolis
ترزه¦Treze
گالاتاسرای¦Galatasaray
فنرباغچه¦Fenerbahce
بشیکتاش¦Besiktas
ترابزون‌اسپور¦Trabzonspor
باشاک‌شهیر¦Basaksehir
سامسون‌اسپور¦Samsunspor
گوزتپه¦Goztepe
قونیه‌اسپور¦Konyaspor
آلانیااسپور¦Alanyaspor
کاسیم‌پاشا¦Kasimpasa
ایوب‌اسپور¦Eyupspor
ریزه‌اسپور¦Rizespor
غازی‌عنتاب¦Gaziantep
گنچلربیرلیغی¦Genclerbirligi
کوجائلی‌اسپور¦Kocaelispor
چوروم اف‌کی¦Corum FK
ارزوروم‌اسپور¦Erzurumspor
آمد اسپور¦Amed
سیواس‌اسپور¦Sivasspor
آنتالیااسپور¦Antalyaspor
آدانا دمیرسپور¦Adana Demirspor
هاتای‌اسپور¦Hatayspor
بودروم‌اسپور¦Bodrumspor
کایسری‌اسپور¦Kayserispor
بورسا‌اسپور¦Bursaspor
آلتای¦Altay
بولوسپور¦Boluspor
آدناسپور¦Adanaspor
ساکاریاسپور¦Sakaryaspor
اومرانیه‌اسپور¦Umraniyespor
کچی‌اورنگوچو¦Keciorengucu
باندیرماسپور¦Bandirmaspor
شانلی‌اورفا¦Sanliurfaspor
دنیزلی‌اسپور¦Denizlispor
اسکی‌شهیرسپور¦Eskisehirspor
کاراگومروک¦Fatih Karagumruk
مانیساسپور¦Manisaspor
وان‌اسپور¦Vanspor
پندیک‌اسپور¦Pendikspor
ایستانبول‌اسپور¦Istanbulspor
ایگدیر‌اسپور¦Igdirspor
سریک بلدیه‌اسپور¦Serik Belediyespor
بایبورت اوزل ایداره¦Bayburt Ozel Idare
مرسین ایدمان یورتو¦Mersin Idman Yurdu
گیرسون‌اسپور¦Giresunspor
ایسپارتا‌اسپور¦Isparta 32 Spor
اوشاک‌اسپور¦Usakspor
کارشیاکا¦Karsiyaka
اینه‌گول‌اسپور¦Inegolspor
زونگولداک‌اسپور¦Zonguldakspor
تکیردا‌اسپور¦Tekirdagspor
مالاتیا‌اسپور¦Malatyaspor
فتحیه‌اسپور¦Fethiyespor
آماسیا‌اسپور¦Amasyaspor
نیغده آنادولوسپور¦Nigde Anadolu
ازمیر‌اسپور¦Izmirspor
بیلجیک‌اسپور¦Bilecikspor
اسنیورت¦Esenyurt
مرزیفون‌اسپور¦Merzifonspor
کرکلارئلی‌اسپور¦Kirklarelispor
بوکا جونیورز¦Boca Juniors
ریور پلاته¦River Plate
ایندیپندینته¦Independiente
راسیینگ کلاب¦Racing Club
سن لورنزو¦San Lorenzo
استودیانتس¦Estudiantes
لانوس¦Lanus
ولز سارسفیلد¦Velez Sarsfield
روساریو سنترال¦Rosario Central
نیوولز اولد بویز¦Newells Old Boys
تالرز¦Talleres
آرژنتینوس جونیورز¦Argentinos Juniors
دفاع و خوستیسیا¦Defensa y Justicia
بلگرانو¦Belgrano
هوراکان¦Huracan
پلاتنسه¦Platense
خیمناسیا لا پلاتا¦Gimnasia La Plata
تیگره¦Tigre
بانفیلد¦Banfield
اونیون سانتا فه¦Union Santa Fe
ایندیپندینته ریوادابیا¦Independiente Rivadavia
اتلتیکو توکومان¦Atletico Tucuman
اینستیتوتو¦Instituto
سنترال کوردوبا¦Central Cordoba
باراکاس سنترال¦Barracas Central
سارمینتو¦Sarmiento
آلدوسیوی¦Aldosivi
دپورتیوو ریسترا¦Deportivo Riestra
خیمناسیا مندوزا¦Gimnasia Mendoza
استودیانتس ریو کوارتو¦Estudiantes Rio Cuarto
کولون¦Colon
گودوی کروز¦Godoy Cruz
پاترونه¦Patronato
کویلمس¦Quilmes
فرروکاریل اوئسته¦Ferro Carril Oeste
چاکاریتا جونیورز¦Chacarita Juniors
سان مارتین توکومان¦San Martin Tucuman
گیلرمو براون¦Guillermo Brown
آتلانتا¦Atlanta
نوئوا شیکاگو¦Nueva Chicago
بنفیکا¦Benfica
پورتو¦Porto
اسپورتینگ لیسبون¦Sporting CP
براگا¦Braga
ویتوریا گیمارش¦Vitoria Guimaraes
فامالیکائو¦Famalicao
ژیل ویسنته¦Gil Vicente
اشتوریل¦Estoril
موریرنزه¦Moreirense
ریو آوه¦Rio Ave
سانتا کلارا¦Santa Clara
کاسا پیا¦Casa Pia
آروکا¦Arouca
ناسیونال¦Nacional
استرلا آمادورا¦Estrela Amadora
آلورکا¦Alverca
ماریتیمو¦Maritimo
آکادمیکو ویزئو¦Academico Viseu
بوآویشتا¦Boavista
فارنسه¦Farense
آکادمیکا کویمبرا¦Academica Coimbra
پنافیل¦Penafiel
لایشوئش¦Leixoes
فیرنزه¦Feirense
اولیوییرنزه¦Oliveirense
مافرا¦Mafra
وارزیم¦Varzim
توندلا¦Tondela
پاکوش فریرا¦Pacos de Ferreira
چاوز¦Chaves
لوزیتانیا¦Lusitania
ویلافرانکنزه¦Vilafranquense
تورینسه¦Torreense
ویتوریا ستوبال¦Vitoria Setubal
بنفیکا بی¦Benfica B
پورتو بی¦Porto B
اسپورتینگ بی¦Sporting B
ویزلا¦Vizela
اوینیون لیریا¦Uniao Leiria
سالگیروش¦Salgueiros
آژاکس¦Ajax
پی‌اس‌وی آیندهوون¦PSV Eindhoven
فاینورد¦Feyenoord
آلکمار¦AZ Alkmaar
توئنته¦Twente
اوترخت¦Utrecht
گو اهد ایگلز¦Go Ahead Eagles
اسپارتا روتردام¦Sparta Rotterdam
هیرنفین¦Heerenveen
نایمخن¦NEC Nijmegen
فورتونا سیتارد¦Fortuna Sittard
زووله¦PEC Zwolle
ویلم دوم¦Willem II
گرونینگن¦Groningen
اکسلسیور¦Excelsior
کامبور¦Cambuur
دن هاخ¦ADO Den Haag
تلستار¦Telstar
هراکلز¦Heracles
بردا¦NAC Breda
رودا جی‌سی¦Roda JC
ام‌وی‌وی ماستریخت¦MVV Maastricht
دی گرافشاپ¦De Graafschap
ویتس آرنهم¦Vitesse
دوردراخت¦FC Dordrecht
اف‌سی آیندهوون¦FC Eindhoven
هلموند اسپورت¦Helmond Sport
دن بوش¦FC Den Bosch
آلمره سیتی¦Almere City
والویک¦Waalwijk
ونلو¦VVV-Venlo
اوس¦TOP Oss
یانگ آژاکس¦Jong Ajax
یانگ پی‌اس‌وی¦Jong PSV
یانگ اوترخت¦Jong Utrecht
یانگ آلکمار¦Jong AZ
اف‌سی امن¦FC Emmen
کاتویک¦Katwijk
وولندام¦FC Volendam
اسپاکنبرگ¦Spakenburg
پرسپولیس¦Persepolis
استقلال¦Esteghlal
سپاهان¦Sepahan
تراکتور¦Tractor
فولاد¦Foolad
گل‌گهر¦Gol Gohar
ملوان¦Malavan
ذوب‌آهن¦Zob Ahan
آلومینیوم اراک¦Aluminium Arak
شمس‌آذر¦Shams Azar
خیبر خرم‌آباد¦Khaybar Khorramabad
چادرملو¦Chadormalou
مس رفسنجان¦Mes Rafsanjan
نساجی¦Nassaji
پیکان¦Paykan
صنعت نفت آبادان¦Sanat Naft Abadan
سایپا¦Saipa
فجر سپاسی¦Fajr Sepasi
استقلال خوزستان¦Esteghlal Khuzestan
مس شهربابک¦Mes Shahr-e Babak
هوادار¦Havadar
نفت مسجدسلیمان¦Naft Masjed Soleyman
پارس جنوبی جم¦Pars Jonoubi Jam
مس کرمان¦Mes Kerman
نفت و گاز گچساران¦Naft va Gaz Gachsaran
آریو اسلامشهر¦Aria Eslamshahr
بعثت کرمانشاه¦Besat Kermanshah
جزیره قشم¦Jazireh Qeshm
شاهین بندر عامری¦Shahin Bandar Ameri
فرد البرز¦Fard Alborz
فولاد نوین خوزستان¦Foolad Novin Khuzestan
نیروی زمینی¦Niroye Zamini
پالایش نفت بندرعباس¦Palayesh Naft Bandar Abbas
کاراگستر شبستر¦Karagostar Shabestar
سپیدرود رشت¦Sepidrood Rasht
داماش گیلان¦Damash Gilan
چوکا تالش¦Choka Talesh
نفت اهواز¦Naft Ahvaz
ایرانجوان بوشهر¦Iranjavan Bushehr
شهرداری بندرعباس¦Shahrdari Bandar Abbas
ذوب‌آهن ب¦Zob Ahan B
استقلال ب¦Esteghlal B
سپاهان ب¦Sepahan B
فولاد هرمزگان¦Foolad Hormozgan
شهرداری نوشهر¦Shahrdari Nowshahr
برق شیراز¦Bargh Shiraz
دنا یاسوج¦Dena Yasuj
رخش خودرو تبریز¦Rakhsh Khodro Tabriz
شاهین تهران¦Shahin Tehran
شهرداری ماهشهر¦Shahrdari Mahshahr
فجر قزوین¦Fajr Qazvin
نفت و گاز غرب ایلام¦Naft va Gaz Gharb Ilam
نود ارومیه¦Nood Urmia
پادیاب خلخال¦Padyab Khalkhal
پرواز سیمرغ¦Parvaz Simorgh
آسمان گلستان¦Asman Golestan
رضوانی اصفهان¦Rezvani Isfahan
شایان دیزل فارس¦Shayan Diesel Fars
شهرآرکا البرز¦Shahr Arka Alborz
شهید قندی یزد¦Shahid Ghandi Yazd
ملوان بوشهر¦Malavan Bushehr
کشاورز رباط‌کریم¦Keshavarz Robat Karim
مس سونگون¦Mes Sungun
استقلال ملاثانی¦Esteghlal Molasani
ماشین‌سازی تبریز¦Machine Sazi Tabriz
گیتی‌پسند اصفهان¦Gity Pasand Isfahan
شهرداری آستارا¦Shahrdari Astara
شهرداری ساوه¦Shahrdari Saveh
شهرداری فومن¦Shahrdari Fuman
قشقایی شیراز¦Qashqai Shiraz
ابومسلم خراسان¦Abu Muslim Khorasan
پتروکیان شوشتر¦Petrokian Shushtar
الوند همدان¦Alvand Hamedan
شهرداری ارومیه¦Shahrdari Urmia
شهرداری اراک¦Shahrdari Arak
شهرداری یاسوج¦Shahrdari Yasuj
کاسپین قزوین¦Caspian Qazvin
اکسین البرز¦Oxin Alborz
پارسه تهران¦Parseh Tehran
نفت تهران¦Naft Tehran"""
