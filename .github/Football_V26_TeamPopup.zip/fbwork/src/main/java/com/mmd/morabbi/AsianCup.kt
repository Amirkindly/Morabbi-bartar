package com.mmd.morabbi

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

val ASIAN_GUEST_FIRST = mapOf(
    "امارات" to listOf("Ali", "Khalid", "Omar", "Abdullah", "Yahya", "Caio", "Yuri", "Igor"),
    "عراق" to listOf("Ali", "Aymen", "Amjad", "Ahmed", "Hussein", "Mustafa", "Mohanad", "Osama"),
    "ازبکستان" to listOf("Jaloliddin", "Eldor", "Otabek", "Odil", "Abbos", "Sherzod", "Azizbek", "Doston"),
    "چین" to listOf("Wu", "Zhang", "Wang", "Liu", "Xu", "Chen", "Li", "Gao"),
    "تایلند" to listOf("Supachai", "Theerathon", "Chanathip", "Suphanat", "Peeradon", "Sarach", "Teerasil", "Ekanit"),
    "استرالیا" to listOf("Mathew", "Jamie", "Andrew", "Aziz", "Marco", "Nathan", "Curtis", "Terry"),
    "مالزی" to listOf("Arif", "Safawi", "Bergson", "Natxo", "Afiq", "Syahmi", "Faisal", "Dion"),
    "ویتنام" to listOf("Nguyen", "Quang", "Ho", "Do", "Bui", "Pham", "Le", "Tran")
)
val ASIAN_GUEST_LAST = mapOf(
    "امارات" to listOf("Eisa", "Al Ahbabi", "Al Ghassani", "Al Hammadi", "Al Meqbali", "Cesar", "Jesus", "Planic"),
    "عراق" to listOf("Hussein", "Jasim", "Rasheed", "Atwan", "Ali", "Yasin", "Hassan", "Mohammed"),
    "ازبکستان" to listOf("Masharipov", "Shukurov", "Khamrobekov", "Nasrullaev", "Urinboev", "Turgunboev", "Akhmedov", "Ceran"),
    "چین" to listOf("Lei", "Xi", "Hanchao", "Vargas", "Oscar", "Gustavo", "Cheng", "Shen"),
    "تایلند" to listOf("Jaided", "Bunmathan", "Chanthip", "Mueanta", "Bureerat", "Promsrikaew", "Dangda", "Sukjitthammakul"),
    "استرالیا" to listOf("Leckie", "Maclaren", "Nabbout", "Behich", "Good", "Atkinson", "Metcalfe", "Caputo"),
    "مالزی" to listOf("Aiman", "Rashid", "Daud", "Amat", "Insa", "Safiq", "Azam", "Fazly"),
    "ویتنام" to listOf("Quang Hai", "Van Hau", "Van Toan", "Dinh Bac", "Van Lam", "Hong Duy", "Tuan Anh", "Tien Linh")
)

private data class AsianGuestStar(val name: String, val pos: String, val rating: Int, val age: Int, val nationality: String)
private val ASIAN_GUEST_STARS = mapOf(
    "Al Ain" to listOf(AsianGuestStar("Khalid Eisa", "GK", 75, 37, "امارات"), AsianGuestStar("Bandar Al Ahbabi", "DF", 72, 36, "امارات"), AsianGuestStar("Soufiane Rahimi", "FW", 81, 30, "مراکش")),
    "Shabab Al Ahli" to listOf(AsianGuestStar("Yuri Cesar", "FW", 76, 26, "برزیل"), AsianGuestStar("Igor Jesus", "FW", 75, 25, "برزیل"), AsianGuestStar("Bogdan Planic", "DF", 74, 34, "صربستان")),
    "Sharjah FC" to listOf(AsianGuestStar("Adel Al Hosani", "GK", 72, 37, "امارات"), AsianGuestStar("Caio Lucas", "FW", 76, 32, "برزیل"), AsianGuestStar("Ousmane Camara", "DF", 73, 27, "مالی")),
    "Al-Shorta" to listOf(AsianGuestStar("Aymen Hussein", "FW", 75, 30, "عراق"), AsianGuestStar("Ahmed Farhan", "MF", 70, 28, "عراق"), AsianGuestStar("Amjad Attwan", "MF", 72, 29, "عراق")),
    "Pakhtakor" to listOf(AsianGuestStar("Jaloliddin Masharipov", "MF", 76, 33, "ازبکستان"), AsianGuestStar("Otabek Shukurov", "MF", 74, 30, "ازبکستان"), AsianGuestStar("Dragan Ceran", "FW", 73, 39, "صربستان")),
    "Shanghai Port" to listOf(AsianGuestStar("Wu Lei", "FW", 79, 34, "چین"), AsianGuestStar("Yan Junling", "GK", 75, 35, "چین"), AsianGuestStar("Matias Vargas", "MF", 77, 29, "آرژانتین")),
    "Shanghai Shenhua" to listOf(AsianGuestStar("Wu Xi", "MF", 73, 37, "چین"), AsianGuestStar("Andre Luis", "FW", 75, 32, "برزیل"), AsianGuestStar("Bao Yaxiong", "GK", 72, 28, "چین")),
    "Chengdu Rongcheng" to listOf(AsianGuestStar("Romulo", "MF", 75, 30, "برزیل"), AsianGuestStar("Felipe Silva", "FW", 75, 34, "برزیل"), AsianGuestStar("Tim Chow", "MF", 71, 32, "چین")),
    "Buriram United" to listOf(AsianGuestStar("Theerathon Bunmathan", "DF", 76, 36, "تایلند"), AsianGuestStar("Supachai Jaided", "FW", 75, 27, "تایلند"), AsianGuestStar("Suphanat Mueanta", "FW", 74, 24, "تایلند")),
    "Melbourne City" to listOf(AsianGuestStar("Mathew Leckie", "FW", 76, 35, "استرالیا"), AsianGuestStar("Jamie Maclaren", "FW", 75, 33, "استرالیا"), AsianGuestStar("Aziz Behich", "DF", 73, 35, "استرالیا")),
    "Johor Darul Ta'zim" to listOf(AsianGuestStar("Arif Aiman", "FW", 77, 24, "مالزی"), AsianGuestStar("Bergson", "FW", 78, 35, "برزیل"), AsianGuestStar("Jordi Amat", "DF", 74, 34, "اسپانیا")),
    "Hanoi Police FC" to listOf(AsianGuestStar("Nguyen Quang Hai", "MF", 75, 29, "ویتنام"), AsianGuestStar("Nguyen Filip", "GK", 74, 34, "ویتنام"), AsianGuestStar("Bui Hoang Viet Anh", "DF", 72, 27, "ویتنام"))
)

private val ASIAN_GUESTS = listOf(
    Triple("Al Ain", "امارات", 77), Triple("Shabab Al Ahli", "امارات", 76),
    Triple("Al Wasl", "امارات", 71), Triple("Pakhtakor", "ازبکستان", 71),
    Triple("Neftchi Fergana", "ازبکستان", 69), Triple("Al Quwa Al Jawiya", "عراق", 69),
    Triple("Buriram United", "تایلند", 72), Triple("Shanghai Port", "چین", 76),
    Triple("Beijing Guoan", "چین", 73), Triple("Newcastle Jets", "استرالیا", 66),
    Triple("Johor Darul Ta'zim", "مالزی", 73), Triple("Cong An Ha Noi FC", "ویتنام", 67)
)


// فهرست بازیکنان واقعی باشگاه‌های مهمان (تقریبی؛ ردیف: پست|نام|اورال|سن|ملیت)
private val ASIAN_GUEST_SQUADS: Map<String, String> = mapOf(
    "Al Ain" to "GK|Khalid Eisa|75|37|امارات;DF|Bandar Al Ahbabi|72|36|امارات;MF|Matias Palacios|74|28|آرژانتین;MF|Kaku|75|30|پاراگوئه;FW|Soufiane Rahimi|81|30|مراکش;FW|Kodjo Laba|77|31|توگو;FW|Caio Canedo|76|35|برزیل",
    "Shabab Al Ahli" to "FW|Yuri Cesar|76|26|برزیل;FW|Igor Jesus|75|25|برزیل;DF|Bogdan Planic|74|34|صربستان;MF|Mohammed Jaber|72|27|امارات;GK|Majed Naser|71|35|امارات",
    "Al Wasl" to "FW|Fabio Lima|77|32|برزیل;MF|Yahya Al Ghassani|74|27|امارات;DF|Mohammed Al Attas|71|28|امارات",
    "Pakhtakor" to "MF|Jaloliddin Masharipov|76|33|ازبکستان;MF|Otabek Shukurov|74|30|ازبکستان;FW|Dragan Ceran|73|39|صربستان;MF|Odil Ahmedov|71|37|ازبکستان;GK|Eldorbek Suyunov|71|32|ازبکستان",
    "Neftchi Fergana" to "",
    "Al Quwa Al Jawiya" to "FW|Aymen Hussein|75|30|عراق;MF|Ahmed Farhan|70|28|عراق;MF|Amjad Attwan|72|29|عراق;GK|Jalal Hassan|70|34|عراق",
    "Buriram United" to "DF|Theerathon Bunmathan|76|36|تایلند;FW|Supachai Jaided|75|27|تایلند;FW|Suphanat Mueanta|74|24|تایلند;MF|Peeradol Chamratsamee|71|30|تایلند;GK|Neil Etheridge|72|36|فیلیپین",
    "Shanghai Port" to "FW|Wu Lei|79|34|چین;GK|Yan Junling|75|35|چین;MF|Matias Vargas|77|29|آرژانتین;MF|Oscar|76|34|برزیل;DF|Fu Huan|73|32|چین;DF|Wang Shenchao|72|36|چین;DF|Li Ang|73|31|چین",
    "Beijing Guoan" to "FW|Fabio Abreu|74|32|آنگولا;FW|Zhang Yuning|73|29|چین;MF|Serginho|74|30|برزیل;MF|Wang Gang|72|35|چین;GK|Han Jiaqi|71|27|چین;FW|Yu Dabao|72|36|چین;DF|Li Lei|72|31|چین",
    "Newcastle Jets" to "MF|Lachlan Brook|68|27|استرالیا;FW|Trent Buhagiar|68|27|استرالیا",
    "Johor Darul Ta'zim" to "FW|Arif Aiman|77|24|مالزی;FW|Bergson|78|35|برزیل;DF|Jordi Amat|74|34|اسپانیا;MF|Natxo Insa|73|38|اسپانیا;MF|Safawi Rasid|72|28|مالزی;GK|Syihan Hazmi|70|27|مالزی",
    "Cong An Ha Noi FC" to "MF|Nguyen Quang Hai|75|29|ویتنام;GK|Nguyen Filip|74|34|ویتنام;DF|Bui Hoang Viet Anh|72|27|ویتنام;FW|Pham Tuan Hai|71|27|ویتنام;DF|Do Duy Manh|70|29|ویتنام"
)

// اورال هدف هر باشگاه (میانگین ۱۴ بازیکن برتر)، هم‌تراز با لیگ‌های آسیایی بازی
private val ASIAN_GUEST_TARGET = mapOf(
    "Al Ain" to 77, "Shabab Al Ahli" to 76, "Al Wasl" to 71, "Pakhtakor" to 71, "Neftchi Fergana" to 69,
    "Al Quwa Al Jawiya" to 69, "Buriram United" to 72, "Shanghai Port" to 76, "Beijing Guoan" to 73,
    "Newcastle Jets" to 66, "Johor Darul Ta'zim" to 73, "Cong An Ha Noi FC" to 67
)

private fun buildGuestSquad(t: Team) {
    val country = t.country
    val real = ArrayList<Player>()
    for (row in ASIAN_GUEST_SQUADS[t.name].orEmpty().split(";")) {
        val f = row.split("|"); if (f.size < 5) continue
        val r = f[2].toInt(); val age = f[3].toInt()
        real.add(Player(G.nid(), f[1], f[0], r, age, t.id, worth(r, age), country = f[4]))
    }
    val target = ASIAN_GUEST_TARGET[t.name] ?: 70
    val need = IntArray(4)
    val plan = listOf("GK" to 3, "DF" to 8, "MF" to 7, "FW" to 4)
    val fill = ArrayList<Player>()
    for ((pos, n) in plan) repeat((n - real.count { it.pos == pos }).coerceAtLeast(0)) { fill.add(genPlayer(t.id, country, pos, target - 3)) }
    G.players.addAll(real); G.players.addAll(fill)
    // اورال بازیکنان تولیدی طوری تنظیم می‌شود که اورال تیم به هدف برسد (بازیکنان واقعی دست‌نخورده)
    repeat(4) {
        val sq = G.players.filter { it.teamId == t.id }
        val cur = sq.map { it.rating }.sortedDescending().take(14).average()
        val d = (target - cur).let { if (it > 0) Math.ceil(it).toInt() else Math.floor(it).toInt() }
        if (d != 0) fill.forEach { it.rating = (it.rating + d).coerceIn(48, 90) }
    }
}

// تیم‌های مهمان در لیگ داخلی ثبت نمی‌شوند؛ فقط در مسابقات قاره‌ای شرکت می‌کنند.
fun ensureAsianGuestTeams() {
    var changed = false
    // باشگاه‌های مهمان قدیمی (قبل از V19) بیرون از فصلِ در جریان جایگزین می‌شوند
    if (!(G.asianSeason == G.season && G.asianActive)) {
        val valid = ASIAN_GUESTS.map { it.first }.toSet()
        val obsolete = G.teams.filter { it.leagueId == -777 && it.name !in valid }.map { it.id }.toSet()
        if (obsolete.isNotEmpty()) {
            G.players.removeAll { it.teamId in obsolete }
            G.academy.removeAll { it.teamId in obsolete }
            G.teams.removeAll { it.id in obsolete }
            changed = true
        }
    }
    for ((name, country, _) in ASIAN_GUESTS) {
        val existing = G.teams.firstOrNull { it.leagueId == -777 && it.name == name }
        if (existing != null) {
            existing.logo = clubLogoPath(country, name)
            val firstReal = ASIAN_GUEST_SQUADS[name].orEmpty().split(";").firstOrNull()?.split("|")?.getOrNull(1)
            // سیو قدیمی: اگر فهرست واقعی هنوز نیامده، یک‌بار بازسازی می‌شود
            if (!firstReal.isNullOrBlank() && G.players.none { it.teamId == existing.id && it.name == firstReal }) {
                G.players.removeAll { it.teamId == existing.id }
                buildGuestSquad(existing); changed = true
            }
            continue
        }
        val t = Team(G.nid(), name, country, -777, PAL.random(), PAL.random(), Random.nextInt(4), clubLogoPath(country, name), 25_000_000L)
        G.teams.add(t); changed = true
        buildGuestSquad(t)
        repeat(5) { G.academy.add(genAcademyPlayer(t)) }
    }
    if (changed) G.touch()
}

private fun asianKey(a: Int, b: Int) = if (a < b) "$a-$b" else "$b-$a"
private fun asianStoreResult(h: Team, a: Team, hg: Int, ag: Int, stage: String, week: Int, winner: Team? = null) {
    val goals = if (h.id < a.id) "$hg,$ag" else "$ag,$hg"
    G.asianResults[asianKey(h.id, a.id)] = if (winner == null) goals else "$goals,${winner.id}"
    G.asianLog.add("$stage: ${h.name} $hg-$ag ${a.name}")
    logMatchW("جام قهرمانان آسیا • $stage", week, h, a, hg, ag)
}

private fun asianScore(a: Int, b: Int): Pair<Int, Int>? {
    val raw = G.asianResults[asianKey(a, b)] ?: return null
    val s = raw.split(",").mapNotNull { it.toIntOrNull() }
    if (s.size != 2) return null
    return if (a < b) s[0] to s[1] else s[1] to s[0]
}

private fun asianGroupFixtures(group: List<Int>): List<List<Pair<Int, Int>>> {
    if (group.size != 4) return emptyList()
    return listOf(
        listOf(group[0] to group[3], group[1] to group[2]),
        listOf(group[0] to group[2], group[3] to group[1]),
        listOf(group[0] to group[1], group[2] to group[3])
    )
}

private data class AsianStanding(val id: Int, val pts: Int, val gd: Int, val gf: Int)
private fun asianGroupTable(group: List<Int>): List<AsianStanding> {
    val rows = group.associateWith { intArrayOf(0, 0, 0, 0) }.toMutableMap() // Pts, GD, GF, played
    for (round in 0..2) for ((h, a) in asianGroupFixtures(group)[round]) {
        val score = asianScore(h, a) ?: continue
        val hs = rows[h]!!; val as_ = rows[a]!!
        hs[3]++; as_[3]++; hs[2] += score.first; as_[2] += score.second
        hs[1] += score.first - score.second; as_[1] += score.second - score.first
        if (score.first > score.second) hs[0] += 3 else if (score.first < score.second) as_[0] += 3 else { hs[0]++; as_[0]++ }
    }
    return rows.map { (id, v) -> AsianStanding(id, v[0], v[1], v[2]) }
        .sortedWith(compareByDescending<AsianStanding> { it.pts }.thenByDescending { it.gd }.thenByDescending { it.gf }.thenByDescending { G.teamOrNull(it.id)?.let(::strengthOf) ?: 0 })
}

private fun buildAsianR16(): ArrayList<Pair<Int, Int>> {
    val winners = G.asianGroups.map { asianGroupTable(it).firstOrNull()?.id ?: -1 }
    val runners = G.asianGroups.map { asianGroupTable(it).getOrNull(1)?.id ?: -1 }
    val out = ArrayList<Pair<Int, Int>>()
    for (i in 0 until 8) out.add(winners[i] to runners[(i + 1) % 8])
    return out
}

fun prepareAsianCupSeason() {
    ensureAsianGuestTeams()
    if (G.asianSeason == G.season && G.asianActive) return
    val qualified = ArrayList<Int>()
    val asianCountries = listOf("ایران", "عربستان", "ژاپن", "قطر", "کره جنوبی")
    for (country in asianCountries) {
        val top = G.leagues.filter { it.country == country }.minByOrNull { it.level } ?: continue
        val previous = G.seasonSums.filter { it.season == G.season - 1 && it.league == top.name }
            .sortedBy { it.rank }.map { it.tid }.filter { G.teamOrNull(it) != null }
        val ranking = if (previous.size >= 4) previous else table(top.id)
            .sortedWith(compareByDescending<Team> { strengthOf(it) }.thenBy { it.name }).map { it.id }
        val topThree = ranking.take(3)
        qualified.addAll(topThree)
        val cupLine = G.history.lastOrNull { it.startsWith("فصل ${G.season - 1} - ${domesticCupName(country)}:") }
        val cupWinnerName = cupLine?.substringAfter("قهرمان ")?.trim()
        val cupWinner = G.teams.firstOrNull { it.name == cupWinnerName && it.country == country }?.id
        val fourthSlot = cupWinner?.takeIf { it !in topThree } ?: ranking.drop(3).firstOrNull()
        if (fourthSlot != null) qualified.add(fourthSlot)
    }
    qualified.addAll(G.teams.filter { it.leagueId == -777 }.map { it.id })
    val entrants = qualified.distinct().take(32)
    if (entrants.size < 32) return
    val ranked = entrants.sortedByDescending { G.teamOrNull(it)?.let(::strengthOf) ?: 0 }.toMutableList()
    val groups = ArrayList<ArrayList<Int>>()
    repeat(8) { groups.add(ArrayList()) }
    // توزیع مارپیچی برای متعادل‌کردن قدرت گروه‌ها
    for ((idx, id) in ranked.withIndex()) {
        val band = idx / 8
        val slot = idx % 8
        val gi = if (band % 2 == 0) slot else 7 - slot
        groups[gi].add(id)
    }
    G.asianSeason = G.season
    G.asianEntrants = entrants.toCollection(ArrayList())
    G.asianGroups = groups
    G.asianSchedule.clear()
    repeat(3) { r -> G.asianSchedule.add(groups.flatMap { asianGroupFixtures(it)[r] }.toCollection(ArrayList())) }
    G.asianResults.clear(); G.asianLog.clear()
    G.asianRound = 0; G.asianActive = true; G.asianChampion = -1
    G.asianLog.add("فصل ${G.season}: ۳۲ تیم در ۸ گروه ۴ تیمی؛ دو تیم برتر هر گروه به یک‌هشتم نهایی صعود می‌کنند.")
    G.touch()
}

private fun asianRoundName(round: Int): String = when (round) {
    0, 1, 2 -> "مرحله گروهی • هفته ${round + 1}"
    3 -> "یک‌هشتم نهایی"
    4 -> "یک‌چهارم نهایی"
    5 -> "نیمه‌نهایی"
    6 -> "فینال"
    else -> "پایان مسابقات"
}

private fun asianRoundComplete(round: Int): Boolean {
    val games = G.asianSchedule.getOrNull(round) ?: return true
    return games.all { G.asianResults.containsKey(asianKey(it.first, it.second)) }
}

private fun playAsianGroupRound(round: Int, live: Boolean, week1: Int) {
    val games = G.asianSchedule.getOrNull(round) ?: return
    var userMatch: MatchRes? = null
    for (pair in games) {
        val h = G.teamOrNull(pair.first) ?: continue
        val a = G.teamOrNull(pair.second) ?: continue
        val isUser = h.id == G.userTeam || a.id == G.userTeam
        if (isUser && live) {
            val m = playMatch(h, a, live = true, deferTableUpdate = true)
            m.tag = "جام قهرمانان آسیا • ${asianRoundName(round)}"
            userMatch = m
        } else {
            val m = playMatch(h, a, live = false, deferTableUpdate = true)
            asianStoreResult(h, a, m.hg, m.ag, asianRoundName(round), week1)
            if (isUser) addUserMatchReport("جام قهرمانان آسیا", m)
        }
    }
    val m = userMatch ?: run { if (asianRoundComplete(round)) advanceAsianRound(round); return }
    m.onFinal = { fm ->
        asianStoreResult(fm.h, fm.a, fm.hg, fm.ag, asianRoundName(round), week1)
        addUserMatchReport("جام قهرمانان آسیا", fm)
        if (asianRoundComplete(round)) advanceAsianRound(round)
        G.touch()
    }
    G.liveQueue.add(m)
}

private fun advanceAsianRound(round: Int) {
    if (G.asianRound != round) return
    when (round) {
        0, 1 -> G.asianRound = round + 1
        2 -> { G.asianRound = 3; G.asianSchedule.add(buildAsianR16()) }
        3, 4, 5 -> {
            val winners = G.asianSchedule[round].mapNotNull { (h, a) ->
                val raw = G.asianResults[asianKey(h, a)] ?: return@mapNotNull null
                val winnerId = raw.split(",").getOrNull(2)?.toIntOrNull()
                if (winnerId != null) winnerId else {
                    val score = asianScore(h, a) ?: return@mapNotNull null
                    if (score.first > score.second) h else if (score.second > score.first) a else -1
                }
            }.filter { it >= 0 }
            G.asianRound = round + 1
            val shuffled = winners.toMutableList()
            val ties = ArrayList<Pair<Int, Int>>()
            while (shuffled.size >= 2) ties.add(shuffled.removeAt(0) to shuffled.removeAt(0))
            G.asianSchedule.add(ties)
        }
        6 -> {
            val final = G.asianSchedule.getOrNull(6)?.firstOrNull()
            if (final != null) {
                val raw = G.asianResults[asianKey(final.first, final.second)]
                val winnerId = raw?.split(",")?.getOrNull(2)?.toIntOrNull() ?: run {
                    val score = asianScore(final.first, final.second)
                    if (score != null && score.first > score.second) final.first else final.second
                }
                G.asianChampion = winnerId
                Honors.add(winnerId, Honors.ASIA)
                (if (final.first == winnerId) final.second else final.first).let { Honors.add(it, Honors.ASIA2) }
            }
            G.asianActive = false; G.asianRound = 7
            val champ = G.teamOrNull(G.asianChampion)
            if (champ != null) {
                val line = "فصل ${G.season} - جام قهرمانان آسیا: قهرمان ${champ.name}"
                G.history.add(line); G.report.add("🏆 $line"); G.asianLog.add("🏆 قهرمان آسیا: ${champ.name}")
            }
        }
    }
    G.touch()
}

private fun playAsianKnockout(round: Int, live: Boolean, week1: Int) {
    val games = G.asianSchedule.getOrNull(round) ?: return
    val ties = games.mapNotNull { (h, a) ->
        val ht = G.teamOrNull(h); val at = G.teamOrNull(a)
        if (ht != null && at != null) ht to at else null
    }
    if (ties.isEmpty()) return
    runKnockoutTies(ties, "جام قهرمانان آسیا • ${asianRoundName(round)}", live,
        onTie = { h, a, m, winner -> asianStoreResult(h, a, m.hg, m.ag, asianRoundName(round), week1, winner) },
        onDone = { advanceAsianRound(round) })
}

fun playScheduledAsianCupWeek(live: Boolean = false, force: Boolean = false) {
    if (G.userTeam < 0) return
    if (G.asianSeason != G.season || (!G.asianActive && G.asianRound == 0)) prepareAsianCupSeason()
    if (!G.asianActive) return
    val r = G.asianRound
    if (r !in 0..6 || (!force && G.week < Cal.asianWeek(r))) return
    if (r <= 2) playAsianGroupRound(r, live, G.week + 1) else playAsianKnockout(r, live, G.week + 1)
    G.touch()
}

fun finishAsianCupQuickly() {
    var guard = 0
    while (G.userTeam >= 0 && G.asianActive && G.asianSeason == G.season && guard < 8) {
        playScheduledAsianCupWeek(false, true); guard++
    }
}

fun asianCupPlanLine(wk: Int): String? {
    if (!G.asianActive || G.asianSeason != G.season || G.userTeam !in G.asianEntrants) return null
    val r = G.asianRound
    if (r !in 0..6 || wk < Cal.asianWeek(r)) return null
    val game = G.asianSchedule.getOrNull(r)?.firstOrNull { it.first == G.userTeam || it.second == G.userTeam }
    if (game == null) return "🏆 جام قهرمانان آسیا • ${asianRoundName(r)}: این هفته استراحت دارید"
    val opponent = G.teamOrNull(if (game.first == G.userTeam) game.second else game.first)
    return "🏆 جام قهرمانان آسیا • ${asianRoundName(r)} مقابل ${opponent?.name ?: "؟"}"
}

@Composable
fun AsianCupScreen() {
    val rv = G.rev
    var tab by remember { mutableStateOf("گروه‌ها") }
    if (G.asianSeason != G.season || (!G.asianActive && G.asianRound == 0)) prepareAsianCupSeason()
    val stage = asianRoundName(G.asianRound)
    Page("جام قهرمانان آسیا") {
        Panel {
            Text("🏆 جام قهرمانان آسیا • فصل ${G.asianSeason}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("۳۲ تیم • ۸ گروه ۴ تیمی • صعود دو تیم برتر هر گروه • سپس یک‌هشتم، یک‌چهارم، نیمه‌نهایی و فینال")
            Text("تقویم مستقل: هفته‌های ${ (0..6).joinToString("، ") { "${Cal.show(Cal.asianWeek(it))}" } }")
            Text(if (G.asianActive) "مرحله فعلی: $stage" else "🏆 قهرمان: ${G.teamOrNull(G.asianChampion)?.name ?: "هنوز مشخص نشده"}")
        }
        Chips(listOf("گروه‌ها", "حذفی و نتایج"), tab) { tab = it }
        if (tab == "گروه‌ها") {
            for ((index, group) in G.asianGroups.withIndex()) Panel {
                Text("گروه ${'A' + index}", fontWeight = FontWeight.Bold)
                val table = asianGroupTable(group)
                for ((rank, row) in table.withIndex()) {
                    val team = G.teamOrNull(row.id) ?: continue
                    Row(Modifier.fillMaxWidth().clickable { G.openTeam(team.id) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${rank + 1}.", Modifier.width(24.dp), fontWeight = FontWeight.Bold)
                        Logo(team, 25.dp); Spacer(Modifier.width(7.dp))
                        Column(Modifier.weight(1f)) { Text(team.name, fontWeight = FontWeight.SemiBold); Text(team.country, fontSize = 10.sp) }
                        Text("${row.pts} امتیاز | ${if (row.gd > 0) "+" else ""}${row.gd}", fontSize = 11.sp)
                        if (rank < 2) Text(" صعود", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                    }
                }
            }
        } else {
            Panel {
                Text("نتایج و مراحل", fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    items(G.asianLog.asReversed()) { line -> Text("• $line", fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                }
            }
            if (G.asianRound >= 3) for (r in 3..minOf(6, G.asianSchedule.lastIndex)) Panel {
                Text(asianRoundName(r), fontWeight = FontWeight.Bold)
                for ((h, a) in G.asianSchedule[r]) {
                    val ht = G.teamOrNull(h); val at = G.teamOrNull(a); if (ht == null || at == null) continue
                    val sc = asianScore(h, a)
                    Text("${ht.name}  ${sc?.first?.toString() ?: "-"} : ${sc?.second?.toString() ?: "-"}  ${at.name}", fontSize = 12.sp)
                }
            }
        }
    }
}
