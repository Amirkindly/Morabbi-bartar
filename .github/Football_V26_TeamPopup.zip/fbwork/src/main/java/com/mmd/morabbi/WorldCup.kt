package com.mmd.morabbi

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private fun worldCupMatchKey(a: Int, b: Int): String = if (a < b) "$a-$b" else "$b-$a"

// جفت‌سازی تیم‌ها با ترجیح حریف خارجی و بدون تکرار مسابقه
private fun pairWorldCupTeams(pool: MutableList<Int>, used: HashSet<String>): ArrayList<Pair<Int, Int>> {
    val games = ArrayList<Pair<Int, Int>>()
    while (pool.size >= 2) {
        val home = pool.removeAt(0)
        val homeCountry = G.teamOrNull(home)?.country
        val candidates = pool.indices.filter { i ->
            G.teamOrNull(pool[i])?.country != homeCountry && !used.contains(worldCupMatchKey(home, pool[i]))
        }
        val chosen = candidates.randomOrNull() ?: pool.indices.firstOrNull { G.teamOrNull(pool[it])?.country != homeCountry } ?: 0
        val away = pool.removeAt(chosen)
        games.add(home to away)
        used.add(worldCupMatchKey(home, away))
    }
    return games
}

// مرحله لیگ: هر تیم دقیقاً ۱۰ بازی دارد. اگر تعداد تیم‌ها زوج باشد ۱۰ هفته کافی است؛
// اگر فرد باشد (مثلاً ۵۵ تیم) برنامه ۱۱ هفته است و هر تیم دقیقاً یک هفته استراحت دارد (بدون بازی جبرانی یا اضافه).
private fun buildWorldCupSchedule(ids: List<Int>): ArrayList<ArrayList<Pair<Int, Int>>> {
    val rounds = ArrayList<ArrayList<Pair<Int, Int>>>()
    val byCountry = ids.mapNotNull { id -> G.teamOrNull(id)?.let { it.country to id } }
        .groupBy({ it.first }, { it.second })
        .mapValues { it.value.sorted() }
    // قالب استاندارد ۵۵ تیمی: ۱۱ کشور، هر کشور ۵ نماینده؛ هر تیم با ۱۰ کشور دیگر
    // دقیقاً یک‌بار بازی می‌کند و در یک هفته استراحت دارد.
    if (byCountry.size == 11 && byCountry.values.all { it.size == 5 }) {
        val countries = byCountry.keys.sorted()
        val wheel = (countries + listOf("__BYE__")).toMutableList()
        repeat(11) { roundIndex ->
            val games = ArrayList<Pair<Int, Int>>()
            for (i in 0 until wheel.size / 2) {
                val c1 = wheel[i]
                val c2 = wheel[wheel.lastIndex - i]
                if (c1 == "__BYE__" || c2 == "__BYE__") continue
                val a = byCountry[c1] ?: emptyList()
                val b = byCountry[c2] ?: emptyList()
                for (slot in 0 until 5) {
                    games.add(a[slot] to b[(slot + roundIndex) % 5])
                }
            }
            rounds.add(games)
            val last = wheel.removeAt(wheel.lastIndex)
            wheel.add(1, last)
        }
        return rounds
    }

    // پشتیبان برای ذخیره‌های سفارشی با تعداد/توزیع متفاوت تیم‌ها.
    val roundCount = if (ids.size % 2 == 0) 10 else 11
    val rests = Array(roundCount) { ArrayList<Int>() }
    if (roundCount == 11) {
        val shuffled = ids.shuffled()
        shuffled.forEachIndexed { index, id -> rests[index % 11].add(id) }
    }
    val used = HashSet<String>()
    repeat(roundCount) { r ->
        val pool = ids.filter { it !in rests[r] }.shuffled().toMutableList()
        val games = ArrayList<Pair<Int, Int>>()
        while (pool.size >= 2) {
            val home = pool.removeAt(0)
            val homeCountry = G.teamOrNull(home)?.country
            val candidates = pool.indices.filter { idx ->
                G.teamOrNull(pool[idx])?.country != homeCountry &&
                    !used.contains(worldCupMatchKey(home, pool[idx]))
            }
            val chosen = candidates.randomOrNull() ?: pool.indices.firstOrNull { idx ->
                !used.contains(worldCupMatchKey(home, pool[idx]))
            } ?: 0
            val away = pool.removeAt(chosen)
            games.add(home to away)
            used.add(worldCupMatchKey(home, away))
        }
        rounds.add(games)
    }
    return rounds
}

fun worldCupQualifiers(seasonForCup: Int = G.season - 1): List<Int> {
    val selected = ArrayList<Int>()
    // سهمیه‌های ویژه آسیا در لیگ قهرمانان جهان: ایران ۲، ژاپن ۲، عربستان ۲، قطر ۱ و کره جنوبی ۱.
    val specialSlots = linkedMapOf("ایران" to 2, "ژاپن" to 2, "عربستان" to 2, "قطر" to 1, "کره جنوبی" to 1)
    for ((country, slots) in specialSlots) {
        val top = G.leagues.filter { it.country == country }.minByOrNull { it.level } ?: continue
        selected.addAll(table(top.id).take(slots).map { it.id })
    }
    // ۴۸ سهمیه باقی‌مانده میان ۱۰ کشور قدیمی خارج از این پنج لیگ آسیایی توزیع می‌شود.
    val otherCountries = COUNTRIES.filter { it !in specialSlots.keys }
    val rankedByCountry = otherCountries.mapNotNull { country ->
        val top = G.leagues.filter { it.country == country }.minByOrNull { it.level } ?: return@mapNotNull null
        country to table(top.id)
    }
    val slots = 48
    for (rank in 0 until 5) {
        for ((_, ranked) in rankedByCountry) if (ranked.size > rank && selected.size < 8 + slots) selected.add(ranked[rank].id)
    }
    // برای لیگ‌های سفارشی/ذخیره‌های قدیمی، تعداد شرکت‌کنندگان تا سقف ۵۶ تکمیل می‌شود.
    if (selected.size < 56) {
        val fallback = G.teams.filter { it.id !in selected && G.leagues.firstOrNull { lg -> lg.id == it.leagueId }?.level == 1 }
            .sortedByDescending { strengthOf(it) }
        selected.addAll(fallback.take(56 - selected.size).map { it.id })
    }
    return selected.distinct().take(56)
}

fun prepareWorldCupSeason() {
    if (G.worldCupSeason == G.season && G.worldCupActive) return
    val entrants = if (G.worldCupSeason == G.season && G.worldCupEntrants.size >= 16) G.worldCupEntrants.toList() else worldCupQualifiers()
    if (entrants.size < 16) return
    G.worldCupSeason = G.season
    G.worldCupEntrants = entrants.toCollection(ArrayList())
    G.worldCupSchedule = buildWorldCupSchedule(entrants)
    G.worldCupResults.clear()
    G.worldCupRound = 0
    G.worldCupActive = true
    G.worldCupChampion = -1
    G.worldCupLog.clear()
    G.worldCupLog.add("فصل ${G.season}: ${entrants.size} تیم در لیگ قهرمانان جهان حضور دارند؛ هر تیم ۱۰ مسابقه با حریفان خارجی دارد؛ هفته بدون بازی، هفته استراحت است.")
    G.touch()
}

private fun worldCupTableIds(): List<Int> {
    val fromSchedule = G.worldCupSchedule.flatMap { r -> r.flatMap { listOf(it.first, it.second) } }.distinct()
    return if (fromSchedule.isNotEmpty()) fromSchedule else G.worldCupEntrants.toList()
}

private fun worldCupTable(): List<Team> {
    val ids = worldCupTableIds()
    val pts = HashMap<Int, Int>()
    val gd = HashMap<Int, Int>()
    val gf = HashMap<Int, Int>()
    for (id in ids) { pts[id] = 0; gd[id] = 0; gf[id] = 0 }
    for ((key, score) in G.worldCupResults) {
        val k = key.split("-").mapNotNull { it.toIntOrNull() }
        val goals = score.split(",").mapNotNull { it.toIntOrNull() }
        if (k.size != 2 || goals.size != 2) continue
        val a = k[0]; val b = k[1]; val x = goals[0]; val y = goals[1]
        gf[a] = (gf[a] ?: 0) + x; gf[b] = (gf[b] ?: 0) + y
        gd[a] = (gd[a] ?: 0) + x - y; gd[b] = (gd[b] ?: 0) + y - x
        if (x > y) pts[a] = (pts[a] ?: 0) + 3 else if (y > x) pts[b] = (pts[b] ?: 0) + 3 else { pts[a] = (pts[a] ?: 0) + 1; pts[b] = (pts[b] ?: 0) + 1 }
    }
    return ids.mapNotNull { G.teamOrNull(it) }.sortedWith(
        compareByDescending<Team> { pts[it.id] ?: 0 }.thenByDescending { gd[it.id] ?: 0 }.thenByDescending { gf[it.id] ?: 0 }.thenByDescending { strengthOf(it) }
    )
}

fun clLeagueRoundsDone(): Int {
    var n = 0
    for (round in G.worldCupSchedule) {
        if (round.all { G.worldCupResults.containsKey(worldCupMatchKey(it.first, it.second)) }) n++ else break
    }
    return n
}

private fun clStageName(ko: Int): String = when (ko) {
    0 -> "پلی‌آف لیگ قهرمانان"
    1 -> "یک‌هشتم نهایی"
    2 -> "یک‌چهارم نهایی"
    3 -> "نیمه‌نهایی"
    else -> "فینال"
}

private fun saveWorldCupResult(home: Team, away: Team, hg: Int, ag: Int, stage: String, week1: Int) {
    G.worldCupResults[worldCupMatchKey(home.id, away.id)] = if (home.id < away.id) "$hg,$ag" else "$ag,$hg"
    logMatchW("لیگ قهرمانان • $stage", week1, home, away, hg, ag)
    G.worldCupLog.add("$stage: ${home.name} $hg-$ag ${away.name}")
}

private fun playWorldCupLeagueRound(roundIndex: Int, live: Boolean, wk1: Int) {
    val stage = "هفته ${roundIndex + 1} لیگ قهرمانان"
    val label = "🌍 لیگ قهرمانان • هفته ${roundIndex + 1}"
    for ((hid, aid) in G.worldCupSchedule[roundIndex]) {
        val home = G.teamOrNull(hid) ?: continue
        val away = G.teamOrNull(aid) ?: continue
        val userMatch = home.id == G.userTeam || away.id == G.userTeam
        if (userMatch && live) {
            // نتیجه موقت ثبت می‌شود و بعد از پایان بازی زنده با نتیجه واقعی جایگزین می‌شود.
            val prov = provisionalScore(home, away)
            saveWorldCupResult(home, away, prov.first, prov.second, stage, wk1)
            val m = playMatch(home, away, live = true, deferTableUpdate = true)
            m.tag = label
            m.onFinal = { fm ->
                G.worldCupResults[worldCupMatchKey(fm.h.id, fm.a.id)] = if (fm.h.id < fm.a.id) "${fm.hg},${fm.ag}" else "${fm.ag},${fm.hg}"
                G.worldCupLog.add("$stage (نتیجه نهایی): ${fm.h.name} ${fm.hg}-${fm.ag} ${fm.a.name}")
            }
            G.report.add("$label: ${home.name}  0 - 0  ${away.name}")
            G.liveQueue.add(m)
        } else {
            val result = playMatch(home, away, live = false, deferTableUpdate = true)
            saveWorldCupResult(home, away, result.hg, result.ag, stage, wk1)
            if (userMatch) addUserMatchReport(label, result)
        }
    }
    G.worldCupLog.add("پایان هفته ${roundIndex + 1} از ${G.worldCupSchedule.size} لیگ قهرمانان جهان")
}

private fun commitWorldCupStage(ko: Int, next: List<Int>) {
    val prevFinalists = G.worldCupEntrants.toList()
    G.worldCupEntrants = next.toCollection(ArrayList())
    if (ko == 0) {
        G.worldCupRound = 2
        G.worldCupLog.add("۸ تیم اول مستقیم صعود کردند؛ ۸ برنده پلی‌آف به آن‌ها پیوستند. مرحله ۱۶ تیمی آغاز شد.")
    } else if (next.size == 1) {
        G.worldCupRound = 6
        G.worldCupActive = false
        G.worldCupChampion = next.first()
        val champion = G.teamOrNull(G.worldCupChampion)
        if (champion != null) {
            champion.titles++
            Honors.add(champion.id, Honors.CL)
            prevFinalists.firstOrNull { it != champion.id }?.let { Honors.add(it, Honors.CL2) }
            val title = "فصل ${G.season} - لیگ قهرمانان جهان: قهرمان ${champion.name}"
            G.history.add(title); G.worldCupLog.add("🏆 $title"); G.report.add("🏆 [لیگ قهرمانان] قهرمان: ${champion.name}")
        }
    } else {
        G.worldCupRound = ko + 2
    }
    G.touch()
}

private fun playWorldCupKnockoutStage(ko: Int, live: Boolean, wk1: Int) {
    val stage = clStageName(ko)
    val label = "🌍 لیگ قهرمانان • $stage"
    val direct: List<Int>
    val ids: List<Int>
    if (ko == 0) {
        val ranked = worldCupTable()
        direct = ranked.take(8).map { it.id }
        ids = ranked.drop(8).take(16).map { it.id }
        if (G.userTeam in direct) G.report.add("$label: تیم شما مستقیم به یک‌هشتم نهایی صعود کرد (این رقابت را استراحت دارید).")
    } else {
        direct = emptyList()
        ids = G.worldCupEntrants.toList()
    }
    val pool = ids.mapNotNull { G.teamOrNull(it) }.shuffled().toMutableList()
    val ties = ArrayList<Pair<Team, Team>>()
    while (pool.size >= 2) {
        val home = pool.removeAt(0)
        val awayIndex = pool.indexOfFirst { it.country != home.country }.let { if (it >= 0) it else 0 }
        val away = pool.removeAt(awayIndex)
        ties.add(Pair(home, away))
    }
    val bye = pool.firstOrNull()
    runKnockoutTies(ties, label, live,
        onTie = { h, a, m, w ->
            logMatchW("لیگ قهرمانان • $stage", wk1, h, a, m.hg, m.ag)
            G.worldCupLog.add("$stage: ${h.name} ${m.hg}-${m.ag}${shootoutSuffix(m)} ${a.name} | صعود: ${w.name}")
        },
        onDone = { winners ->
            val next = ArrayList<Int>()
            next.addAll(direct)
            next.addAll(winners.map { it.id })
            if (bye != null) next.add(bye.id)
            commitWorldCupStage(ko, next)
        })
}

fun playScheduledWorldCupWeek(live: Boolean = false, force: Boolean = false) {
    if (G.userTeam < 0) return
    if (!G.worldCupActive || G.worldCupSeason != G.season) prepareWorldCupSeason()
    if (!G.worldCupActive) return
    val wk1 = G.week + 1
    if (G.worldCupRound == 0) {
        val done = clLeagueRoundsDone()
        if (done < G.worldCupSchedule.size) {
            if (force || G.week >= Cal.clLeagueWeek(done)) {
                playWorldCupLeagueRound(done, live, wk1)
                if (done == G.worldCupSchedule.size - 1) G.worldCupRound = 1
                G.touch()
            }
            return
        }
        G.worldCupRound = 1
    }
    val ko = G.worldCupRound - 1
    if (ko !in 0..4) return
    if (!force && G.week < Cal.clKoWeek(ko)) return
    playWorldCupKnockoutStage(ko, live, wk1)
    G.touch()
}

fun finishWorldCupQuickly() {
    var guard = 0
    while (G.userTeam >= 0 && G.worldCupActive && G.worldCupSeason == G.season && guard < 25) {
        playScheduledWorldCupWeek(false, true)
        guard++
    }
}

fun worldCupPlanLine(wk: Int): String? {
    if (!G.worldCupActive || G.worldCupSeason != G.season) return null
    val u = G.userTeam
    if (G.worldCupSchedule.none { r -> r.any { it.first == u || it.second == u } }) return null
    if (G.worldCupRound == 0) {
        val done = clLeagueRoundsDone()
        if (done >= G.worldCupSchedule.size || wk < Cal.clLeagueWeek(done)) return null
        val g = G.worldCupSchedule[done].firstOrNull { it.first == u || it.second == u }
        return if (g != null) {
            val opp = G.teamOrNull(if (g.first == u) g.second else g.first)
            "🌍 لیگ قهرمانان • هفته ${done + 1}: ${if (g.first == u) "خانه" else "خارج از خانه"} مقابل ${opp?.name ?: "؟"}"
        } else "🌍 لیگ قهرمانان • هفته ${done + 1}: این رقابت را استراحت دارید"
    }
    val ko = G.worldCupRound - 1
    if (ko !in 0..4 || wk < Cal.clKoWeek(ko)) return null
    val stage = clStageName(ko)
    if (ko == 0) {
        val ranked = worldCupTable()
        return when {
            ranked.take(8).any { it.id == u } -> "🌍 $stage: صعود مستقیم کرده‌اید؛ این رقابت را استراحت دارید"
            ranked.drop(8).take(16).any { it.id == u } -> "🌍 $stage (حریف در قرعه‌کشی همین هفته مشخص می‌شود)"
            else -> "🌍 $stage: از لیگ قهرمانان حذف شده‌اید؛ استراحت"
        }
    }
    return if (u in G.worldCupEntrants) "🌍 لیگ قهرمانان • $stage (حریف در قرعه‌کشی همین هفته مشخص می‌شود)"
    else "🌍 لیگ قهرمانان • $stage: حذف شده‌اید؛ این رقابت را استراحت دارید"
}

@Composable
fun WorldCupScreen() {
    val rv = G.rev
    var tab by remember { mutableStateOf("جدول") }
    if (G.worldCupSeason != G.season || !G.worldCupActive && G.worldCupRound == 0) prepareWorldCupSeason()
    val ranking = worldCupTable()
    Page("لیگ قهرمانان جهان") {
        B("🏆 جام قهرمانان آسیا", Modifier.fillMaxWidth()) { G.go("asianCup") }
        Panel {
            Text("🌍 لیگ قهرمانان جهان • فصل ${G.worldCupSeason}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("${worldCupTableIds().size} تیم • هر تیم ۱۰ بازی با تیم‌های کشورهای دیگر • هفته‌های لیگ: ${(0 until 11).joinToString("، ") { "${Cal.show(Cal.clLeagueWeek(it))}" }} • حذفی: ${(0..4).joinToString("، ") { "${Cal.show(Cal.clKoWeek(it))}" }}")
            Text(when (G.worldCupRound) {
                0 -> "مرحله لیگ: ${G.worldCupResults.size} مسابقه از ${G.worldCupSchedule.sumOf { it.size }} مسابقه انجام شده"
                1 -> "پایان مرحله لیگ؛ ۸ تیم اول مستقیم صعود می‌کنند، رتبه‌های ۹ تا ۲۴ پلی‌آف می‌دهند و رتبه‌های ۲۵ به بعد حذف می‌شوند."
                2 -> "یک‌هشتم نهایی (۱۶ تیم)"
                3 -> "یک‌چهارم نهایی"
                4 -> "نیمه‌نهایی"
                5 -> "فینال"
                else -> "قهرمان: ${G.teamOrNull(G.worldCupChampion)?.name ?: "نامشخص"}"
            })
            Text("۵۶ تیم • سهمیه آسیایی: ایران ۲، ژاپن ۲، عربستان ۲، قطر ۱ و کره جنوبی ۱؛ سهمیه‌های دیگر بین لیگ‌های حاضر توزیع می‌شوند.", fontSize = 12.sp)
        }
        Chips(listOf("جدول", "نتایج و مراحل"), tab) { tab = it }
        if (tab == "جدول") {
            ranking.forEachIndexed { index, team ->
                Row(Modifier.fillMaxWidth().clickable { G.openTeam(team.id) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}.", Modifier.width(28.dp), fontWeight = FontWeight.Bold)
                    Logo(team, 26.dp)
                    val played = G.worldCupResults.keys.count { it.startsWith("${team.id}-") || it.endsWith("-${team.id}") }
                    val scored = G.worldCupResults.entries.mapNotNull { entry ->
                        val ids = entry.key.split("-").mapNotNull { it.toIntOrNull() }
                        val goals = entry.value.split(",").mapNotNull { it.toIntOrNull() }
                        if (ids.size != 2 || goals.size != 2 || team.id !in ids) null
                        else if (ids[0] == team.id) goals[0] to goals[1] else goals[1] to goals[0]
                    }
                    val points = scored.sumOf { (gf, ga) -> if (gf > ga) 3L else if (gf == ga) 1L else 0L }
                    val gd = scored.sumOf { it.first - it.second }
                    Column(Modifier.weight(1f).padding(start = 8.dp)) {
                        Text(team.name, fontWeight = FontWeight.SemiBold)
                        Text("${team.country} • ${played} بازی • ${points} امتیاز • تفاضل ${if (gd > 0) "+" else ""}$gd", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        when {
                            G.worldCupRound == 0 -> "گل زده: ${scored.sumOf { it.first }}"
                            G.worldCupRound == 1 -> if (index < 8) "صعود مستقیم" else if (index < 24) "پلی‌آف" else "حذف"
                            team.id in G.worldCupEntrants -> "در جام"
                            else -> "حذف"
                        },
                        fontSize = 10.sp
                    )
                }
                HorizontalDivider()
            }
        } else {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                items(G.worldCupLog.takeLast(150).asReversed()) { line -> Text("• $line", modifier = Modifier.padding(vertical = 4.dp), fontSize = 12.sp) }
            }
        }
    }
}

