package com.mmd.morabbi

// تیم‌های معروف هر کشور (قدرت = اورال کل = میانگین ۱۴ بازیکن برتر).
// سطح ۱: غول‌ها، سطح ۲: بزرگ‌ها، سطح ۳: معروف‌ها. اورال هدف هر تیم در تابع targetOvr از روی کشور، دسته و جایگاه باشگاه محاسبه می‌شود
// (فیلدهای targets/cap/lowTarget/lowCap قدیمی دیگر استفاده نمی‌شوند و فقط برای سازگاری مانده‌اند).
class FamousSpec(
    val t1: List<String>, val t2: List<String>, val t3: List<String>,
    val targets: IntArray, val cap: Int,
    val low: List<String>, val lowTarget: Int, val lowCap: Int
)

val FAMOUS_SPECS: Map<String, FamousSpec> = mapOf(
    "ایران" to FamousSpec(
        listOf("پرسپولیس", "استقلال"),
        listOf("سپاهان", "تراکتور"),
        listOf("فولاد", "ذوب‌آهن", "گل‌گهر", "ملوان"),
        intArrayOf(87,86,84), 82,
        listOf("هوادار", "نفت مسجدسلیمان", "پارس جنوبی جم", "مس کرمان"), 77, 75
    ),
    "انگلیس" to FamousSpec(
        listOf("منچسترسیتی", "آرسنال", "لیورپول", "چلسی"),
        listOf("منچستریونایتد", "تاتنهام", "نیوکاسل یونایتد", "استون ویلا"),
        listOf("اورتون", "لیدز یونایتد", "ناتینگهام فارست"),
        intArrayOf(90,89,87), 85,
        listOf("وستهم", "ولورهمپتون", "ساوتهمپتون", "برنلی"), 80, 78
    ),
    "اسپانیا" to FamousSpec(
        listOf("رئال مادرید", "بارسلونا", "اتلتیکو مادرید"),
        listOf("اتلتیک بیلبائو", "رئال سوسیداد", "ویارئال", "رئال بتیس"),
        listOf("سویا", "والنسیا"),
        intArrayOf(90,89,87), 85,
        listOf("خیرونا", "مایورکا", "لاس پالماس", "گرانادا"), 80, 78
    ),
    "ایتالیا" to FamousSpec(
        listOf("اینتر", "آث میلان", "یوونتوس", "ناپولی"),
        listOf("آتالانتا", "رم"),
        listOf("لاتزیو", "فیورنتینا", "بولونیا"),
        intArrayOf(90,89,87), 85,
        listOf("سمپدوریا", "پالرمو", "ورونا", "امپولی"), 80, 78
    ),
    "آلمان" to FamousSpec(
        listOf("بایرن مونیخ"),
        listOf("بروسیا دورتموند", "بایر لورکوزن", "لایپزیگ"),
        listOf("اشتوتگارت", "آینتراخت فرانکفورت", "وردربرمن", "مونشن‌گلادباخ", "شالکه ۰۴", "هامبورگ"),
        intArrayOf(90,89,87), 85,
        listOf("هانوفر ۹۶", "هرتابرلین", "کایزرسلاوترن", "نورنبرگ"), 80, 78
    ),
    "فرانسه" to FamousSpec(
        listOf("پاری سن ژرمن"),
        listOf("مارسی", "موناکو", "لیون", "لیل"),
        listOf("نیس", "رن", "لانس"),
        intArrayOf(90,89,87), 85,
        listOf("سن‌اتین", "مون‌پلیه", "ریمز", "کلرمون فوت"), 80, 78
    ),
    "برزیل" to FamousSpec(
        listOf("فلامینگو", "پالمیراس"),
        listOf("سائوپائولو", "کورینتیانس", "سانتوس", "گرمیو", "اینترناسیونال"),
        listOf("اتلتیکو مینیرو", "فلومیننزه", "بوتافوگو", "کروزیرو", "واسکو دا گاما"),
        intArrayOf(89,88,86), 84,
        listOf("فورتالزا", "سیارا", "کویابا", "گوییاس"), 80, 78
    ),
    "ترکیه" to FamousSpec(
        listOf("گالاتاسرای", "فنرباغچه"),
        listOf("بشیکتاش", "ترابزون‌اسپور"),
        listOf("باشاک‌شهیر", "سامسون‌اسپور"),
        intArrayOf(89,88,86), 84,
        listOf("آدانا دمیرسپور", "هاتای‌اسپور", "بودروم‌اسپور", "کایسری‌اسپور"), 80, 78
    ),
    "آرژانتین" to FamousSpec(
        listOf("بوکا جونیورز", "ریور پلاته"),
        listOf("ایندیپندینته", "راسیینگ کلاب", "سن لورنزو"),
        listOf("استودیانتس", "ولز سارسفیلد", "نیوولز اولد بویز", "روساریو سنترال"),
        intArrayOf(89,88,86), 84,
        listOf("ایندیپندینته ریوادابیا", "اتلتیکو توکومان", "اینستیتوتو", "سنترال کوردوبا"), 80, 78
    ),
    "پرتغال" to FamousSpec(
        listOf("بنفیکا", "پورتو", "اسپورتینگ لیسبون"),
        listOf("براگا"),
        listOf("ویتوریا گیمارش", "فامالیکائو"),
        intArrayOf(89,88,86), 84,
        listOf("آکادمیکا کویمبرا", "پنافیل", "لایشوئش", "فیرنزه"), 80, 78
    ),
    "هلند" to FamousSpec(
        listOf("آژاکس", "پی‌اس‌وی آیندهوون"),
        listOf("فاینورد"),
        listOf("آلکمار", "توئنته", "اوترخت"),
        intArrayOf(89,88,86), 84,
        listOf("رودا جی‌سی", "ام‌وی‌وی ماستریخت", "دی گرافشاپ", "ویتس آرنهم"), 80, 78
    ),
    "عربستان" to FamousSpec(
        listOf("الهلال", "النصر", "الاتحاد", "الاهلی"),
        listOf("القادسیه", "الشباب", "الاتفاق"),
        listOf("التعاون", "الفتح", "الخلیج", "الریاض"),
        intArrayOf(84,80,76), 80,
        emptyList(), 0, 0
    ),
    "ژاپن" to FamousSpec(
        listOf("ویسل کوبه", "یوکوهاما مارینوس", "سانفرسه هیروشیما", "کاشیما آنتلرز"),
        listOf("کاوازاکی فرونتاله", "اوراوا ردز", "ناگویا گرامپوس", "سرزو اوساکا"),
        listOf("اف‌سی توکیو", "گامبا اوساکا", "کاشیوا ریسول", "ماچیدا زلویا"),
        intArrayOf(84,80,76), 80,
        emptyList(), 0, 0
    ),
    "کره جنوبی" to FamousSpec(
        listOf("اولسان اچ‌دی", "جونبوک هیوندای موتورز", "اف‌سی سئول", "پوهانگ استیلرز"),
        listOf("گوانگجو اف‌سی", "اینچئون یونایتد", "دائجون هانا سیتیزن", "کیمچئون سانگمو"),
        listOf("ججو یونایتد", "کانگوون اف‌سی", "اف‌سی آنیانگ", "بوچئون ۱۹۹۵"),
        intArrayOf(84,80,76), 80,
        emptyList(), 0, 0
    ),
    "قطر" to FamousSpec(
        listOf("السد", "الدحیل", "الریان", "الغرافه"),
        listOf("العربی", "الوکره", "قطر اس‌سی", "الشمال"),
        listOf("الاهلی", "لوسیل", "الشحانیه", "ام‌صلال"),
        intArrayOf(84,80,76), 80,
        emptyList(), 0, 0
    )
)

fun famousTierOf(spec: FamousSpec, name: String): Int = when (name) {
    in spec.t1 -> 1
    in spec.t2 -> 2
    in spec.t3 -> 3
    else -> 0
}

// ضریب قدرت لیگ هر کشور (۰ = قوی‌ترین لیگ‌ها)
val COUNTRY_OVR_ADJ: Map<String, Int> = mapOf(
    "انگلیس" to 0, "اسپانیا" to 0, "ایتالیا" to -1, "آلمان" to -1, "فرانسه" to -2,
    "پرتغال" to -3, "هلند" to -3, "برزیل" to -3, "ایران" to -3, "ترکیه" to -4, "آرژانتین" to -4,
    "عربستان" to -3, "ژاپن" to -5, "کره جنوبی" to -5, "قطر" to -6
)
private val TIER_OVR = intArrayOf(84, 80, 76) // غول‌ها، بزرگ‌ها، معروف‌ها (دسته اول)

// اورال هدف یک تیم. posInLeague: جایگاه تیم در فهرست باشگاه‌های همان لیگ (۰ = بالاترین)، nonFamousRank: جایگاه بین تیم‌های غیرمعروف دسته اول.
fun targetOvr(country: String, level: Int, name: String, posInLeague: Int, nonFamousRank: Int): Int {
    val adj = COUNTRY_OVR_ADJ[country] ?: -3
    val spec = FAMOUS_SPECS[country]
    if (level == 1) {
        if (spec != null) {
            val tier = famousTierOf(spec, name)
            if (tier > 0) {
                val list = when (tier) { 1 -> spec.t1; 2 -> spec.t2; else -> spec.t3 }
                return Math.round(TIER_OVR[tier - 1] + adj - 0.7 * list.indexOf(name)).toInt()
            }
        }
        return Math.round(maxOf(73.0 + adj - 0.65 * nonFamousRank, 58.0 + adj)).toInt()
    }
    val half = adj / 2.0
    return when (level) {
        2 -> Math.round(64.0 + half - 0.45 * posInLeague).toInt()
        3 -> Math.round(55.0 + half - 0.35 * posInLeague).toInt()
        else -> Math.round(47.0 + half - 0.3 * posInLeague).toInt()
    }
}

// فقط بازیکنان غیرستاره تغییر می‌کنند (ستاره‌های واقعی دست‌نخورده می‌مانند)؛ اورال تیم به عدد هدف نزدیک می‌شود (هم بالا هم پایین).
private fun adjustNonStars(t: Team, target: Int) {
    var guard = 0
    val touched = HashSet<Int>()
    while (guard < 70) {
        val s = strengthOf(t)
        if (s == target) break
        val up = s < target
        var changed = false
        for (p in squad(t.id)) {
            if (p.name in STAR_NAMES) continue
            if (up && p.rating < 95) { p.rating++; changed = true; touched.add(p.id) }
            if (!up && p.rating > 40) { p.rating--; changed = true; touched.add(p.id) }
        }
        if (!changed) break
        guard++
    }
    for (p in squad(t.id)) if (p.id in touched) p.value = worth(p.rating, p.age)
}

// اورال همه تیم‌های همه لیگ‌ها را بر اساس سطح باشگاه تنظیم می‌کند (تیم کاربر دست‌نخورده می‌ماند).
fun applyFamousRatings() {
    for (lg in G.leagues) {
        val spec = FAMOUS_SPECS[lg.country]
        val teams = G.teams.filter { it.leagueId == lg.id }
        val ref = if (lg.level == 1) REAL_CLUBS[lg.country].orEmpty() else LOWER_CLUBS[lg.country].orEmpty()
        val ordered = teams.sortedBy { val i = ref.indexOf(it.name); if (i < 0) 9999 else i }
        val nonFamous = ordered.filter { spec == null || famousTierOf(spec, it.name) == 0 }
        for (t in teams) {
            if (t.id == G.userTeam) continue
            val target = targetOvr(lg.country, lg.level, t.name, ordered.indexOf(t), nonFamous.indexOf(t).coerceAtLeast(0))
            adjustNonStars(t, target)
        }
    }
}
