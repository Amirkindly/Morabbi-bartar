package com.mmd.morabbi

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val LOAD_MSGS_FA = listOf(
    "در حال آماده‌سازی دنیای فوتبال…",
    "بارگذاری باشگاه‌ها و بازیکنان…",
    "چیدن ترکیب و تاکتیک‌ها…",
    "تنظیم برنامه بازی‌ها…",
    "تقریباً آماده‌ایم…"
)
private val LOAD_MSGS_EN = listOf(
    "Preparing the football world…",
    "Loading clubs and players…",
    "Setting up lineups and tactics…",
    "Building the fixture list…",
    "Almost ready…"
)

@Composable
fun LoadingScreen() {
    val gold = Color(0xFFB8860B)
    val en = I18n.lang == "en"
    val msgs = if (en) LOAD_MSGS_EN else LOAD_MSGS_FA
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { delay(1700); idx = (idx + 1).coerceAtMost(msgs.size - 1) }
    }
    val inf = rememberInfiniteTransition(label = "load")
    val pulse by inf.animateFloat(1f, 1.07f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val glow by inf.animateFloat(0.25f, 0.6f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse), label = "glow")

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFBF8EF), Color(0xFFF1EBD9)))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(200.dp)) {
                    drawCircle(
                        Brush.radialGradient(listOf(gold.copy(alpha = glow), Color.Transparent), center = Offset(size.width / 2, size.height / 2), radius = size.minDimension / 2),
                        radius = size.minDimension / 2
                    )
                }
                Image(
                    painterResource(R.drawable.app_logo), contentDescription = null,
                    modifier = Modifier.size(118.dp).scale(pulse).clip(CircleShape)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(if (en) "Top Coach" else "مربی برتر", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF3A2D0B))
            Spacer(Modifier.height(26.dp))
            Box(Modifier.width(190.dp).height(26.dp), contentAlignment = Alignment.CenterStart) {
                LinearProgressIndicator(
                    modifier = Modifier.width(190.dp).height(5.dp).clip(RoundedCornerShape(50)),
                    color = gold, trackColor = gold.copy(alpha = 0.18f)
                )
            }
            Spacer(Modifier.height(14.dp))
            Crossfade(idx, animationSpec = tween(500), label = "msg") { i ->
                Text(msgs[i.coerceIn(0, msgs.size - 1)], fontSize = 14.sp, color = Color(0xFF6B5A2E), textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
            }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (en) CREDIT_EN else CREDIT_FA,
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF6B5A2E), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (en) "First launch may take a few seconds" else "بار اول ممکنه چند ثانیه طول بکشه",
                fontSize = 11.sp, color = Color(0xFF9A8A5C)
            )
        }
    }
}
