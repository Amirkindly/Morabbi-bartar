package com.mmd.morabbi

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONObject

// ======================= افتخارات باشگاه‌ها =======================
// برای همه تیم‌ها (کاربر و رایانه): قهرمانی و نایب‌قهرمانی لیگ، جام حذفی، لیگ قهرمانان جهان،
// جام قهرمانان آسیا و جام دوستانه. در فایل ذخیره بازی (کلید "honors") نگهداری می‌شود.
object Honors {
    const val LEAGUE = 0; const val LEAGUE2 = 1
    const val CUP = 2; const val CUP2 = 3
    const val CL = 4; const val CL2 = 5
    const val ASIA = 6; const val ASIA2 = 7
    const val FRIENDLY = 8; const val FRIENDLY2 = 9
    private const val N = 10

    private val map = HashMap<Int, IntArray>()

    fun clear() { map.clear() }
    fun add(tid: Int, idx: Int) {
        if (tid < 0) return
        map.getOrPut(tid) { IntArray(N) }[idx]++
    }
    fun get(tid: Int, idx: Int): Int = map[tid]?.get(idx) ?: 0

    fun toJson(): JSONObject {
        val o = JSONObject()
        for ((tid, arr) in map) if (arr.any { it > 0 }) o.put(tid.toString(), arr.joinToString(","))
        return o
    }

    fun fromJson(o: JSONObject?) {
        map.clear()
        if (o == null) return
        for (k in o.keys()) {
            val tid = k.toIntOrNull() ?: continue
            val parts = o.optString(k, "").split(",")
            val arr = IntArray(N)
            for (i in 0 until N) arr[i] = parts.getOrNull(i)?.trim()?.toIntOrNull() ?: 0
            map[tid] = arr
        }
    }

    // سیوهای قدیمی: قهرمانی‌های ثبت‌شده در تاریخچه فصل‌ها شمرده می‌شود (نایب‌قهرمانی قدیمی ثبت نشده بود).
    fun migrateFromHistory() {
        map.clear()
        val byName = HashMap<String, Team>()
        for (t in G.teams) byName[t.name] = t
        for (h in G.history) {
            if (!h.startsWith("فصل") || !h.contains(": قهرمان ")) continue
            val title = h.substringAfter(" - ").substringBefore(": قهرمان ")
            val champ = h.substringAfter(": قهرمان ").substringBefore(" | ").trim()
            val t = byName[champ] ?: continue
            val idx = when {
                title.contains("قهرمانان جهان") -> CL
                title.contains("قهرمانان آسیا") -> ASIA
                title.contains("جام حذفی") || title.contains("کوپا") -> CUP
                else -> LEAGUE
            }
            add(t.id, idx)
        }
    }
}

// ======================= منوی اطلاعات تیم (با لمس نام تیم) =======================

private val PopBg = Color(0xFF16324F)
private val PopGold = Color(0xFFF2C400)
private val PopHeader = Color(0xFFE0B000)
private val PopCard = Color(0xFF0F2438)

@Composable
private fun HonorCell(icon: String, label: String, count: Int, modifier: Modifier) {
    Column(modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 34.sp)
        Text("$count $label", fontSize = 12.sp, textAlign = TextAlign.Center,
            fontWeight = if (count > 0) FontWeight.Bold else FontWeight.Normal,
            color = if (count > 0) Color.White else Color(0xFF9FB3C8))
    }
}

@Composable
private fun HonorRow(title: String, champ: Int, runner: Int) {
    Row(Modifier.fillMaxWidth()) {
        HonorCell("🏆", "قهرمانی $title", champ, Modifier.weight(1f))
        HonorCell("🥈", "نایب‌قهرمانی $title", runner, Modifier.weight(1f))
    }
}

@Composable
fun TeamPopup() {
    val rv = G.rev
    val team = G.teamOrNull(G.popupTeam)
    if (team == null) {
        LaunchedEffect(G.popupTeam) { G.popupTeam = -1 }
        return
    }
    var tab by remember(team.id) { mutableIntStateOf(0) }
    val league = G.leagues.firstOrNull { it.id == team.leagueId }
    val powers = remember(G.rev) { strengthsByTeam() }
    val worldRank = remember(G.rev, team.id) {
        G.teams.sortedWith(compareByDescending<Team> { powers[it.id] ?: 0 }.thenBy { it.name }).indexOfFirst { it.id == team.id } + 1
    }
    // مجموع برد/مساوی/باخت لیگ در همه فصل‌ها (فصل‌های تمام‌شده + فصل جاری)
    val sums = G.seasonSums.filter { it.tid == team.id }
    val wins = sums.sumOf { it.w } + team.w
    val draws = sums.sumOf { it.d } + team.d
    val losses = sums.sumOf { it.l } + team.l

    Dialog(onDismissRequest = { G.popupTeam = -1 }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.86f),
            shape = RoundedCornerShape(16.dp), color = PopBg, border = BorderStroke(2.dp, PopGold)
        ) {
            CompositionLocalProvider(LocalContentColor provides Color.White) {
                Column(Modifier.fillMaxSize().padding(8.dp)) {
                    // سربرگ تیم
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PopHeader).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Logo(team, 52.dp)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(team.name, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Color(0xFF1A1400), maxLines = 1)
                            Text("${league?.name ?: "بدون لیگ"} • ${team.country}", fontSize = 12.sp, color = Color(0xFF3B3000), maxLines = 1)
                            Text("قدرت ${powers[team.id] ?: strengthOf(team)} • بودجه ${money(team.budget)}", fontSize = 12.sp, color = Color(0xFF3B3000), maxLines = 1)
                        }
                        Text("✕", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A1400),
                            modifier = Modifier.clip(CircleShape).clickable { G.popupTeam = -1 }.padding(8.dp))
                    }
                    // برد / مساوی / باخت
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                        Row(Modifier.clip(RoundedCornerShape(10.dp)).background(PopCard).padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🟢 $wins برد", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("⚪ $draws مساوی", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("🔴 $losses باخت", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    // تب‌ها
                    val tabs = listOf("کلاب", "جدول لیگ", "آخرین نتایج", "بازیکنان")
                    Row(Modifier.fillMaxWidth()) {
                        tabs.forEachIndexed { i, label ->
                            val on = tab == i
                            Column(Modifier.weight(1f).clickable { tab = i }.padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(label, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                                    color = if (on) Color.White else Color(0xFF9FB3C8), maxLines = 1)
                                Spacer(Modifier.height(6.dp))
                                Box(Modifier.fillMaxWidth().height(3.dp).background(if (on) PopGold else Color.Transparent))
                            }
                        }
                    }
                    HorizontalDivider(color = Color(0x33FFFFFF))
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                            when (tab) {
                                0 -> ClubTab(team, worldRank)
                                1 -> LeagueTab(team)
                                2 -> ResultsTab(team)
                                else -> PlayersTab(team)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClubTab(team: Team, worldRank: Int) {
    val tb = table(team.leagueId)
    val rank = tb.indexOfFirst { it.id == team.id } + 1
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border12().padding(6.dp)) {
        Text("🏅 افتخارات تیم", fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
        HonorRow("لیگ", Honors.get(team.id, Honors.LEAGUE), Honors.get(team.id, Honors.LEAGUE2))
        HonorRow("جام حذفی", Honors.get(team.id, Honors.CUP), Honors.get(team.id, Honors.CUP2))
        HonorRow("لیگ قهرمانان", Honors.get(team.id, Honors.CL), Honors.get(team.id, Honors.CL2))
        HonorRow("قهرمانان آسیا", Honors.get(team.id, Honors.ASIA), Honors.get(team.id, Honors.ASIA2))
        HonorRow("جام دوستانه", Honors.get(team.id, Honors.FRIENDLY), Honors.get(team.id, Honors.FRIENDLY2))
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.clip(RoundedCornerShape(10.dp)).border12().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("لباس بازیکنان", fontSize = 11.sp, color = Color(0xFF9FB3C8))
            Shirt(team, 64.dp)
        }
        Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(PopHeader).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("رتبه جهانی", color = Color(0xFF1A1400), fontSize = 13.sp)
            Text("$worldRank", color = Color(0xFF1A1400), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(PopHeader).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("رتبه در لیگ", color = Color(0xFF1A1400), fontSize = 13.sp)
            Text(if (rank > 0) "$rank" else "—", color = Color(0xFF1A1400), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
    Spacer(Modifier.height(8.dp))
    Button(
        onClick = { G.popupTeam = -1; G.viewedTeamId = team.id; G.go("teamHistory") },
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8D6E63), contentColor = Color.White)
    ) { Text("📜 تاریخچه بازی‌ها در هر فصل") }
    Text("افتخارات قدیمی‌تر فقط از روی تاریخچه فصل‌ها شمرده شده؛ نایب‌قهرمانی‌ها از این به بعد ثبت می‌شوند.",
        fontSize = 10.sp, color = Color(0xFF9FB3C8), modifier = Modifier.padding(top = 6.dp))
}

private fun Modifier.border12(): Modifier = this.background(PopCard)

@Composable
private fun LeagueTab(team: Team) {
    val tb = table(team.leagueId)
    if (tb.isEmpty()) { Text("جدولی برای این لیگ وجود ندارد.", color = Color(0xFF9FB3C8)); return }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Cell("#", 24.dp, true); Spacer(Modifier.width(28.dp))
        Text("تیم", Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Cell("بازی", 28.dp, true); Cell("برد", 28.dp, true); Cell("مس", 28.dp, true); Cell("باخت", 30.dp, true); Cell("امتیاز", 34.dp, true)
    }
    HorizontalDivider(color = Color(0x33FFFFFF))
    for ((i, t) in tb.withIndex()) {
        val me = t.id == team.id
        Row(
            Modifier.fillMaxWidth().background(if (me) Color(0x55F2C400) else Color.Transparent)
                .clickable { G.popupTeam = t.id }.padding(vertical = 5.dp, horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Cell("${i + 1}", 24.dp)
            Logo(t, 24.dp)
            Text(t.name, Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, maxLines = 1,
                fontWeight = if (me) FontWeight.Bold else FontWeight.Normal)
            Cell("${t.p}", 28.dp); Cell("${t.w}", 28.dp); Cell("${t.d}", 28.dp); Cell("${t.l}", 30.dp); Cell("${t.pts}", 34.dp, true)
        }
        HorizontalDivider(color = Color(0x22FFFFFF))
    }
}

@Composable
private fun ResultsTab(team: Team) {
    val recent = G.matchLog.filter { it.hid == team.id || it.aid == team.id }
        .sortedWith(compareByDescending<MatchRec> { it.season }.thenByDescending { it.week })
        .take(15)
    if (recent.isEmpty()) {
        Text("هنوز نتیجه‌ای برای این تیم ثبت نشده است.", color = Color(0xFF9FB3C8), fontSize = 13.sp)
        return
    }
    for (r in recent) {
        MatchRow(team.id, r.week, "فصل ${r.season} • " + G.compNames.getOrElse(r.comp) { "لیگ" }, r.hid, r.aid, r.hg, r.ag)
    }
}

@Composable
private fun PlayersTab(team: Team) {
    val players = squad(team.id).sortedWith(compareBy({ listOf("GK", "DF", "MF", "FW").indexOf(it.pos) }, { -it.rating }))
    val posName = mapOf("GK" to "دروازه‌بان", "DF" to "مدافع", "MF" to "هافبک", "FW" to "مهاجم")
    if (players.isEmpty()) { Text("بازیکنی در این تیم نیست.", color = Color(0xFF9FB3C8)); return }
    for (p in players) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(PopCard).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(posColor(p.pos)), contentAlignment = Alignment.Center) {
                Text(p.pos, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                Text("${posName[p.pos] ?: p.pos} • ${p.country}", fontSize = 11.sp, color = Color(0xFF9FB3C8), maxLines = 1)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${p.rating}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PopGold)
                Text("سن : ${p.age}", fontSize = 11.sp, color = Color(0xFF9FB3C8))
            }
        }
    }
}
