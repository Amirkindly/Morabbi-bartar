package com.mmd.morabbi

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.exp
import kotlin.math.pow
import kotlin.random.Random

// ======================= داده‌ها =======================

val POS = listOf("GK", "DF", "MF", "FW")
val FORMS = listOf("4-4-2", "4-3-3", "3-5-2", "4-5-1", "5-3-2", "3-4-3", "5-4-1", "5-2-3", "4-2-4", "3-3-4", "4-1-5")
val STY = listOf("دفاعی", "متعادل", "تهاجمی")
val DIFFS = listOf("آسان", "متوسط", "سخت")
val SHIRTS = listOf("ساده", "راه‌راه", "دو نیمه", "کمربند")
val ADMIN_PASS = "MMD#2000"

val PAL: List<Long> = listOf(
    0xFFD32F2F, 0xFF1565C0, 0xFF2E7D32, 0xFFFBC02D, 0xFF6A1B9A, 0xFFEF6C00,
    0xFF212121, 0xFFFFFFFF, 0xFF00ACC1, 0xFFE91E63, 0xFF5D4037, 0xFF90A4AE
)

val FIRST = mapOf(
    "ایران" to listOf("علی", "رضا", "مهدی", "حسین", "امیر", "سعید", "پوریا", "کاوه"),
    "انگلیس" to listOf("جیمز", "جک", "هری", "جورج", "ویلیام", "چارلی", "تام", "لوک"),
    "اسپانیا" to listOf("کارلوس", "خاویر", "پدرو", "دیگو", "مانوئل", "آلوارو", "ایکر", "رائول"),
    "ایتالیا" to listOf("مارکو", "لوکا", "آندرئا", "جووانی", "فدریکو", "ماتئو", "لورنتزو", "الساندرو"),
    "آلمان" to listOf("یوناس", "مارکوس", "توماس", "فلیکس", "لوکاس", "کای", "یان", "مانوئل"),
    "فرانسه" to listOf("کیلیان", "آنتوان", "اوسمان", "هوگو", "تئو", "نیکولا", "پل", "ژولیان"),
    "برزیل" to listOf("ویتور", "رودریگو", "گابریل", "ماتئوس", "لوکاس", "فرناندو", "دانیلو", "کائو"),
    "آرژانتین" to listOf("لیونل", "خولیان", "نیکولاس", "لاوتارو", "فرانکو", "آنخل", "پائولو", "تیاگو"),
    "ترکیه" to listOf("امره", "عثمان", "مراد", "کریم", "یوسف", "برکی", "اردا", "جان"),
    "پرتغال" to listOf("کریستیانو", "برونو", "ژوائو", "رافائل", "دیگو", "پدرو", "تیاگو", "گونچالو"),
    "هلند" to listOf("فرنکی", "ممفیس", "کودی", "ژاوی", "ماتیاس", "دانی", "یورین", "استیون")
)
val LAST = mapOf(
    "ایران" to listOf("احمدی", "رضایی", "کریمی", "موسوی", "حسینی", "جعفری", "صادقی", "نوری"),
    "انگلیس" to listOf("اسمیت", "جونز", "تیلور", "براون", "ویلسون", "اوانز", "واکر", "رایت"),
    "اسپانیا" to listOf("گارسیا", "مارتینز", "لوپز", "سانچز", "پرز", "فرناندز", "رومرو", "نوارو"),
    "ایتالیا" to listOf("روسی", "روسو", "فرارا", "بیانکی", "کوستا", "ریچی", "گالو", "مورو"),
    "آلمان" to listOf("مولر", "شمیت", "فیشر", "وبر", "واگنر", "بکر", "هافمن", "کراوس"),
    "فرانسه" to listOf("مارتن", "برنار", "دوبوآ", "موریس", "لوران", "میشل", "فونتن", "گارنیه"),
    "برزیل" to listOf("سیلوا", "سانتوس", "اولیویرا", "سوزا", "لیما", "پریرا", "کاستا", "ریبیرو"),
    "آرژانتین" to listOf("گونزالس", "رودریگز", "آکوستا", "مدینا", "سوسا", "بنیتز", "ایبارا", "پاز"),
    "ترکیه" to listOf("یلماز", "کایا", "دمیر", "چلیک", "شاهین", "آیدین", "ازتورک", "آرسلان"),
    "پرتغال" to listOf("سیلوا", "سانتوس", "فریرا", "پریرا", "کوستا", "اولیویرا", "مارتینز", "کاروالیو"),
    "هلند" to listOf("دی‌یونگ", "دیپای", "گاکپو", "سیمونز", "فن‌دایک", "آکه", "مالن", "بروبی")
)
val COUNTRIES: List<String> = FIRST.keys.toList()

val NAME_A = listOf(
    "شاهین", "ستاره", "آتش", "فولاد", "پارس", "طوفان", "آریا", "سپهر", "کاوه", "ققنوس",
    "سیمرغ", "نسیم", "البرز", "دریا", "پیروزی", "ماهان", "آرمان", "شهاب", "هیرمند", "زاگرس"
)
val NAME_B = listOf(
    "تهران", "شیراز", "تبریز", "اصفهان", "مشهد", "اهواز", "رشت", "کرمان", "یزد", "ساری", "قم", "همدان"
)

val CLUB_A = mapOf(
    "انگلیس" to listOf("رویال", "یونایتد", "کینگز", "رورز", "اتلتیک", "ولز", "دیوک", "کرون"),
    "اسپانیا" to listOf("رئال", "اتلتیکو", "دپورتیوو", "اسپورتینگ", "کلوب", "یونیون", "سلتا", "ریال"),
    "ایتالیا" to listOf("اینترنو", "یونیون", "کالچو", "ویرتوس", "آزورا", "فورتیتودو", "رومولو", "سانتا"),
    "آلمان" to listOf("بروسیا", "آیندراخت", "فورتونا", "ویکتوریا", "ترو", "ریزن", "اشتورم", "هانزا"),
    "فرانسه" to listOf("اولمپیک", "ستاد", "ایگل", "لوکوک", "فلور", "رویال", "اتوال", "راسینگ"),
    "برزیل" to listOf("اسپورت", "اتلتیکو", "آمریکا", "گوارانی", "اونیاو", "ایتوانو", "ناسیونال", "رئال"),
    "ترکیه" to listOf("ینی", "بلدیه", "گنج", "اتلتیک", "آنادولو", "دمیر"),
    "آرژانتین" to listOf("سان", "کلوب", "اتلتیکو", "دپورتیوو", "سنترال", "یونیون"),
    "پرتغال" to listOf("اسپورتیو", "اتلتیکو", "گرمیو", "یونیائو", "کلوب"),
    "هلند" to listOf("اف‌سی", "فورتونا", "ویتسه", "اس‌سی", "وی‌وی‌وی")
)
val CLUB_B = mapOf(
    "انگلیس" to listOf("لندن", "منچستر", "لیورپول", "لیدز", "بریستول", "شفیلد", "نیوکاسل", "لستر", "ناتینگهام", "برایتون"),
    "اسپانیا" to listOf("مادرید", "بارسلونا", "سویا", "والنسیا", "بیلبائو", "مالاگا", "گرانادا", "ویگو", "ساراگوسا", "مایورکا"),
    "ایتالیا" to listOf("میلان", "تورین", "رم", "ناپل", "ژنوا", "فلورانس", "بولونیا", "پالرمو", "باری", "ورونا"),
    "آلمان" to listOf("برلین", "مونیخ", "هامبورگ", "کلن", "دورتموند", "اشتوتگارت", "لایپزیگ", "برمن", "دوسلدورف", "فرانکفورت"),
    "فرانسه" to listOf("پاریس", "مارسی", "لیون", "لیل", "نیس", "رن", "نانت", "تولوز", "بوردو", "استراسبورگ"),
    "برزیل" to listOf("ریو", "سائوپائولو", "کوریتیبا", "سالوادور", "رسیف", "بلو هوریزونته", "مانائوس", "بلم", "گویانیا", "فلوریانوپولیس"),
    "ترکیه" to listOf("بورسا", "ازمیر", "مالاتیا", "مرسین", "دیاربکر", "ترابزون", "سامسون", "اردو", "ایسپارتا", "آدیامان"),
    "آرژانتین" to listOf("مندوسا", "سالتا", "کوردوبا", "لاپلاتا", "ویلا", "خوخوی", "نیوکن", "ریسیستنسیا"),
    "پرتغال" to listOf("ویزئو", "لیریا", "اوئیراش", "ماتوزینیوش", "سیتوبال", "پورتالگره", "لاگوش", "آویرو"),
    "هلند" to listOf("لیدن", "هارلم", "بریدا", "ماستریخت", "دلفت", "آمستردام", "روتردام", "زوله")
)

// لیگ‌های پایه: کشور و دسته‌ها (ایران همیشه اول)
val LEAGUE_DEFS: List<Pair<String, List<String>>> = listOf(
    "ایران" to listOf("لیگ برتر ایران", "لیگ دسته یک ایران", "لیگ دسته دو ایران", "لیگ دسته سه ایران"),
    "انگلیس" to listOf("لیگ برتر انگلیس", "چمپیونشیپ انگلیس", "لیگ یک انگلیس", "لیگ دو انگلیس"),
    "اسپانیا" to listOf("لالیگا", "لالیگا ۲", "دسته سه اسپانیا"),
    "ایتالیا" to listOf("سری آ", "سری بی", "سری سی"),
    "آلمان" to listOf("بوندسلیگا", "بوندسلیگا ۲", "لیگا ۳"),
    "فرانسه" to listOf("لیگ ۱ فرانسه", "لیگ ۲ فرانسه", "ملی فرانسه"),
    "برزیل" to listOf("سری آ برزیل", "سری بی برزیل", "سری سی برزیل"),
    "ترکیه" to listOf("سوپر لیگ ترکیه", "لیگ یک ترکیه", "لیگ دو ترکیه"),
    "آرژانتین" to listOf("لیگ برتر آرژانتین", "دسته یک آرژانتین"),
    "پرتغال" to listOf("لیگ برتر پرتغال", "لیگ دسته یک پرتغال"),
    "هلند" to listOf("اردیویسه", "ارسته دیویسه")
)

// باشگاه‌های واقعی در اولویت اول هر لیگ قرار می‌گیرند؛ در صورت نیاز، تیم‌های تولیدی تکمیل‌کننده‌اند.
val REAL_CLUBS: Map<String, List<String>> = mapOf(
    "ایران" to listOf("پرسپولیس", "استقلال", "سپاهان", "تراکتور", "فولاد", "گل‌گهر", "ملوان", "ذوب‌آهن", "آلومینیوم اراک", "شمس‌آذر", "خیبر خرم‌آباد", "چادرملو", "مس رفسنجان", "نساجی", "پیکان", "صنعت نفت آبادان", "سایپا", "فجر سپاسی", "استقلال خوزستان", "مس شهربابک"),
    "انگلیس" to listOf("منچسترسیتی", "آرسنال", "لیورپول", "منچستریونایتد", "چلسی", "تاتنهام", "نیوکاسل یونایتد", "استون ویلا", "برایتون", "کریستال پالاس", "برنتفورد", "فولام", "اورتون", "ناتینگهام فارست", "بورنموث", "لیدز یونایتد", "ساندرلند", "کاونتری سیتی", "ایپسویچ تاون", "هال سیتی"),
    "اسپانیا" to listOf("رئال مادرید", "بارسلونا", "اتلتیکو مادرید", "اتلتیک بیلبائو", "رئال سوسیداد", "ویارئال", "رئال بتیس", "سویا", "والنسیا", "سلتاویگو", "اوساسونا", "ختافه", "رایو وایکانو", "اسپانیول", "دپورتیوو لاکرونیا", "مالاگا", "لوانته", "الچه", "راسینگ سانتاندر", "آلاوس"),
    "ایتالیا" to listOf("اینتر", "آث میلان", "یوونتوس", "ناپولی", "آتالانتا", "رم", "لاتزیو", "فیورنتینا", "بولونیا", "تورینو", "مونزا", "اودینزه", "جنوا", "کالیاری", "ساسولو", "لچه", "پارما", "کومو", "ونتزیا", "فروزینونه"),
    "آلمان" to listOf("بایرن مونیخ", "بروسیا دورتموند", "بایر لورکوزن", "لایپزیگ", "اشتوتگارت", "آینتراخت فرانکفورت", "وولفسبورگ", "فرایبورگ", "هوفنهایم", "وردربرمن", "آگزبورگ", "ماینتس", "مونشن‌گلادباخ", "یونیون برلین", "هامبورگ", "شالکه ۰۴", "کلن", "پادربورن", "سن پائولی", "السفرسبرگ"),
    "فرانسه" to listOf("پاری سن ژرمن", "مارسی", "موناکو", "لیون", "لیل", "نیس", "رن", "لانس", "استراسبورگ", "نانت", "تولوز", "برست", "لوهاور", "متز", "لوریان", "اوسر", "آنژه", "پاری اف‌سی", "تروا", "لومان"),
    "برزیل" to listOf("فلامینگو", "پالمیراس", "سائوپائولو", "کورینتیانس", "سانتوس", "گرمیو", "اینترناسیونال", "اتلتیکو مینیرو", "فلومیننزه", "بوتافوگو", "کروزیرو", "واسکو دا گاما", "باهیا", "براگانتی‌نو", "اتلتیکو پارانائنزه", "ویتوریا", "کوریتیبا", "میراسول", "شاپکوئنسه", "رمو"),
    "ترکیه" to listOf("گالاتاسرای", "فنرباغچه", "بشیکتاش", "ترابزون‌اسپور", "باشاک‌شهیر", "سامسون‌اسپور", "گوزتپه", "قونیه‌اسپور", "آلانیااسپور", "کاسیم‌پاشا", "ایوب‌اسپور", "ریزه‌اسپور", "غازی‌عنتاب", "گنچلربیرلیغی", "کوجائلی‌اسپور", "چوروم اف‌کی", "ارزوروم‌اسپور", "آمد اسپور", "سیواس‌اسپور", "آنتالیااسپور"),
    "آرژانتین" to listOf("بوکا جونیورز", "ریور پلاته", "ایندیپندینته", "راسیینگ کلاب", "سن لورنزو", "استودیانتس", "لانوس", "ولز سارسفیلد", "روساریو سنترال", "نیوولز اولد بویز", "تالرز", "آرژنتینوس جونیورز", "دفاع و خوستیسیا", "بلگرانو", "هوراکان", "پلاتنسه", "خیمناسیا لا پلاتا", "تیگره", "بانفیلد", "اونیون سانتا فه"),
    "پرتغال" to listOf("بنفیکا", "پورتو", "اسپورتینگ لیسبون", "براگا", "ویتوریا گیمارش", "فامالیکائو", "ژیل ویسنته", "اشتوریل", "موریرنزه", "ریو آوه", "سانتا کلارا", "کاسا پیا", "آروکا", "ناسیونال", "استرلا آمادورا", "آلورکا", "ماریتیمو", "آکادمیکو ویزئو", "بوآویشتا", "فارنسه"),
    "هلند" to listOf("آژاکس", "پی‌اس‌وی آیندهوون", "فاینورد", "آلکمار", "توئنته", "اوترخت", "گو اهد ایگلز", "اسپارتا روتردام", "هیرنفین", "نایمخن", "فورتونا سیتارد", "زووله", "ویلم دوم", "گرونینگن", "اکسلسیور", "کامبور", "دن هاخ", "تلستار", "هراکلز", "بردا")
)


class Player(
    var id: Int, var name: String, var pos: String, var rating: Int, var age: Int,
    teamId: Int, var value: Long, var goals: Int = 0, var total: Int = 0, var country: String = "ایران"
) {
    // تغییر تیم بازیکن، کش ترکیب تیم‌ها را باطل می‌کند.
    var teamId: Int = teamId
        set(v) {
            if (field != v) {
                field = v
                G.squadVer++
            }
        }
}

// لیستی که هر تغییر ساختاری آن را اطلاع می‌دهد (برای باطل کردن کش‌ها).
class TrackedList<T>(private val onChange: () -> Unit) : ArrayList<T>() {
    override fun add(element: T): Boolean { onChange(); return super.add(element) }
    override fun add(index: Int, element: T) { onChange(); super.add(index, element) }
    override fun addAll(elements: Collection<T>): Boolean { onChange(); return super.addAll(elements) }
    override fun remove(element: T): Boolean { onChange(); return super.remove(element) }
    override fun removeAt(index: Int): T { onChange(); return super.removeAt(index) }
    override fun removeAll(elements: Collection<T>): Boolean { onChange(); return super.removeAll(elements.toSet()) }
    override fun removeIf(filter: java.util.function.Predicate<in T>): Boolean { onChange(); return super.removeIf(filter) }
    override fun set(index: Int, element: T): T { onChange(); return super.set(index, element) }
    override fun clear() { onChange(); super.clear() }
}

class AcademyPlayer(
    var id: Int, var name: String, var pos: String, var rating: Int, var age: Int,
    var teamId: Int, var potential: Int, var country: String
)

class Team(
    var id: Int, var name: String, var country: String, var leagueId: Int,
    var c1: Long, var c2: Long, var style: Int, var logo: String?, var budget: Long
) {
    var p = 0
    var w = 0
    var d = 0
    var l = 0
    var gf = 0
    var ga = 0
    var pts = 0
    var allPts = 0
    var titles = 0
}

class League(var id: Int, var name: String, var level: Int, var country: String)

class Offer(val pid: Int, val from: Int, val price: Long)
class Ev(val min: Int, val text: String, val side: Int, val scorerId: Int = -1) // side: 0 گل میزبان، 1 گل میهمان، 2 رویداد
// ثبت ساختاریافته هر مسابقه؛ برای تاریخچه کامل هر تیم (فصل جاری، گذشته و آینده)
class MatchRec(val season: Int, val week: Int, val comp: Int, val hid: Int, val aid: Int, var hg: Int, var ag: Int)
class SeasonSum(val season: Int, val tid: Int, val league: String, val rank: Int,
                val p: Int, val w: Int, val d: Int, val l: Int, val gf: Int, val ga: Int, val pts: Int)

class MatchRes(val h: Team, val a: Team, var hg: Int, var ag: Int, var ev: List<Ev>) {
    var finalized: Boolean = false
    var tableApplied: Boolean = false
    var homeGoalRate: Double = 0.0
    var awayGoalRate: Double = 0.0
    var lastAdvancedMinute: Int = 0
    // بازی زنده لیگ داخلی: نتیجه بعد از پایان بازی وارد جدول می‌شود.
    var affectsLeague: Boolean = false
    // مسابقه حذفی (جام حذفی / لیگ قهرمانان): در صورت تساوی، ضربات پنالتی تعیین‌کننده است.
    var knockout: Boolean = false
    var penH: Int = -1
    var penA: Int = -1
    // عنوان رقابت برای نمایش در صفحه بازی زنده و گزارش (مثلاً «🏆 جام حذفی • فینال»)
    var tag: String = ""
    // بعد از نهایی شدن بازی زنده صدا زده می‌شود (ثبت نتیجه دور حذفی و ...)
    var onFinal: ((MatchRes) -> Unit)? = null

    fun winner(): Team = when {
        hg > ag -> h
        ag > hg -> a
        penH >= 0 && penA >= 0 && penH != penA -> if (penH > penA) h else a
        else -> if (strengthOf(h) + Random.nextInt(0, 8) >= strengthOf(a) + Random.nextInt(0, 8)) h else a
    }
}

object G {
    var rev by mutableIntStateOf(0)
    var ready by mutableStateOf(false)
    var screen by mutableStateOf("pick")
    val stack = ArrayList<String>()
    val leagues = ArrayList<League>()
    var worldVer = 0
    var teamVer = 0
    var squadVer = 0
    val teams: ArrayList<Team> = TrackedList { teamVer++ }
    val players: ArrayList<Player> = TrackedList { squadVer++ }
    val academy = ArrayList<AcademyPlayer>()
    val history = ArrayList<String>()
    // تاریخچه مسابقات همه تیم‌ها (مسابقات تیم کاربر همیشه کامل نگه‌داری می‌شود؛ بقیه ۳ فصل اخیر) و خلاصه فصل‌ها
    val matchLog = ArrayList<MatchRec>()
    val compNames = arrayListOf("لیگ")
    val seasonSums = ArrayList<SeasonSum>()
    var lineup = ArrayList<Int>()
    var report = ArrayList<String>()
    var live: MatchRes? = null
    // بازی‌های زنده بعدی همین هفته (مثلاً میان‌هفته جام/قهرمانان و سپس لیگ آخر هفته)
    val liveQueue = ArrayList<MatchRes>()
    var liveAffectsLeague: Boolean = false
    var pendingPenaltyMatch: MatchRes? = null
    var penaltySide: Int = 0
    var penaltyReturnScreen: String = "play"
    val news = ArrayList<String>()
    val offers = ArrayList<Offer>()
    var msg by mutableStateOf("")
    var userTeam by mutableIntStateOf(-1)
    var tpl = 20
    var ppt = 22
    var promo = 3
    var season = 1
    var week = 0
    var diff = 1
    var academyCoachLevel = 0
    var academyTrainedSeason = 0
    var academyTrainedWeek = -1
    var cupSeason = 0
    var cupCountry = ""
    var cupRound = 0
    var cupEntrants = ArrayList<Int>()
    var cupFinished = false
    // مرحله مقدماتی: تیم‌های لیگ دسته دوم برای چهار سهمیه جام اصلی رقابت می‌کنند.
    var cupQualifiers = ArrayList<Int>()
    var cupQualRound = 0
    var cupQualFinished = false
    var cupFormat = 0
    var cupStartWeek = 0
    val cupLog = ArrayList<String>()
    // جام قهرمانان جهان: ۵۵ تیم (۴ سهمیه لیگ + قهرمان جام حذفی از ۱۱ کشور)، ۱۰ هفته لیگ سوئیسی و سپس حذفی
    var worldCupSeason = 0
    var worldCupEntrants = ArrayList<Int>()
    var worldCupSchedule = ArrayList<ArrayList<Pair<Int, Int>>>()
    var worldCupResults = HashMap<String, String>()
    var worldCupRound = 0 // 0 لیگ، 1 پلی‌آف، 2 تا 5 مراحل ۱۶ تیمی تا فینال، 6 پایان
    var worldCupActive = false
    var worldCupChampion = -1
    val worldCupLog = ArrayList<String>()
    var viewedTeamId = -1
    var formation = "4-4-2"
    var style = 1
    var nextId = 1
    var editTeam = -1
    lateinit var ctx: Context

    fun nid(): Int = nextId++
    private var tmap = HashMap<Int, Team>()
    private var tmapVer = -1
    private var tmapSize = -1
    private fun idx(): HashMap<Int, Team> {
        if (tmapVer != teamVer || tmapSize != teams.size) {
            val m = HashMap<Int, Team>(teams.size * 2)
            for (t in teams) m[t.id] = t
            tmap = m; tmapVer = teamVer; tmapSize = teams.size
        }
        return tmap
    }
    fun team(id: Int): Team = idx()[id] ?: throw NoSuchElementException("team $id")
    fun teamOrNull(id: Int): Team? = idx()[id]

    // کش ترکیب هر تیم: به جای فیلتر کل بازیکنان برای هر تیم، یک‌بار گروه‌بندی می‌شود.
    private var sq = HashMap<Int, List<Player>>()
    private var sqVer = -1
    private var sqSize = -1
    fun squadOf(tid: Int): List<Player> {
        if (sqVer != squadVer || sqSize != players.size) {
            val m = HashMap<Int, ArrayList<Player>>()
            for (p in players) m.getOrPut(p.teamId) { ArrayList() }.add(p)
            @Suppress("UNCHECKED_CAST")
            sq = m as HashMap<Int, List<Player>>
            sqVer = squadVer; sqSize = players.size
        }
        return sq[tid] ?: emptyList()
    }
    fun go(s: String) {
        stack.add(screen)
        screen = s
    }
    fun back() {
        screen = if (stack.isEmpty()) "home" else stack.removeAt(stack.size - 1)
    }
    private val main = Handler(Looper.getMainLooper())
    private val saveTask = Runnable { saveNow() }
    fun touch() {
        rev++
        main.removeCallbacks(saveTask)
        main.postDelayed(saveTask, 1200)
    }
    fun flush() {
        main.removeCallbacks(saveTask)
        saveNow()
    }
}

// ======================= ذخیره و بارگذاری =======================

private val saveExec = Executors.newSingleThreadExecutor()

// ساخت JSON روی ترد اصلی ولی سریع (بدون JSONObject)، نوشتن فایل در پس‌زمینه و به‌صورت اتمیک.
fun saveNow() {
    try {
        val q = { x: String -> JSONObject.quote(x) }
        val sb = StringBuilder(1 shl 20)
        sb.append("{\"nid\":").append(G.nextId)
            .append(",\"tpl\":").append(G.tpl)
            .append(",\"ppt\":").append(G.ppt)
            .append(",\"promo\":").append(G.promo)
            .append(",\"season\":").append(G.season)
            .append(",\"week\":").append(G.week)
            .append(",\"diff\":").append(G.diff)
            .append(",\"user\":").append(G.userTeam)
            .append(",\"form\":").append(q(G.formation))
            .append(",\"style\":").append(G.style)
            .append(",\"coach\":").append(G.academyCoachLevel)
            .append(",\"acTrainSeason\":").append(G.academyTrainedSeason)
            .append(",\"acTrainWeek\":").append(G.academyTrainedWeek)
            .append(",\"cupSeason\":").append(G.cupSeason)
            .append(",\"cupCountry\":").append(q(G.cupCountry))
            .append(",\"cupRound\":").append(G.cupRound)
            .append(",\"cupFinished\":").append(G.cupFinished)
            .append(",\"cupQualRound\":").append(G.cupQualRound)
            .append(",\"cupQualFinished\":").append(G.cupQualFinished)
            .append(",\"cupFormat\":").append(G.cupFormat)
            .append(",\"cupStartWeek\":").append(G.cupStartWeek)
            .append(",\"wcSeason\":").append(G.worldCupSeason)
            .append(",\"wcRound\":").append(G.worldCupRound)
            .append(",\"wcActive\":").append(G.worldCupActive)
            .append(",\"wcChampion\":").append(G.worldCupChampion)
            .append(",\"wv\":").append(G.worldVer)
        sb.append(",\"leagues\":[")
        for ((i, l) in G.leagues.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(l.id).append(",\"name\":").append(q(l.name))
                .append(",\"level\":").append(l.level).append(",\"country\":").append(q(l.country)).append('}')
        }
        sb.append("],\"teams\":[")
        for ((i, t) in G.teams.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(t.id).append(",\"name\":").append(q(t.name))
                .append(",\"country\":").append(q(t.country)).append(",\"lg\":").append(t.leagueId)
                .append(",\"c1\":").append(t.c1).append(",\"c2\":").append(t.c2)
                .append(",\"st\":").append(t.style).append(",\"logo\":").append(q(t.logo ?: ""))
                .append(",\"bud\":").append(t.budget).append(",\"p\":").append(t.p)
                .append(",\"w\":").append(t.w).append(",\"d\":").append(t.d).append(",\"l\":").append(t.l)
                .append(",\"gf\":").append(t.gf).append(",\"ga\":").append(t.ga)
                .append(",\"pts\":").append(t.pts).append(",\"ap\":").append(t.allPts)
                .append(",\"ti\":").append(t.titles).append('}')
        }
        sb.append("],\"players\":[")
        for ((i, p) in G.players.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(p.id).append(",\"n\":").append(q(p.name))
                .append(",\"pos\":").append(q(p.pos)).append(",\"r\":").append(p.rating)
                .append(",\"a\":").append(p.age).append(",\"t\":").append(p.teamId)
                .append(",\"v\":").append(p.value).append(",\"g\":").append(p.goals)
                .append(",\"tg\":").append(p.total).append(",\"c\":").append(q(p.country)).append('}')
        }
        sb.append("],\"academy\":[")
        for ((i, p) in G.academy.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(p.id).append(",\"n\":").append(q(p.name))
                .append(",\"pos\":").append(q(p.pos)).append(",\"r\":").append(p.rating)
                .append(",\"a\":").append(p.age).append(",\"t\":").append(p.teamId)
                .append(",\"pot\":").append(p.potential).append(",\"c\":").append(q(p.country)).append('}')
        }
        sb.append("],\"cupEntrants\":[")
        for ((i, id) in G.cupEntrants.withIndex()) { if (i > 0) sb.append(','); sb.append(id) }
        sb.append("],\"cupQualifiers\":[")
        for ((i, id) in G.cupQualifiers.withIndex()) { if (i > 0) sb.append(','); sb.append(id) }
        sb.append("],\"cupLog\":[")
        for ((i, line) in G.cupLog.withIndex()) { if (i > 0) sb.append(','); sb.append(q(line)) }
        sb.append("],\"wcEntrants\":[")
        for ((i, id) in G.worldCupEntrants.withIndex()) { if (i > 0) sb.append(','); sb.append(id) }
        sb.append("],\"wcSchedule\":[")
        for ((r, games) in G.worldCupSchedule.withIndex()) {
            if (r > 0) sb.append(','); sb.append('[')
            for ((i, game) in games.withIndex()) { if (i > 0) sb.append(','); sb.append("[${game.first},${game.second}]") }
            sb.append(']')
        }
        sb.append("],\"wcResults\":{")
        for ((i, entry) in G.worldCupResults.entries.withIndex()) { if (i > 0) sb.append(','); sb.append(q(entry.key)).append(':').append(q(entry.value)) }
        sb.append("},\"wcLog\":[")
        for ((i, line) in G.worldCupLog.withIndex()) { if (i > 0) sb.append(','); sb.append(q(line)) }
        sb.append("],\"hist\":[")
        for ((i, h) in G.history.withIndex()) { if (i > 0) sb.append(','); sb.append(q(h)) }
        sb.append("],\"cn\":[")
        for ((i, h) in G.compNames.withIndex()) { if (i > 0) sb.append(','); sb.append(q(h)) }
        sb.append("],\"ml\":[")
        for ((i, r) in G.matchLog.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append('"').append(r.season).append(',').append(r.week).append(',').append(r.comp).append(',')
                .append(r.hid).append(',').append(r.aid).append(',').append(r.hg).append(',').append(r.ag).append('"')
        }
        sb.append("],\"ss\":[")
        for ((i, r) in G.seasonSums.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append(q("${r.season}~${r.tid}~${r.league}~${r.rank}~${r.p}~${r.w}~${r.d}~${r.l}~${r.gf}~${r.ga}~${r.pts}"))
        }
        sb.append("],\"lineup\":[")
        for ((i, x) in G.lineup.withIndex()) { if (i > 0) sb.append(','); sb.append(x) }
        sb.append("],\"news\":[")
        for ((i, n) in G.news.withIndex()) { if (i > 0) sb.append(','); sb.append(q(n)) }
        sb.append("],\"offers\":[")
        for ((i, f) in G.offers.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"p\":").append(f.pid).append(",\"f\":").append(f.from).append(",\"v\":").append(f.price).append('}')
        }
        sb.append("]}")
        val data = sb.toString()
        val dir = G.ctx.filesDir
        saveExec.execute {
            try {
                val tmp = File(dir, "save.json.tmp")
                tmp.writeText(data)
                val dst = File(dir, "save.json")
                if (!tmp.renameTo(dst)) {
                    dst.delete()
                    tmp.renameTo(dst)
                }
            } catch (e: Exception) {
            }
        }
    } catch (e: Exception) {
    }
}

// ======================= پشتیبان‌گیری و بازیابی پیشرفت بازی =======================
// خروجی: فایل JSON کامل بازی در مسیری که کاربر انتخاب می‌کند (حافظه گوشی، Drive و ...).
fun exportSaveTo(uri: Uri) {
    val main = Handler(Looper.getMainLooper())
    val toast = { msg: String -> main.post { android.widget.Toast.makeText(G.ctx, msg, android.widget.Toast.LENGTH_LONG).show() } }
    try {
        saveNow() // آخرین وضعیت بازی ساخته و در صف نوشتن قرار می‌گیرد
    } catch (e: Exception) { toast("ساخت پشتیبان ناموفق بود"); return }
    Thread {
        try {
            saveExec.submit { }.get() // صبر تا نوشتن save.json تمام شود
            val f = File(G.ctx.filesDir, "save.json")
            if (!f.exists()) { toast("فایل ذخیره پیدا نشد"); return@Thread }
            G.ctx.contentResolver.openOutputStream(uri, "w")?.use { out -> f.inputStream().use { it.copyTo(out) } }
            toast("پشتیبان بازی ذخیره شد")
        } catch (e: Exception) { toast("ذخیره پشتیبان ناموفق بود") }
    }.start()
}

// ورودی: فایل پشتیبان را می‌خواند، اعتبارش را می‌سنجد و جای بازی فعلی می‌گذارد. نتیجه: null = موفق، در غیر این صورت پیام خطا.
fun importSaveFrom(uri: Uri): String? {
    val dir = G.ctx.filesDir
    val cur = File(dir, "save.json")
    val bak = File(dir, "save.json.bak")
    try {
        val text = G.ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return "فایل خوانده نشد"
        val o = try { JSONObject(text) } catch (e: Exception) { return "این فایل پشتیبان معتبر بازی نیست" }
        if (!o.has("nid") || !o.has("season") || !o.has("user") || !o.has("tpl")) return "این فایل پشتیبان معتبر بازی نیست"
        saveExec.submit { }.get()
        if (cur.exists()) cur.copyTo(bak, overwrite = true)
        val tmp = File(dir, "save.json.tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(cur)) { cur.delete(); tmp.renameTo(cur) }
        val ok = try { load() } catch (e: Exception) { false }
        if (!ok) {
            if (bak.exists()) { bak.copyTo(cur, overwrite = true); try { load() } catch (e: Exception) { } }
            return "بازیابی ناموفق بود؛ بازی قبلی حفظ شد"
        }
        ensureWorldStructure()
        G.stack.clear()
        G.screen = "home"
        G.live = null
        G.touch()
        return null
    } catch (e: Exception) {
        if (bak.exists()) { try { bak.copyTo(cur, overwrite = true); load() } catch (x: Exception) { } }
        return "بازیابی ناموفق بود"
    }
}

fun load(): Boolean {
    try {
        val f = File(G.ctx.filesDir, "save.json")
        if (!f.exists()) return false
        val o = JSONObject(f.readText())
        G.leagues.clear(); G.teams.clear(); G.players.clear(); G.academy.clear(); G.history.clear(); G.lineup = ArrayList()
        G.nextId = o.getInt("nid")
        G.tpl = o.getInt("tpl")
        G.ppt = o.getInt("ppt")
        G.promo = o.getInt("promo")
        G.season = o.getInt("season")
        G.week = o.getInt("week")
        G.diff = o.getInt("diff")
        G.userTeam = o.getInt("user")
        G.formation = o.getString("form")
        G.style = o.getInt("style")
        G.academyCoachLevel = o.optInt("coach", 0).coerceIn(0, 5)
        G.academyTrainedSeason = o.optInt("acTrainSeason", 0)
        G.academyTrainedWeek = o.optInt("acTrainWeek", -1)
        G.cupSeason = o.optInt("cupSeason", 0); G.cupCountry = o.optString("cupCountry", "")
        G.cupRound = o.optInt("cupRound", 0); G.cupFinished = o.optBoolean("cupFinished", false)
        G.cupQualRound = o.optInt("cupQualRound", 0)
        G.cupQualFinished = o.optBoolean("cupQualFinished", false)
        G.cupFormat = o.optInt("cupFormat", 0)
        G.cupStartWeek = o.optInt("cupStartWeek", G.week)
        G.cupEntrants.clear(); o.optJSONArray("cupEntrants")?.let { a -> for (i in 0 until a.length()) G.cupEntrants.add(a.getInt(i)) }
        G.cupQualifiers.clear(); o.optJSONArray("cupQualifiers")?.let { a -> for (i in 0 until a.length()) G.cupQualifiers.add(a.getInt(i)) }
        G.cupLog.clear(); o.optJSONArray("cupLog")?.let { a -> for (i in 0 until a.length()) G.cupLog.add(a.getString(i)) }
        G.worldCupSeason = o.optInt("wcSeason", 0)
        G.worldCupRound = o.optInt("wcRound", 0)
        G.worldCupActive = o.optBoolean("wcActive", false)
        G.worldCupChampion = o.optInt("wcChampion", -1)
        G.worldCupEntrants.clear(); o.optJSONArray("wcEntrants")?.let { a -> for (i in 0 until a.length()) G.worldCupEntrants.add(a.getInt(i)) }
        G.worldCupSchedule.clear(); o.optJSONArray("wcSchedule")?.let { a ->
            for (r in 0 until a.length()) { val row = ArrayList<Pair<Int, Int>>(); val arr = a.getJSONArray(r)
                for (i in 0 until arr.length()) { val pair = arr.getJSONArray(i); row.add(pair.getInt(0) to pair.getInt(1)) }; G.worldCupSchedule.add(row) }
        }
        G.worldCupResults.clear(); o.optJSONObject("wcResults")?.let { obj -> val it = obj.keys(); while (it.hasNext()) { val k = it.next(); G.worldCupResults[k] = obj.getString(k) } }
        G.worldCupLog.clear(); o.optJSONArray("wcLog")?.let { a -> for (i in 0 until a.length()) G.worldCupLog.add(a.getString(i)) }
        G.worldVer = o.optInt("wv", 0)
        val la = o.getJSONArray("leagues")
        for (i in 0 until la.length()) {
            val j = la.getJSONObject(i)
            G.leagues.add(League(j.getInt("id"), j.getString("name"), j.getInt("level"), j.getString("country")))
        }
        val ta = o.getJSONArray("teams")
        // هویت هر باشگاه (کشور|نام) باید یکتا باشد و لوگو همیشه از همان هویت ساخته شود.
        // ۱) اگر نام ذخیره‌شده یک باشگاه رسمی همان کشور باشد، همان هویت معتبر است
        //    (لوگوی اشتباه ذخیره‌شده نادیده گرفته می‌شود و از روی نام ساخته می‌شود).
        // ۲) در غیر این صورت هویت از کلید لوگو بازیابی می‌شود.
        // ۳) ردیف تکراری به یک باشگاه رسمی آزاد از همان کشور تبدیل می‌شود؛
        //    هیچ‌وقت برچسب «تکراری» یا لوگوی باشگاه دیگر روی آن نمی‌ماند.
        val savedUserTeamId = o.optInt("user", -1)
        val loadOrder = (0 until ta.length()).sortedBy { index ->
            if (ta.getJSONObject(index).optInt("id", -1) == savedUserTeamId) 0 else 1
        }
        val dupSuffix = Regex("\\s*\\(تکراری[^)]*\\)\\s*$")
        class LoadedIdentity(val row: org.json.JSONObject, var country: String, var name: String, var leagueId: Int, val customLogo: Boolean)
        val identities = ArrayList<LoadedIdentity>()
        for (i in loadOrder) {
            val j = ta.getJSONObject(i)
            var country = j.getString("country").trim()
            var clubName = j.getString("name").trim().replace(dupSuffix, "").trim()
            var leagueId = j.getInt("lg")
            val savedLogo = j.optString("logo", "")
            val customLogo = savedLogo.isNotBlank() && !savedLogo.contains("/club_logos/")
            if (!customLogo && !isOfficialClub(country, clubName)) {
                val logoFileKey = if (savedLogo.contains("/club_logos/")) File(savedLogo).nameWithoutExtension.lowercase() else ""
                val identity = CLUB_BY_LOGO_KEY[logoFileKey]
                if (identity != null) {
                    val previousLevel = G.leagues.firstOrNull { it.id == leagueId }?.level ?: 1
                    country = identity.first
                    clubName = identity.second
                    val canonicalLeague = G.leagues.firstOrNull { it.country == country && it.level == previousLevel }
                        ?: G.leagues.firstOrNull { it.country == country }
                    if (canonicalLeague != null) leagueId = canonicalLeague.id
                }
            }
            identities.add(LoadedIdentity(j, country, clubName, leagueId, customLogo))
        }
        // نام‌های رسمی معتبرِ همه ردیف‌ها از ابتدا رزرو می‌شوند تا رفع تکرار آن‌ها را مصرف نکند.
        val usedClubKeys = HashSet<String>()
        val reservedClubKeys = HashSet<String>()
        for (id in identities) if (isOfficialClub(id.country, id.name)) reservedClubKeys.add(id.country + "|" + id.name)
        for (id in identities) {
            val key = id.country + "|" + id.name
            if (usedClubKeys.add(key)) continue
            // تکراری: ابتدا هویت لوگوی ذخیره‌شده، بعد اولین باشگاه رسمی آزاد همان کشور (هم‌سطح اولویت دارد)
            val level = G.leagues.firstOrNull { it.id == id.leagueId }?.level ?: 1
            val pools = if (level == 1) listOf(REAL_CLUBS[id.country].orEmpty(), LOWER_CLUBS[id.country].orEmpty())
                        else listOf(LOWER_CLUBS[id.country].orEmpty(), REAL_CLUBS[id.country].orEmpty())
            var replacement: String? = null
            if (!id.customLogo) {
                val savedLogo = id.row.optString("logo", "")
                val lk = if (savedLogo.contains("/club_logos/")) File(savedLogo).nameWithoutExtension.lowercase() else ""
                CLUB_BY_LOGO_KEY[lk]?.let { (c, n) ->
                    val k = "$c|$n"
                    if (c == id.country && k !in usedClubKeys && k !in reservedClubKeys) replacement = n
                }
            }
            if (replacement == null) {
                for (pool in pools) {
                    replacement = pool.firstOrNull { n -> val k = id.country + "|" + n; k !in usedClubKeys && k !in reservedClubKeys }
                    if (replacement != null) break
                }
            }
            if (replacement == null) {
                var n = 2
                while (usedClubKeys.contains(id.country + "|" + id.name + " " + n)) n++
                replacement = id.name + " " + n
            }
            id.name = replacement!!
            usedClubKeys.add(id.country + "|" + id.name)
        }
        for (id in identities) {
            val j = id.row
            val savedLogo = j.optString("logo", "")
            val logoPath = if (id.customLogo) savedLogo else clubLogoPath(id.country, id.name)
            val t = Team(
                j.getInt("id"), id.name, id.country, id.leagueId,
                j.getLong("c1"), j.getLong("c2"), j.getInt("st"),
                logoPath, j.getLong("bud")
            )
            t.p = j.getInt("p")
            t.w = j.getInt("w")
            t.d = j.getInt("d")
            t.l = j.getInt("l")
            t.gf = j.getInt("gf")
            t.ga = j.getInt("ga")
            t.pts = j.getInt("pts")
            t.allPts = j.getInt("ap")
            t.titles = j.getInt("ti")
            G.teams.add(t)
        }
        val pa = o.getJSONArray("players")
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i)
            G.players.add(
                Player(
                    j.getInt("id"), j.getString("n"), j.getString("pos"), j.getInt("r"), j.getInt("a"),
                    j.getInt("t"), j.getLong("v"), j.getInt("g"), j.getInt("tg"), j.optString("c", G.teamOrNull(j.getInt("t"))?.country ?: "ایران")
                )
            )
        }
        o.optJSONArray("academy")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                G.academy.add(AcademyPlayer(j.getInt("id"), j.getString("n"), j.getString("pos"), j.getInt("r"), j.getInt("a"), j.getInt("t"), j.getInt("pot"), j.getString("c")))
            }
        }
        val ha = o.getJSONArray("hist")
        for (i in 0 until ha.length()) G.history.add(ha.getString(i))
        G.matchLog.clear(); G.seasonSums.clear(); G.compNames.clear()
        o.optJSONArray("cn")?.let { a -> for (i in 0 until a.length()) G.compNames.add(a.getString(i)) }
        if (G.compNames.isEmpty()) G.compNames.add("لیگ")
        o.optJSONArray("ml")?.let { a ->
            for (i in 0 until a.length()) {
                val p = a.getString(i).split(",")
                if (p.size >= 7) G.matchLog.add(MatchRec(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), p[6].toInt()))
            }
        }
        o.optJSONArray("ss")?.let { a ->
            for (i in 0 until a.length()) {
                val p = a.getString(i).split("~")
                if (p.size >= 11) G.seasonSums.add(SeasonSum(p[0].toInt(), p[1].toInt(), p[2], p[3].toInt(), p[4].toInt(), p[5].toInt(), p[6].toInt(), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt()))
            }
        }
        if (o.optJSONArray("ml") == null) migrateLegacyMatches(o)
        val lu = o.getJSONArray("lineup")
        for (i in 0 until lu.length()) G.lineup.add(lu.getInt(i))
        G.news.clear(); G.offers.clear(); G.live = null
        o.optJSONArray("news")?.let { a -> for (i in 0 until a.length()) G.news.add(a.getString(i)) }
        o.optJSONArray("offers")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                G.offers.add(Offer(j.getInt("p"), j.getInt("f"), j.getLong("v")))
            }
        }
        G.screen = if (G.teamOrNull(G.userTeam) == null) "pick" else "home"
        G.stack.clear()
        return G.leagues.isNotEmpty()
    } catch (e: Exception) {
        return false
    }
}

// ======================= ساخت دنیا =======================

fun worth(r: Int, age: Int): Long {
    // قیمت‌گذاری متعادل‌تر: اورال و سن هر دو اثر محسوس دارند.
    val b = (r - 32).coerceAtLeast(1).toLong()
    val base = b * b * 5_500L
    val ageFactor = when {
        age < 21 -> 150L
        age < 24 -> 135L
        age <= 29 -> 115L
        age <= 32 -> 95L
        else -> 70L
    }
    return (base * ageFactor / 100L).coerceAtLeast(100_000L)
}

fun posPlan(n: Int): List<String> {
    val cyc = listOf("DF", "MF", "FW", "DF", "MF", "DF", "MF", "FW")
    val out = ArrayList<String>()
    repeat(if (n >= 20) 3 else 2) { out.add("GK") }
    var i = 0
    while (out.size < n) {
        out.add(cyc[i % cyc.size])
        i++
    }
    return out
}

fun genPlayer(tid: Int, country: String, pos: String, base: Int): Player {
    val f = FIRST[country] ?: FIRST.getValue("ایران")
    val l = LAST[country] ?: LAST.getValue("ایران")
    val r = (base + Random.nextInt(-8, 9)).coerceIn(40, 92)
    val age = Random.nextInt(18, 35)
    return Player(G.nid(), "${f.random()} ${l.random()}", pos, r, age, tid, worth(r, age), country = country)
}

fun genAcademyPlayer(t: Team, age: Int = Random.nextInt(14, 18)): AcademyPlayer {
    val f = FIRST[t.country] ?: FIRST.getValue("ایران")
    val l = LAST[t.country] ?: LAST.getValue("ایران")
    val pos = listOf("GK", "DF", "MF", "FW").random()
    val rating = Random.nextInt(55, 71)
    val potential = (rating + Random.nextInt(8, 25)).coerceIn(65, 91)
    return AcademyPlayer(G.nid(), "${f.random()} ${l.random()}", pos, rating, age, t.id, potential, t.country)
}

val OLD_STAR_NAMES = setOf(
    "Kylian Mbappe", "Erling Haaland", "Lionel Messi", "Cristiano Ronaldo", "Lamine Yamal", "Jude Bellingham",
    "Vinicius Junior", "Kevin De Bruyne", "Mohamed Salah", "Virgil van Dijk", "Harry Kane", "Robert Lewandowski"
)

// ستاره‌های واقعی را در باشگاه واقعی خودشان قرار می‌دهد (بازیکن بدون باشگاه: بازار آزاد)
fun addRealStars() {
    val byName = HashMap<String, Team>()
    for (t in G.teams) {
        val lg = G.leagues.firstOrNull { it.id == t.leagueId }
        if (lg != null && lg.level == 1) byName[t.name] = t
    }
    val existing = G.players.mapTo(HashSet()) { it.name }
    for (st in REAL_STARS) {
        if (st.name in existing) continue
        var tid = -1
        if (st.club != "-") {
            val t = byName[st.club] ?: continue
            tid = t.id
            val sq = squad(t.id)
            val minKeep = if (st.pos == "GK") 2 else 3
            if (sq.size >= G.ppt && sq.count { it.pos == st.pos } > minKeep) {
                sq.filter { it.pos == st.pos && it.name !in STAR_NAMES }.minByOrNull { it.rating }?.let { G.players.remove(it) }
            }
        }
        G.players.add(Player(G.nid(), st.name, st.pos, st.rating, st.age, tid, worth(st.rating, st.age), country = st.nat))
        existing.add(st.name)
    }
}

val LOWER_CLUBS: Map<String, List<String>> = mapOf(
    "ایران" to listOf("هوادار", "نفت مسجدسلیمان", "پارس جنوبی جم", "مس کرمان", "نفت و گاز گچساران", "آریو اسلامشهر", "بعثت کرمانشاه", "جزیره قشم", "شاهین بندر عامری", "فرد البرز", "فولاد نوین خوزستان", "نیروی زمینی", "پالایش نفت بندرعباس", "کاراگستر شبستر", "سپیدرود رشت", "داماش گیلان", "چوکا تالش", "نفت اهواز", "ایرانجوان بوشهر", "شهرداری بندرعباس", "ذوب‌آهن ب", "استقلال ب", "سپاهان ب", "فولاد هرمزگان", "شهرداری نوشهر", "برق شیراز", "دنا یاسوج", "رخش خودرو تبریز", "شاهین تهران", "شهرداری ماهشهر", "فجر قزوین", "نفت و گاز غرب ایلام", "نود ارومیه", "پادیاب خلخال", "پرواز سیمرغ", "آسمان گلستان", "رضوانی اصفهان", "شایان دیزل فارس", "شهرآرکا البرز", "شهید قندی یزد", "ملوان بوشهر", "کشاورز رباط‌کریم", "مس سونگون", "استقلال ملاثانی", "ماشین‌سازی تبریز", "گیتی‌پسند اصفهان", "شهرداری آستارا", "شهرداری ساوه", "شهرداری فومن", "قشقایی شیراز", "ابومسلم خراسان", "پتروکیان شوشتر", "الوند همدان", "شهرداری ارومیه", "شهرداری اراک", "شهرداری یاسوج", "کاسپین قزوین", "اکسین البرز", "پارسه تهران", "نفت تهران"),
    "انگلیس" to listOf("وستهم", "ولورهمپتون", "ساوتهمپتون", "برنلی", "شفیلد یونایتد", "میدلزبرو", "نوریچ سیتی", "وست برومویچ", "واتفورد", "بیرمنگام سیتی", "بلاکبرن روورز", "استوک سیتی", "دربی کانتی", "بریستول سیتی", "سوانسی سیتی", "کاردیف سیتی", "کوئینز پارک رنجرز", "پرستون نورث‌اند", "میلوال", "پورتسموث", "بولتون واندررز", "چارلتون اتلتیک", "رکسهام", "لینکلن سیتی", "لوتون تاون", "ردینگ", "ویگان اتلتیک", "بارنزلی", "پلیموث آرگایل", "هادرزفیلد تاون", "پیتربورو یونایتد", "اکستر سیتی", "استاکپورت کانتی", "برادفورد سیتی", "منسفیلد تاون", "روترهام یونایتد", "لیتون اورینت", "وایکامب واندررز", "کمبریج یونایتد", "نورثهمپتون تاون", "استیونیج", "برتون آلبیون", "بلکپول", "کرولی تاون", "بریستول روورز", "دانکستر روورز", "ای‌اف‌سی ویمبلدون", "ناتس کانتی", "چسترفیلد", "والسال", "گریمزبی تاون", "کرو الکساندرا", "پورت ویل", "سالفورد سیتی", "سویندون تاون", "گیلینگهام", "کولچستر یونایتد", "برومیلی", "بارو", "هارگیت تاون", "ترانمیر روورز", "فلیت‌وود تاون", "چلتنهام تاون", "نیوپورت کانتی"),
    "اسپانیا" to listOf("خیرونا", "مایورکا", "لاس پالماس", "گرانادا", "رئال وایادولید", "کادیس", "آلمریا", "لگانس", "رئال اویدو", "اسپورتینگ خیخون", "تنریف", "ایبار", "کاستیون", "کوردوبا", "آندورا", "بورگوس", "آلباسته", "سابادل", "الدنسه", "سئوتا", "زاراگوزا", "هوئسکا", "میراندس", "راسینگ فرول", "مورسیا", "کولتورال لئونسا", "رئال سوسیداد ب", "ویارئال ب", "بارسلونا ب", "لوگو", "پونفرادینا", "الخسیراس", "آنتکرا", "ترول", "آرنتیرو", "اونیونیستاس", "هرکولس", "مریدا", "رئال اونیون", "اتلتیکو مادرید ب"),
    "ایتالیا" to listOf("سمپدوریا", "پالرمو", "ورونا", "امپولی", "کرمونزه", "پیزا", "بنونتو", "کاتانزارو", "چزنا", "مودنا", "آولینو", "پادوا", "ویچنزا", "مانتوا", "آرتزو", "آسکولی", "کارارزه", "یوونتوس استابیا", "ویرتوس انتلا", "سودتیرول", "برشا", "پروجا", "باری", "ترنانا", "رجیانا", "اسپتزیا", "کروتونه", "پسکارا", "تریستینا", "تورس", "لوکزه", "فوجا", "لکو", "تراپانی", "مسینا", "چریگنولا", "کازرتانا", "لاتینا", "پونتدرا", "پیاچنزا"),
    "آلمان" to listOf("هانوفر ۹۶", "هرتابرلین", "کایزرسلاوترن", "نورنبرگ", "بوخوم", "هایدنهایم", "هولشتاین کیل", "دارمشتات", "کارلسروهه", "مگدبورگ", "دینامو درسدن", "براونشوایگ", "ارمینیا بیلفلد", "گروتر فورت", "انرژی کوتبوس", "اوسنابروک", "فورتونا دوسلدورف", "اسن", "وهن ویسبادن", "یان رگنسبورگ", "ساندهاوزن", "هانزا روستوک", "پروسن مونستر", "مونیخ ۱۸۶۰", "زاربروکن", "ویکتوریا کلن", "والدهوف مانهایم", "دویسبورگ", "اولم", "اروتسگبیرگه آئو", "فرل", "لوبک", "اونترهاخینگ", "بایروت", "اولدنبورگ", "هاولسه", "آلمانیا آخن", "بروسیا دورتموند ب", "اشتوتگارت ب", "هوفنهایم ب"),
    "فرانسه" to listOf("سن‌اتین", "مون‌پلیه", "ریمز", "کلرمون فوت", "گنگام", "گرونوبل", "سوشو", "دیژون", "نانسی", "دانکرک", "آنسی", "بولون", "پو", "رد استار", "رودز", "لاوال", "بوردو", "کاین", "آمیان", "بستیا", "والنسین", "نیور", "کوویی‌رون", "ورسای", "کنکارنو", "اورلئان", "پاری ۱۳", "شاتورو", "ویلفرانش", "سدان", "کن", "نیم", "مارتیگ", "فلوری", "بورگ‌آن‌برس", "لیون لا دوشر", "لوپوی", "آنگولم", "شربورگ", "سن‌مالو"),
    "برزیل" to listOf("فورتالزا", "سیارا", "کویابا", "گوییاس", "اسپورت رسیف", "آمریکا مینیرو", "اتلتیکو گویانینسه", "ژوونتوده", "کریسیوما", "پونته پرتا", "ناوتیکو", "آوای", "ویلا نوا", "نووریزونتینو", "بوتافوگو اس‌پی", "اوپراریو", "سی‌آرب", "اتلتیک کلوبه", "ساو برناردو", "لوندرینا", "ایپیرانگا", "ولتا ردونده", "فیگوئیرنسه", "بوتافوگو پی‌بی", "پایسندو", "فروویاریا", "برسکه", "آ‌ب‌ث", "کونفیانسا", "مارینگا", "سانتا کروز", "تومبنسه", "فلورستا", "کاشیاس", "ایتابایانا", "آپارسیدنسه", "ساو خوزه", "کامپینینسه", "آناپولیس", "ترزه"),
    "ترکیه" to listOf("آدانا دمیرسپور", "هاتای‌اسپور", "بودروم‌اسپور", "کایسری‌اسپور", "بورسا‌اسپور", "آلتای", "بولوسپور", "آدناسپور", "ساکاریاسپور", "اومرانیه‌اسپور", "کچی‌اورنگوچو", "باندیرماسپور", "شانلی‌اورفا", "دنیزلی‌اسپور", "اسکی‌شهیرسپور", "کاراگومروک", "مانیساسپور", "وان‌اسپور", "پندیک‌اسپور", "ایستانبول‌اسپور", "ایگدیر‌اسپور", "سریک بلدیه‌اسپور", "بایبورت اوزل ایداره", "مرسین ایدمان یورتو", "گیرسون‌اسپور", "ایسپارتا‌اسپور", "اوشاک‌اسپور", "کارشیاکا", "اینه‌گول‌اسپور", "زونگولداک‌اسپور", "تکیردا‌اسپور", "مالاتیا‌اسپور", "فتحیه‌اسپور", "آماسیا‌اسپور", "نیغده آنادولوسپور", "ازمیر‌اسپور", "بیلجیک‌اسپور", "اسنیورت", "مرزیفون‌اسپور", "کرکلارئلی‌اسپور"),
    "آرژانتین" to listOf("ایندیپندینته ریوادابیا", "اتلتیکو توکومان", "اینستیتوتو", "سنترال کوردوبا", "باراکاس سنترال", "سارمینتو", "آلدوسیوی", "دپورتیوو ریسترا", "خیمناسیا مندوزا", "استودیانتس ریو کوارتو", "کولون", "گودوی کروز", "پاترونه", "کویلمس", "فرروکاریل اوئسته", "چاکاریتا جونیورز", "سان مارتین توکومان", "گیلرمو براون", "آتلانتا", "نوئوا شیکاگو"),
    "پرتغال" to listOf("آکادمیکا کویمبرا", "پنافیل", "لایشوئش", "فیرنزه", "اولیوییرنزه", "مافرا", "وارزیم", "توندلا", "پاکوش فریرا", "چاوز", "لوزیتانیا", "ویلافرانکنزه", "تورینسه", "ویتوریا ستوبال", "بنفیکا بی", "پورتو بی", "اسپورتینگ بی", "ویزلا", "اوینیون لیریا", "سالگیروش"),
    "هلند" to listOf("رودا جی‌سی", "ام‌وی‌وی ماستریخت", "دی گرافشاپ", "ویتس آرنهم", "دوردراخت", "اف‌سی آیندهوون", "هلموند اسپورت", "دن بوش", "آلمره سیتی", "والویک", "ونلو", "اوس", "یانگ آژاکس", "یانگ پی‌اس‌وی", "یانگ اوترخت", "یانگ آلکمار", "اف‌سی امن", "کاتویک", "وولندام", "اسپاکنبرگ")
)

fun uniqueName(country: String, leagueId: Int): String {
    val league = G.leagues.firstOrNull { it.id == leagueId }
    val clubs = if (league?.level == 1) REAL_CLUBS[country].orEmpty() else LOWER_CLUBS[country].orEmpty()
    val usedNames = G.teams.map { it.name }.toSet()
    clubs.firstOrNull { it !in usedNames }?.let { return it }
    val a = CLUB_A[country] ?: NAME_A
    val b = CLUB_B[country] ?: NAME_B
    repeat(300) {
        val n = "${a.random()} ${b.random()}"
        if (G.teams.none { it.name == n }) return n
    }
    return "باشگاه ${G.nextId}"
}

fun newTeam(lg: League): Team {
    val clubName = uniqueName(lg.country, lg.id)
    val t = Team(G.nid(), clubName, lg.country, lg.id, PAL.random(), PAL.random(), Random.nextInt(4), clubLogoPath(lg.country, clubName), 20_000_000L)
    while (t.c2 == t.c1) t.c2 = PAL.random()
    G.teams.add(t)
    val bonus = if (lg.country == "ایران") 2 else 6
    val boost = realisticClubBoost(t.name, lg.country, lg.level)
    // First-division squads should feel stronger, with a clearer gap between tiers.
    val base = 74 + bonus - (lg.level - 1) * 7 + boost + (if (boost > 0) Random.nextInt(-2, 3) else Random.nextInt(-5, 6))
    for (pos in posPlan(G.ppt)) G.players.add(genPlayer(t.id, t.country, pos, base))
    repeat(5) { G.academy.add(genAcademyPlayer(t, Random.nextInt(14, 18))) }
    return t
}

fun lgSorted(): List<League> = G.leagues.sortedWith(compareBy({ COUNTRIES.indexOf(it.country) }, { it.level }))

// برای باشگاه‌هایی که در فهرست ستاره‌های اختصاصی نیستند نیز قدرت پایه بر اساس جایگاه واقعی‌شان تنظیم می‌شود.
fun realisticClubBoost(name: String, country: String, level: Int): Int {
    if (level == 1) {
        CLUB_BOOST[name]?.let { return it }
        val rank = REAL_CLUBS[country].orEmpty().indexOf(name)
        return when {
            rank in 0..2 -> 5
            rank in 3..5 -> 3
            rank in 6..9 -> 2
            rank in 10..13 -> 1
            else -> 0
        }
    }
    if (level == 2) {
        val rank = LOWER_CLUBS[country].orEmpty().indexOf(name)
        return when {
            rank in 0..2 -> 3
            rank in 3..6 -> 2
            rank in 7..11 -> 1
            else -> 0
        }
    }
    // در دسته‌های پایین‌تر، اختلاف قدرت عمدتاً از سطح لیگ می‌آید.
    return 0
}

fun cntryOf(t: Team): String = G.leagues.firstOrNull { it.id == t.leagueId }?.country ?: t.country

fun addNews(x: String) {
    G.news.add(x)
    while (G.news.size > 80) G.news.removeAt(0)
}

fun newWorld() {
    G.leagues.clear(); G.teams.clear(); G.players.clear(); G.academy.clear(); G.history.clear(); G.matchLog.clear(); G.seasonSums.clear(); G.compNames.clear(); G.compNames.add("لیگ")
    G.lineup = ArrayList(); G.report.clear(); G.stack.clear()
    G.news.clear(); G.offers.clear(); G.live = null; G.liveQueue.clear()
    G.msg = ""; G.userTeam = -1; G.season = 1; G.week = 0; G.nextId = 1
    G.academyCoachLevel = 0
    G.academyTrainedSeason = 0
    G.academyTrainedWeek = -1
    G.cupSeason = 0; G.cupCountry = ""; G.cupRound = 0; G.cupFinished = false
    G.worldCupSeason = 0; G.worldCupEntrants.clear(); G.worldCupSchedule.clear(); G.worldCupResults.clear(); G.worldCupLog.clear(); G.worldCupRound = 0; G.worldCupActive = false; G.worldCupChampion = -1
    G.cupEntrants.clear(); G.cupQualifiers.clear(); G.cupQualRound = 0
    G.cupQualFinished = false; G.cupFormat = 0; G.cupStartWeek = 0; G.cupLog.clear()
    G.tpl = 20; G.ppt = 25; G.promo = 3
    for ((country, names) in LEAGUE_DEFS) {
        for ((i, n) in names.withIndex()) {
            val lg = League(G.nid(), n, i + 1, country)
            G.leagues.add(lg)
            repeat(G.tpl) { newTeam(lg) }
        }
    }
    addRealStars()
    applyFamousRatings()
    G.worldVer = 4
    G.screen = "pick"
}

// ======================= منطق بازی =======================

fun squad(tid: Int): List<Player> = G.squadOf(tid)

fun squadAvg(t: Team): Int {
    val sq = squad(t.id)
    return if (sq.isEmpty()) 62 else sq.map { it.rating }.average().toInt()
}

fun strengthOf(t: Team): Int {
    val top = squad(t.id).map { it.rating }.sortedDescending().take(14)
    return if (top.isEmpty()) 0 else top.average().toInt()
}

// محاسبه قدرت همه تیم‌ها با یک بار گروه‌بندی بازیکنان؛ از فیلتر کردن کل بازیکنان برای تک‌تک تیم‌ها جلوگیری می‌کند.
fun strengthsByTeam(): Map<Int, Int> {
    return G.teams.associate { team ->
        val top = squad(team.id).map { it.rating }.sortedDescending().take(14)
        team.id to if (top.isEmpty()) 0 else top.average().toInt()
    }
}

fun autoLineup(tid: Int, fm: String): List<Player> {
    val n = fm.split("-").map { it.toInt() }
    val sq = squad(tid).sortedByDescending { it.rating }
    val res = ArrayList<Player>()
    res.addAll(sq.filter { it.pos == "GK" }.take(1))
    res.addAll(sq.filter { it.pos == "DF" }.take(n[0]))
    res.addAll(sq.filter { it.pos == "MF" }.take(n[1]))
    res.addAll(sq.filter { it.pos == "FW" }.take(n[2]))
    if (res.size < 11) {
        val rest = sq.filter { it !in res }.take(11 - res.size)
        res.addAll(rest)
    }
    return res
}

fun lineupOf(t: Team): List<Player> {
    if (t.id != G.userTeam) return autoLineup(t.id, FORMS[t.id % 3])
    val mine = squad(t.id)
    val l = G.lineup.mapNotNull { id -> mine.firstOrNull { it.id == id } }.take(11)
    if (l.size == 11) return l
    return l + autoLineup(t.id, G.formation).filter { it !in l }.take(11 - l.size)
}

fun styleOf(t: Team): Int = if (t.id == G.userTeam) G.style else 1

fun strength(lu: List<Player>, style: Int): DoubleArray {
    fun avg(a: String, b: String): Double {
        val l = lu.filter { it.pos == a || it.pos == b }
        return if (l.isEmpty()) 50.0 else l.map { it.rating }.average()
    }
    val att = avg("FW", "FW") * 0.6 + avg("MF", "MF") * 0.4
    val def = avg("GK", "DF") * 0.7 + avg("MF", "MF") * 0.3
    val sa = 1.0 + (style - 1) * 0.05
    val sd = 1.0 - (style - 1) * 0.05
    return doubleArrayOf(att * sa, def * sd)
}

fun poisson(l: Double): Int {
    val lim = exp(-l)
    var k = 0
    var p = 1.0
    do {
        k++
        p *= Random.nextDouble()
    } while (p > lim)
    return k - 1
}

fun pickScorer(lu: List<Player>): Player {
    val ws = lu.map {
        val w = when (it.pos) {
            "FW" -> 6.0
            "MF" -> 3.0
            "DF" -> 1.0
            else -> 0.05
        }
        w * it.rating
    }
    var r = Random.nextDouble() * ws.sum()
    for (i in lu.indices) {
        r -= ws[i]
        if (r <= 0) return lu[i]
    }
    return lu.last()
}

// نرخ گل مورد انتظار دو تیم (میزبان، میهمان)
fun goalRates(h: Team, a: Team): Pair<Double, Double> {
    val hl = lineupOf(h)
    val al = lineupOf(a)
    val hs = strength(hl, styleOf(h))
    val aw = strength(al, styleOf(a))
    val f = doubleArrayOf(1.15, 1.0, 0.87)[G.diff]
    var hx = 1.35 * 1.1 * (hs[0] / aw[1]).pow(3.0)
    var ax = 1.35 * (aw[0] / hs[1]).pow(3.0)
    if (h.id == G.userTeam) {
        hx *= f; ax /= f
    } else if (a.id == G.userTeam) {
        ax *= f; hx /= f
    }
    return Pair(hx.coerceIn(0.2, 4.5), ax.coerceIn(0.2, 4.5))
}

// نتیجه موقت (بدون ثبت گلزن) برای مسابقه‌ای که زنده بازی می‌شود؛ بعد از پایان بازی زنده با نتیجه واقعی جایگزین می‌شود.
fun provisionalScore(h: Team, a: Team): Pair<Int, Int> {
    val r = goalRates(h, a)
    return Pair(poisson(r.first), poisson(r.second))
}

fun playMatch(h: Team, a: Team, live: Boolean = false, deferTableUpdate: Boolean = false): MatchRes {
    val hl = lineupOf(h)
    val al = lineupOf(a)
    val rates = goalRates(h, a)
    val hx = rates.first
    val ax = rates.second
    val hg = if (live) 0 else poisson(hx)
    val ag = if (live) 0 else poisson(ax)
    val ev = ArrayList<Ev>()
    if (!live) {
        repeat(hg) {
            val scorer = pickScorer(hl)
            scorer.goals++; scorer.total++
            ev.add(Ev(Random.nextInt(1, 91), "⚽ گل! ${scorer.name} (${h.name})", 0, scorer.id))
        }
        repeat(ag) {
            val scorer = pickScorer(al)
            scorer.goals++; scorer.total++
            ev.add(Ev(Random.nextInt(1, 91), "⚽ گل! ${scorer.name} (${a.name})", 1, scorer.id))
        }
    } else {
        ev.add(Ev(0, "▶️ سوت شروع بازی", 2))
    }
    val result = MatchRes(h, a, hg, ag, ev.sortedBy { it.min })
    if (live) {
        result.homeGoalRate = hx
        result.awayGoalRate = ax
    }
    if (!deferTableUpdate) applyMatchTableResult(result)
    return result
}

fun applyMatchTableResult(m: MatchRes) {
    if (m.tableApplied) return
    val h = m.h
    val a = m.a
    h.p++; a.p++
    h.gf += m.hg; h.ga += m.ag
    a.gf += m.ag; a.ga += m.hg
    if (m.hg > m.ag) { h.w++; h.pts += 3; a.l++ }
    else if (m.hg < m.ag) { a.w++; a.pts += 3; h.l++ }
    else { h.d++; a.d++; h.pts++; a.pts++ }
    m.tableApplied = true
}

// هر دقیقه مسابقه به‌صورت مستقل اجرا می‌شود؛ گل‌ها و رویدادها هنگام رسیدن دقیقه ثبت می‌شوند.
fun advanceLiveMatch(m: MatchRes, minute: Int) {
    if (m.finalized || minute <= 0 || minute <= m.lastAdvancedMinute) return
    val current = minute.coerceIn(1, 90)
    for (min in (m.lastAdvancedMinute + 1)..current) {
        if (min == 45) m.ev = (m.ev + Ev(45, "⏸ پایان نیمه اول", 2)).sortedBy { it.min }
        if (min == 90) {
            m.ev = (m.ev + Ev(90, "🏁 سوت پایان بازی", 2)).sortedBy { it.min }
            continue
        }
        if (Random.nextDouble() < (m.homeGoalRate / 90.0).coerceIn(0.0, 0.12)) {
            val scorer = pickScorer(lineupOf(m.h))
            m.hg++
            m.ev = (m.ev + Ev(min, "⚽ گل! ${scorer.name} (${m.h.name})", 0, scorer.id)).sortedBy { it.min }
        }
        if (Random.nextDouble() < (m.awayGoalRate / 90.0).coerceIn(0.0, 0.12)) {
            val scorer = pickScorer(lineupOf(m.a))
            m.ag++
            m.ev = (m.ev + Ev(min, "⚽ گل! ${scorer.name} (${m.a.name})", 1, scorer.id)).sortedBy { it.min }
        }
        if (Random.nextDouble() < 0.075) {
            val home = Random.nextBoolean()
            val team = if (home) m.h else m.a
            val lu = lineupOf(team)
            val text = when (Random.nextInt(4)) {
                0 -> "🔥 موقعیت خطرناک برای ${team.name}"
                1 -> "🟨 کارت زرد برای ${lu.random().name} (${team.name})"
                2 -> "🧤 واکنش زیبای دروازه‌بان ${team.name}"
                else -> "💨 شوت ${pickScorer(lu).name} به بیرون رفت"
            }
            m.ev = (m.ev + Ev(min, text, 2)).sortedBy { it.min }
        }
    }
    m.lastAdvancedMinute = current
    G.rev++
}

// نتیجه مسابقه زنده فقط پس از رسیدن دقیقه به ۹۰ نهایی می‌شود.
fun finalizeLiveMatch(m: MatchRes) {
    if (m.finalized) return
    m.ev.filter { it.scorerId >= 0 }.forEach { event ->
        G.players.firstOrNull { it.id == event.scorerId }?.let { player ->
            player.goals++
            player.total++
        }
    }
    if (m.affectsLeague && !m.tableApplied) applyMatchTableResult(m)
    // مسابقه حذفی مساوی: ضربات پنالتی
    if (m.knockout && m.hg == m.ag) resolveShootout(m)
    m.finalized = true
    G.liveAffectsLeague = false
    syncMatchRec(m)
    val prefix = if (m.tag.isNotBlank()) "${m.tag}: " else ""
    val line = "$prefix${m.h.name}  ${m.hg} - ${m.ag}  ${m.a.name}${shootoutSuffix(m)}"
    val reportIndex = G.report.indexOfFirst { it.contains(m.h.name) && it.contains(m.a.name) && it.contains(" - ") }
    if (reportIndex >= 0) G.report[reportIndex] = line else G.report.add(line)
    G.report.addAll(m.ev.filter { it.side < 2 }.map { "${it.min}' ${it.text}" })
    G.msg = "🏁 نتیجه نهایی: ${m.h.name} ${m.hg} - ${m.ag} ${m.a.name}${shootoutSuffix(m)}"
    m.onFinal?.invoke(m)
    m.onFinal = null
    G.touch()
    saveNow()
}

fun resolveInteractivePenalty(target: Int, power: Float) {
    val m = G.pendingPenaltyMatch ?: return
    val keeperTarget = Random.nextInt(1, 10)
    val side = G.penaltySide
    val team = if (side == 0) m.h else m.a
    val opponent = if (side == 0) m.a else m.h
    val keeper = lineupOf(opponent).firstOrNull { it.pos == "GK" }
    val keeperRating = keeper?.rating ?: 60
    val shooter = lineupOf(team).filter { it.pos == "FW" || it.pos == "MF" }.maxByOrNull { it.rating }
        ?: lineupOf(team).first()
    val keeperReach = (keeperRating - 60).coerceAtLeast(0) / 100f
    val scored = if (target == keeperTarget) {
        Random.nextFloat() > (0.58f + keeperReach).coerceAtMost(0.82f) * (0.55f + power * 0.45f)
    } else {
        Random.nextFloat() < (0.76f - keeperReach * 0.18f) * (1.05f - power * 0.12f)
    }
    val minute = Random.nextInt(12, 89)
    if (scored) {
        if (side == 0) m.hg++ else m.ag++
        m.ev = (m.ev + Ev(minute, "⚽ پنالتی گل شد! ${shooter.name}", side, if (G.penaltyReturnScreen == "live") shooter.id else -1)).sortedBy { it.min }
        if (G.penaltyReturnScreen != "live") { shooter.goals++; shooter.total++; m.finalized = true }
        G.report.add("⚽ پنالتی گل شد؛ ${shooter.name} موفق شد.")
    } else {
        m.ev = (m.ev + Ev(minute, "🧤 پنالتی مهار شد؛ ${keeper?.name ?: "دروازه‌بان"} توپ را گرفت", 2)).sortedBy { it.min }
        G.report.add("🧤 پنالتی مهار شد؛ دروازه‌بان ${opponent.name} موفق بود.")
    }
    applyMatchTableResult(m)
    syncMatchRec(m)
    val penIdx = G.report.indexOfFirst { it.contains(m.h.name) && it.contains(m.a.name) && it.contains(" - ") }
    if (penIdx >= 0) G.report[penIdx] = "${m.h.name}  ${m.hg} - ${m.ag}  ${m.a.name}"
    G.live = m
    G.msg = "🏁 نتیجه مسابقه شما: ${m.h.name} ${m.hg} - ${m.ag} ${m.a.name}"
    G.pendingPenaltyMatch = null
    if (G.stack.isNotEmpty()) G.stack.removeAt(G.stack.lastIndex)
    G.screen = G.penaltyReturnScreen
    G.touch()
}

private val fixCache = HashMap<Int, Pair<List<Int>, List<List<Pair<Int, Int>>>>>()

fun fixturesFor(lid: Int): List<List<Pair<Int, Int>>> {
    val key = G.teams.filter { it.leagueId == lid }.map { it.id }.sorted()
    val c = fixCache[lid]
    if (c != null && c.first == key) return c.second
    val r = buildFixtures(key)
    fixCache[lid] = key to r
    return r
}

private fun buildFixtures(sortedIds: List<Int>): List<List<Pair<Int, Int>>> {
    val ids = sortedIds.toMutableList()
    if (ids.size % 2 == 1) ids.add(-1)
    val n = ids.size
    val rounds = ArrayList<List<Pair<Int, Int>>>()
    val arr = ids.toMutableList()
    for (r in 0 until n - 1) {
        val m = ArrayList<Pair<Int, Int>>()
        for (i in 0 until n / 2) {
            val a = arr[i]
            val b = arr[n - 1 - i]
            if (a != -1 && b != -1) m.add(if (r % 2 == 0) Pair(a, b) else Pair(b, a))
        }
        rounds.add(m)
        val last = arr.removeAt(n - 1)
        arr.add(1, last)
    }
    val second = rounds.map { rd -> rd.map { Pair(it.second, it.first) } }
    return rounds + second
}

// طول فصل: ۴۵ هفته (۳۸ هفته لیگ + ۷ هفته پایانی مخصوص مراحل آخر جام حذفی و لیگ قهرمانان)
fun totalWeeks(): Int = Cal.total()

fun table(lid: Int): List<Team> =
    G.teams.filter { it.leagueId == lid }.sortedWith(
        compareByDescending<Team> { it.pts }
            .thenByDescending { it.gf - it.ga }
            .thenByDescending { it.gf }
            .thenBy { it.name }
    )

fun compIdx(name: String): Int {
    val i = G.compNames.indexOf(name)
    if (i >= 0) return i
    G.compNames.add(name)
    return G.compNames.lastIndex
}

fun logMatch(comp: String, h: Team, a: Team, hg: Int, ag: Int) {
    G.matchLog.add(MatchRec(G.season, G.week + 1, compIdx(comp), h.id, a.id, hg, ag))
}

// نتیجه مسابقه زنده/پنالتی پس از نهایی شدن در تاریخچه هم به‌روز می‌شود.
fun syncMatchRec(m: MatchRes) {
    val i = G.matchLog.indexOfLast { it.season == G.season && it.hid == m.h.id && it.aid == m.a.id }
    if (i >= 0) { G.matchLog[i].hg = m.hg; G.matchLog[i].ag = m.ag }
}

// انتقال تاریخچه‌های قدیمی (متنی) به ساختار جدید در سیوهای قبلی
fun migrateLegacyMatches(o: org.json.JSONObject) {
    val byName = HashMap<String, Int>()
    for (t in G.teams) byName.putIfAbsent(t.name, t.id)
    val lines = LinkedHashSet<String>()
    val doubled = Regex("^فصل \\d+ \\| (فصل \\d+ \\| هفته .*)$")
    for (h in G.history) doubled.find(h)?.let { lines.add(it.groupValues[1]) }
    o.optJSONArray("matchHist")?.let { a -> for (i in 0 until a.length()) lines.add(a.getString(i)) }
    o.optJSONArray("seasonMatches")?.let { a -> for (i in 0 until a.length()) lines.add(a.getString(i)) }
    val rx = Regex("^فصل (\\d+) \\| هفته (\\d+) \\| (.+) (\\d+) - (\\d+) (.+)$")
    val seen = HashSet<String>()
    for (ln in lines) {
        val m = rx.find(ln) ?: continue
        val hid = byName[m.groupValues[3]] ?: continue
        val aid = byName[m.groupValues[6]] ?: continue
        val key = "${m.groupValues[1]}|${m.groupValues[2]}|$hid|$aid"
        if (!seen.add(key)) continue
        G.matchLog.add(MatchRec(m.groupValues[1].toInt(), m.groupValues[2].toInt(), 0, hid, aid, m.groupValues[4].toInt(), m.groupValues[5].toInt()))
    }
    G.matchLog.sortWith(compareBy({ it.season }, { it.week }))
    G.history.removeAll { it.startsWith("فصل") && (doubled.containsMatchIn(it) || it.contains("آرشیو نتایج مسابقات")) }
}

fun playWeek(live: Boolean = false) {
    G.report.clear()
    G.msg = ""
    G.live = null
    G.liveAffectsLeague = false
    G.pendingPenaltyMatch = null
    G.liveQueue.clear()
    // ۱) میان‌هفته: جام حذفی و لیگ قهرمانان طبق تقویم ۴۵ هفته‌ای (اگر تیم کاربر در آن‌ها باشد، زنده هم بازی می‌شود)
    playScheduledUserCupWeek(live)
    playScheduledWorldCupWeek(live)
    // ۲) آخر هفته: لیگ داخلی
    var userLeagueMatch: MatchRes? = null
    for (lg in G.leagues.toList()) {
        val fx = fixturesFor(lg.id)
        if (G.week < fx.size) {
            for ((hid, aid) in fx[G.week]) {
                val h = G.team(hid)
                val a = G.team(aid)
                val isU = hid == G.userTeam || aid == G.userTeam
                val r = playMatch(h, a, live && isU, deferTableUpdate = isU)
                logMatch("لیگ", h, a, r.hg, r.ag)
                if (isU) {
                    userLeagueMatch = r
                    r.affectsLeague = live
                    G.liveAffectsLeague = live
                    G.penaltyReturnScreen = if (live) "live" else "play"
                    if (!live && Random.nextInt(100) < 11) {
                        G.pendingPenaltyMatch = r
                        G.penaltySide = if (hid == G.userTeam) 0 else 1
                        G.report.add("⚠️ داور برای تیم شما پنالتی اعلام کرد!")
                    } else if (!live) applyMatchTableResult(r)
                    G.report.add("${h.name}  ${r.hg} - ${r.ag}  ${a.name}")
                    for (e in r.ev) if (e.side < 2) G.report.add("${e.min}' ${e.text}")
                }
            }
        }
    }
    // صف بازی‌های زنده: ابتدا میان‌هفته (جام/قهرمانان)، سپس لیگ
    if (live) {
        userLeagueMatch?.let { G.liveQueue.add(it) }
        if (G.liveQueue.isNotEmpty()) G.live = G.liveQueue.removeAt(0)
    } else {
        G.live = userLeagueMatch
    }
    G.week++
    val scores = G.report.filter { it.contains(" - ") }
    G.msg = when {
        scores.size == 1 -> "🏁 نتیجه مسابقه شما: ${scores[0]}"
        scores.size > 1 -> "🏁 نتایج مسابقات شما:\n" + scores.joinToString("\n")
        else -> "هفته ${G.week} شبیه‌سازی شد؛ تیم شما این هفته مسابقه نداشت (استراحت)."
    }
    if (Random.nextInt(100) < 12) genOffers(1)
}

// ======================= نقل و انتقالات =======================

fun aiTransfers() {
    addNews("📢 پنجره نقل و انتقالات فصل ${G.season} باز شد")
    repeat(30) {
        val seller = G.teams.filter { it.id != G.userTeam }.randomOrNull() ?: return@repeat
        val sq = squad(seller.id)
        if (sq.size <= 16) return@repeat
        val p = sq.sortedByDescending { it.rating }.take(6).random()
        val price = p.value * 11 / 10
        val buyer = G.teams.filter {
            it.id != G.userTeam && it.id != seller.id && it.budget >= price && squad(it.id).size < G.ppt + 4
        }.randomOrNull() ?: return@repeat
        buyer.budget -= price
        seller.budget += price
        p.teamId = buyer.id
        addNews("🔁 ${p.name} (${p.rating}) | مبدا: ${seller.name} ← مقصد: ${buyer.name} | ${money(price)}")
    }
}

fun genOffers(n: Int) {
    val t = G.teamOrNull(G.userTeam) ?: return
    val top = squad(t.id).sortedByDescending { it.rating }.take(6)
    repeat(n) {
        val p = top.randomOrNull() ?: return@repeat
        if (G.offers.size >= 6 || G.offers.any { it.pid == p.id }) return@repeat
        val price = p.value * 13 / 10
        val b = G.teams.filter { it.id != t.id && it.budget >= price && squad(it.id).size < G.ppt + 4 }.randomOrNull() ?: return@repeat
        G.offers.add(Offer(p.id, b.id, price))
    }
}

fun resetSeason() {
    for (t in G.teams) {
        t.p = 0; t.w = 0; t.d = 0; t.l = 0; t.gf = 0; t.ga = 0; t.pts = 0
    }
    for (p in G.players) {
        p.total -= p.goals
        p.goals = 0
    }
    G.week = 0
    G.report.clear()
    G.msg = ""
}


// جام حذفی هر کشور؛ شرکت‌کنندگان از چند سطح لیگ انتخاب می‌شوند و تعداد تیم‌های لیگ تغییر نمی‌کند.
fun domesticCupName(country: String): String = when (country) {
    "انگلیس" -> "جام حذفی انگلیس (FA Cup)"
    "اسپانیا" -> "کوپا دل‌ری"
    "آلمان" -> "جام حذفی آلمان (DFB-Pokal)"
    "ایتالیا" -> "کوپا ایتالیا"
    "فرانسه" -> "جام حذفی فرانسه"
    "پرتغال" -> "جام حذفی پرتغال"
    "هلند" -> "جام حذفی هلند"
    "برزیل" -> "کوپا دو برزیل"
    "ترکیه" -> "جام حذفی ترکیه"
    "آرژانتین" -> "کوپا آرژانتین"
    "ایران" -> "جام حذفی ایران"
    else -> "جام حذفی $country"
}

fun simulateDomesticCup(country: String, powers: Map<Int, Int>): Team? {
    val countryLeagues = G.leagues.filter { it.country == country }.sortedBy { it.level }
    if (countryLeagues.isEmpty()) return null
    val entrants = countryLeagues.flatMap { lg ->
        val ranked = table(lg.id)
        when (country) {
            "انگلیس", "ایران", "فرانسه" -> ranked
            "اسپانیا" -> when (lg.level) { 1, 2 -> ranked; 3 -> ranked.take(8); else -> emptyList() }
            "آلمان" -> when (lg.level) { 1, 2 -> ranked; 3 -> ranked.take(4); else -> emptyList() }
            "ایتالیا" -> when (lg.level) { 1 -> ranked; 2 -> ranked.take(8); 3 -> ranked.take(4); else -> emptyList() }
            "پرتغال", "هلند", "آرژانتین" -> if (lg.level <= 2) ranked else emptyList()
            "برزیل", "ترکیه" -> if (lg.level <= 3) ranked else emptyList()
            else -> if (lg.level <= 3) ranked else emptyList()
        }
    }.distinctBy { it.id }.toMutableList()
    if (entrants.size < 2) return null
    fun seed(t: Team): Int {
        val tier = countryLeagues.firstOrNull { it.id == t.leagueId }?.level ?: 9
        val rank = table(t.leagueId).indexOfFirst { it.id == t.id }.coerceAtLeast(0)
        return tier * 100 + rank
    }
    fun power(t: Team): Double {
        val tier = countryLeagues.firstOrNull { it.id == t.leagueId }?.level ?: 3
        val rank = table(t.leagueId).indexOfFirst { it.id == t.id }.coerceAtLeast(0)
        return (powers[t.id] ?: 55).toDouble() + (4 - tier).coerceAtLeast(0) * 1.5 + (20 - rank).coerceAtLeast(0) * 0.12
    }
    var round = entrants.sortedBy { seed(it) }.toMutableList()
    var roundNo = 0
    while (round.size > 1) {
        val bracketSize = Integer.highestOneBit(round.size - 1)
        val byeCount = (2 * bracketSize - round.size).coerceAtLeast(0)
        val seeded = round.sortedBy { seed(it) }
        val winners = ArrayList<Team>()
        winners.addAll(seeded.take(byeCount))
        val playing = seeded.drop(byeCount).shuffled().toMutableList()
        while (playing.size >= 2) {
            val home = playing.removeAt(0)
            val otherLeague = if (roundNo == 0) playing.indexOfFirst { it.leagueId != home.leagueId } else -1
            val away = playing.removeAt(if (otherLeague >= 0) otherLeague else 0)
            val ph = power(home) + 1.2 // امتیاز میزبانی در بازی تک‌حذفی
            val pa = power(away)
            val chanceHome = (ph / (ph + pa)).coerceIn(0.16, 0.84)
            winners.add(if (Random.nextDouble() < chanceHome) home else away)
        }
        if (playing.isNotEmpty()) winners.add(playing.removeAt(0))
        round = winners
        roundNo++
    }
    return round.firstOrNull()
}

fun simulateAllDomesticCups(summary: MutableList<String>) {
    val powers = strengthsByTeam()
    for (country in G.leagues.map { it.country }.distinct()) {
        if (country == G.teamOrNull(G.userTeam)?.country) continue // جام کشور کاربر در طول فصل برگزار می‌شود.
        val winner = simulateDomesticCup(country, powers) ?: continue
        val cupName = domesticCupName(country)
        G.history.add("فصل ${G.season} - $cupName: قهرمان ${winner.name}")
        summary.add("🏆 $cupName: قهرمان ${winner.name}")
        winner.titles++
        // پاداش قهرمانی جام حذفی
        winner.budget += 2_000_000L
    }
}

fun leaguePrize(lg: League, ranked: List<Team>): Map<Int, Long> {
    val firstPrize = when (lg.level) { 1 -> 18_000_000L; 2 -> 9_000_000L; 3 -> 4_500_000L; else -> 2_500_000L }
    val total = ranked.size.coerceAtLeast(1)
    return ranked.mapIndexed { index, team ->
        val factor = (1.0 - index.toDouble() / total * 0.78).coerceAtLeast(0.22)
        team.id to (firstPrize * factor).toLong()
    }.toMap()
}

fun endSeason() {
    val sb = ArrayList<String>()
    val moves = ArrayList<Pair<Team, Int>>()
    // خلاصه جدول هر تیم برای همیشه نگه‌داری می‌شود؛ ریز مسابقات فصل‌های قدیمی تیم‌های دیگر بعد از ۳ فصل حذف می‌شود.
    G.seasonSums.removeAll { it.season == G.season }
    for (lg in G.leagues) for ((i, t) in table(lg.id).withIndex()) {
        G.seasonSums.add(SeasonSum(G.season, t.id, lg.name, i + 1, t.p, t.w, t.d, t.l, t.gf, t.ga, t.pts))
    }
    G.matchLog.removeAll { it.season <= G.season - 3 && it.hid != G.userTeam && it.aid != G.userTeam }
    for ((country, list) in G.leagues.groupBy { it.country }.toList().sortedBy { COUNTRIES.indexOf(it.first) }) {
        val lgs = list.sortedBy { it.level }
        val tables = lgs.map { table(it.id) }
        for ((i, lg) in lgs.withIndex()) {
            val tb = tables[i]
            if (tb.isNotEmpty()) {
                val prizes = leaguePrize(lg, tb)
                for (club in tb) club.budget += prizes[club.id] ?: 0L
                sb.add("💰 پاداش ${lg.name}: " + tb.take(3).mapIndexed { idx, club ->
                    "${idx + 1}. ${club.name} (${money(prizes[club.id] ?: 0L)})"
                }.joinToString(" | "))
                // رتبه افتخارات فقط قهرمانی سطح اول و جام حذفی را حساب می‌کند.
                if (lg.level == 1) tb[0].titles++
                val sc = tb.asSequence().flatMap { squad(it.id).asSequence() }.maxByOrNull { it.goals }
                var line = "فصل ${G.season} - ${lg.name}: قهرمان ${tb[0].name}"
                if (sc != null && sc.goals > 0) line += " | آقای گل: ${sc.name} (${sc.goals} گل)"
                G.history.add(line)
                sb.add(line)
            }
        }
        // صعود و سقوط فقط بین دسته‌های «همین کشور» (هیچ تیمی از کشوری به کشور دیگر نمی‌رود)
        for (i in 0 until lgs.size - 1) {
            val up = tables[i].filter { it.leagueId == lgs[i].id }
            val lo = tables[i + 1].filter { it.leagueId == lgs[i + 1].id }
            val k = minOf(G.promo, up.size / 2, lo.size / 2)
            if (k > 0) {
                val down = up.takeLast(k)
                val rise = lo.take(k)
                for (t in down) moves.add(Pair(t, lgs[i + 1].id))
                for (t in rise) moves.add(Pair(t, lgs[i].id))
                sb.add("⬆️ صعود به ${lgs[i].name}: " + rise.joinToString("، ") { it.name })
                sb.add("⬇️ سقوط به ${lgs[i + 1].name}: " + down.joinToString("، ") { it.name })
            }
        }
    }
    finishUserCupQuickly()
    finishWorldCupQuickly()
    simulateAllDomesticCups(sb)
    // سهمیه‌های فصل بعد قبل از صفر شدن جدول لیگ ذخیره می‌شوند.
    G.worldCupEntrants = worldCupQualifiers(G.season).toCollection(ArrayList())
    G.worldCupSeason = G.season + 1
    G.worldCupActive = false
    G.worldCupRound = 0
    G.worldCupSchedule.clear()
    G.worldCupResults.clear()
    G.worldCupLog.clear()
    for (t in G.teams) t.allPts += t.pts
    for ((t, id) in moves) t.leagueId = id
    for (t in G.teams) {
        t.p = 0; t.w = 0; t.d = 0; t.l = 0; t.gf = 0; t.ga = 0; t.pts = 0
    }
    for (p in G.players.toList()) {
        p.goals = 0
        p.age++
        val ch = when {
            p.age < 24 -> Random.nextInt(0, 4)
            p.age > 31 -> -Random.nextInt(0, 4)
            else -> Random.nextInt(-1, 2)
        }
        p.rating = (p.rating + ch).coerceIn(35, 95)
        p.value = worth(p.rating, p.age)
        if (p.age >= 43) {
            val t = G.teamOrNull(p.teamId)
            G.players.remove(p)
            if (t != null) {
                val y = genPlayer(t.id, t.country, p.pos, (p.rating - 3).coerceIn(55, 82))
                y.age = Random.nextInt(17, 19)
                // بازیکن جایگزین می‌تواند استعداد بالایی داشته باشد؛ امتیاز ۸۲ نادر است.
                if (Random.nextInt(100) < 12) y.rating = Random.nextInt(78, 83)
                y.value = worth(y.rating, y.age)
                G.players.add(y)
                addNews("🌟 نسل جدید: ${y.name} (${y.age} سال، اورال ${y.rating}) جایگزین ${p.name} شد")
            }
        }
    }
    for (ap in G.academy.toList()) {
        ap.age++
        ap.rating = (ap.rating + Random.nextInt(0, 4)).coerceAtMost(ap.potential)
        if (ap.age >= 18) {
            val t = G.teamOrNull(ap.teamId)
            G.academy.remove(ap)
            if (t != null) {
                val rating = if (Random.nextInt(100) < 8) Random.nextInt(80, 84) else ap.rating.coerceAtLeast(55)
                val promoted = Player(G.nid(), ap.name, ap.pos, rating, 18, t.id, worth(rating, 18), country = ap.country)
                G.players.add(promoted)
                addNews("🎓 فارغ‌التحصیل آکادمی ${t.name}: ${promoted.name} با اورال ${promoted.rating}")
            }
        }
    }
    val acCount = HashMap<Int, Int>()
    for (a in G.academy) acCount[a.teamId] = (acCount[a.teamId] ?: 0) + 1
    for (t in G.teams) repeat((5 - (acCount[t.id] ?: 0)).coerceAtLeast(0)) { if ((acCount[t.id] ?: 0) < 15) G.academy.add(genAcademyPlayer(t)) }
    G.season++
    G.week = 0
    resetUserCupSeason()
    G.report.clear()
    G.live = null
    G.liveQueue.clear()
    G.offers.clear()
    aiTransfers()
    genOffers(3)
    G.msg = sb.joinToString("\n")
}

// ======================= توابع ادمین =======================

fun removeTeam(t: Team) {
    G.players.removeAll { it.teamId == t.id }
    G.academy.removeAll { it.teamId == t.id }
    G.teams.remove(t)
}

fun adjustTeams(lg: League) {
    var n = G.teams.count { it.leagueId == lg.id }
    while (n < G.tpl) {
        newTeam(lg)
        n++
    }
    while (n > G.tpl) {
        val v = G.teams.filter { it.leagueId == lg.id && it.id != G.userTeam }.minByOrNull { strengthOf(it) } ?: break
        removeTeam(v)
        n--
    }
}

fun adjustPlayers(t: Team) {
    val plan = posPlan(G.ppt)
    while (squad(t.id).size < G.ppt) {
        val cur = squad(t.id).groupBy { it.pos }
        val pos = POS.maxByOrNull { p -> plan.count { it == p } - (cur[p]?.size ?: 0) } ?: "MF"
        G.players.add(genPlayer(t.id, t.country, pos, squadAvg(t)))
    }
    while (squad(t.id).size > G.ppt) {
        val sq = squad(t.id)
        val gk = sq.count { it.pos == "GK" }
        val w = sq.filter { it.pos != "GK" || gk > 2 }.minByOrNull { it.rating } ?: break
        G.players.remove(w)
    }
}

fun applyAdmin() {
    for (lg in G.leagues.toList()) adjustTeams(lg)
    for (t in G.teams.toList()) adjustPlayers(t)
    resetSeason()
}

fun addLeague(c: String = "ایران") {
    val lv = (G.leagues.filter { it.country == c }.maxOfOrNull { it.level } ?: 0) + 1
    val lg = League(G.nid(), "لیگ سطح $lv $c", lv, c)
    G.leagues.add(lg)
    repeat(G.tpl) { newTeam(lg) }
    resetSeason()
}

fun deleteLeague(lg: League): Boolean {
    if (G.leagues.size <= 1) return false
    if (G.teams.any { it.leagueId == lg.id && it.id == G.userTeam }) return false
    for (t in G.teams.filter { it.leagueId == lg.id }) removeTeam(t)
    G.leagues.remove(lg)
    for ((i, l) in G.leagues.filter { it.country == lg.country }.sortedBy { it.level }.withIndex()) l.level = i + 1
    resetSeason()
    return true
}

fun copyLogo(uri: Uri, id: Int): String? = try {
    val f = File(G.ctx.filesDir, "logo_${id}_${System.currentTimeMillis()}.img")
    G.ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    if (f.exists() && f.length() > 0) f.absolutePath else null
} catch (e: Exception) {
    null
}

fun logoKeyOf(country: String, name: String): String =
    (country + "|" + name).hashCode().toUInt().toString(16).padStart(8, '0')

fun isOfficialClub(country: String, name: String): Boolean =
    name in REAL_CLUBS[country].orEmpty() || name in LOWER_CLUBS[country].orEmpty()

// کلید لوگو ← (کشور، نام باشگاه رسمی)
val CLUB_BY_LOGO_KEY: Map<String, Pair<String, String>> by lazy {
    val m = HashMap<String, Pair<String, String>>()
    for (country in (REAL_CLUBS.keys + LOWER_CLUBS.keys).distinct()) {
        for (n in REAL_CLUBS[country].orEmpty() + LOWER_CLUBS[country].orEmpty()) {
            m.putIfAbsent(logoKeyOf(country, n), country to n)
        }
    }
    m
}

fun clubLogoPath(country: String, name: String): String {
    val key = logoKeyOf(country, name)
    return File(G.ctx.filesDir, "club_logos/$key.png").absolutePath
}

fun installClubLogoAssets(context: Context) {
    try {
        val dir = File(context.filesDir, "club_logos")
        if (!dir.exists()) dir.mkdirs()
        val names = context.assets.list("club_logos") ?: return
        // نسخه‌بندی دارایی‌ها: بعد از به‌روزرسانی برنامه، لوگوهای رسمی فقط یک‌بار
        // روی فایل‌های قدیمی کپی می‌شوند؛ اجرای عادی برنامه باعث کپی مکرر نمی‌شود.
        val marker = File(context.filesDir, "club_logos_version.txt")
        val version = "club_identity_v6_unique_logos_no_duplicates"
        val refresh = !marker.exists() || marker.readText() != version
        for (name in names) {
            val dst = File(dir, name)
            if (refresh || !dst.exists() || dst.length() == 0L) {
                context.assets.open("club_logos/$name").use { input -> dst.outputStream().use { output -> input.copyTo(output) } }
            }
        }
        if (refresh) marker.writeText(version)
    } catch (_: Exception) { }
}

// تمام لوگوها از assets داخل APK خوانده می‌شوند؛ هیچ دریافت اینترنتی انجام نمی‌شود.

val bmpCache = HashMap<String, ImageBitmap?>()

fun loadBmp(path: String): ImageBitmap? = try {
    val o = BitmapFactory.Options()
    o.inJustDecodeBounds = true
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / s > 256 || o.outHeight / s > 256) s *= 2
    val o2 = BitmapFactory.Options()
    o2.inSampleSize = s
    BitmapFactory.decodeFile(path, o2)?.asImageBitmap()
} catch (e: Exception) {
    null
}

fun money(v: Long): String =
    if (v >= 1_000_000L) String.format("%.1f میلیون", v / 1_000_000.0) else "${v / 1000} هزار"

fun posColor(p: String): Color = when (p) {
    "GK" -> Color(0xFFF9A825)
    "DF" -> Color(0xFF1565C0)
    "MF" -> Color(0xFF2E7D32)
    else -> Color(0xFFC62828)
}

// ======================= اجزای رابط =======================

@Composable
fun Logo(t: Team, sz: Dp = 32.dp) {
    val path = t.logo
    val bmp = if (path != null) remember(path) { bmpCache.getOrPut(path) { loadBmp(path) } } else null
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(sz))
    } else {
        val shape = when (t.id % 3) {
            0 -> CircleShape
            1 -> RoundedCornerShape(8.dp)
            else -> RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
        }
        Box(
            Modifier.size(sz).clip(shape).background(Color(t.c1)).border(2.dp, Color(t.c2), shape),
            contentAlignment = Alignment.Center
        ) {
            Text(t.name.take(1), color = Color(t.c2), fontWeight = FontWeight.Bold, fontSize = (sz.value * 0.5f).sp)
        }
    }
}

@Composable
fun Shirt(t: Team, sz: Dp = 56.dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.3f, 0f)
            lineTo(w * 0.7f, 0f)
            lineTo(w, h * 0.25f)
            lineTo(w * 0.85f, h * 0.4f)
            lineTo(w * 0.75f, h * 0.32f)
            lineTo(w * 0.75f, h)
            lineTo(w * 0.25f, h)
            lineTo(w * 0.25f, h * 0.32f)
            lineTo(w * 0.15f, h * 0.4f)
            lineTo(0f, h * 0.25f)
            close()
        }
        drawPath(path, Color(t.c1))
        clipPath(path) {
            when (t.style) {
                1 -> {
                    for (i in 0 until 5) {
                        if (i % 2 == 1) drawRect(Color(t.c2), Offset(w * i * 0.2f, 0f), Size(w * 0.2f, h))
                    }
                }
                2 -> {
                    drawRect(Color(t.c2), Offset(w * 0.5f, 0f), Size(w * 0.5f, h))
                }
                3 -> {
                    drawRect(Color(t.c2), Offset(0f, h * 0.45f), Size(w, h * 0.18f))
                }
                else -> {
                }
            }
        }
        drawPath(path, Color(0x55000000), style = Stroke(width = 3f))
    }
}

@Composable
fun Page(title: String, scroll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF0B0B0B))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (G.screen != "home" && G.screen != "pick") {
                Text(if (I18n.lang == "en") "←" else "→", color = Color(0xFFFFC107), fontSize = 26.sp, modifier = Modifier.clickable { G.back() }.padding(end = 12.dp))
            }
            val logoPainter = painterResource(R.drawable.app_logo)
            Image(logoPainter, null, Modifier.size(34.dp).clip(CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color(0xFFFFC107), fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        val m = if (scroll) Modifier.fillMaxSize().verticalScroll(rememberScrollState()) else Modifier.fillMaxSize()
        Column(m.padding(10.dp), content = content)
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(10.dp), content = content)
    }
}

@Composable
fun B(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier) { Text(text) }
}

@Composable
fun Chips(opts: List<String>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for (o in opts) {
            FilterChip(
                selected = o == sel,
                onClick = { onSel(o) },
                label = { Text(o) },
                modifier = Modifier.padding(end = 6.dp)
            )
        }
    }
}

@Composable
fun NumField(label: String, v: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = { s -> onChange(s.filter { c -> c.isDigit() }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier
    )
}

@Composable
fun TextF(label: String, v: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier
    )
}

@Composable
fun Prompt(title: String, init: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var s by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { TextF("", s, { s = it }, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onOk(s) }) { Text("تأیید") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("لغو") } }
    )
}

@Composable
fun ColorRow(sel: Long, onPick: (Long) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for (c in PAL) {
            Box(
                Modifier.padding(end = 6.dp).size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == sel) 3.dp else 1.dp, if (c == sel) Color.Black else Color.Gray, CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun PlayerRow(p: Player, extra: @Composable RowScope.() -> Unit = {}) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(p.pos, Modifier.width(34.dp), color = posColor(p.pos), fontWeight = FontWeight.Bold)
            Column(Modifier.weight(1f)) {
                Text(p.name)
                Text("سن ${p.age} | گل ${p.goals} | ارزش ${money(p.value)}", fontSize = 12.sp, color = Color.Gray)
            }
            Text("${p.rating}", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 6.dp))
            extra()
        }
        HorizontalDivider()
    }
}

@Composable
fun Cell(text: String, w: Dp, bold: Boolean = false) {
    Text(
        text, Modifier.width(w), fontSize = 12.sp, textAlign = TextAlign.Center,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
    )
}

// ======================= صفحه‌ها =======================

@Composable
fun Pick() {
    val rv = G.rev
    var cty by remember { mutableStateOf("ایران") }
    var startDifficulty by remember { mutableStateOf("متوسط") }
    val countries = COUNTRIES.filter { c -> G.leagues.any { it.country == c } }
    val pickRows = remember(rv, cty) {
        val powers = strengthsByTeam()
        G.leagues.filter { it.country == cty }.associate { lg ->
            lg.id to G.teams.filter { it.leagueId == lg.id }.map { it to (powers[it.id] ?: 0) }.sortedByDescending { it.second }
        }
    }
    Page("تیم خود را انتخاب کنید", scroll = false) {
        Chips(listOf("فارسی", "English"), if (I18n.lang == "en") "English" else "فارسی") { l ->
            I18n.changeLang(if (l == "English") "en" else "fa")
            G.ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString("lang", I18n.lang).apply()
        }
        Chips(countries, cty) { cty = it }
        Text("درجه سختی و بودجه شروع", fontWeight = FontWeight.Bold)
        Chips(DIFFS, startDifficulty) { startDifficulty = it }
        Text(when (startDifficulty) {
            "آسان" -> "بودجه شروع باشگاه انتخابی: ۱۵۰ میلیون"
            "متوسط" -> "بودجه شروع باشگاه انتخابی: ۸۵ میلیون"
            else -> "بودجه شروع باشگاه انتخابی: ۴۵ میلیون | فقط دسته دوم و سوم"
        }, color = Color.Gray)
        Button(onClick = { G.go("createTeam") }, modifier = Modifier.fillMaxWidth()) { Text("➕ ساخت تیم اختصاصی؛ شروع از دسته دوم") }
        Button(onClick = { G.go("worldRank") }, modifier = Modifier.fillMaxWidth()) { Text("🌍 رتبه‌بندی جهانی باشگاه‌ها") }
        Text("🏆 لیگ کشور $cty", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(6.dp))
        LazyColumn(Modifier.weight(1f)) {
            for (lg in G.leagues.filter { it.country == cty && (startDifficulty != "سخت" || it.level in 2..3) }.sortedBy { it.level }) {
                item {
                    Text(lg.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp))
                }
                val rows = pickRows[lg.id].orEmpty()
                items(rows, key = { it.first.id }) { (t, st) ->
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                G.userTeam = t.id
                                G.diff = DIFFS.indexOf(startDifficulty).coerceIn(0, 2)
                                // بودجه شروع بر اساس سختی انتخاب‌شده تعیین می‌شود.
                                if (G.week == 0 && G.season == 1) t.budget = when (G.diff) {
                                    0 -> 150_000_000L
                                    1 -> 85_000_000L
                                    else -> 45_000_000L
                                }
                                G.academyCoachLevel = 0
                                G.lineup = ArrayList(autoLineup(t.id, G.formation).map { p -> p.id })
                                G.stack.clear()
                                G.screen = "home"
                                G.touch()
                            }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Logo(t, 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(t.name, Modifier.weight(1f))
                            Text("قدرت $st")
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun CreateTeam() {
    var name by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("ایران") }
    var difficulty by remember { mutableStateOf("سخت") }
    var kit by remember { mutableIntStateOf(0) }
    var selectedLogoPath by remember { mutableStateOf<String?>(null) }
    val pickTeamLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) selectedLogoPath = copyLogo(uri, -1)
    }
    Page("ساخت تیم اختصاصی") {
        Text("نام تیم", fontWeight = FontWeight.Bold)
        OutlinedTextField(value = name, onValueChange = { name = it.take(28) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("مثلاً ستاره تهران") }, singleLine = true)
        Text("کشور", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Chips(COUNTRIES, country) { country = it }
        Panel {
            Text("لوگوی تیم اختصاصی", fontWeight = FontWeight.Bold)
            Text(if (selectedLogoPath == null) "می‌توانید از گالری گوشی برای تیمتان لوگو انتخاب کنید." else "لوگوی اختصاصی انتخاب شده است.", color = Color.Gray)
            B("🖼 انتخاب لوگو از گالری", Modifier.fillMaxWidth()) { pickTeamLogo.launch("image/*") }
            if (selectedLogoPath != null) B("حذف لوگوی انتخاب‌شده") { selectedLogoPath = null }
        }
        Text("سطح شروع", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Chips(listOf("آسان", "متوسط", "سخت"), difficulty) { difficulty = it }
        Text(when(difficulty) {
            "آسان" -> "قدرت شروع حدود ۶۰ | بودجه شروع: ۱۲۰ میلیون"
            "متوسط" -> "قدرت شروع حدود ۴۸ | بودجه شروع: ۶۵ میلیون"
            else -> "قدرت شروع حدود ۳۷ | بودجه شروع: ۲۲ میلیون | شروع از دسته سوم"
        }, color = Color.Gray)
        Text("در سختی دشوار از دسته سوم (در صورت نبود، دسته دوم) شروع می‌کنید؛ تعداد تیم‌های لیگ افزایش نمی‌یابد.")
        Button(onClick = {
            val n = name.trim()
            if (n.isEmpty() || G.teams.any { it.name.equals(n, true) }) {
                G.msg = if (n.isEmpty()) "نام تیم را وارد کنید" else "این نام قبلاً استفاده شده است"
            } else {
                val startLevel = if (difficulty == "سخت" && G.leagues.any { it.country == country && it.level == 3 }) 3 else 2
                val league = G.leagues.firstOrNull { it.country == country && it.level == startLevel } ?: G.leagues.first { it.level == 2 }
                val powers = strengthsByTeam()
                val weakest = G.teams.asSequence().filter { it.leagueId == league.id }
                    .minByOrNull { powers[it.id] ?: 0 }
                val base = when(difficulty) { "آسان" -> 60; "متوسط" -> 48; else -> 37 }
                val startingBudget = when (difficulty) {
                    "آسان" -> 120_000_000L
                    "متوسط" -> 65_000_000L
                    else -> 22_000_000L
                }
                G.diff = when (difficulty) { "آسان" -> 0; "متوسط" -> 1; else -> 2 }
                val team = Team(G.nid(), n, league.country, league.id, PAL[kit % PAL.size], PAL[(kit + 3) % PAL.size], kit % 4, selectedLogoPath, startingBudget)
                if (weakest != null) {
                    val oldId = weakest.id
                    G.players.removeAll { it.teamId == oldId }
                    G.academy.removeAll { it.teamId == oldId }
                    G.teams.remove(weakest)
                }
                G.teams.add(team)
                for (pos in posPlan(G.ppt)) G.players.add(genPlayer(team.id, team.country, pos, base + Random.nextInt(-3, 4)))
                repeat(5) { G.academy.add(genAcademyPlayer(team)) }
                G.academyCoachLevel = 0
                G.userTeam = team.id
                G.lineup = ArrayList(autoLineup(team.id, G.formation).map { it.id })
                G.msg = ""
                G.stack.clear(); G.screen = "home"; G.touch()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ساخت تیم و شروع بازی") }
        if (G.msg.isNotBlank()) Text(G.msg, color = Color.Red)
    }
}

@Composable
fun WorldRank() {
    var mode by remember { mutableStateOf("قدرت تیم") }
    // رتبه‌بندی فقط هنگام تغییر داده‌های بازی یا فیلتر دوباره محاسبه می‌شود.
    val powers = remember(G.rev) { strengthsByTeam() }
    val ranked = remember(G.rev, mode) {
        if (mode == "قدرت تیم") {
            G.teams.sortedWith(compareByDescending<Team> { powers[it.id] ?: 0 }.thenBy { it.name })
        } else {
            G.teams.sortedWith(compareByDescending<Team> { it.titles }
                .thenByDescending { powers[it.id] ?: 0 }.thenBy { it.name })
        }
    }
    Page("رتبه‌بندی جهانی", scroll = false) {
        Chips(listOf("قدرت تیم", "افتخارات"), mode) { mode = it }
        Text(if (mode == "قدرت تیم") "بر اساس قدرت و اورال ترکیب" else "افتخارات لیگ برتر و جام حذفی؛ سپس قدرت تیم", color = Color.Gray)
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(ranked, key = { _, team -> team.id }) { index, team ->
                val rank = index + 1
                Row(Modifier.fillMaxWidth().clickable { G.viewedTeamId = team.id; G.go("teamDetails") }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("$rank", modifier = Modifier.width(32.dp), fontWeight = FontWeight.Bold)
                    Logo(team, 34.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(team.name, fontWeight = FontWeight.Medium)
                        Text("${team.country} • ${G.leagues.firstOrNull { it.id == team.leagueId }?.name ?: ""}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(if (mode == "قدرت تیم") "${powers[team.id] ?: 0} OVR" else "🏆 ${team.titles}")
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun TeamDetails() {
    val rv = G.rev
    val team = G.teamOrNull(G.viewedTeamId)
    if (team == null) {
        Page("اطلاعات تیم") { Text("تیمی پیدا نشد.") }
        return
    }
    val league = G.leagues.firstOrNull { it.id == team.leagueId }
    Page("اطلاعات ${team.name}") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(team, 54.dp)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(team.name, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text("${league?.name ?: "بدون لیگ"} • ${team.country}")
                    Text("فصل ${G.season} | رتبه ${table(team.leagueId).indexOfFirst { it.id == team.id } + 1}")
                }
            }
            Text("بازی‌ها: ${team.p} | برد: ${team.w} | مساوی: ${team.d} | باخت: ${team.l}")
            Text("گل زده: ${team.gf} | گل خورده: ${team.ga} | امتیاز: ${team.pts}")
        }
        B("📜 تاریخچه کامل بازی‌ها (فصل جاری، گذشته و آینده)", Modifier.fillMaxWidth()) { G.viewedTeamId = team.id; G.go("teamHistory") }
        Panel {
            Text("فهرست بازیکنان تیم", fontWeight = FontWeight.Bold)
            val players = squad(team.id).sortedWith(
                compareBy({ listOf("GK", "DF", "MF", "FW").indexOf(it.pos) }, { -it.rating })
            )
            players.forEach { player ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(player.name, fontWeight = FontWeight.SemiBold)
                        Text(player.country, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("${player.age} سال • ${player.pos} • قدرت ${player.rating}", fontSize = 12.sp)
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun MatchRow(tid: Int, week: Int, comp: String, hid: Int, aid: Int, hg: Int?, ag: Int?) {
    val home = G.teamOrNull(hid)?.name ?: "؟"
    val away = G.teamOrNull(aid)?.name ?: "؟"
    val mine = if (hid == tid) hg to ag else ag to hg
    val color = when {
        hg == null || ag == null -> Color(0xFF8A8A8A)
        mine.first!! > mine.second!! -> Color(0xFF2E7D32)
        mine.first!! < mine.second!! -> Color(0xFFC62828)
        else -> Color(0xFF9E9E9E)
    }
    val badge = when {
        hg == null || ag == null -> "—"
        mine.first!! > mine.second!! -> "برد"
        mine.first!! < mine.second!! -> "باخت"
        else -> "مساوی"
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(badge, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(color).padding(horizontal = 7.dp, vertical = 3.dp))
        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Text("$home  ${if (hg == null) "-" else "$hg - $ag"}  $away", fontWeight = if (hg == null) FontWeight.Normal else FontWeight.SemiBold, fontSize = 13.sp)
            Text("هفته $week • $comp", fontSize = 10.sp, color = Color.Gray)
        }
    }
    HorizontalDivider()
}

@Composable
fun TeamHistory() {
    val rv = G.rev
    val team = G.teamOrNull(G.viewedTeamId)
    if (team == null) {
        Page("تاریخچه تیم") { Text("تیمی پیدا نشد.") }
        return
    }
    val all = G.matchLog.filter { it.hid == team.id || it.aid == team.id }
    val sums = G.seasonSums.filter { it.tid == team.id }
    val seasons = (all.map { it.season } + sums.map { it.season } + G.season).distinct().sortedDescending()
    var selState by remember(team.id) { mutableStateOf(G.season) }
    val sel = if (selState in seasons) selState else G.season
    val league = G.leagues.firstOrNull { it.id == team.leagueId }
    Page("📜 تاریخچه ${team.name}") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(team, 48.dp)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(team.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${league?.name ?: ""} • ${team.country}", fontSize = 12.sp, color = Color.Gray)
                    Text("${all.size} بازی ثبت‌شده در ${seasons.size} فصل", fontSize = 12.sp)
                }
            }
            B("👥 اطلاعات و بازیکنان تیم", Modifier.fillMaxWidth()) { G.viewedTeamId = team.id; G.go("teamDetails") }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (s in seasons) {
                val on = s == sel
                Text(if (s == G.season) "فصل $s (جاری)" else "فصل $s", fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    color = if (on) Color.Black else LocalContentColor.current,
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (on) Color(0xFFFFC107) else Color(0x33888888))
                        .clickable { selState = s }.padding(horizontal = 14.dp, vertical = 8.dp))
            }
        }
        val played = all.filter { it.season == sel }.sortedBy { it.week }
        var w = 0; var d = 0; var l = 0; var gf = 0; var ga = 0
        for (r in played) {
            val f = if (r.hid == team.id) r.hg else r.ag
            val a = if (r.hid == team.id) r.ag else r.hg
            gf += f; ga += a
            if (f > a) w++ else if (f < a) l++ else d++
        }
        Panel {
            Text(if (sel == G.season) "خلاصه فصل جاری" else "خلاصه فصل $sel", fontWeight = FontWeight.Bold)
            if (sel == G.season) {
                val rank = table(team.leagueId).indexOfFirst { it.id == team.id } + 1
                Text("جایگاه فعلی در ${league?.name ?: "لیگ"}: $rank • امتیاز ${team.pts}")
            } else {
                sums.firstOrNull { it.season == sel }?.let {
                    Text("جایگاه نهایی در ${it.league}: ${it.rank} • امتیاز ${it.pts}")
                    Text("لیگ: ${it.p} بازی | ${it.w} برد | ${it.d} مساوی | ${it.l} باخت | گل زده ${it.gf} | گل خورده ${it.ga}")
                }
            }
            if (played.isNotEmpty()) Text("همه رقابت‌ها: ${played.size} بازی | $w برد | $d مساوی | $l باخت | گل زده $gf | گل خورده $ga")
        }
        Panel {
            Text("بازی‌های انجام‌شده", fontWeight = FontWeight.Bold)
            if (played.isEmpty()) {
                Text(if (sel == G.season) "هنوز بازی‌ای برای این تیم ثبت نشده است." else "ریز نتایج این فصل برای صرفه‌جویی در حافظه نگه‌داری نشده؛ فقط خلاصه جدول موجود است.", fontSize = 12.sp, color = Color.Gray)
            }
            for (r in played) MatchRow(team.id, r.week, G.compNames.getOrElse(r.comp) { "لیگ" }, r.hid, r.aid, r.hg, r.ag)
        }
        if (sel == G.season) {
            val upcoming = ArrayList<Triple<Int, String, Pair<Int, Int>>>()
            fixturesFor(team.leagueId).drop(G.week.coerceAtLeast(0)).forEachIndexed { off, round ->
                round.filter { it.first == team.id || it.second == team.id }.forEach { upcoming.add(Triple(G.week + off + 1, "لیگ", it)) }
            }
            if (G.worldCupActive && G.worldCupSeason == G.season && G.worldCupRound == 0) {
                G.worldCupSchedule.forEachIndexed { ri, round ->
                    if (Cal.clLeagueWeek(ri) >= G.week) round.filter { it.first == team.id || it.second == team.id }.forEach { upcoming.add(Triple(Cal.show(Cal.clLeagueWeek(ri)), "لیگ قهرمانان جهان", it)) }
                }
            }
            upcoming.sortBy { it.first }
            Panel {
                Text("بازی‌های پیش‌رو", fontWeight = FontWeight.Bold)
                if (upcoming.isEmpty()) Text("بازی پیش‌رویی در برنامه نیست.", fontSize = 12.sp, color = Color.Gray)
                for ((wk, comp, pr) in upcoming) MatchRow(team.id, wk, comp, pr.first, pr.second, null, null)
                Text("جام حذفی بر اساس قرعه‌کشی هر دور به تاریخچه اضافه می‌شود.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
fun Home() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val lg = G.leagues.firstOrNull { it.id == t.leagueId }
    Page("مربی برتر") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 56.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${lg?.name ?: ""} | فصل ${G.season} - هفته ${G.week}")
                    Text("بودجه: ${money(t.budget)}")
                }
                Shirt(t, 56.dp)
            }
        }
        Panel {
            Text("مرکز مدیریت باشگاه", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("از نوار پایین برای ورود مستقیم به خانه، بازیکنان، بازار نقل‌وانتقالات، آکادمی و جدول لیگ استفاده کن.")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp)) {
                Text("قدرت تیم", fontWeight = FontWeight.SemiBold)
                Text("${strengthOf(t)}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp)) {
                Text("بازیکنان", fontWeight = FontWeight.SemiBold)
                Text("${squad(t.id).size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        B("📜 تاریخچه بازی‌های تیم من", Modifier.fillMaxWidth()) { G.viewedTeamId = t.id; G.go("teamHistory") }
        B("⚽ رفتن به مسابقه", Modifier.fillMaxWidth()) { G.go("play") }
        B("📋 تاکتیک و ترکیب", Modifier.fillMaxWidth()) { G.go("tactics") }
        B("🌍 جدول لیگ", Modifier.fillMaxWidth()) { G.go("table") }
        B("🏆 رتبه‌بندی جهانی باشگاه‌ها", Modifier.fillMaxWidth()) { G.go("worldRank") }
        B("🏆 جام‌های حذفی کشورها", Modifier.fillMaxWidth()) { G.go("cups") }
        B("🌍 لیگ قهرمانان جهان", Modifier.fillMaxWidth()) { G.go("worldCup") }
        B("⚙️ تنظیمات باشگاه", Modifier.fillMaxWidth()) { G.go("settings") }
    }
}

// شروع فصل جام کشور کاربر. در بازی، «لیگ دسته دوم» همان سطح سوم ساختار لیگ‌هاست.
fun resetUserCupSeason() {
    val user = G.teamOrNull(G.userTeam) ?: return
    val countryLeagues = G.leagues.filter { it.country == user.country }
    val feeder = countryLeagues.firstOrNull { it.level == 3 }
        ?: countryLeagues.firstOrNull { it.level == 2 }
    G.cupSeason = G.season
    G.cupStartWeek = G.week
    G.cupCountry = user.country
    G.cupRound = 0
    G.cupEntrants.clear()
    G.cupQualifiers = feeder?.let { G.teams.filter { t -> t.leagueId == it.id }.map { t -> t.id }.toCollection(ArrayList()) } ?: arrayListOf()
    G.cupQualRound = 0
    G.cupQualFinished = G.cupQualifiers.size <= 4
    G.cupFinished = false
    G.cupFormat = 2
    G.cupLog.clear()
    if (G.cupQualFinished) buildMainCupEntrants()
    saveNow()
}

fun prepareUserCup() {
    val user = G.teamOrNull(G.userTeam) ?: return
    if (G.cupFormat == 2 && G.cupSeason == G.season && G.cupCountry == user.country) return
    resetUserCupSeason()
}

fun buildMainCupEntrants() {
    val user = G.teamOrNull(G.userTeam) ?: return
    val premier = G.leagues.firstOrNull { it.country == user.country && it.level == 1 }
    val entrants = ArrayList<Int>()
    if (premier != null) entrants.addAll(G.teams.filter { it.leagueId == premier.id }.map { it.id })
    entrants.addAll(G.cupQualifiers.take(4))
    // جام اصلی دقیقاً از تیم‌های لیگ برتر و چهار صعودکننده مرحله مقدماتی تشکیل می‌شود.
    G.cupEntrants = entrants.distinct().toCollection(ArrayList())
    G.cupRound = 0
    G.cupFinished = G.cupEntrants.size < 2
}

fun cupStageName(before: Int): String = when {
    before <= 2 -> "فینال"
    before <= 4 -> "نیمه‌نهایی"
    before <= 8 -> "یک‌چهارم نهایی"
    before <= 16 -> "یک‌هشتم نهایی"
    else -> "مرحله اول جام اصلی"
}

// یک دور تک‌حذفی را تا تعداد هدف اجرا می‌کند؛ تیم‌های قوی‌تر در دورهای دارای استراحت، بای می‌گیرند.
// اگر تیم کاربر بازی زنده داشته باشد، نتیجه دور بعد از پایان بازی زنده نهایی می‌شود (onDone).
fun runKnockoutStage(ids: List<Int>, targetCount: Int, stageName: String, live: Boolean, onDone: (List<Int>) -> Unit) {
    val teams = ids.distinct().mapNotNull { G.teamOrNull(it) }
        .sortedWith(compareByDescending<Team> { strengthOf(it) }.thenBy { it.name })
    if (teams.size <= targetCount) { onDone(teams.map { it.id }); return }
    val matchesNeeded = (teams.size - targetCount).coerceAtLeast(0)
    val byeCount = (teams.size - matchesNeeded * 2).coerceAtLeast(0)
    val byes = teams.take(byeCount)
    val playing = teams.drop(byeCount).shuffled().toMutableList()
    val ties = ArrayList<Pair<Team, Team>>()
    while (playing.size >= 2) {
        val home = playing.removeAt(0)
        val away = playing.removeAt(0)
        ties.add(Pair(home, away))
    }
    if (byes.any { it.id == G.userTeam }) G.report.add("🏆 [جام حذفی] $stageName: تیم شما در این دور معاف است و مستقیم صعود کرد.")
    val wk = G.week + 1
    runKnockoutTies(ties, "🏆 جام حذفی • $stageName", live,
        onTie = { h, a, m, w ->
            logMatchW("جام حذفی • $stageName", wk, h, a, m.hg, m.ag)
            G.cupLog.add("$stageName: ${h.name} ${m.hg}-${m.ag}${shootoutSuffix(m)} ${a.name} | صعود: ${w.name}")
        },
        onDone = { tieWinners ->
            onDone((byes + tieWinners).take(targetCount).map { it.id })
        })
}

fun playScheduledUserCupWeek(live: Boolean = false, force: Boolean = false) {
    if (G.userTeam < 0) return
    prepareUserCup()
    if (G.cupSeason != G.season || G.cupFinished) return

    // سه دور مقدماتی (هفته‌های ۲، ۵، ۸): لیگ دسته دوم برای رسیدن به چهار سهمیه.
    val qualifierTargets = listOf(12, 8, 4)
    if (!G.cupQualFinished) {
        val q = G.cupQualRound
        if (q < qualifierTargets.size && (force || G.week >= Cal.cupQualWeek(q))) {
            val roundNo = q + 1
            runKnockoutStage(G.cupQualifiers, qualifierTargets[q], "مقدماتی جام حذفی • دور $roundNo", live) { winners ->
                G.cupQualifiers = winners.toCollection(ArrayList())
                G.cupQualRound = roundNo
                G.cupLog.add("پایان دور مقدماتی $roundNo؛ ${G.cupQualifiers.size} تیم باقی ماندند.")
                if (roundNo >= qualifierTargets.size || G.cupQualifiers.size <= 4) {
                    G.cupQualifiers = G.cupQualifiers.take(4).toCollection(ArrayList())
                    G.cupQualFinished = true
                    buildMainCupEntrants()
                    val line = "چهار سهمیه مقدماتی مشخص شد: " + G.cupQualifiers.mapNotNull { G.teamOrNull(it)?.name }.joinToString("، ")
                    G.cupLog.add(line); G.report.add("🏆 [جام حذفی] $line")
                }
                saveNow()
            }
        }
        return
    }

    // جام اصلی: هفته‌های ۱۱، ۲۰، ۲۹ و سپس نیمه‌نهایی و فینال در ۷ هفته پایانی
    val r = G.cupRound
    if (!G.cupFinished && G.cupEntrants.size > 1 && (force || G.week >= Cal.cupMainWeek(r))) {
        val before = G.cupEntrants.size
        val stage = cupStageName(before)
        val target = if (before and (before - 1) == 0) before / 2 else Integer.highestOneBit(before)
        runKnockoutStage(G.cupEntrants, target, stage, live) { winners ->
            G.cupEntrants = winners.toCollection(ArrayList())
            G.cupRound = r + 1
            if (G.cupEntrants.size == 1) {
                G.cupFinished = true
                val champion = G.teamOrNull(G.cupEntrants.first())
                if (champion != null) {
                    champion.titles++
                    champion.budget += 2_000_000L
                    val line = "فصل ${G.season} - ${domesticCupName(G.cupCountry)}: قهرمان ${champion.name}"
                    G.history.add(line); G.cupLog.add("🏆 قهرمان جام: ${champion.name}"); G.report.add("🏆 [جام حذفی] قهرمان جام: ${champion.name}")
                }
            } else {
                val line = "$stage برگزار شد؛ $before تیم به ${G.cupEntrants.size} تیم رسیدند."
                G.cupLog.add(line); G.report.add("🏆 [جام حذفی] $line")
            }
            saveNow()
        }
    }
}

// اگر تا پایان فصل دوری از جام مانده باشد، سریع شبیه‌سازی می‌شود.
fun finishUserCupQuickly() {
    var guard = 0
    while (G.userTeam >= 0 && G.cupSeason == G.season && !G.cupFinished && guard < 15) {
        playScheduledUserCupWeek(false, true)
        guard++
    }
}

fun userCupEligible(): Boolean {
    val user = G.teamOrNull(G.userTeam) ?: return false
    if (user.country != G.cupCountry) return false
    val lvl = G.leagues.firstOrNull { it.id == user.leagueId }?.level ?: return false
    val feeder = G.leagues.filter { it.country == user.country }.let { l -> l.firstOrNull { it.level == 3 } ?: l.firstOrNull { it.level == 2 } }
    return lvl == 1 || (feeder != null && feeder.id == user.leagueId)
}

fun cupPlanLine(wk: Int): String? {
    if (G.userTeam < 0 || G.cupSeason != G.season || G.cupFinished || !userCupEligible()) return null
    val name = domesticCupName(G.cupCountry)
    val u = G.userTeam
    if (!G.cupQualFinished) {
        if (G.cupQualRound >= 3 || wk < Cal.cupQualWeek(G.cupQualRound)) return null
        if (u !in G.cupQualifiers) return null
        return "🏆 $name • مقدماتی دور ${G.cupQualRound + 1} (حریف در قرعه‌کشی همین هفته مشخص می‌شود)"
    }
    if (G.cupEntrants.size < 2 || wk < Cal.cupMainWeek(G.cupRound)) return null
    val stage = cupStageName(G.cupEntrants.size)
    return if (u in G.cupEntrants) "🏆 $name • $stage (حریف در قرعه‌کشی همین هفته مشخص می‌شود)"
    else "🏆 $name • $stage: تیم شما حذف شده؛ این رقابت را استراحت دارید"
}

@Composable
fun Cups() {
    val rv = G.rev
    val user = G.team(G.userTeam)
    prepareUserCup()
    Page("جام حذفی کشورها") {
        Panel {
            Text("🏆 ${domesticCupName(user.country)}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("مقدماتی: هفته‌های ${(0..2).joinToString("، ") { "${Cal.show(Cal.cupQualWeek(it))}" }} • جام اصلی: هفته‌های ${(0..4).joinToString("، ") { "${Cal.show(Cal.cupMainWeek(it))}" }}. اگر تیم شما در جام باشد، بازی را زنده بازی می‌کنید؛ در صورت حذف، آن هفته‌ها استراحت دارید.")
            Text("تیم شما: ${user.name} • فصل ${G.season} • هفته ${G.week + 1}")
            if (!G.cupQualFinished) {
                Text("مرحله مقدماتی لیگ دسته دوم: دور ${G.cupQualRound + 1} از ۳ • تیم‌های باقی‌مانده: ${G.cupQualifiers.size}")
                Text("چهار تیم نهایی این مرحله به جام اصلی کشور صعود می‌کنند.")
            } else if (!G.cupFinished) {
                Text("مرحله جام اصلی: ${cupStageName(G.cupEntrants.size)} • تیم‌های باقی‌مانده: ${G.cupEntrants.size}")
                Text("ترکیب جام: همه تیم‌های لیگ برتر + دقیقاً چهار تیم صعودکرده از مقدماتی لیگ دسته دوم.")
            } else {
                Text("🏆 قهرمان: ${G.cupEntrants.firstOrNull()?.let { G.teamOrNull(it)?.name } ?: "نامشخص"}")
            }
        }
        Panel {
            Text("تیم‌های حاضر در مرحله فعلی", fontWeight = FontWeight.Bold)
            val ids = if (!G.cupQualFinished) G.cupQualifiers else G.cupEntrants
            for (id in ids) {
                val t = G.teamOrNull(id) ?: continue
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Logo(t, 28.dp); Spacer(Modifier.width(8.dp)); Text(t.name)
                }
            }
        }
        if (G.cupLog.isNotEmpty()) Panel {
            Text("نتایج مراحل برگزارشده", fontWeight = FontWeight.Bold)
            for (line in G.cupLog.takeLast(18).asReversed()) Text("• $line", fontSize = 12.sp)
        }
        val countries = G.leagues.map { it.country }.distinct().filter { it != user.country }
        for (country in countries) {
            val cupName = domesticCupName(country)
            val champion = G.history.lastOrNull { it.contains(cupName) }
            Panel { Text(cupName, fontWeight = FontWeight.Bold); Text(champion ?: "نتیجه این جام در شبیه‌سازی پایان فصل ثبت می‌شود.") }
        }
    }
}

@Composable
fun Play() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val lg = G.leagues.firstOrNull { it.id == t.leagueId }
    val tw = totalWeeks()
    val tb = table(t.leagueId)
    Page("بازی") {
        Panel {
            Text("${lg?.name ?: ""} - فصل ${G.season}", fontWeight = FontWeight.Bold)
            Text("هفته ${G.week} از $tw")
            Text("رتبه شما: ${tb.indexOfFirst { it.id == t.id } + 1} از ${tb.size} | امتیاز ${t.pts}")
        }
        if (G.week < tw) {
            val fx = fixturesFor(t.leagueId)
            val m = if (G.week < fx.size) fx[G.week].firstOrNull { it.first == t.id || it.second == t.id } else null
            val plan = userWeekPlan()
            Panel {
                Text("برنامه هفته ${G.week + 1}", fontWeight = FontWeight.Bold)
                for (l in plan) Text(l, fontSize = 13.sp)
                if (m != null) {
                    val h = G.team(m.first)
                    val a = G.team(m.second)
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Logo(h, 44.dp)
                            Text(h.name, fontSize = 13.sp)
                        }
                        Text("VS", fontWeight = FontWeight.Bold)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Logo(a, 44.dp)
                            Text(a.name, fontSize = 13.sp)
                        }
                    }
                } else {
                    Text(if (plan.isEmpty()) "این هفته استراحت دارید" else "در لیگ این هفته بازی ندارید", fontSize = 13.sp)
                }
            }
            Button(
                onClick = {
                    playWeek(true)
                    G.touch()
                    if (G.pendingPenaltyMatch != null) G.go("penalty") else if (G.live != null) G.go("live")
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
            ) { Text("▶️ بازی زنده - هفته ${G.week + 1}") }
            B("⚡ شبیه‌سازی سریع هفته ${G.week + 1}", Modifier.fillMaxWidth()) {
                playWeek()
                G.touch()
                if (G.pendingPenaltyMatch != null) G.go("penalty")
            }
            B("شبیه‌سازی تا پایان فصل", Modifier.fillMaxWidth()) {
                var lastUserResult = ""
                while (G.week < totalWeeks() && G.pendingPenaltyMatch == null) {
                    playWeek()
                    if (G.report.isNotEmpty()) lastUserResult = G.report.firstOrNull { it.contains(" - ") } ?: G.report.first()
                }
                if (G.pendingPenaltyMatch != null) {
                    G.msg = "⚽ برای تیم شما پنالتی اعلام شده؛ ابتدا ضربه را بزنید."
                    G.go("penalty")
                } else {
                    G.msg = if (lastUserResult.isNotBlank()) "🏁 شبیه‌سازی فصل تمام شد. آخرین نتیجه تیم شما: $lastUserResult" else "فصل شبیه‌سازی شد؛ تیم شما مسابقه‌ای نداشت."
                }
                G.touch()
            }
        } else {
            Panel {
                Text("فصل ${G.season} تمام شد!", fontWeight = FontWeight.Bold)
                if (tb.isNotEmpty()) Text("قهرمان لیگ شما: ${tb[0].name}")
            }
            B("پایان فصل و شروع فصل بعد", Modifier.fillMaxWidth()) {
                endSeason()
                G.touch()
            }
        }
        if (G.msg.isNotEmpty()) {
            Panel {
                Text("🏁 اعلام نتیجه", fontWeight = FontWeight.Bold)
                Text(G.msg, fontWeight = FontWeight.SemiBold)
            }
        }
        if (G.report.isNotEmpty()) {
            Panel {
                Text("گزارش آخرین بازی", fontWeight = FontWeight.Bold)
                for (l in G.report) Text(l)
            }
        }
    }
}

@Composable
fun Academy() {
    val rv = G.rev
    val team = G.team(G.userTeam)
    val youth = G.academy.filter { it.teamId == team.id }.sortedWith(compareBy({ it.age }, { -it.potential }))
    var info by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("manage") }
    var selected by remember { mutableStateOf(setOf<Int>()) }
    var selling by remember { mutableStateOf<AcademyPlayer?>(null) }
    var saleInput by remember { mutableStateOf("") }
    var marketSearch by remember { mutableStateOf("") }
    var marketPosition by remember { mutableStateOf("همه") }
    val coachCosts = listOf(0L, 8_000_000L, 16_000_000L, 28_000_000L, 45_000_000L, 70_000_000L)
    val trainCaps = listOf(0, 2, 3, 4, 4, 5)
    val trainGain = listOf(0, 1, 1, 2, 2, 3)
    val trainedThisWeek = G.academyTrainedSeason == G.season && G.academyTrainedWeek == G.week
    fun youthPrice(p: AcademyPlayer): Long {
        val base = ((p.rating - 35).coerceAtLeast(1).toLong().let { it * it } * 9_000L)
        val ageFactor = if (p.age <= 15) 90L else 100L
        return base * (100L + (p.potential - p.rating).coerceAtLeast(0)) * ageFactor / 10_000L
    }
    Page("آکادمی جوانان", scroll = false) {
        Panel {
            Text("🎓 آکادمی ${team.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("ظرفیت آکادمی: ${youth.size} از ۱۵ بازیکن")
            Text("بازیکنان ۱۴ تا ۱۸ سال؛ در ۱۸ سالگی به تیم اصلی منتقل می‌شوند.")
            LinearProgressIndicator(progress = { youth.size / 15f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                B("⚙️ مدیریت آکادمی", Modifier.weight(1f)) { section = "manage" }
                B("👥 بازیکنان (${youth.size})", Modifier.weight(1f)) { section = "players" }
                B("🛒 بازار استعدادها", Modifier.weight(1f)) { section = "market" }
            }
        }
        if (section == "manage") {
            Panel {
                Text("👨‍🏫 مربی آکادمی", fontWeight = FontWeight.Bold)
                Text(if (G.academyCoachLevel == 0) "هنوز مربی استخدام نکرده‌اید؛ برای آموزش بازیکنان مربی لازم است." else "سطح مربی فعلی: ${G.academyCoachLevel} از ۵")
                if (G.academyCoachLevel < 5) {
                    val next = G.academyCoachLevel + 1
                    B("استخدام / ارتقای مربی به سطح $next • ${money(coachCosts[next])}", Modifier.fillMaxWidth(), team.budget >= coachCosts[next]) {
                        if (team.budget >= coachCosts[next]) {
                            team.budget -= coachCosts[next]; G.academyCoachLevel = next
                            info = "مربی آکادمی به سطح $next ارتقا یافت."; G.touch()
                        } else info = "بودجه کافی نیست."
                    }
                } else Text("⭐ مربی شما در بالاترین سطح قرار دارد.", color = Color(0xFF2E7D32))
                if (G.academyCoachLevel > 0) {
                    val cap = trainCaps[G.academyCoachLevel]
                    Text("سهمیه آموزش هفتگی: حداکثر $cap بازیکن • رشد هر بازیکن: ${trainGain[G.academyCoachLevel]} اورال")
                    Text("انتخاب‌شده: ${selected.size.coerceAtMost(cap)} از $cap")
                    B(if (trainedThisWeek) "✅ آموزش این هفته انجام شده" else "🎯 آموزش بازیکنان انتخاب‌شده", Modifier.fillMaxWidth(), !trainedThisWeek && selected.isNotEmpty() && selected.size <= cap) {
                        var trained = 0
                        val chosen = youth.filter { selected.contains(it.id) }.take(cap)
                        for (p in chosen) {
                            val gain = trainGain[G.academyCoachLevel].coerceAtMost((p.potential - p.rating).coerceAtLeast(0))
                            if (gain > 0) { p.rating += gain; trained++ }
                        }
                        G.academyTrainedSeason = G.season; G.academyTrainedWeek = G.week
                        selected = emptySet()
                        info = "آموزش ${trained} بازیکن انجام شد. سهمیه تا هفته بعد قابل استفاده نیست."
                        G.touch()
                    }
                    if (trainedThisWeek) Text("سهمیه آموزش این هفته مصرف شده است؛ هفته بعد دوباره فعال می‌شود.", color = Color.Gray, fontSize = 12.sp)
                    else Text("برای انتخاب بازیکنان، وارد فهرست بازیکنان آکادمی شو و گزینه آموزش را فعال کن.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Panel {
                Text("➕ جذب استعداد", fontWeight = FontWeight.Bold)
                Text("هزینه جذب هر بازیکن: ۲ میلیون")
                B("جذب بازیکن جوان", Modifier.fillMaxWidth(), youth.size < 15 && team.budget >= 2_000_000L) {
                    if (youth.size >= 15) info = "ظرفیت آکادمی تکمیل است."
                    else if (team.budget < 2_000_000L) info = "بودجه کافی نیست."
                    else { team.budget -= 2_000_000L; G.academy.add(genAcademyPlayer(team)); info = "استعداد جدید به آکادمی اضافه شد."; G.touch() }
                }
            }
            
        } else if (section == "market") {
            val marketPlayers = G.academy
                .filter { it.teamId != team.id }
                .filter { marketSearch.isBlank() || it.name.contains(marketSearch.trim(), ignoreCase = true) }
                .filter { marketPosition == "همه" || it.pos == marketPosition }
                .sortedWith(compareByDescending<AcademyPlayer> { it.potential }.thenByDescending { it.rating })
            Panel {
                Text("🛒 بازار استعدادها", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("بازیکنان آکادمی باشگاه‌های دیگر را بررسی و با پرداخت هزینه جذب کن.")
                Text("ظرفیت خالی شما: ${(15 - youth.size).coerceAtLeast(0)} نفر • بودجه: ${money(team.budget)}")
                OutlinedTextField(
                    value = marketSearch,
                    onValueChange = { marketSearch = it },
                    label = { Text("جست‌وجوی نام بازیکن") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Chips(listOf("همه") + POS, marketPosition) { marketPosition = it }
                Text("نتایج: ${marketPlayers.size}", color = MaterialTheme.colorScheme.primary)
                if (marketPlayers.isEmpty()) {
                    Text("بازیکن قابل خریدی با این فیلتر پیدا نشد. فیلتر را تغییر بده یا بعداً دوباره بررسی کن.")
                    B("ایجاد استعداد برای باشگاه‌های بدون آکادمی", Modifier.fillMaxWidth()) {
                        var created = 0
                        for (club in G.teams.filter { it.id != team.id }) {
                            val count = G.academy.count { it.teamId == club.id }
                            val add = (5 - count).coerceAtLeast(0).coerceAtMost(15 - count)
                            repeat(add) { G.academy.add(genAcademyPlayer(club)); created++ }
                        }
                        info = if (created > 0) "$created استعداد جدید در بازار ایجاد شد." else "همه باشگاه‌ها در حال حاضر بازیکن آکادمی دارند."
                        G.touch()
                    }
                }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(marketPlayers, key = { it.id }) { p ->
                    val price = youthPrice(p) * 12 / 10
                    val seller = G.teamOrNull(p.teamId)
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("${seller?.name ?: "باشگاه نامشخص"} • ${p.age} سال • ${p.country}")
                                Text("${p.pos} • اورال ${p.rating} • پتانسیل ${p.potential}")
                            }
                            Text(if (p.potential >= 85) "⭐ ویژه" else "🎓 جوان", color = Color(0xFF2E7D32))
                        }
                        Text("قیمت انتقال: ${money(price)}")
                        B(
                            "خرید بازیکن",
                            Modifier.fillMaxWidth(),
                            enabled = seller != null && youth.size < 15 && team.budget >= price
                        ) {
                            val currentSeller = G.teamOrNull(p.teamId)
                            val currentYouthCount = G.academy.count { it.teamId == team.id }
                            if (currentSeller == null || currentSeller.id == team.id || !G.academy.any { it.id == p.id && it.teamId == currentSeller.id }) {
                                info = "این بازیکن دیگر در بازار موجود نیست."
                            } else if (currentYouthCount >= 15) {
                                info = "ظرفیت آکادمی شما تکمیل است."
                            } else if (team.budget < price) {
                                info = "بودجه کافی نیست."
                            } else {
                                team.budget -= price
                                currentSeller.budget += price
                                p.teamId = team.id
                                info = "${p.name} از ${currentSeller.name} به آکادمی شما منتقل شد."
                                G.touch()
                            }
                        }
                    }
                }
            }
        } else {
            Panel {
                Text("👥 فهرست بازیکنان آکادمی", fontWeight = FontWeight.Bold)
                Text("برای آموزش هفتگی، بازیکنان را انتخاب کن. سهمیه سطح ${G.academyCoachLevel}: ${trainCaps[G.academyCoachLevel]} نفر")
                if (youth.isEmpty()) Text("در حال حاضر بازیکنی در آکادمی نیست.")
            }
            LazyColumn(Modifier.weight(1f)) {
                items(youth, key = { it.id }) { p ->
                    val price = youthPrice(p)
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("${p.age} سال | ${p.country} | ${p.pos}")
                                Text("اورال ${p.rating} • پتانسیل ${p.potential}")
                            }
                            Text(if (p.potential >= 85) "⭐ استعداد ویژه" else "🎓 جوان", color = Color(0xFF2E7D32))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = selected.contains(p.id), onCheckedChange = { yes ->
                                selected = if (yes) selected + p.id else selected - p.id
                            }, enabled = !trainedThisWeek && G.academyCoachLevel > 0 && p.rating < p.potential && (selected.contains(p.id) || selected.size < trainCaps[G.academyCoachLevel]))
                            Text("انتخاب برای آموزش")
                        }
                        Text("بازه قیمت فروش: ${money(price * 6 / 10)} تا ${money(price * 16 / 10)}", color = MaterialTheme.colorScheme.primary)
                        B("تعیین قیمت و فروش", Modifier.fillMaxWidth()) {
                            selling = p
                            saleInput = (price).toString()
                        }
                    }
                }
            }
        }
        if (info.isNotBlank()) Text(info, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(6.dp))
        if (selling != null) {
            val p = selling!!
            val base = youthPrice(p)
            val minPrice = (base * 6 / 10).coerceAtLeast(1L)
            val maxPrice = (base * 16 / 10).coerceAtLeast(minPrice)
            Prompt("قیمت فروش ${p.name} (${money(minPrice)} تا ${money(maxPrice)})", saleInput, { raw ->
                val price = raw.toLongOrNull()
                if (price == null || price !in minPrice..maxPrice) info = "قیمت باید داخل بازه اعلام‌شده باشد."
                else {
                    val buyer = G.teams.filter { it.id != team.id && it.budget >= price && G.academy.count { a -> a.teamId == it.id } < 15 }.maxByOrNull { it.budget }
                    if (buyer == null) info = "باشگاه خریدار دارای بودجه کافی پیدا نشد."
                    else { buyer.budget -= price; team.budget += price; p.teamId = buyer.id; info = "${p.name} با مبلغ ${money(price)} به ${buyer.name} فروخته شد."; G.touch() }
                }
                selling = null
            }, { selling = null })
        }
    }
}

@Composable
fun Players() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var ageFilter by remember { mutableStateOf("همه سنین") }
    var ratingFilter by remember { mutableStateOf("همه قدرت‌ها") }
    var nationality by remember { mutableStateOf("همه ملیت‌ها") }
    var position by remember { mutableStateOf("همه") }
    val all = squad(t.id)
    val sq = all.filter { p ->
        (ageFilter == "همه سنین" || when (ageFilter) { "زیر ۱۸" -> p.age < 18; "۱۸ تا ۲۳" -> p.age in 18..23; "۲۴ تا ۳۰" -> p.age in 24..30; "۳۱ به بالا" -> p.age >= 31; else -> true }) &&
        (ratingFilter == "همه قدرت‌ها" || when (ratingFilter) { "زیر ۶۰" -> p.rating < 60; "۶۰ تا ۶۹" -> p.rating in 60..69; "۷۰ تا ۷۹" -> p.rating in 70..79; "۸۰ به بالا" -> p.rating >= 80; else -> true }) &&
        (nationality == "همه ملیت‌ها" || p.country == nationality) &&
        (position == "همه" || p.pos == position)
    }.sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))
    Page("ترکیب و بازیکنان", scroll = false) {
        Text("${t.name} - ${all.size} بازیکن | نمایش ${sq.size}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
        Text("فیلتر پست", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه") + POS, position) { position = it }
        Text("فیلتر سن", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه سنین", "زیر ۱۸", "۱۸ تا ۲۳", "۲۴ تا ۳۰", "۳۱ به بالا"), ageFilter) { ageFilter = it }
        Text("فیلتر اورال", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه قدرت‌ها", "زیر ۶۰", "۶۰ تا ۶۹", "۷۰ تا ۷۹", "۸۰ به بالا"), ratingFilter) { ratingFilter = it }
        Text("ملیت", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه ملیت‌ها") + COUNTRIES, nationality) { nationality = it }
        LazyColumn(Modifier.weight(1f)) { items(sq, key = { it.id }) { p -> PlayerRow(p) } }
    }
}

// مختصات جایگاه‌ها روی زمین عمودی: first = موقعیت عرضی، second = عمق (بالا: حمله، پایین: دروازه)
private fun formationSlots(formation: String): List<Pair<Float, Float>> {
    val parts = formation.split("-").mapNotNull { it.toIntOrNull() }
    val defenders = parts.getOrElse(0) { 4 }
    val midfielders = parts.getOrElse(1) { 4 }
    val forwards = parts.getOrElse(2) { 2 }
    val result = mutableListOf(0.5f to 0.90f)
    fun line(count: Int, y: Float) {
        for (i in 0 until count) {
            val x = if (count == 1) 0.5f else 0.11f + (0.78f * i / (count - 1))
            result.add(x to y)
        }
    }
    line(defenders, 0.71f)
    line(midfielders, 0.46f)
    line(forwards, 0.19f)
    return result.take(11)
}

@Composable
fun Tactics() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id).sortedByDescending { it.rating }
    val current = G.lineup.mapNotNull { id -> sq.firstOrNull { it.id == id } }.take(11).toMutableList()
    val starters = (current + autoLineup(t.id, G.formation).filter { p -> current.none { it.id == p.id } })
        .take(11)
    val starterIds = starters.map { it.id }
    val bench = sq.filter { it.id !in starterIds }
    var selectedSlot by remember(t.id) { mutableIntStateOf(0) }
    var dragOrigin by remember(t.id) { mutableIntStateOf(-1) }
    var dragDelta by remember(t.id) { mutableStateOf(Offset.Zero) }
    var selectedBenchId by remember(t.id) { mutableIntStateOf(-1) }
    val slots = formationSlots(G.formation)

    Page("ترکیب و تاکتیک") {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("بازیکن انتخاب‌شده: ${selectedSlot + 1}/11", color = Color.Gray, fontSize = 12.sp)
            }
            B("ترکیب خودکار") {
                G.lineup = ArrayList(autoLineup(t.id, G.formation).map { it.id })
                selectedSlot = 0
                G.touch()
            }
        }
        Text("آرایش تیم", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Chips(FORMS, G.formation) { f ->
            G.formation = f
            G.lineup = ArrayList(autoLineup(t.id, f).map { it.id })
            selectedSlot = 0
            G.touch()
        }

        // زمین عمودی: دروازه‌بان پایین، مهاجم‌ها بالا؛ مستقل از RTL
        val gkTeam = remember { Team(-1, "", "", 0, 0xFFF9A825, 0xFF212121, 0, null, 0L) }
        val maxLine = (FORMS.firstOrNull { it == G.formation } ?: "4-4-2").split("-").mapNotNull { it.toIntOrNull() }.maxOrNull() ?: 4
        val nodeW = if (maxLine >= 5) 62.dp else 78.dp
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            BoxWithConstraints(
                Modifier.fillMaxWidth().height(480.dp).clip(RoundedCornerShape(14.dp))
                    .border(2.dp, Color(0xFFB8D9B7), RoundedCornerShape(14.dp))
            ) {
                val pitchWidthPx = with(LocalDensity.current) { maxWidth.toPx() }
                val pitchHeightPx = with(LocalDensity.current) { maxHeight.toPx() }
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val stripes = 10
                    for (i in 0 until stripes) {
                        drawRect(
                            if (i % 2 == 0) Color(0xFF1B7A43) else Color(0xFF17703C),
                            Offset(0f, h * i / stripes), Size(w, h / stripes + 1f)
                        )
                    }
                    val lc = Color(0xCCFFFFFF)
                    val sw = 2.dp.toPx()
                    val m = 8.dp.toPx()
                    drawRect(lc, Offset(m, m), Size(w - 2 * m, h - 2 * m), style = Stroke(sw))
                    drawLine(lc, Offset(m, h / 2f), Offset(w - m, h / 2f), sw)
                    drawCircle(lc, radius = w * 0.14f, center = Offset(w / 2f, h / 2f), style = Stroke(sw))
                    drawCircle(lc, radius = 3.dp.toPx(), center = Offset(w / 2f, h / 2f))
                    val bw = w * 0.58f
                    val bh = h * 0.15f
                    val gw = w * 0.28f
                    val gh = h * 0.055f
                    drawRect(lc, Offset((w - bw) / 2f, m), Size(bw, bh), style = Stroke(sw))
                    drawRect(lc, Offset((w - gw) / 2f, m), Size(gw, gh), style = Stroke(sw))
                    drawRect(lc, Offset((w - bw) / 2f, h - m - bh), Size(bw, bh), style = Stroke(sw))
                    drawRect(lc, Offset((w - gw) / 2f, h - m - gh), Size(gw, gh), style = Stroke(sw))
                    drawCircle(lc, radius = 2.dp.toPx(), center = Offset(w / 2f, m + h * 0.105f))
                    drawCircle(lc, radius = 2.dp.toPx(), center = Offset(w / 2f, h - m - h * 0.105f))
                }
                slots.forEachIndexed { index, point ->
                    val player = starters.getOrNull(index) ?: return@forEachIndexed
                    val sel = index == selectedSlot
                    val shown = if (nodeW < 70.dp) player.name.substringAfterLast(' ') else player.name
                    Column(
                        Modifier.absoluteOffset(x = maxWidth * point.first - nodeW / 2, y = maxHeight * point.second - 36.dp)
                            .width(nodeW).clip(RoundedCornerShape(8.dp))
                            .clickable {
                                // لمس بازیکن فقط جایگاه را انتخاب می‌کند؛ هیچ تعویضی بدون دکمه انجام نمی‌شود.
                                selectedSlot = index
                            }
                            .pointerInput(index, starters, slots) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragOrigin = index; dragDelta = Offset.Zero },
                                    onDrag = { change, amount -> change.consume(); dragDelta += amount },
                                    onDragEnd = {
                                        if (dragOrigin in starters.indices) {
                                            val wPx = pitchWidthPx
                                            val hPx = pitchHeightPx
                                            val originPoint = slots.getOrNull(dragOrigin) ?: (0.5f to 0.9f)
                                            val drop = Offset(originPoint.first * wPx, originPoint.second * hPx) + dragDelta
                                            val target = slots.indices.minByOrNull { i ->
                                                val pt = slots[i]
                                                val dx = pt.first * wPx - drop.x
                                                val dy = pt.second * hPx - drop.y
                                                dx * dx + dy * dy
                                            } ?: dragOrigin
                                            if (target != dragOrigin && target in starters.indices) {
                                                val ids = starters.map { it.id }.toMutableList()
                                                val temp = ids[dragOrigin]; ids[dragOrigin] = ids[target]; ids[target] = temp
                                                G.lineup = ArrayList(ids); selectedSlot = target; G.touch()
                                            }
                                        }
                                        dragOrigin = -1; dragDelta = Offset.Zero
                                    }
                                )
                            },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                            if (sel) Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0x99FFC107)))
                            Shirt(if (player.pos == "GK") gkTeam else t, 38.dp)
                            Text(
                                player.pos, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopStart).clip(RoundedCornerShape(4.dp))
                                    .background(posColor(player.pos)).padding(horizontal = 3.dp)
                            )
                            Text(
                                "${player.rating}", fontSize = 9.sp, color = Color(0xFFFFE082), fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopEnd).clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xE60B1F17)).padding(horizontal = 3.dp)
                            )
                        }
                        Text(
                            shown, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center,
                            color = if (sel) Color.Black else Color.White, fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                                .background(if (sel) Color(0xFFFFC107) else Color(0xCC0B1F17))
                                .border(1.dp, if (sel) Color.White else Color(0xFF4ADE80), RoundedCornerShape(6.dp))
                                .padding(horizontal = 3.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
        Text("برای انتخاب بازیکن، روی او بزن؛ لمس بازیکن فقط جایگاه را انتخاب می‌کند و هیچ تعویضی انجام نمی‌شود. برای تعویض، جایگاه بازیکن اصلی و بازیکن ذخیره را انتخاب کن و حتماً دکمه «تأیید تعویض» را بزن. جابه‌جایی جایگاه بازیکنان اصلی با نگه‌داشتن و کشیدن همچنان فعال است.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 3.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ذخیره‌ها (${bench.size})", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("سبک بازی", fontSize = 12.sp)
        }
        Chips(STY, STY[G.style]) { s -> G.style = STY.indexOf(s); G.touch() }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            bench.forEach { p ->
                Column(
                    Modifier.width(94.dp).clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF202A32)).border(1.dp, Color(0xFF64748B), RoundedCornerShape(8.dp))
                        .border(2.dp, if (selectedBenchId == p.id) Color(0xFFFFC107) else Color(0xFF64748B), RoundedCornerShape(8.dp))
                        .clickable { selectedBenchId = p.id }.padding(7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Shirt(if (p.pos == "GK") gkTeam else t, 34.dp)
                    Text(p.name, color = Color.White, fontSize = 11.sp, maxLines = 1)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.pos, color = posColor(p.pos), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Spacer(Modifier.width(6.dp))
                        Text("${p.rating}", color = Color(0xFFFFD54F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (selectedBenchId >= 0) "ذخیره انتخاب‌شده: ${squad(t.id).firstOrNull { it.id == selectedBenchId }?.name ?: "—"}" else "ابتدا یک بازیکن ذخیره را انتخاب کن",
                modifier = Modifier.weight(1f), fontSize = 12.sp, color = Color.Gray
            )
            Button(
                enabled = selectedBenchId >= 0 && selectedSlot in starters.indices,
                onClick = {
                    val ids = starters.map { it.id }.toMutableList()
                    val benchIndex = bench.indexOfFirst { it.id == selectedBenchId }
                    if (benchIndex >= 0 && selectedSlot in ids.indices) {
                        ids[selectedSlot] = selectedBenchId
                        G.lineup = ArrayList(ids)
                        selectedBenchId = -1
                        G.touch()
                    }
                }
            ) { Text("تأیید تعویض") }
        }
    }
}

@Composable
fun Count() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id)
    Page("تعداد بازیکنان", scroll = false) {
        Panel {
            Text("مجموع: ${sq.size} نفر (حداکثر ${G.ppt + 8})", fontWeight = FontWeight.Bold)
            Text("دروازه‌بان: ${sq.count { it.pos == "GK" }}  |  مدافع: ${sq.count { it.pos == "DF" }}")
            Text("هافبک: ${sq.count { it.pos == "MF" }}  |  مهاجم: ${sq.count { it.pos == "FW" }}")
            if (sq.isNotEmpty()) {
                Text("میانگین سن: ${String.format("%.1f", sq.map { it.age }.average())} | میانگین قدرت: ${String.format("%.1f", sq.map { it.rating }.average())}")
            }
            Text("ارزش کل: ${money(sq.sumOf { it.value })}")
        }
        Text("آزاد کردن بازیکن (حداقل ۱۵ نفر باید بماند)", modifier = Modifier.padding(4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(sq.sortedBy { it.rating }, key = { it.id }) { p ->
                PlayerRow(p) {
                    OutlinedButton(onClick = {
                        if (squad(t.id).size > 15) {
                            G.players.remove(p)
                            G.touch()
                        }
                    }) { Text("آزاد") }
                }
            }
        }
    }
}

@Composable
fun Penalty() {
    val match = G.pendingPenaltyMatch
    if (match == null) { LaunchedEffect(Unit) { G.back() }; return }
    var power by remember { mutableFloatStateOf(0.72f) }
    val shooterTeam = if (G.penaltySide == 0) match.h else match.a
    val keeperTeam = if (G.penaltySide == 0) match.a else match.h
    val shooter = lineupOf(shooterTeam).filter { it.pos == "FW" || it.pos == "MF" }.maxByOrNull { it.rating }
        ?: lineupOf(shooterTeam).first()
    val zones = listOf("چپ بالا", "وسط بالا", "راست بالا", "چپ", "وسط", "راست", "چپ پایین", "وسط پایین", "راست پایین")
    Page("ضربه پنالتی", scroll = false) {
        Panel {
            Text("⚽ پنالتی برای ${shooterTeam.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("زننده: ${shooter.name}  •  دروازه‌بان: ${keeperTeam.name}")
            Text("جهت شوت را انتخاب کن؛ سپس نتیجه مهار یا گل شدن مشخص می‌شود.")
        }
        Canvas(Modifier.fillMaxWidth().weight(1f).padding(8.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF267A3D))) {
            val w = size.width; val h = size.height
            drawRect(Color(0xFF267A3D))
            drawRect(Color.White, Offset(w * 0.13f, h * 0.12f), Size(w * 0.74f, h * 0.72f), style = Stroke(3f))
            drawRect(Color.White, Offset(w * 0.30f, h * 0.12f), Size(w * 0.40f, h * 0.30f), style = Stroke(3f))
            drawCircle(Color.White, radius = 7f, center = Offset(w * 0.5f, h * 0.53f))
            drawRect(Color(0xFFEEEEEE), Offset(w * 0.28f, h * 0.08f), Size(w * 0.44f, h * 0.035f))
        }
        Text("گوشه‌ی شوت را انتخاب کن", fontWeight = FontWeight.Bold)
        for (row in 0..2) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (col in 0..2) {
                val idx = row * 3 + col + 1
                OutlinedButton(onClick = { resolveInteractivePenalty(idx, power) }, modifier = Modifier.weight(1f)) {
                    Text(zones[idx - 1], fontSize = 11.sp)
                }
            }
        }
        Text("قدرت ضربه: ${(power * 100).toInt()}٪")
        Slider(value = power, onValueChange = { power = it }, valueRange = 0.35f..1f)
        Text("قدرت بیشتر سرعت شوت را بالا می‌برد؛ قدرت خیلی زیاد کنترل ضربه را دشوارتر می‌کند.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun Live() {
    val rv = G.rev
    val m = G.live
    if (m == null) {
        LaunchedEffect(Unit) { if (G.screen == "live") G.back() }
        return
    }
    var minute by remember(m) { mutableStateOf(0) }
    var speed by remember { mutableStateOf("×۱") }
    var selectedStarterId by remember(m) { mutableIntStateOf(-1) }
    var selectedBenchId by remember(m) { mutableIntStateOf(-1) }
    var substitutions by remember(m) { mutableIntStateOf(0) }
    val userMatchTeam = if (m.h.id == G.userTeam) m.h else m.a
    val userStarting = if (userMatchTeam.id == G.userTeam) lineupOf(userMatchTeam) else emptyList()
    val userBench = if (userMatchTeam.id == G.userTeam) squad(userMatchTeam.id).filter { p -> userStarting.none { it.id == p.id } } else emptyList()
    LaunchedEffect(speed, m) {
        while (minute < 90) {
            delay(
                when (speed) {
                    "×۱" -> 450L
                    "×۲" -> 220L
                    else -> 80L
                }
            )
            minute++
        }
    }
    val hs = m.hg
    val aS = m.ag
    val shown = m.ev.filter { it.min <= minute }.reversed()
    LaunchedEffect(minute, m) {
        advanceLiveMatch(m, minute)
        if (minute >= 90) finalizeLiveMatch(m)
    }
    val status = if (minute >= 90) "پایان بازی" else if (minute < 45) "نیمه اول" else "نیمه دوم"
    BackHandler(enabled = minute < 90) { minute = 90 }
    Page("بازی زنده", scroll = false) {
        if (m.tag.isNotBlank()) Text(m.tag, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Panel {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(m.h, 48.dp)
                    Text(m.h.name, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$hs - $aS", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("$status | ${minute}'", fontSize = 13.sp, color = Color.Gray)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(m.a, 48.dp)
                    Text(m.a.name, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
            LinearProgressIndicator(progress = { minute / 90f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("سرعت: ", fontWeight = FontWeight.Bold)
            Chips(listOf("×۱", "×۲", "×۴"), speed) { speed = it }
        }
        if (minute < 90 && userMatchTeam.id == G.userTeam) {
            Panel {
                Text("🔁 تعویض بازیکن • $substitutions از ۵", fontWeight = FontWeight.Bold)
                Text("۱) بازیکن اصلی را انتخاب کن", fontSize = 12.sp, color = Color.Gray)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    userStarting.forEach { player ->
                        OutlinedButton(
                            onClick = { selectedStarterId = player.id },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selectedStarterId == player.id) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            )
                        ) { Text("${player.pos} ${player.name}", fontSize = 11.sp) }
                    }
                }
                Text("۲) بازیکن ذخیره را انتخاب کن", fontSize = 12.sp, color = Color.Gray)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    userBench.forEach { player ->
                        OutlinedButton(
                            onClick = { selectedBenchId = player.id },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selectedBenchId == player.id) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent
                            )
                        ) { Text("${player.pos} ${player.name}", fontSize = 11.sp) }
                    }
                }
                Button(
                    onClick = {
                        val updated = G.lineup.toMutableList()
                        val index = updated.indexOf(selectedStarterId)
                        if (index >= 0 && updated.none { it == selectedBenchId }) {
                            updated[index] = selectedBenchId
                            G.lineup = ArrayList(updated)
                            substitutions++
                            selectedStarterId = -1
                            selectedBenchId = -1
                            G.touch()
                        }
                    },
                    enabled = substitutions < 5 && selectedStarterId >= 0 && selectedBenchId >= 0 &&
                        G.lineup.contains(selectedStarterId) && !G.lineup.contains(selectedBenchId),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("تأیید تعویض") }
            }
        }
        if (minute >= 90) {
            Panel {
                Text("🏁 نتیجه نهایی مسابقه", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("${m.h.name}  $hs - $aS  ${m.a.name}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (m.penH >= 0) {
                    Text("🥅 ضربات پنالتی: ${m.penH} - ${m.penA} • صعود: ${m.winner().name}", fontWeight = FontWeight.SemiBold)
                }
                Text("مسابقه به پایان رسید.", color = Color.Gray)
            }
            if (G.liveQueue.isNotEmpty()) {
                val nxt = G.liveQueue.first()
                Button({ G.live = G.liveQueue.removeAt(0); G.touch() }, Modifier.fillMaxWidth()) {
                    Text("▶️ بازی بعدی همین هفته: ${nxt.tag.ifBlank { "لیگ" }}")
                }
            } else B("مشاهده نتیجه و بازگشت", Modifier.fillMaxWidth()) { G.back() }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { e ->
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${e.min}'", Modifier.width(36.dp), color = Color.Gray, fontSize = 12.sp)
                        Text(
                            e.text, Modifier.weight(1f),
                            fontWeight = if (e.side < 2) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (e.side < 2) 16.sp else 13.sp
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun Transfers() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var mode by remember { mutableStateOf("خرید") }
    var pos by remember { mutableStateOf("همه") }
    var cty by remember { mutableStateOf("همه") }
    var ageFilter by remember { mutableStateOf("همه سنین") }
    var ratingFilter by remember { mutableStateOf("همه قدرت‌ها") }
    var q by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    val modes = listOf("خرید", "فروش", "پیشنهادها (${G.offers.size})", "اخبار")
    Page("نقل و انتقالات", scroll = false) {
        Text("بودجه: ${money(t.budget)} | بازیکنان: ${squad(t.id).size}", fontWeight = FontWeight.Bold)
        Chips(modes, modes.first { it.startsWith(mode) }) { mode = it.substringBefore(" (") }
        if (info.isNotEmpty()) Text(info, color = MaterialTheme.colorScheme.primary)
        if (mode == "اخبار") {
            if (G.news.isEmpty()) Text("هنوز خبری نیست. پس از پایان هر فصل بازار نقل و انتقالات باز می‌شود.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.news.reversed()) { n ->
                    Column {
                        Text(n, Modifier.padding(8.dp), fontSize = 13.sp)
                        HorizontalDivider()
                    }
                }
            }
        } else if (mode == "پیشنهادها") {
            if (G.offers.isEmpty()) Text("پیشنهادی برای بازیکنان شما نیست.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.offers.toList()) { o ->
                    val p = G.players.firstOrNull { it.id == o.pid }
                    val b = G.teamOrNull(o.from)
                    if (p != null && b != null) {
                        PlayerRow(p) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(b.name.take(10), fontSize = 11.sp, color = Color.Gray)
                                Row {
                                    Button(onClick = {
                                        if (p.teamId != t.id) {
                                            G.offers.remove(o)
                                            info = "این بازیکن دیگر در تیم شما نیست"
                                        } else if (squad(t.id).size <= 15) {
                                            info = "حداقل ۱۵ بازیکن لازم است"
                                        } else if (b.budget < o.price) {
                                            info = "باشگاه خریدار بودجه ندارد"
                                        } else {
                                            t.budget += o.price
                                            b.budget -= o.price
                                            p.teamId = b.id
                                            G.offers.remove(o)
                                            addNews("🔁 ${p.name} | مبدا: ${t.name} ← مقصد: ${b.name} | ${money(o.price)}")
                                            info = "${p.name} فروخته شد"
                                        }
                                        G.touch()
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(money(o.price), fontSize = 12.sp) }
                                    Spacer(Modifier.width(4.dp))
                                    OutlinedButton(onClick = {
                                        G.offers.remove(o)
                                        G.touch()
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("رد", fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Chips(listOf("همه") + POS, pos) { pos = it }
            if (mode == "خرید") {
                Chips(listOf("همه") + COUNTRIES, cty) { cty = it }
                TextF("جستجوی نام بازیکن", q, { q = it }, Modifier.fillMaxWidth())
            }
            Text("فیلتر سن", fontWeight = FontWeight.SemiBold)
            Chips(listOf("همه سنین", "زیر ۱۸", "۱۸ تا ۲۳", "۲۴ تا ۳۰", "۳۱ به بالا"), ageFilter) { ageFilter = it }
            Text("فیلتر اورال", fontWeight = FontWeight.SemiBold)
            Chips(listOf("همه قدرت‌ها", "زیر ۶۰", "۶۰ تا ۶۹", "۷۰ تا ۷۹", "۸۰ به بالا"), ratingFilter) { ratingFilter = it }
            fun fitsFilters(p: Player): Boolean =
                (ageFilter == "همه سنین" || when (ageFilter) { "زیر ۱۸" -> p.age < 18; "۱۸ تا ۲۳" -> p.age in 18..23; "۲۴ تا ۳۰" -> p.age in 24..30; "۳۱ به بالا" -> p.age >= 31; else -> true }) &&
                (ratingFilter == "همه قدرت‌ها" || when (ratingFilter) { "زیر ۶۰" -> p.rating < 60; "۶۰ تا ۶۹" -> p.rating in 60..69; "۷۰ تا ۷۹" -> p.rating in 70..79; "۸۰ به بالا" -> p.rating >= 80; else -> true })
            val list: List<Player> = remember(G.rev, mode, pos, cty, ageFilter, ratingFilter, q) {
                if (mode == "خرید") {
                    G.players.filter { p -> p.teamId != t.id && fitsFilters(p) && (pos == "همه" || p.pos == pos) && (q.isBlank() || p.name.contains(q.trim(), ignoreCase = true)) &&
                        (cty == "همه" || p.country == cty)
                    }.sortedByDescending { it.rating }
                } else {
                    squad(t.id).filter { fitsFilters(it) && (pos == "همه" || it.pos == pos) }.sortedByDescending { it.rating }
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.id }) { p ->
                    val price = if (mode == "خرید") p.value * 12 / 10 else p.value * 8 / 10
                    val from = G.teamOrNull(p.teamId)
                    PlayerRow(p) {
                        if (mode == "خرید") {
                            Text((from?.name ?: "").take(9), fontSize = 11.sp, color = Color.Gray)
                        }
                        Button(onClick = {
                            if (mode == "خرید") {
                                if (t.budget < price) {
                                    info = "بودجه کافی نیست"
                                } else if (squad(t.id).size >= G.ppt + 8) {
                                    info = "سقف تعداد بازیکنان پر است"
                                } else if (from != null && squad(from.id).size <= 15) {
                                    info = "تیم فروشنده این بازیکن را نمی‌فروشد"
                                } else {
                                    t.budget -= price
                                    if (from != null) from.budget += price
                                    p.teamId = t.id
                                    addNews("🛒 ${p.name} | مبدا: ${from?.name ?: "بازار آزاد"} ← مقصد: ${t.name} | ${money(price)}")
                                    info = "${p.name} خریداری شد"
                                    G.touch()
                                }
                            } else {
                                if (squad(t.id).size <= 15) {
                                    info = "حداقل ۱۵ بازیکن لازم است"
                                } else {
                                    t.budget += price
                                    val c = G.teams.filter { it.id != t.id && squad(it.id).size < G.ppt + 4 }
                                    if (c.isEmpty()) G.players.remove(p) else p.teamId = c.random().id
                                    info = "${p.name} فروخته شد"
                                    G.touch()
                                }
                            }
                        }) { Text(money(price), fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun Settings() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var dlg by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var nm by remember { mutableStateOf(t.name) }
    val pickClubLogo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val path = copyLogo(uri, t.id)
            if (path != null) { t.logo = path; G.touch(); saveNow() }
        }
    }
    var restoreUri by remember { mutableStateOf<Uri?>(null) }
    var backupMsg by remember { mutableStateOf("") }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) exportSaveTo(uri)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) restoreUri = uri
    }
    Page("تنظیمات") {
        Panel {
            Text("🌐 زبان", fontWeight = FontWeight.Bold)
            Chips(listOf("فارسی", "English"), if (I18n.lang == "en") "English" else "فارسی") { l ->
            I18n.changeLang(if (l == "English") "en" else "fa")
            G.ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString("lang", I18n.lang).apply()
        }
        }
        Panel {
            Text("سطح سختی", fontWeight = FontWeight.Bold)
            Chips(DIFFS, DIFFS[G.diff]) { d ->
                G.diff = DIFFS.indexOf(d)
                G.touch()
            }
        }
        Panel {
            TextF("نام تیم من", nm, { nm = it }, Modifier.fillMaxWidth())
            B("ذخیره نام") {
                if (nm.isNotBlank()) {
                    t.name = nm.trim()
                    G.touch()
                }
            }
        }
        Panel {
            Text("🛡 لوگوی باشگاه", fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 64.dp)
                Spacer(Modifier.width(12.dp))
                Text("لوگوی اختصاصی تیم را از گالری انتخاب کنید.", modifier = Modifier.weight(1f))
            }
            B("🖼 انتخاب لوگو از گالری", Modifier.fillMaxWidth()) { pickClubLogo.launch("image/*") }
            B("بازگشت به لوگوی پیش‌فرض") {
                t.logo = clubLogoPath(t.country, t.name)
                G.touch(); saveNow()
            }
        }
        Panel {
            Text("پنل ادمین", fontWeight = FontWeight.Bold)
            B("ورود به پنل ادمین", Modifier.fillMaxWidth()) {
                pw = ""
                err = false
                dlg = "admin"
            }
        }
        Panel {
            Text("💾 پشتیبان‌گیری از پیشرفت بازی", fontWeight = FontWeight.Bold)
            Text("اگر برنامه را حذف کنید، پیشرفت بازی هم پاک می‌شود. قبل از حذف، یک فایل پشتیبان بگیرید و بعد از نصب دوباره، از همین بخش بازیابی کنید تا بازی از همان‌جا ادامه پیدا کند.", fontSize = 12.sp)
            B("ذخیره فایل پشتیبان", Modifier.fillMaxWidth()) {
                backupMsg = ""
                backupLauncher.launch("morabbi_backup_season${G.season}_week${G.week}.json")
            }
            B("بازیابی از فایل پشتیبان", Modifier.fillMaxWidth()) {
                backupMsg = ""
                restoreLauncher.launch(arrayOf("*/*"))
            }
            if (backupMsg.isNotEmpty()) Text(backupMsg, color = MaterialTheme.colorScheme.primary)
        }
        Panel {
            OutlinedButton(onClick = { dlg = "new" }, modifier = Modifier.fillMaxWidth()) { Text("شروع بازی جدید (حذف همه‌چیز)") }
        }
    }
    if (dlg == "admin") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("رمز ادمین") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pw,
                        onValueChange = { pw = it },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        label = { Text("رمز") }
                    )
                    if (err) Text("رمز اشتباه است", color = Color.Red)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pw == ADMIN_PASS) {
                        dlg = ""
                        G.go("admin")
                    } else {
                        err = true
                    }
                }) { Text("ورود") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("لغو") } }
        )
    }
    if (restoreUri != null) {
        AlertDialog(
            onDismissRequest = { restoreUri = null },
            title = { Text("بازیابی پشتیبان؟") },
            text = { Text("بازی فعلی با پیشرفت داخل فایل پشتیبان جایگزین می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    val u = restoreUri
                    restoreUri = null
                    if (u != null) {
                        val r = importSaveFrom(u)
                        backupMsg = r ?: "بازی با موفقیت بازیابی شد"
                    }
                }) { Text("بازیابی") }
            },
            dismissButton = { TextButton(onClick = { restoreUri = null }) { Text("لغو") } }
        )
    }
    if (dlg == "new") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("شروع بازی جدید؟") },
            text = { Text("همه اطلاعات فعلی پاک می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = ""
                    newWorld()
                    G.touch()
                }) { Text("بله") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("لغو") } }
        )
    }
}

@Composable
fun TableScr() {
    val rv = G.rev
    val me = G.team(G.userTeam)
    var lid by remember { mutableStateOf(me.leagueId) }
    var cty by remember { mutableStateOf(G.leagues.firstOrNull { it.id == me.leagueId }?.country ?: "ایران") }
    var tab by remember { mutableStateOf("جدول") }
    val sorted = lgSorted().filter { it.country == cty }.ifEmpty { lgSorted() }
    val lg = sorted.firstOrNull { it.id == lid } ?: sorted.first()
    val maxLevel = sorted.maxOf { it.level }
    val tb = table(lg.id)
    Page("رتبه‌بندی لیگ", scroll = false) {
        Chips(COUNTRIES.filter { c -> G.leagues.any { it.country == c } }, lg.country) { c ->
            cty = c
            lid = lgSorted().first { it.country == c }.id
        }
        Text("🏆 لیگ کشور ${lg.country}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
        Chips(sorted.map { it.name }, lg.name) { n -> lid = sorted.first { it.name == n }.id }
        Chips(listOf("جدول", "آقای گل"), tab) { tab = it }
        if (tab == "جدول") {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Cell("#", 24.dp, true)
                Spacer(Modifier.width(24.dp))
                Text("تیم", Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Cell("مسابقه", 28.dp, true)
                Cell("برد", 28.dp, true)
                Cell("مس", 28.dp, true)
                Cell("باخت", 28.dp, true)
                Cell("+/-", 30.dp, true)
                Cell("امتیاز", 34.dp, true)
            }
            HorizontalDivider()
            LazyColumn(Modifier.weight(1f)) {
                items(tb.size) { i ->
                    val t = tb[i]
                    val bg = when {
                        t.id == me.id -> Color(0x33FFC107)
                        lg.level > 1 && i < G.promo -> Color(0x3300C853)
                        lg.level < maxLevel && i >= tb.size - G.promo -> Color(0x33F44336)
                        else -> Color.Transparent
                    }
                    Column {
                        Row(
                            Modifier.fillMaxWidth().background(bg).padding(vertical = 5.dp, horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cell("${i + 1}", 24.dp)
                            Logo(t, 24.dp)
                            Text(t.name, Modifier.weight(1f).padding(horizontal = 4.dp).clickable { G.viewedTeamId = t.id; G.go("teamDetails") }, fontSize = 12.sp, maxLines = 1)
                            Cell("${t.p}", 28.dp)
                            Cell("${t.w}", 28.dp)
                            Cell("${t.d}", 28.dp)
                            Cell("${t.l}", 28.dp)
                            Cell("${t.gf - t.ga}", 30.dp)
                            Cell("${t.pts}", 34.dp, true)
                        }
                        HorizontalDivider()
                    }
                }
            }
            Text("سبز: صعود | قرمز: سقوط | زرد: تیم شما", fontSize = 11.sp, color = Color.Gray)
        } else {
            val sc = remember(G.rev, lg.id) { tb.flatMap { squad(it.id) }.sortedByDescending { it.goals }.take(15) }
            LazyColumn(Modifier.weight(1f)) {
                items(sc.size) { i ->
                    val p = sc[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(G.teamOrNull(p.teamId)?.name ?: "", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.clickable { G.viewedTeamId = p.teamId; G.go("teamDetails") })
                            }
                            Text("${p.goals} گل", fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun Overall() {
    val rv = G.rev
    var tab by remember { mutableStateOf("تیم‌ها") }
    Page("رتبه‌بندی کلی", scroll = false) {
        Chips(listOf("تیم‌ها", "گلزنان", "تاریخچه"), tab) { tab = it }
        if (tab == "تیم‌ها") {
            val l = remember(G.rev) { G.teams.sortedByDescending { it.allPts + it.pts } }
            LazyColumn(Modifier.weight(1f)) {
                items(l.size) { i ->
                    val t = l[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp))
                            Logo(t, 30.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.name, fontWeight = if (t.id == G.userTeam) FontWeight.Bold else FontWeight.Normal)
                                Text(G.leagues.firstOrNull { it.id == t.leagueId }?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${t.allPts + t.pts} امتیاز")
                                Text("🏆 ${t.titles}", fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        } else if (tab == "گلزنان") {
            val sc = remember(G.rev) { G.players.sortedByDescending { it.total }.take(20) }
            LazyColumn(Modifier.weight(1f)) {
                items(sc.size) { i ->
                    val p = sc[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(G.teamOrNull(p.teamId)?.name ?: "", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.clickable { G.viewedTeamId = p.teamId; G.go("teamDetails") })
                            }
                            Text("${p.total} گل", fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
            }
        } else {
            if (G.history.isEmpty()) Text("هنوز فصلی تمام نشده است.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.history.reversed()) { h ->
                    Column {
                        Text(h, Modifier.padding(8.dp), fontSize = 13.sp)
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

// ======================= پنل ادمین =======================

@Composable
fun Admin() {
    val rv = G.rev
    var tpl by remember { mutableStateOf(G.tpl.toString()) }
    var ppt by remember { mutableStateOf(G.ppt.toString()) }
    var promo by remember { mutableStateOf(G.promo.toString()) }
    var msg by remember { mutableStateOf("") }
    var rename by remember { mutableStateOf(-1) }
    var expanded by remember { mutableStateOf(setOf<Int>()) }
    val counts = HashMap<Int, Int>()
    for (t in G.teams) counts[t.leagueId] = (counts[t.leagueId] ?: 0) + 1
    Page("پنل ادمین") {
        Panel {
            Text("تنظیمات کلی", fontWeight = FontWeight.Bold)
            NumField("تعداد تیم هر لیگ", tpl, { tpl = it }, Modifier.fillMaxWidth())
            NumField("تعداد بازیکن هر تیم", ppt, { ppt = it }, Modifier.fillMaxWidth())
            NumField("تعداد تیم صعود/سقوط", promo, { promo = it }, Modifier.fillMaxWidth())
            B("اعمال تغییرات (فصل از اول شروع می‌شود)", Modifier.fillMaxWidth()) {
                val a = tpl.toIntOrNull()
                val b = ppt.toIntOrNull()
                val c = promo.toIntOrNull()
                if (a == null || b == null || c == null || a < 2 || a > 40 || b < 16 || b > 40) {
                    msg = "مقدار نامعتبر (تیم: ۲ تا ۴۰ | بازیکن: ۱۶ تا ۴۰)"
                } else {
                    G.tpl = a
                    G.ppt = b
                    G.promo = c
                    applyAdmin()
                    msg = "اعمال شد"
                    G.touch()
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
        }
        for (lg in lgSorted()) {
            Panel {
                Text("${lg.country} - سطح ${lg.level}: ${lg.name} (${counts[lg.id] ?: 0} تیم)", fontWeight = FontWeight.Bold)
                Text("کشور لیگ (برای نام بازیکنان جدید):", fontSize = 12.sp)
                Chips(COUNTRIES, lg.country) { c ->
                    lg.country = c
                    G.touch()
                }
                Row {
                    OutlinedButton(onClick = {
                        rename = lg.id
                    }) { Text("نام", fontSize = 12.sp) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = {
                        newTeam(lg)
                        resetSeason()
                        G.touch()
                    }) { Text("+ تیم", fontSize = 12.sp) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = {
                        if (deleteLeague(lg)) {
                            msg = ""
                            G.touch()
                        } else {
                            msg = "این لیگ قابل حذف نیست (تنها لیگ یا شامل تیم شما)"
                        }
                    }) { Text("حذف لیگ", fontSize = 12.sp) }
                }
                val isOpen = lg.id in expanded
                OutlinedButton(
                    onClick = { expanded = if (isOpen) expanded - lg.id else expanded + lg.id },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (isOpen) "▲ بستن لیست تیم‌ها" else "▼ نمایش تیم‌ها", fontSize = 12.sp) }
                if (isOpen) for (t in G.teams.filter { it.leagueId == lg.id }) {
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            G.editTeam = t.id
                            G.go("adminTeam")
                        }.padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Logo(t, 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(t.name, Modifier.weight(1f))
                        Shirt(t, 28.dp)
                    }
                }
            }
        }
        B("افزودن لیگ جدید", Modifier.fillMaxWidth()) {
            addLeague()
            G.touch()
        }
        B("شروع دوباره فصل (ریست جدول‌ها)", Modifier.fillMaxWidth()) {
            resetSeason()
            G.touch()
        }
    }
    if (rename >= 0) {
        val lg = G.leagues.firstOrNull { it.id == rename }
        if (lg == null) {
            rename = -1
        } else {
            Prompt("نام لیگ", lg.name, { n ->
                if (n.isNotBlank()) {
                    lg.name = n.trim()
                    G.touch()
                }
                rename = -1
            }, { rename = -1 })
        }
    }
}

@Composable
fun AdminTeam() {
    val rv = G.rev
    val t = G.teamOrNull(G.editTeam)
    if (t == null) {
        LaunchedEffect(Unit) { if (G.screen == "adminTeam") G.back() }
        return
    }
    var nm by remember(t.id) { mutableStateOf(t.name) }
    var cnt by remember { mutableStateOf("5") }
    var gc by remember(t.id) { mutableStateOf(t.country) }
    var pn by remember { mutableStateOf("") }
    var pr by remember { mutableStateOf("65") }
    var pa by remember { mutableStateOf("24") }
    var pp by remember { mutableStateOf("FW") }
    var msg by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val p = copyLogo(uri, t.id)
            if (p != null) {
                t.logo = p
                G.touch()
            }
        }
    }
    Page("ویرایش تیم") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 64.dp)
                Spacer(Modifier.width(12.dp))
                Shirt(t, 64.dp)
            }
            TextF("نام تیم", nm, { nm = it }, Modifier.fillMaxWidth())
            B("ذخیره نام") {
                if (nm.isNotBlank()) {
                    t.name = nm.trim()
                    G.touch()
                }
            }
            Text("کشور تیم", fontWeight = FontWeight.Bold)
            Chips(COUNTRIES, t.country) { c ->
                t.country = c
                G.touch()
            }
            Text("لیگ تیم", fontWeight = FontWeight.Bold)
            val lgs = lgSorted()
            Chips(lgs.map { it.name }, lgs.firstOrNull { it.id == t.leagueId }?.name ?: "") { n ->
                t.leagueId = lgs.first { it.name == n }.id
                resetSeason()
                G.touch()
            }
        }
        Panel {
            Text("پیراهن", fontWeight = FontWeight.Bold)
            Text("رنگ اصلی")
            ColorRow(t.c1) { c ->
                t.c1 = c
                G.touch()
            }
            Text("رنگ دوم")
            ColorRow(t.c2) { c ->
                t.c2 = c
                G.touch()
            }
            Chips(SHIRTS, SHIRTS[t.style]) { s ->
                t.style = SHIRTS.indexOf(s)
                G.touch()
            }
        }
        Panel {
            Text("لوگو", fontWeight = FontWeight.Bold)
            B("انتخاب لوگو از حافظه گوشی", Modifier.fillMaxWidth()) { pick.launch("image/*") }
            OutlinedButton(onClick = {
                t.logo = null
                G.touch()
            }, modifier = Modifier.fillMaxWidth()) { Text("لوگوی خودکار (بر اساس رنگ تیم)") }
        }
        Panel {
            Text("بازیکنان (${squad(t.id).size})", fontWeight = FontWeight.Bold)
            Text("ساخت بازیکن تصادفی بر اساس کشور:")
            Chips(COUNTRIES, gc) { gc = it }
            NumField("تعداد", cnt, { cnt = it }, Modifier.fillMaxWidth())
            B("ساخت بازیکنان تصادفی", Modifier.fillMaxWidth()) {
                val n = (cnt.toIntOrNull() ?: 0).coerceIn(0, 30)
                val base = squadAvg(t)
                val kinds = listOf("GK", "DF", "DF", "DF", "MF", "MF", "MF", "FW", "FW")
                repeat(n) { G.players.add(genPlayer(t.id, gc, kinds.random(), base)) }
                msg = "$n بازیکن ساخته شد"
                G.touch()
            }
            OutlinedButton(onClick = {
                val base = squadAvg(t)
                G.players.removeAll { it.teamId == t.id }
                for (pos in posPlan(G.ppt)) G.players.add(genPlayer(t.id, gc, pos, base))
                msg = "کل بازیکنان با کشور $gc ساخته شد"
                G.touch()
            }, modifier = Modifier.fillMaxWidth()) { Text("ساخت مجدد کل بازیکنان این تیم") }
            Text("افزودن بازیکن دستی:", modifier = Modifier.padding(top = 8.dp))
            TextF("نام بازیکن", pn, { pn = it }, Modifier.fillMaxWidth())
            Chips(POS, pp) { pp = it }
            Row {
                NumField("قدرت", pr, { pr = it }, Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                NumField("سن", pa, { pa = it }, Modifier.weight(1f))
            }
            B("افزودن بازیکن", Modifier.fillMaxWidth()) {
                val r = pr.toIntOrNull()
                val a = pa.toIntOrNull()
                if (pn.isBlank() || r == null || a == null) {
                    msg = "اطلاعات ناقص است"
                } else {
                    val rr = r.coerceIn(30, 99)
                    val aa = a.coerceIn(15, 45)
                    G.players.add(Player(G.nid(), pn.trim(), pp, rr, aa, t.id, worth(rr, aa), country = t.country))
                    pn = ""
                    msg = "بازیکن اضافه شد"
                    G.touch()
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
        }
        Panel {
            Text("لیست بازیکنان", fontWeight = FontWeight.Bold)
            for (p in squad(t.id).sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))) {
                PlayerRow(p) {
                    OutlinedButton(onClick = {
                        G.players.remove(p)
                        G.touch()
                    }) { Text("حذف", fontSize = 12.sp) }
                }
            }
        }
        if (t.id != G.userTeam) {
            OutlinedButton(onClick = { confirmDel = true }, modifier = Modifier.fillMaxWidth()) { Text("حذف این تیم") }
        }
    }
    if (confirmDel) {
        AlertDialog(
            onDismissRequest = { confirmDel = false },
            title = { Text("حذف تیم ${t.name}؟") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDel = false
                    removeTeam(t)
                    resetSeason()
                    G.touch()
                    G.back()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("لغو") } }
        )
    }
}


// ساختاردهی/مهاجرت سیوهای قدیمی به کشورها و لیگ‌های جدید
fun ensureWorldStructure() {
    G.ppt = maxOf(G.ppt, 25)
    for ((country, names) in LEAGUE_DEFS) {
        for ((idx, leagueName) in names.withIndex()) {
            val level = idx + 1
            var league = G.leagues.firstOrNull { it.country == country && it.level == level }
            if (league == null) {
                league = League(G.nid(), leagueName, level, country)
                G.leagues.add(league)
            } else {
                league.name = leagueName
                league.country = country
            }
            val existing = G.teams.filter { it.leagueId == league.id }
            existing.forEach { it.country = country }
            if (level == 1) {
                // فقط تیم‌هایی که نام رسمی ندارند نام یک باشگاه رسمیِ آزاد می‌گیرند (بدون ایجاد نام تکراری)؛
                // لوگو همراه نام جدید به‌روز می‌شود.
                val real = REAL_CLUBS[country].orEmpty()
                val taken = G.teams.filter { it.country == country }.map { it.name }.toMutableSet()
                for (team in existing) {
                    if (team.id == G.userTeam || team.name in real) continue
                    val free = real.firstOrNull { it !in taken } ?: break
                    taken.remove(team.name); taken.add(free)
                    team.name = free
                    if (team.logo.isNullOrBlank() || team.logo!!.contains("/club_logos/")) team.logo = clubLogoPath(country, free)
                }
            }
            var n = existing.size
            while (n < G.tpl) { newTeam(league); n++ }
        }
    }
    if (G.worldVer < 3) {
        // مهاجرت سیوهای قدیمی: ستاره‌های تصادفی حذف، نام‌های ایرانیِ تیم‌های خارجی اصلاح، باشگاه‌های بزرگ تقویت، ستاره‌های واقعی اضافه
        G.players.removeAll { it.name in OLD_STAR_NAMES }
        for (t in G.teams.toList()) {
            if (t.country == "ایران") continue
            val w = t.name.split(" ")
            if (w.size == 2 && w[0] in NAME_A && w[1] in NAME_B) t.name = uniqueName(t.country, t.leagueId)
        }
        val grp = G.players.groupBy { it.teamId }
        for (t in G.teams) {
            val lv = G.leagues.firstOrNull { it.id == t.leagueId }?.level ?: 9
            val b = realisticClubBoost(t.name, t.country, lv)
            for (p in grp[t.id].orEmpty()) {
                if (b > 0) p.rating = (p.rating + b * 8 / 10).coerceIn(40, 95)
                p.value = worth(p.rating, p.age)
            }
        }
        addRealStars()
        G.worldVer = 3
    }
    if (G.worldVer < 4) {
        // مهاجرت: اورال باشگاه‌های معروف هر کشور از بقیه تیم‌ها بالاتر می‌رود
        applyFamousRatings()
        G.worldVer = 4
    }
    val plan = posPlan(G.ppt)
    for (t in G.teams) {
        val over = G.academy.filter { it.teamId == t.id }.sortedByDescending { it.potential }.drop(15)
        if (over.isNotEmpty()) G.academy.removeAll(over.toSet())
    }
    val acCount = HashMap<Int, Int>()
    for (a in G.academy) acCount[a.teamId] = (acCount[a.teamId] ?: 0) + 1
    val grouped = G.players.groupBy { it.teamId }
    for (t in G.teams.toList()) {
        val sq = grouped[t.id].orEmpty()
        if (sq.size < G.ppt) {
            val avg = if (sq.isEmpty()) 62 else sq.map { it.rating }.average().toInt()
            for (i in sq.size until G.ppt) G.players.add(genPlayer(t.id, t.country, plan[i % plan.size], avg))
        }
        repeat((5 - (acCount[t.id] ?: 0)).coerceAtLeast(0)) { if ((acCount[t.id] ?: 0) < 15) G.academy.add(genAcademyPlayer(t)) }
    }
    // نگاشت ملیت بازیکنان سیو قدیمی به کشور باشگاه به‌عنوان مقدار پیش‌فرض
    for (p in G.players) if (p.country.isBlank()) p.country = G.teamOrNull(p.teamId)?.country ?: "ایران"
}

// ======================= ریشه برنامه =======================

@Composable
fun App() {
    if (!G.ready) {
        Box(Modifier.fillMaxSize().background(Color(0xFFF6F3EA)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color(0xFFB8860B))
        }
        LaunchedEffect(Unit) {
            // بارگذاری/ساخت دنیا خارج از ترد اصلی انجام می‌شود تا اپ هنگام باز شدن قفل نکند.
            withContext(Dispatchers.Default) {
                if (!load()) newWorld()
                ensureWorldStructure()
            }
            G.ready = true
            G.flush()
        }
        return
    }
    CompositionLocalProvider(LocalLayoutDirection provides (if (I18n.lang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl)) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Color(0xFFB8860B), secondary = Color(0xFFFFC107),
                secondaryContainer = Color(0xFFFFE9A8), onSecondaryContainer = Color(0xFF1A1400)
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFFF6F3EA)) {
                // هر دو state همیشه خوانده می‌شوند تا با تغییرشان همین‌جا دوباره رسم شود
                val curScreen = G.screen
                val hasTeam = G.teamOrNull(G.userTeam) != null
                // بدون تیم فقط این سه صفحه مجازند (قبلاً ساخت تیم و رتبه‌بندی جهانی هرگز باز نمی‌شدند)
                val s = if (!hasTeam && curScreen != "createTeam" && curScreen != "worldRank") "pick" else curScreen
                BackHandler(enabled = s != "home" && s != "pick") { G.back() }
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (s) {
                            "pick" -> Pick()
                            "createTeam" -> CreateTeam()
                            "worldRank" -> WorldRank()
                            "home" -> Home()
                            "play" -> Play()
                            "cups" -> Cups()
                            "worldCup" -> WorldCupScreen()
                            "teamDetails" -> TeamDetails()
                            "teamHistory" -> TeamHistory()
                            "players" -> Players()
                            "academy" -> Academy()
                            "tactics" -> Tactics()
                            "count" -> Count()
                            "transfers" -> Transfers()
                            "settings" -> Settings()
                            "table" -> TableScr()
                            "overall" -> Overall()
                            "admin" -> Admin()
                            "adminTeam" -> AdminTeam()
                            "live" -> Live()
                            "penalty" -> Penalty()
                            else -> Home()
                        }
                    }
                    if (hasTeam && s != "pick" && s != "live" && s != "admin" && s != "adminTeam") {
                        NavigationBar(containerColor = Color(0xFF101820), contentColor = Color(0xFFFFC107), tonalElevation = 8.dp) {
                            val nav = listOf(
                                Triple("home", "⌂", "خانه"), Triple("players", "♟", "بازیکنان"),
                                Triple("transfers", "⇄", "بازار"), Triple("academy", "★", "آکادمی"),
                                Triple("table", "🏆", "لیگ"), Triple("worldCup", "🌐", "قهرمانان")
                            )
                            nav.forEach { (key, iconText, label) ->
                                NavigationBarItem(
                                    selected = s == key,
                                    onClick = { if (s != key) G.go(key) },
                                    icon = { Text(iconText, fontSize = 20.sp) },
                                    label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFFFC107), selectedTextColor = Color(0xFFFFC107),
                                        indicatorColor = Color(0xFF3B3421), unselectedIconColor = Color(0xFFCFD8DC),
                                        unselectedTextColor = Color(0xFFCFD8DC)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        G.ctx = applicationContext
        installClubLogoAssets(applicationContext)
        I18n.changeLang(getSharedPreferences("prefs", MODE_PRIVATE).getString("lang", "fa") ?: "fa")
        setContent { App() }
    }

    override fun onStop() {
        super.onStop()
        if (G.ready) G.flush()
    }
}
