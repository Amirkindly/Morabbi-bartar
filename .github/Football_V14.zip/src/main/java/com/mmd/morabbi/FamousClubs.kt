package com.mmd.morabbi

// تیم‌های معروف هر کشور و اورال هدف آن‌ها (قدرت = میانگین ۱۴ بازیکن برتر).
// سطح ۱: غول‌ها، سطح ۲: بزرگ‌ها، سطح ۳: معروف‌ها؛ بقیه تیم‌های دسته اول حداکثر تا سقف (cap) قدرت دارند.
// برای دسته دوم هم باشگاه‌های معروف (low) بالاتر از بقیه قرار می‌گیرند.
class FamousSpec(
    val t1: List<String>, val t2: List<String>, val t3: List<String>,
    val targets: IntArray, val cap: Int,
    val low: List<String>, val lowTarget: Int, val lowCap: Int
)

val FAMOUS_SPECS: Map<String, FamousSpec> = mapOf(
    "ایران" to FamousSpec(
        listOf("پرسپولیس", "استقلال"),
        listOf("سپاهان", "تراکتور"),
        listOf("فولاد", "ذوب‌آهن", "گل‌گهر", "ملوان"),
        intArrayOf(87,86,84), 82,
        listOf("هوادار", "نفت مسجدسلیمان", "پارس جنوبی جم", "مس کرمان"), 77, 75
    ),
    "انگلیس" to FamousSpec(
        listOf("منچسترسیتی", "آرسنال", "لیورپول", "چلسی"),
        listOf("منچستریونایتد", "تاتنهام", "نیوکاسل یونایتد", "استون ویلا"),
        listOf("اورتون", "لیدز یونایتد", "ناتینگهام فارست"),
        intArrayOf(90,89,87), 85,
        listOf("وستهم", "ولورهمپتون", "ساوتهمپتون", "برنلی"), 80, 78
    ),
    "اسپانیا" to FamousSpec(
        listOf("رئال مادرید", "بارسلونا", "اتلتیکو مادرید"),
        listOf("اتلتیک بیلبائو", "رئال سوسیداد", "ویارئال", "رئال بتیس"),
        listOf("سویا", "والنسیا"),
        intArrayOf(90,89,87), 85,
        listOf("خیرونا", "مایورکا", "لاس پالماس", "گرانادا"), 80, 78
    ),
    "ایتالیا" to FamousSpec(
        listOf("اینتر", "آث میلان", "یوونتوس", "ناپولی"),
        listOf("آتالانتا", "رم"),
        listOf("لاتزیو", "فیورنتینا", "بولونیا"),
        intArrayOf(90,89,87), 85,
        listOf("سمپدوریا", "پالرمو", "ورونا", "امپولی"), 80, 78
    ),
    "آلمان" to FamousSpec(
        listOf("بایرن مونیخ"),
        listOf("بروسیا دورتموند", "بایر لورکوزن", "لایپزیگ"),
        listOf("اشتوتگارت", "آینتراخت فرانکفورت", "وردربرمن", "مونشن‌گلادباخ", "شالکه ۰۴", "هامبورگ"),
        intArrayOf(90,89,87), 85,
        listOf("هانوفر ۹۶", "هرتابرلین", "کایزرسلاوترن", "نورنبرگ"), 80, 78
    ),
    "فرانسه" to FamousSpec(
        listOf("پاری سن ژرمن"),
        listOf("مارسی", "موناکو", "لیون", "لیل"),
        listOf("نیس", "رن", "لانس"),
        intArrayOf(90,89,87), 85,
        listOf("سن‌اتین", "مون‌پلیه", "ریمز", "کلرمون فوت"), 80, 78
    ),
    "برزیل" to FamousSpec(
        listOf("فلامینگو", "پالمیراس"),
        listOf("سائوپائولو", "کورینتیانس", "سانتوس", "گرمیو", "اینترناسیونال"),
        listOf("اتلتیکو مینیرو", "فلومیننزه", "بوتافوگو", "کروزیرو", "واسکو دا گاما"),
        intArrayOf(89,88,86), 84,
        listOf("فورتالزا", "سیارا", "کویابا", "گوییاس"), 80, 78
    ),
    "ترکیه" to FamousSpec(
        listOf("گالاتاسرای", "فنرباغچه"),
        listOf("بشیکتاش", "ترابزون‌اسپور"),
        listOf("باشاک‌شهیر", "سامسون‌اسپور"),
        intArrayOf(89,88,86), 84,
        listOf("آدانا دمیرسپور", "هاتای‌اسپور", "بودروم‌اسپور", "کایسری‌اسپور"), 80, 78
    ),
    "آرژانتین" to FamousSpec(
        listOf("بوکا جونیورز", "ریور پلاته"),
        listOf("ایندیپندینته", "راسیینگ کلاب", "سن لورنزو"),
        listOf("استودیانتس", "ولز سارسفیلد", "نیوولز اولد بویز", "روساریو سنترال"),
        intArrayOf(89,88,86), 84,
        listOf("ایندیپندینته ریوادابیا", "اتلتیکو توکومان", "اینستیتوتو", "سنترال کوردوبا"), 80, 78
    ),
    "پرتغال" to FamousSpec(
        listOf("بنفیکا", "پورتو", "اسپورتینگ لیسبون"),
        listOf("براگا"),
        listOf("ویتوریا گیمارش", "فامالیکائو"),
        intArrayOf(89,88,86), 84,
        listOf("آکادمیکا کویمبرا", "پنافیل", "لایشوئش", "فیرنزه"), 80, 78
    ),
    "هلند" to FamousSpec(
        listOf("آژاکس", "پی‌اس‌وی آیندهوون"),
        listOf("فاینورد"),
        listOf("آلکمار", "توئنته", "اوترخت"),
        intArrayOf(89,88,86), 84,
        listOf("رودا جی‌سی", "ام‌وی‌وی ماستریخت", "دی گرافشاپ", "ویتس آرنهم"), 80, 78
    )
)

fun famousTierOf(spec: FamousSpec, name: String): Int = when (name) {
    in spec.t1 -> 1
    in spec.t2 -> 2
    in spec.t3 -> 3
    else -> 0
}

// فقط بازیکنان غیرستاره تغییر می‌کنند (ستاره‌های واقعی دست‌نخورده می‌مانند).
private fun adjustNonStars(t: Team, target: Int, up: Boolean) {
    var guard = 0
    val touched = HashSet<Int>()
    while (guard < 40) {
        val s = strengthOf(t)
        if (up && s >= target) break
        if (!up && s <= target) break
        var changed = false
        for (p in squad(t.id)) {
            if (p.name in STAR_NAMES) continue
            if (up && p.rating < 90) { p.rating++; changed = true; touched.add(p.id) }
            if (!up && p.rating > 40) { p.rating--; changed = true; touched.add(p.id) }
        }
        if (!changed) break
        guard++
    }
    for (p in squad(t.id)) if (p.id in touched) p.value = worth(p.rating, p.age)
}

// اورال باشگاه‌های معروف هر کشور را بالاتر از بقیه می‌برد (تیم کاربر دست‌نخورده می‌ماند).
fun applyFamousRatings() {
    for ((country, spec) in FAMOUS_SPECS) {
        for (t in G.teams.toList()) {
            if (t.id == G.userTeam || t.country != country) continue
            val lvl = G.leagues.firstOrNull { it.id == t.leagueId }?.level ?: continue
            if (lvl == 1) {
                val tier = famousTierOf(spec, t.name)
                if (tier > 0) adjustNonStars(t, spec.targets[tier - 1], true)
                else adjustNonStars(t, spec.cap, false)
            } else if (lvl == 2) {
                val famous = t.name in spec.low || famousTierOf(spec, t.name) > 0
                if (famous) adjustNonStars(t, spec.lowTarget, true) else adjustNonStars(t, spec.lowCap, false)
            }
        }
    }
}
