package com.mmd.morabbi

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private fun worldCupMatchKey(a: Int, b: Int): String = if (a < b) "$a-$b" else "$b-$a"

// جفت‌سازی تیم‌ها با ترجیح حریف خارجی و بدون تکرار مسابقه
private fun pairWorldCupTeams(pool: MutableList<Int>, used: HashSet<String>): ArrayList<Pair<Int, Int>> {
    val games = ArrayList<Pair<Int, Int>>()
    while (pool.size >= 2) {
        val home = pool.removeAt(0)
        val homeCountry = G.teamOrNull(home)?.country
        val candidates = pool.indices.filter { i ->
            G.teamOrNull(pool[i])?.country != homeCountry && !used.contains(worldCupMatchKey(home, pool[i]))
        }
        val chosen = candidates.randomOrNull() ?: pool.indices.firstOrNull { G.teamOrNull(pool[it])?.country != homeCountry } ?: 0
        val away = pool.removeAt(chosen)
        games.add(home to away)
        used.add(worldCupMatchKey(home, away))
    }
    return games
}

// مرحله لیگ: هر تیم دقیقاً ۱۰ بازی دارد. اگر تعداد تیم‌ها زوج باشد ۱۰ هفته کافی است؛
// اگر فرد باشد (مثلاً ۵۵ تیم) برنامه ۱۱ هفته است و هر تیم دقیقاً یک هفته استراحت دارد (بدون بازی جبرانی یا اضافه).
private fun buildWorldCupSchedule(ids: List<Int>): ArrayList<ArrayList<Pair<Int, Int>>> {
    val rounds = ArrayList<ArrayList<Pair<Int, Int>>>()
    val byCountry = ids.mapNotNull { id -> G.teamOrNull(id)?.let { it.country to id } }
        .groupBy({ it.first }, { it.second })
        .mapValues { it.value.sorted() }
    // قالب استاندارد ۵۵ تیمی: ۱۱ کشور، هر کشور ۵ نماینده؛ هر تیم با ۱۰ کشور دیگر
    // دقیقاً یک‌بار بازی می‌کند و در یک هفته استراحت دارد.
    if (byCountry.size == 11 && byCountry.values.all { it.size == 5 }) {
        val countries = byCountry.keys.sorted()
        val wheel = (countries + listOf("__BYE__")).toMutableList()
        repeat(11) { roundIndex ->
            val games = ArrayList<Pair<Int, Int>>()
            for (i in 0 until wheel.size / 2) {
                val c1 = wheel[i]
                val c2 = wheel[wheel.lastIndex - i]
                if (c1 == "__BYE__" || c2 == "__BYE__") continue
                val a = byCountry[c1] ?: emptyList()
                val b = byCountry[c2] ?: emptyList()
                for (slot in 0 until 5) {
                    games.add(a[slot] to b[(slot + roundIndex) % 5])
                }
            }
            rounds.add(games)
            val last = wheel.removeAt(wheel.lastIndex)
            wheel.add(1, last)
        }
        return rounds
    }

    // پشتیبان برای ذخیره‌های سفارشی با تعداد/توزیع متفاوت تیم‌ها.
    val roundCount = if (ids.size % 2 == 0) 10 else 11
    val rests = Array(roundCount) { ArrayList<Int>() }
    if (roundCount == 11) {
        val shuffled = ids.shuffled()
        shuffled.forEachIndexed { index, id -> rests[index % 11].add(id) }
    }
    val used = HashSet<String>()
    repeat(roundCount) { r ->
        val pool = ids.filter { it !in rests[r] }.shuffled().toMutableList()
        val games = ArrayList<Pair<Int, Int>>()
        while (pool.size >= 2) {
            val home = pool.removeAt(0)
            val homeCountry = G.teamOrNull(home)?.country
            val candidates = pool.indices.filter { idx ->
                G.teamOrNull(pool[idx])?.country != homeCountry &&
                    !used.contains(worldCupMatchKey(home, pool[idx]))
            }
            val chosen = candidates.randomOrNull() ?: pool.indices.firstOrNull { idx ->
                !used.contains(worldCupMatchKey(home, pool[idx]))
            } ?: 0
            val away = pool.removeAt(chosen)
            games.add(home to away)
            used.add(worldCupMatchKey(home, away))
        }
        rounds.add(games)
    }
    return rounds
}

fun worldCupQualifiers(seasonForCup: Int = G.season - 1): List<Int> {
    val selected = ArrayList<Int>()
    for (country in COUNTRIES) {
        val topLeague = G.leagues.filter { it.country == country }.minByOrNull { it.level } ?: continue
        val ranked = table(topLeague.id)
        val cupName = domesticCupName(country)
        val previousSeason = seasonForCup
        val cupWinnerName = G.history.lastOrNull { it.contains("فصل $previousSeason") && it.contains(cupName) }
            ?.substringAfterLast("قهرمان ")?.substringBefore(" | ")
        val cupWinner = G.teams.firstOrNull { it.country == country && it.name == cupWinnerName }
        val chosen = ArrayList<Team>()
        chosen.addAll(ranked.take(4))
        if (cupWinner != null) {
            if (chosen.none { it.id == cupWinner.id }) chosen.add(cupWinner)
            else chosen.addAll(ranked.filter { r -> chosen.none { it.id == r.id } }.take(1))
        } else {
            // اگر هنوز قهرمان جام حذفی در تاریخچه ثبت نشده، سهمیه پنجم از رتبه پنجم لیگ می‌رسد.
            chosen.addAll(ranked.drop(4).take(1))
        }
        val target = 5
        if (chosen.size < target) {
            chosen.addAll(ranked.filter { candidate -> chosen.none { it.id == candidate.id } }.take(target - chosen.size))
        }
        if (chosen.size < target) {
            chosen.addAll(G.teams.filter { t -> t.country == country && chosen.none { it.id == t.id } }.take(target - chosen.size))
        }
        selected.addAll(chosen.take(target).map { it.id })
    }
    return selected.distinct().take(55)
}

fun prepareWorldCupSeason() {
    if (G.worldCupSeason == G.season && G.worldCupActive) return
    val entrants = if (G.worldCupSeason == G.season && G.worldCupEntrants.size >= 16) G.worldCupEntrants.toList() else worldCupQualifiers()
    if (entrants.size < 16) return
    G.worldCupSeason = G.season
    G.worldCupEntrants = entrants.toCollection(ArrayList())
    G.worldCupSchedule = buildWorldCupSchedule(entrants)
    G.worldCupResults.clear()
    G.worldCupRound = 0
    G.worldCupActive = true
    G.worldCupChampion = -1
    G.worldCupLog.clear()
    G.worldCupLog.add("فصل ${G.season}: ${entrants.size} تیم در لیگ قهرمانان جهان حضور دارند؛ هر تیم ۱۰ مسابقه با حریفان خارجی دارد؛ هفته بدون بازی، هفته استراحت است.")
    G.touch()
}

private fun worldCupTable(): List<Team> {
    val pts = HashMap<Int, Int>()
    val gd = HashMap<Int, Int>()
    val gf = HashMap<Int, Int>()
    for (id in G.worldCupEntrants) { pts[id] = 0; gd[id] = 0; gf[id] = 0 }
    for ((key, score) in G.worldCupResults) {
        val ids = key.split("-").mapNotNull { it.toIntOrNull() }
        val goals = score.split(",").mapNotNull { it.toIntOrNull() }
        if (ids.size != 2 || goals.size != 2) continue
        val a = ids[0]; val b = ids[1]; val x = goals[0]; val y = goals[1]
        gf[a] = (gf[a] ?: 0) + x; gf[b] = (gf[b] ?: 0) + y
        gd[a] = (gd[a] ?: 0) + x - y; gd[b] = (gd[b] ?: 0) + y - x
        if (x > y) pts[a] = (pts[a] ?: 0) + 3 else if (y > x) pts[b] = (pts[b] ?: 0) + 3 else { pts[a] = (pts[a] ?: 0) + 1; pts[b] = (pts[b] ?: 0) + 1 }
    }
    return G.worldCupEntrants.mapNotNull { G.teamOrNull(it) }.sortedWith(
        compareByDescending<Team> { pts[it.id] ?: 0 }.thenByDescending { gd[it.id] ?: 0 }.thenByDescending { gf[it.id] ?: 0 }.thenByDescending { strengthOf(it) }
    )
}

private fun saveWorldCupResult(home: Team, away: Team, hg: Int, ag: Int, stage: String) {
    G.worldCupResults[worldCupMatchKey(home.id, away.id)] = if (home.id < away.id) "$hg,$ag" else "$ag,$hg"
    logMatch("لیگ قهرمانان • $stage", home, away, hg, ag)
    val line = "$stage: ${home.name} $hg-$ag ${away.name}"
    G.worldCupLog.add(line)
    if (home.id == G.userTeam || away.id == G.userTeam) {
        G.report.add("🌍 [بازی های لیگ قهرمانان] $line")
    }
}

private fun runWorldCupKnockout(ids: List<Int>, stage: String, live: Boolean = false): List<Int> {
    val pool = ids.mapNotNull { G.teamOrNull(it) }.shuffled().toMutableList()
    val winners = ArrayList<Int>()
    while (pool.size >= 2) {
        val home = pool.removeAt(0)
        val awayIndex = pool.indexOfFirst { it.country != home.country }.let { if (it >= 0) it else 0 }
        val away = pool.removeAt(awayIndex)
        val userMatch = home.id == G.userTeam || away.id == G.userTeam
        val result = playMatch(home, away, live = live && userMatch, deferTableUpdate = true)
        if (live && userMatch) {
            G.live = result
            G.liveAffectsLeague = false
            G.penaltyReturnScreen = "live"
        }
        val winner = when {
            result.hg > result.ag -> home
            result.ag > result.hg -> away
            strengthOf(home) + Random.nextInt(0, 10) >= strengthOf(away) + Random.nextInt(0, 10) -> home
            else -> away
        }
        saveWorldCupResult(home, away, result.hg, result.ag, stage)
        G.worldCupLog.add("صعود: ${winner.name}")
        winners.add(winner.id)
    }
    if (pool.isNotEmpty()) winners.add(pool.first().id)
    return winners
}

fun playScheduledWorldCupWeek(live: Boolean = false) {
    if (G.userTeam < 0) return
    if (!G.worldCupActive || G.worldCupSeason != G.season) prepareWorldCupSeason()
    if (!G.worldCupActive) return
    if (G.worldCupRound == 0) {
        val roundIndex = G.week / 3
        if (G.week % 3 != 0 || roundIndex >= G.worldCupSchedule.size) return
        for ((hid, aid) in G.worldCupSchedule[roundIndex]) {
            val home = G.teamOrNull(hid) ?: continue
            val away = G.teamOrNull(aid) ?: continue
            val userMatch = home.id == G.userTeam || away.id == G.userTeam
            val result = playMatch(home, away, live = live && userMatch, deferTableUpdate = true)
            if (live && userMatch) {
            G.live = result
            G.liveAffectsLeague = false
            G.penaltyReturnScreen = "live"
        }
            saveWorldCupResult(home, away, result.hg, result.ag, "هفته ${roundIndex + 1} لیگ قهرمانان")
        }
        G.worldCupLog.add("پایان هفته ${roundIndex + 1} از ${G.worldCupSchedule.size} لیگ قهرمانان جهان")
        if (roundIndex == G.worldCupSchedule.size - 1) G.worldCupRound = 1
        G.touch()
        return
    }
    if (G.week !in listOf(32, 34, 35, 36, 37)) return
    when (G.worldCupRound) {
        1 -> {
            val ranked = worldCupTable()
            val direct = ranked.take(8).map { it.id }
            val playoff = ranked.drop(8).take(16).map { it.id }
            val winners = runWorldCupKnockout(playoff, "پلی‌آف صعود به یک‌شانزدهم", live)
            val bracket = direct + winners
            G.worldCupEntrants = bracket.toCollection(ArrayList())
            G.worldCupRound = 2
            G.worldCupLog.add("۸ تیم اول مستقیم صعود کردند؛ ۸ برنده پلی‌آف به آن‌ها پیوستند. مرحله ۱۶ تیمی آغاز شد.")
        }
        2, 3, 4, 5 -> {
            val stage = when (G.worldCupRound) { 2 -> "یک‌شانزدهم نهایی"; 3 -> "یک‌چهارم نهایی"; 4 -> "نیمه‌نهایی"; else -> "فینال" }
            val winners = runWorldCupKnockout(G.worldCupEntrants, stage, live)
            G.worldCupEntrants = winners.toCollection(ArrayList())
            if (G.worldCupEntrants.size == 1) {
                G.worldCupRound = 6
                G.worldCupActive = false
                G.worldCupChampion = G.worldCupEntrants.first()
                G.teamOrNull(G.worldCupChampion)?.let { it.titles++ }
                val champion = G.teamOrNull(G.worldCupChampion)
                if (champion != null) {
                    val title = "فصل ${G.season} - لیگ قهرمانان جهان: قهرمان ${champion.name}"
                    G.history.add(title); G.worldCupLog.add("🏆 $title"); G.report.add("🏆 [بازی های لیگ قهرمانان] قهرمان: ${champion.name}")
                }
            } else G.worldCupRound++
        }
    }
    G.touch()
}

@Composable
fun WorldCupScreen() {
    val rv = G.rev
    var tab by remember { mutableStateOf("جدول") }
    if (G.worldCupSeason != G.season || !G.worldCupActive && G.worldCupRound == 0) prepareWorldCupSeason()
    val ranking = worldCupTable()
    Page("لیگ قهرمانان جهان") {
        Panel {
            Text("🌍 لیگ قهرمانان جهان • فصل ${G.worldCupSeason}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("${G.worldCupEntrants.size} تیم • هر تیم ۱۰ بازی با تیم‌های کشورهای دیگر")
            Text(when (G.worldCupRound) {
                0 -> "مرحله لیگ: ${G.worldCupResults.size} مسابقه از ${G.worldCupSchedule.sumOf { it.size }} مسابقه انجام شده"
                1 -> "پایان مرحله لیگ؛ ۸ تیم اول مستقیم صعود می‌کنند، رتبه‌های ۹ تا ۲۴ پلی‌آف می‌دهند و رتبه‌های ۲۵ به بعد حذف می‌شوند."
                2 -> "مرحله حذفی ۱۶ تیمی"
                3 -> "یک‌چهارم نهایی"
                4 -> "نیمه‌نهایی"
                5 -> "فینال"
                else -> "قهرمان: ${G.teamOrNull(G.worldCupChampion)?.name ?: "نامشخص"}"
            })
            Text("سهمیه هر کشور: ۴ تیم برتر لیگ + قهرمان جام حذفی (مجموع ۵۵ تیم)؛ اگر قهرمان جام جزو ۴ تیم اول لیگ باشد، تیم پنجم لیگ جایگزین می‌شود.", fontSize = 12.sp)
        }
        Chips(listOf("جدول", "نتایج و مراحل"), tab) { tab = it }
        if (tab == "جدول") {
            ranking.forEachIndexed { index, team ->
                Row(Modifier.fillMaxWidth().clickable { G.viewedTeamId = team.id; G.go("teamDetails") }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}.", Modifier.width(28.dp), fontWeight = FontWeight.Bold)
                    Logo(team, 26.dp)
                    val played = G.worldCupResults.keys.count { it.startsWith("${team.id}-") || it.endsWith("-${team.id}") }
                    val scored = G.worldCupResults.entries.mapNotNull { entry ->
                        val ids = entry.key.split("-").mapNotNull { it.toIntOrNull() }
                        val goals = entry.value.split(",").mapNotNull { it.toIntOrNull() }
                        if (ids.size != 2 || goals.size != 2 || team.id !in ids) null
                        else if (ids[0] == team.id) goals[0] to goals[1] else goals[1] to goals[0]
                    }
                    val points = scored.sumOf { (gf, ga) -> if (gf > ga) 3L else if (gf == ga) 1L else 0L }
                    val gd = scored.sumOf { it.first - it.second }
                    Column(Modifier.weight(1f).padding(start = 8.dp)) {
                        Text(team.name, fontWeight = FontWeight.SemiBold)
                        Text("${team.country} • ${played} بازی • ${points} امتیاز • تفاضل ${if (gd > 0) "+" else ""}$gd", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        if (G.worldCupRound == 0) "گل زده: ${scored.sumOf { it.first }}"
                        else if (index < 8) "صعود مستقیم" else if (index < 24) "پلی‌آف" else "حذف",
                        fontSize = 10.sp
                    )
                }
                HorizontalDivider()
            }
        } else {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                items(G.worldCupLog.takeLast(150).asReversed()) { line -> Text("• $line", modifier = Modifier.padding(vertical = 4.dp), fontSize = 12.sp) }
            }
        }
    }
}

