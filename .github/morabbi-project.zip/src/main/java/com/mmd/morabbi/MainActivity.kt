package com.mmd.morabbi

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.exp
import kotlin.math.pow
import kotlin.random.Random

// ======================= داده‌ها =======================

val POS = listOf("GK", "DF", "MF", "FW")
val FORMS = listOf("4-4-2", "4-3-3", "3-5-2", "4-5-1", "5-3-2")
val STY = listOf("دفاعی", "متعادل", "تهاجمی")
val DIFFS = listOf("آسان", "متوسط", "سخت")
val SHIRTS = listOf("ساده", "راه‌راه", "دو نیمه", "کمربند")
val ADMIN_PASS = "MMD#2000"

val PAL: List<Long> = listOf(
    0xFFD32F2F, 0xFF1565C0, 0xFF2E7D32, 0xFFFBC02D, 0xFF6A1B9A, 0xFFEF6C00,
    0xFF212121, 0xFFFFFFFF, 0xFF00ACC1, 0xFFE91E63, 0xFF5D4037, 0xFF90A4AE
)

val FIRST = mapOf(
    "ایران" to listOf("علی", "رضا", "مهدی", "حسین", "امیر", "سعید", "پوریا", "کاوه"),
    "انگلیس" to listOf("جیمز", "جک", "هری", "جورج", "ویلیام", "چارلی", "تام", "لوک"),
    "اسپانیا" to listOf("کارلوس", "خاویر", "پدرو", "دیگو", "مانوئل", "آلوارو", "ایکر", "رائول"),
    "ایتالیا" to listOf("مارکو", "لوکا", "آندرئا", "جووانی", "فدریکو", "ماتئو", "لورنتزو", "الساندرو"),
    "آلمان" to listOf("یوناس", "مارکوس", "توماس", "فلیکس", "لوکاس", "کای", "یان", "مانوئل"),
    "فرانسه" to listOf("کیلیان", "آنتوان", "اوسمان", "هوگو", "تئو", "نیکولا", "پل", "ژولیان"),
    "برزیل" to listOf("ویتور", "رودریگو", "گابریل", "ماتئوس", "لوکاس", "فرناندو", "دانیلو", "کائو"),
    "آرژانتین" to listOf("لیونل", "خولیان", "نیکولاس", "لاوتارو", "فرانکو", "آنخل", "پائولو", "تیاگو"),
    "ترکیه" to listOf("امره", "عثمان", "مراد", "کریم", "یوسف", "برکی", "اردا", "جان")
)
val LAST = mapOf(
    "ایران" to listOf("احمدی", "رضایی", "کریمی", "موسوی", "حسینی", "جعفری", "صادقی", "نوری"),
    "انگلیس" to listOf("اسمیت", "جونز", "تیلور", "براون", "ویلسون", "اوانز", "واکر", "رایت"),
    "اسپانیا" to listOf("گارسیا", "مارتینز", "لوپز", "سانچز", "پرز", "فرناندز", "رومرو", "نوارو"),
    "ایتالیا" to listOf("روسی", "روسو", "فرارا", "بیانکی", "کوستا", "ریچی", "گالو", "مورو"),
    "آلمان" to listOf("مولر", "شمیت", "فیشر", "وبر", "واگنر", "بکر", "هافمن", "کراوس"),
    "فرانسه" to listOf("مارتن", "برنار", "دوبوآ", "موریس", "لوران", "میشل", "فونتن", "گارنیه"),
    "برزیل" to listOf("سیلوا", "سانتوس", "اولیویرا", "سوزا", "لیما", "پریرا", "کاستا", "ریبیرو"),
    "آرژانتین" to listOf("گونزالس", "رودریگز", "آکوستا", "مدینا", "سوسا", "بنیتز", "ایبارا", "پاز"),
    "ترکیه" to listOf("یلماز", "کایا", "دمیر", "چلیک", "شاهین", "آیدین", "ازتورک", "آرسلان")
)
val COUNTRIES: List<String> = FIRST.keys.toList()

val NAME_A = listOf(
    "شاهین", "ستاره", "آتش", "فولاد", "پارس", "طوفان", "آریا", "سپهر", "کاوه", "ققنوس",
    "سیمرغ", "نسیم", "البرز", "دریا", "پیروزی", "ماهان", "آرمان", "شهاب", "هیرمند", "زاگرس"
)
val NAME_B = listOf(
    "تهران", "شیراز", "تبریز", "اصفهان", "مشهد", "اهواز", "رشت", "کرمان", "یزد", "ساری", "قم", "همدان"
)

val CLUB_A = mapOf(
    "انگلیس" to listOf("رویال", "یونایتد", "کینگز", "رورز", "اتلتیک", "ولز", "دیوک", "کرون"),
    "اسپانیا" to listOf("رئال", "اتلتیکو", "دپورتیوو", "اسپورتینگ", "کلوب", "یونیون", "سلتا", "ریال"),
    "ایتالیا" to listOf("اینترنو", "یونیون", "کالچو", "ویرتوس", "آزورا", "فورتیتودو", "رومولو", "سانتا"),
    "آلمان" to listOf("بروسیا", "آیندراخت", "فورتونا", "ویکتوریا", "ترو", "ریزن", "اشتورم", "هانزا"),
    "فرانسه" to listOf("اولمپیک", "ستاد", "ایگل", "لوکوک", "فلور", "رویال", "اتوال", "راسینگ")
)
val CLUB_B = mapOf(
    "انگلیس" to listOf("لندن", "منچستر", "لیورپول", "لیدز", "بریستول", "شفیلد", "نیوکاسل", "لستر", "ناتینگهام", "برایتون"),
    "اسپانیا" to listOf("مادرید", "بارسلونا", "سویا", "والنسیا", "بیلبائو", "مالاگا", "گرانادا", "ویگو", "ساراگوسا", "مایورکا"),
    "ایتالیا" to listOf("میلان", "تورین", "رم", "ناپل", "ژنوا", "فلورانس", "بولونیا", "پالرمو", "باری", "ورونا"),
    "آلمان" to listOf("برلین", "مونیخ", "هامبورگ", "کلن", "دورتموند", "اشتوتگارت", "لایپزیگ", "برمن", "دوسلدورف", "فرانکفورت"),
    "فرانسه" to listOf("پاریس", "مارسی", "لیون", "لیل", "نیس", "رن", "نانت", "تولوز", "بوردو", "استراسبورگ")
)

// لیگ‌های پایه: کشور و دسته‌ها (ایران همیشه اول)
val LEAGUE_DEFS: List<Pair<String, List<String>>> = listOf(
    "ایران" to listOf("لیگ برتر", "دسته یک", "دسته دو", "دسته سه"),
    "انگلیس" to listOf("لیگ برتر انگلیس", "چمپیونشیپ انگلیس"),
    "اسپانیا" to listOf("لالیگا"),
    "ایتالیا" to listOf("سری آ"),
    "آلمان" to listOf("بوندسلیگا"),
    "فرانسه" to listOf("لیگ ۱ فرانسه")
)

class Player(
    var id: Int, var name: String, var pos: String, var rating: Int, var age: Int,
    var teamId: Int, var value: Long, var goals: Int = 0, var total: Int = 0
)

class Team(
    var id: Int, var name: String, var country: String, var leagueId: Int,
    var c1: Long, var c2: Long, var style: Int, var logo: String?, var budget: Long
) {
    var p = 0
    var w = 0
    var d = 0
    var l = 0
    var gf = 0
    var ga = 0
    var pts = 0
    var allPts = 0
    var titles = 0
}

class League(var id: Int, var name: String, var level: Int, var country: String)

class Offer(val pid: Int, val from: Int, val price: Long)
class Ev(val min: Int, val text: String, val side: Int) // side: 0 گل میزبان، 1 گل میهمان، 2 رویداد
class MatchRes(val h: Team, val a: Team, val hg: Int, val ag: Int, val ev: List<Ev>)

object G {
    var rev by mutableIntStateOf(0)
    var screen by mutableStateOf("pick")
    val stack = ArrayList<String>()
    val leagues = ArrayList<League>()
    val teams = ArrayList<Team>()
    val players = ArrayList<Player>()
    val history = ArrayList<String>()
    var lineup = ArrayList<Int>()
    var report = ArrayList<String>()
    var live: MatchRes? = null
    val news = ArrayList<String>()
    val offers = ArrayList<Offer>()
    var msg = ""
    var userTeam = -1
    var tpl = 20
    var ppt = 22
    var promo = 3
    var season = 1
    var week = 0
    var diff = 1
    var formation = "4-4-2"
    var style = 1
    var nextId = 1
    var editTeam = -1
    lateinit var ctx: Context

    fun nid(): Int = nextId++
    fun team(id: Int): Team = teams.first { it.id == id }
    fun teamOrNull(id: Int): Team? = teams.firstOrNull { it.id == id }
    fun go(s: String) {
        stack.add(screen)
        screen = s
    }
    fun back() {
        screen = if (stack.isEmpty()) "home" else stack.removeAt(stack.size - 1)
    }
    fun touch() {
        rev++
        save()
    }
}

// ======================= ذخیره و بارگذاری =======================

fun save() {
    try {
        val o = JSONObject()
        o.put("nid", G.nextId)
        o.put("tpl", G.tpl)
        o.put("ppt", G.ppt)
        o.put("promo", G.promo)
        o.put("season", G.season)
        o.put("week", G.week)
        o.put("diff", G.diff)
        o.put("user", G.userTeam)
        o.put("form", G.formation)
        o.put("style", G.style)
        val la = JSONArray()
        for (l in G.leagues) {
            la.put(JSONObject().put("id", l.id).put("name", l.name).put("level", l.level).put("country", l.country))
        }
        o.put("leagues", la)
        val ta = JSONArray()
        for (t in G.teams) {
            val j = JSONObject()
            j.put("id", t.id)
            j.put("name", t.name)
            j.put("country", t.country)
            j.put("lg", t.leagueId)
            j.put("c1", t.c1)
            j.put("c2", t.c2)
            j.put("st", t.style)
            j.put("logo", t.logo ?: "")
            j.put("bud", t.budget)
            j.put("p", t.p)
            j.put("w", t.w)
            j.put("d", t.d)
            j.put("l", t.l)
            j.put("gf", t.gf)
            j.put("ga", t.ga)
            j.put("pts", t.pts)
            j.put("ap", t.allPts)
            j.put("ti", t.titles)
            ta.put(j)
        }
        o.put("teams", ta)
        val pa = JSONArray()
        for (p in G.players) {
            val j = JSONObject()
            j.put("id", p.id)
            j.put("n", p.name)
            j.put("pos", p.pos)
            j.put("r", p.rating)
            j.put("a", p.age)
            j.put("t", p.teamId)
            j.put("v", p.value)
            j.put("g", p.goals)
            j.put("tg", p.total)
            pa.put(j)
        }
        o.put("players", pa)
        val ha = JSONArray()
        for (h in G.history) ha.put(h)
        o.put("hist", ha)
        val lu = JSONArray()
        for (i in G.lineup) lu.put(i)
        o.put("lineup", lu)
        val na = JSONArray()
        for (n in G.news) na.put(n)
        o.put("news", na)
        val oa = JSONArray()
        for (f in G.offers) oa.put(JSONObject().put("p", f.pid).put("f", f.from).put("v", f.price))
        o.put("offers", oa)
        File(G.ctx.filesDir, "save.json").writeText(o.toString())
    } catch (e: Exception) {
    }
}

fun load(): Boolean {
    try {
        val f = File(G.ctx.filesDir, "save.json")
        if (!f.exists()) return false
        val o = JSONObject(f.readText())
        G.leagues.clear(); G.teams.clear(); G.players.clear(); G.history.clear(); G.lineup = ArrayList()
        G.nextId = o.getInt("nid")
        G.tpl = o.getInt("tpl")
        G.ppt = o.getInt("ppt")
        G.promo = o.getInt("promo")
        G.season = o.getInt("season")
        G.week = o.getInt("week")
        G.diff = o.getInt("diff")
        G.userTeam = o.getInt("user")
        G.formation = o.getString("form")
        G.style = o.getInt("style")
        val la = o.getJSONArray("leagues")
        for (i in 0 until la.length()) {
            val j = la.getJSONObject(i)
            G.leagues.add(League(j.getInt("id"), j.getString("name"), j.getInt("level"), j.getString("country")))
        }
        val ta = o.getJSONArray("teams")
        for (i in 0 until ta.length()) {
            val j = ta.getJSONObject(i)
            val lg = j.optString("logo", "")
            val t = Team(
                j.getInt("id"), j.getString("name"), j.getString("country"), j.getInt("lg"),
                j.getLong("c1"), j.getLong("c2"), j.getInt("st"),
                if (lg.isEmpty() || !File(lg).exists()) null else lg, j.getLong("bud")
            )
            t.p = j.getInt("p")
            t.w = j.getInt("w")
            t.d = j.getInt("d")
            t.l = j.getInt("l")
            t.gf = j.getInt("gf")
            t.ga = j.getInt("ga")
            t.pts = j.getInt("pts")
            t.allPts = j.getInt("ap")
            t.titles = j.getInt("ti")
            G.teams.add(t)
        }
        val pa = o.getJSONArray("players")
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i)
            G.players.add(
                Player(
                    j.getInt("id"), j.getString("n"), j.getString("pos"), j.getInt("r"), j.getInt("a"),
                    j.getInt("t"), j.getLong("v"), j.getInt("g"), j.getInt("tg")
                )
            )
        }
        val ha = o.getJSONArray("hist")
        for (i in 0 until ha.length()) G.history.add(ha.getString(i))
        val lu = o.getJSONArray("lineup")
        for (i in 0 until lu.length()) G.lineup.add(lu.getInt(i))
        G.news.clear(); G.offers.clear(); G.live = null
        o.optJSONArray("news")?.let { a -> for (i in 0 until a.length()) G.news.add(a.getString(i)) }
        o.optJSONArray("offers")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                G.offers.add(Offer(j.getInt("p"), j.getInt("f"), j.getLong("v")))
            }
        }
        G.screen = if (G.teamOrNull(G.userTeam) == null) "pick" else "home"
        G.stack.clear()
        return G.leagues.isNotEmpty()
    } catch (e: Exception) {
        return false
    }
}

// ======================= ساخت دنیا =======================

fun worth(r: Int, age: Int): Long {
    val b = (r - 35).coerceAtLeast(1).toLong()
    val v = b * b * 2000L
    return if (age < 24) v * 13 / 10 else if (age > 31) v * 7 / 10 else v
}

fun posPlan(n: Int): List<String> {
    val cyc = listOf("DF", "MF", "FW", "DF", "MF", "DF", "MF", "FW")
    val out = ArrayList<String>()
    repeat(if (n >= 20) 3 else 2) { out.add("GK") }
    var i = 0
    while (out.size < n) {
        out.add(cyc[i % cyc.size])
        i++
    }
    return out
}

fun genPlayer(tid: Int, country: String, pos: String, base: Int): Player {
    val f = FIRST[country] ?: FIRST.getValue("ایران")
    val l = LAST[country] ?: LAST.getValue("ایران")
    val r = (base + Random.nextInt(-8, 9)).coerceIn(40, 92)
    val age = Random.nextInt(18, 35)
    return Player(G.nid(), "${f.random()} ${l.random()}", pos, r, age, tid, worth(r, age))
}

fun uniqueName(country: String): String {
    val a = CLUB_A[country] ?: NAME_A
    val b = CLUB_B[country] ?: NAME_B
    repeat(300) {
        val n = "${a.random()} ${b.random()}"
        if (G.teams.none { it.name == n }) return n
    }
    return "باشگاه ${G.nextId}"
}

fun newTeam(lg: League): Team {
    val t = Team(G.nid(), uniqueName(lg.country), lg.country, lg.id, PAL.random(), PAL.random(), Random.nextInt(4), null, 20_000_000L)
    while (t.c2 == t.c1) t.c2 = PAL.random()
    G.teams.add(t)
    val bonus = if (lg.country == "ایران") 0 else 5
    val base = 70 + bonus - (lg.level - 1) * 5 + Random.nextInt(-7, 8)
    for (pos in posPlan(G.ppt)) G.players.add(genPlayer(t.id, t.country, pos, base))
    return t
}

fun lgSorted(): List<League> = G.leagues.sortedWith(compareBy({ COUNTRIES.indexOf(it.country) }, { it.level }))

fun cntryOf(t: Team): String = G.leagues.firstOrNull { it.id == t.leagueId }?.country ?: t.country

fun addNews(x: String) {
    G.news.add(x)
    while (G.news.size > 80) G.news.removeAt(0)
}

fun newWorld() {
    G.leagues.clear(); G.teams.clear(); G.players.clear(); G.history.clear()
    G.lineup = ArrayList(); G.report.clear(); G.stack.clear()
    G.news.clear(); G.offers.clear(); G.live = null
    G.msg = ""; G.userTeam = -1; G.season = 1; G.week = 0; G.nextId = 1
    G.tpl = 20; G.ppt = 22; G.promo = 3
    for ((country, names) in LEAGUE_DEFS) {
        for ((i, n) in names.withIndex()) {
            val lg = League(G.nid(), n, i + 1, country)
            G.leagues.add(lg)
            repeat(G.tpl) { newTeam(lg) }
        }
    }
    G.screen = "pick"
}

// ======================= منطق بازی =======================

fun squad(tid: Int): List<Player> = G.players.filter { it.teamId == tid }

fun squadAvg(t: Team): Int {
    val sq = squad(t.id)
    return if (sq.isEmpty()) 62 else sq.map { it.rating }.average().toInt()
}

fun strengthOf(t: Team): Int {
    val a = squad(t.id).sortedByDescending { it.rating }.take(14).map { it.rating }.average()
    return if (a.isNaN()) 0 else a.toInt()
}

fun autoLineup(tid: Int, fm: String): List<Player> {
    val n = fm.split("-").map { it.toInt() }
    val sq = squad(tid).sortedByDescending { it.rating }
    val res = ArrayList<Player>()
    res.addAll(sq.filter { it.pos == "GK" }.take(1))
    res.addAll(sq.filter { it.pos == "DF" }.take(n[0]))
    res.addAll(sq.filter { it.pos == "MF" }.take(n[1]))
    res.addAll(sq.filter { it.pos == "FW" }.take(n[2]))
    if (res.size < 11) {
        val rest = sq.filter { it !in res }.take(11 - res.size)
        res.addAll(rest)
    }
    return res
}

fun lineupOf(t: Team): List<Player> {
    if (t.id != G.userTeam) return autoLineup(t.id, FORMS[t.id % 3])
    val l = G.lineup.mapNotNull { id -> G.players.firstOrNull { it.id == id && it.teamId == t.id } }.take(11)
    if (l.size == 11) return l
    return l + autoLineup(t.id, G.formation).filter { it !in l }.take(11 - l.size)
}

fun styleOf(t: Team): Int = if (t.id == G.userTeam) G.style else 1

fun strength(lu: List<Player>, style: Int): DoubleArray {
    fun avg(a: String, b: String): Double {
        val l = lu.filter { it.pos == a || it.pos == b }
        return if (l.isEmpty()) 50.0 else l.map { it.rating }.average()
    }
    val att = avg("FW", "FW") * 0.6 + avg("MF", "MF") * 0.4
    val def = avg("GK", "DF") * 0.7 + avg("MF", "MF") * 0.3
    val sa = 1.0 + (style - 1) * 0.05
    val sd = 1.0 - (style - 1) * 0.05
    return doubleArrayOf(att * sa, def * sd)
}

fun poisson(l: Double): Int {
    val lim = exp(-l)
    var k = 0
    var p = 1.0
    do {
        k++
        p *= Random.nextDouble()
    } while (p > lim)
    return k - 1
}

fun pickScorer(lu: List<Player>): Player {
    val ws = lu.map {
        val w = when (it.pos) {
            "FW" -> 6.0
            "MF" -> 3.0
            "DF" -> 1.0
            else -> 0.05
        }
        w * it.rating
    }
    var r = Random.nextDouble() * ws.sum()
    for (i in lu.indices) {
        r -= ws[i]
        if (r <= 0) return lu[i]
    }
    return lu.last()
}

fun playMatch(h: Team, a: Team, live: Boolean = false): MatchRes {
    val hl = lineupOf(h)
    val al = lineupOf(a)
    val hs = strength(hl, styleOf(h))
    val aw = strength(al, styleOf(a))
    val f = doubleArrayOf(1.15, 1.0, 0.87)[G.diff]
    var hx = 1.35 * 1.1 * (hs[0] / aw[1]).pow(3.0)
    var ax = 1.35 * (aw[0] / hs[1]).pow(3.0)
    if (h.id == G.userTeam) {
        hx *= f; ax /= f
    } else if (a.id == G.userTeam) {
        ax *= f; hx /= f
    }
    hx = hx.coerceIn(0.2, 4.5)
    ax = ax.coerceIn(0.2, 4.5)
    val hg = poisson(hx)
    val ag = poisson(ax)
    val ev = ArrayList<Ev>()
    repeat(hg) {
        val s = pickScorer(hl)
        s.goals++; s.total++
        ev.add(Ev(Random.nextInt(1, 91), "⚽ گل! ${s.name} (${h.name})", 0))
    }
    repeat(ag) {
        val s = pickScorer(al)
        s.goals++; s.total++
        ev.add(Ev(Random.nextInt(1, 91), "⚽ گل! ${s.name} (${a.name})", 1))
    }
    if (live) {
        ev.add(Ev(0, "▶️ سوت شروع بازی", 2))
        ev.add(Ev(45, "⏸ پایان نیمه اول", 2))
        ev.add(Ev(90, "🏁 سوت پایان بازی", 2))
        repeat(Random.nextInt(7, 12)) {
            val home = Random.nextBoolean()
            val tm = if (home) h else a
            val lu = if (home) hl else al
            val txt = when (Random.nextInt(4)) {
                0 -> "🔥 موقعیت خطرناک برای ${tm.name}"
                1 -> "🟨 کارت زرد برای ${lu.random().name} (${tm.name})"
                2 -> "🧤 واکنش زیبای دروازه‌بان ${tm.name}"
                else -> "💨 شوت ${pickScorer(lu).name} به بیرون رفت"
            }
            ev.add(Ev(Random.nextInt(2, 90), txt, 2))
        }
    }
    h.p++; a.p++
    h.gf += hg; h.ga += ag
    a.gf += ag; a.ga += hg
    if (hg > ag) {
        h.w++; h.pts += 3; a.l++
    } else if (hg < ag) {
        a.w++; a.pts += 3; h.l++
    } else {
        h.d++; a.d++; h.pts++; a.pts++
    }
    return MatchRes(h, a, hg, ag, ev.sortedBy { it.min })
}

fun fixturesFor(lid: Int): List<List<Pair<Int, Int>>> {
    val ids = G.teams.filter { it.leagueId == lid }.map { it.id }.sorted().toMutableList()
    if (ids.size % 2 == 1) ids.add(-1)
    val n = ids.size
    val rounds = ArrayList<List<Pair<Int, Int>>>()
    val arr = ids.toMutableList()
    for (r in 0 until n - 1) {
        val m = ArrayList<Pair<Int, Int>>()
        for (i in 0 until n / 2) {
            val a = arr[i]
            val b = arr[n - 1 - i]
            if (a != -1 && b != -1) m.add(if (r % 2 == 0) Pair(a, b) else Pair(b, a))
        }
        rounds.add(m)
        val last = arr.removeAt(n - 1)
        arr.add(1, last)
    }
    val second = rounds.map { rd -> rd.map { Pair(it.second, it.first) } }
    return rounds + second
}

fun totalWeeks(): Int {
    var best = 0
    for (lg in G.leagues) {
        val n = G.teams.count { it.leagueId == lg.id }
        val m = if (n % 2 == 0) n else n + 1
        val w = 2 * (m - 1)
        if (w > best) best = w
    }
    return best
}

fun table(lid: Int): List<Team> =
    G.teams.filter { it.leagueId == lid }.sortedWith(
        compareByDescending<Team> { it.pts }
            .thenByDescending { it.gf - it.ga }
            .thenByDescending { it.gf }
            .thenBy { it.name }
    )

fun playWeek(live: Boolean = false) {
    G.report.clear()
    G.msg = ""
    G.live = null
    for (lg in G.leagues.toList()) {
        val fx = fixturesFor(lg.id)
        if (G.week < fx.size) {
            for ((hid, aid) in fx[G.week]) {
                val h = G.team(hid)
                val a = G.team(aid)
                val isU = hid == G.userTeam || aid == G.userTeam
                val r = playMatch(h, a, live && isU)
                if (isU) {
                    G.report.add("${h.name}  ${r.hg} - ${r.ag}  ${a.name}")
                    for (e in r.ev) if (e.side < 2) G.report.add("${e.min}' ${e.text}")
                    if (live) G.live = r
                }
            }
        }
    }
    G.week++
    if (Random.nextInt(100) < 12) genOffers(1)
}

// ======================= نقل و انتقالات =======================

fun aiTransfers() {
    addNews("📢 پنجره نقل و انتقالات فصل ${G.season} باز شد")
    repeat(30) {
        val seller = G.teams.filter { it.id != G.userTeam }.randomOrNull() ?: return@repeat
        val sq = squad(seller.id)
        if (sq.size <= 16) return@repeat
        val p = sq.sortedByDescending { it.rating }.take(6).random()
        val price = p.value * 11 / 10
        val buyer = G.teams.filter {
            it.id != G.userTeam && it.id != seller.id && it.budget >= price && squad(it.id).size < G.ppt + 4
        }.randomOrNull() ?: return@repeat
        buyer.budget -= price
        seller.budget += price
        p.teamId = buyer.id
        addNews("🔁 ${p.name} (${p.rating}) از ${seller.name} به ${buyer.name} پیوست - ${money(price)}")
    }
}

fun genOffers(n: Int) {
    val t = G.teamOrNull(G.userTeam) ?: return
    val top = squad(t.id).sortedByDescending { it.rating }.take(6)
    repeat(n) {
        val p = top.randomOrNull() ?: return@repeat
        if (G.offers.size >= 6 || G.offers.any { it.pid == p.id }) return@repeat
        val price = p.value * 13 / 10
        val b = G.teams.filter { it.id != t.id && it.budget >= price && squad(it.id).size < G.ppt + 4 }.randomOrNull() ?: return@repeat
        G.offers.add(Offer(p.id, b.id, price))
    }
}

fun resetSeason() {
    for (t in G.teams) {
        t.p = 0; t.w = 0; t.d = 0; t.l = 0; t.gf = 0; t.ga = 0; t.pts = 0
    }
    for (p in G.players) {
        p.total -= p.goals
        p.goals = 0
    }
    G.week = 0
    G.report.clear()
    G.msg = ""
}

fun endSeason() {
    val sb = ArrayList<String>()
    val moves = ArrayList<Pair<Team, Int>>()
    for ((country, list) in G.leagues.groupBy { it.country }.toList().sortedBy { COUNTRIES.indexOf(it.first) }) {
        val lgs = list.sortedBy { it.level }
        val tables = lgs.map { table(it.id) }
        for ((i, lg) in lgs.withIndex()) {
            val tb = tables[i]
            if (tb.isNotEmpty()) {
                tb[0].titles++
                val sc = G.players.filter { p -> tb.any { it.id == p.teamId } }.maxByOrNull { it.goals }
                var line = "فصل ${G.season} - ${lg.name}: قهرمان ${tb[0].name}"
                if (sc != null && sc.goals > 0) line += " | آقای گل: ${sc.name} (${sc.goals} گل)"
                G.history.add(line)
                sb.add(line)
            }
        }
        for (i in 0 until lgs.size - 1) {
            val up = tables[i]
            val lo = tables[i + 1]
            val k = minOf(G.promo, up.size / 2, lo.size / 2)
            if (k > 0) {
                for (t in up.takeLast(k)) moves.add(Pair(t, lgs[i + 1].id))
                for (t in lo.take(k)) moves.add(Pair(t, lgs[i].id))
                sb.add("صعود به ${lgs[i].name}: " + lo.take(k).joinToString("، ") { it.name })
                sb.add("سقوط به ${lgs[i + 1].name}: " + up.takeLast(k).joinToString("، ") { it.name })
            }
        }
    }
    for (t in G.teams) t.allPts += t.pts
    for ((t, id) in moves) t.leagueId = id
    for (t in G.teams) {
        t.p = 0; t.w = 0; t.d = 0; t.l = 0; t.gf = 0; t.ga = 0; t.pts = 0
        t.budget += 5_000_000L
    }
    for (p in G.players.toList()) {
        p.goals = 0
        p.age++
        val ch = when {
            p.age < 24 -> Random.nextInt(0, 4)
            p.age > 31 -> -Random.nextInt(0, 4)
            else -> Random.nextInt(-1, 2)
        }
        p.rating = (p.rating + ch).coerceIn(35, 95)
        p.value = worth(p.rating, p.age)
        if (p.age >= 37) {
            val t = G.teamOrNull(p.teamId)
            G.players.remove(p)
            if (t != null) {
                val y = genPlayer(t.id, t.country, p.pos, 55)
                y.age = Random.nextInt(17, 20)
                y.value = worth(y.rating, y.age)
                G.players.add(y)
            }
        }
    }
    G.season++
    G.week = 0
    G.report.clear()
    G.live = null
    G.offers.clear()
    aiTransfers()
    genOffers(3)
    G.msg = sb.joinToString("\n")
}

// ======================= توابع ادمین =======================

fun removeTeam(t: Team) {
    G.players.removeAll { it.teamId == t.id }
    G.teams.remove(t)
}

fun adjustTeams(lg: League) {
    var n = G.teams.count { it.leagueId == lg.id }
    while (n < G.tpl) {
        newTeam(lg)
        n++
    }
    while (n > G.tpl) {
        val v = G.teams.filter { it.leagueId == lg.id && it.id != G.userTeam }.minByOrNull { strengthOf(it) } ?: break
        removeTeam(v)
        n--
    }
}

fun adjustPlayers(t: Team) {
    val plan = posPlan(G.ppt)
    while (squad(t.id).size < G.ppt) {
        val cur = squad(t.id).groupBy { it.pos }
        val pos = POS.maxByOrNull { p -> plan.count { it == p } - (cur[p]?.size ?: 0) } ?: "MF"
        G.players.add(genPlayer(t.id, t.country, pos, squadAvg(t)))
    }
    while (squad(t.id).size > G.ppt) {
        val sq = squad(t.id)
        val gk = sq.count { it.pos == "GK" }
        val w = sq.filter { it.pos != "GK" || gk > 2 }.minByOrNull { it.rating } ?: break
        G.players.remove(w)
    }
}

fun applyAdmin() {
    for (lg in G.leagues.toList()) adjustTeams(lg)
    for (t in G.teams.toList()) adjustPlayers(t)
    resetSeason()
}

fun addLeague(c: String = "ایران") {
    val lv = (G.leagues.filter { it.country == c }.maxOfOrNull { it.level } ?: 0) + 1
    val lg = League(G.nid(), "لیگ سطح $lv $c", lv, c)
    G.leagues.add(lg)
    repeat(G.tpl) { newTeam(lg) }
    resetSeason()
}

fun deleteLeague(lg: League): Boolean {
    if (G.leagues.size <= 1) return false
    if (G.teams.any { it.leagueId == lg.id && it.id == G.userTeam }) return false
    for (t in G.teams.filter { it.leagueId == lg.id }) removeTeam(t)
    G.leagues.remove(lg)
    for ((i, l) in G.leagues.filter { it.country == lg.country }.sortedBy { it.level }.withIndex()) l.level = i + 1
    resetSeason()
    return true
}

fun copyLogo(uri: Uri, id: Int): String? = try {
    val f = File(G.ctx.filesDir, "logo_${id}_${System.currentTimeMillis()}.img")
    G.ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    if (f.exists() && f.length() > 0) f.absolutePath else null
} catch (e: Exception) {
    null
}

val bmpCache = HashMap<String, ImageBitmap?>()

fun loadBmp(path: String): ImageBitmap? = try {
    val o = BitmapFactory.Options()
    o.inJustDecodeBounds = true
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / s > 256 || o.outHeight / s > 256) s *= 2
    val o2 = BitmapFactory.Options()
    o2.inSampleSize = s
    BitmapFactory.decodeFile(path, o2)?.asImageBitmap()
} catch (e: Exception) {
    null
}

fun money(v: Long): String =
    if (v >= 1_000_000L) String.format("%.1f میلیون", v / 1_000_000.0) else "${v / 1000} هزار"

fun posColor(p: String): Color = when (p) {
    "GK" -> Color(0xFFF9A825)
    "DF" -> Color(0xFF1565C0)
    "MF" -> Color(0xFF2E7D32)
    else -> Color(0xFFC62828)
}

// ======================= اجزای رابط =======================

@Composable
fun Logo(t: Team, sz: Dp = 32.dp) {
    val path = t.logo
    val bmp = if (path != null) remember(path) { bmpCache.getOrPut(path) { loadBmp(path) } } else null
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(sz))
    } else {
        val shape = when (t.id % 3) {
            0 -> CircleShape
            1 -> RoundedCornerShape(8.dp)
            else -> RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
        }
        Box(
            Modifier.size(sz).clip(shape).background(Color(t.c1)).border(2.dp, Color(t.c2), shape),
            contentAlignment = Alignment.Center
        ) {
            Text(t.name.take(1), color = Color(t.c2), fontWeight = FontWeight.Bold, fontSize = (sz.value * 0.5f).sp)
        }
    }
}

@Composable
fun Shirt(t: Team, sz: Dp = 56.dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.3f, 0f)
            lineTo(w * 0.7f, 0f)
            lineTo(w, h * 0.25f)
            lineTo(w * 0.85f, h * 0.4f)
            lineTo(w * 0.75f, h * 0.32f)
            lineTo(w * 0.75f, h)
            lineTo(w * 0.25f, h)
            lineTo(w * 0.25f, h * 0.32f)
            lineTo(w * 0.15f, h * 0.4f)
            lineTo(0f, h * 0.25f)
            close()
        }
        drawPath(path, Color(t.c1))
        clipPath(path) {
            when (t.style) {
                1 -> {
                    for (i in 0 until 5) {
                        if (i % 2 == 1) drawRect(Color(t.c2), Offset(w * i * 0.2f, 0f), Size(w * 0.2f, h))
                    }
                }
                2 -> {
                    drawRect(Color(t.c2), Offset(w * 0.5f, 0f), Size(w * 0.5f, h))
                }
                3 -> {
                    drawRect(Color(t.c2), Offset(0f, h * 0.45f), Size(w, h * 0.18f))
                }
                else -> {
                }
            }
        }
        drawPath(path, Color(0x55000000), style = Stroke(width = 3f))
    }
}

@Composable
fun Page(title: String, scroll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF0B0B0B))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (G.screen != "home" && G.screen != "pick") {
                Text("→", color = Color(0xFFFFC107), fontSize = 26.sp, modifier = Modifier.clickable { G.back() }.padding(end = 12.dp))
            }
            Image(
                painterResource(R.drawable.app_logo), null,
                Modifier.size(34.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color(0xFFFFC107), fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        val m = if (scroll) Modifier.fillMaxSize().verticalScroll(rememberScrollState()) else Modifier.fillMaxSize()
        Column(m.padding(10.dp), content = content)
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(10.dp), content = content)
    }
}

@Composable
fun B(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier) { Text(text) }
}

@Composable
fun Chips(opts: List<String>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for (o in opts) {
            FilterChip(
                selected = o == sel,
                onClick = { onSel(o) },
                label = { Text(o) },
                modifier = Modifier.padding(end = 6.dp)
            )
        }
    }
}

@Composable
fun NumField(label: String, v: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = { s -> onChange(s.filter { c -> c.isDigit() }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier
    )
}

@Composable
fun TextF(label: String, v: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier
    )
}

@Composable
fun Prompt(title: String, init: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var s by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { TextF("", s, { s = it }, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onOk(s) }) { Text("تأیید") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("لغو") } }
    )
}

@Composable
fun ColorRow(sel: Long, onPick: (Long) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for (c in PAL) {
            Box(
                Modifier.padding(end = 6.dp).size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == sel) 3.dp else 1.dp, if (c == sel) Color.Black else Color.Gray, CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun PlayerRow(p: Player, extra: @Composable RowScope.() -> Unit = {}) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(p.pos, Modifier.width(34.dp), color = posColor(p.pos), fontWeight = FontWeight.Bold)
            Column(Modifier.weight(1f)) {
                Text(p.name)
                Text("سن ${p.age} | گل ${p.goals} | ارزش ${money(p.value)}", fontSize = 12.sp, color = Color.Gray)
            }
            Text("${p.rating}", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 6.dp))
            extra()
        }
        HorizontalDivider()
    }
}

@Composable
fun Cell(text: String, w: Dp, bold: Boolean = false) {
    Text(
        text, Modifier.width(w), fontSize = 12.sp, textAlign = TextAlign.Center,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
    )
}

// ======================= صفحه‌ها =======================

@Composable
fun Pick() {
    val rv = G.rev
    var cty by remember { mutableStateOf("ایران") }
    val countries = COUNTRIES.filter { c -> G.leagues.any { it.country == c } }
    Page("تیم خود را انتخاب کنید", scroll = false) {
        Chips(countries, cty) { cty = it }
        Text("🏆 لیگ کشور $cty", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(6.dp))
        LazyColumn(Modifier.weight(1f)) {
            for (lg in G.leagues.filter { it.country == cty }.sortedBy { it.level }) {
                item {
                    Text(lg.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp))
                }
                val rows = G.teams.filter { it.leagueId == lg.id }.map { it to strengthOf(it) }.sortedByDescending { it.second }
                items(rows) { (t, st) ->
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                G.userTeam = t.id
                                G.lineup = ArrayList(autoLineup(t.id, G.formation).map { p -> p.id })
                                G.stack.clear()
                                G.screen = "home"
                                G.touch()
                            }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Logo(t, 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(t.name, Modifier.weight(1f))
                            Text("قدرت $st")
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun Home() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val lg = G.leagues.firstOrNull { it.id == t.leagueId }
    Page("مربی برتر") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 56.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${lg?.name ?: ""} | فصل ${G.season} - هفته ${G.week}")
                    Text("بودجه: ${money(t.budget)}")
                }
                Shirt(t, 56.dp)
            }
        }
        val menu = listOf(
            "play" to "⚽ بازی",
            "players" to "👥 بازیکنان",
            "tactics" to "📋 تاکتیک و ترکیب",
            "count" to "🔢 تعداد بازیکنان",
            "transfers" to (if (G.offers.isEmpty()) "💰 نقل و انتقالات" else "💰 نقل و انتقالات (${G.offers.size} پیشنهاد)"),
            "settings" to "⚙️ تنظیمات",
            "table" to "🏆 رتبه‌بندی لیگ",
            "overall" to "🌍 رتبه‌بندی کلی"
        )
        for (row in menu.chunked(2)) {
            Row(Modifier.fillMaxWidth()) {
                for ((k, label) in row) {
                    Button(
                        onClick = { G.go(k) },
                        modifier = Modifier.weight(1f).padding(4.dp).height(64.dp)
                    ) { Text(label, fontSize = 15.sp) }
                }
            }
        }
    }
}

@Composable
fun Play() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val lg = G.leagues.firstOrNull { it.id == t.leagueId }
    val tw = totalWeeks()
    val tb = table(t.leagueId)
    Page("بازی") {
        Panel {
            Text("${lg?.name ?: ""} - فصل ${G.season}", fontWeight = FontWeight.Bold)
            Text("هفته ${G.week} از $tw")
            Text("رتبه شما: ${tb.indexOfFirst { it.id == t.id } + 1} از ${tb.size} | امتیاز ${t.pts}")
        }
        if (G.week < tw) {
            val fx = fixturesFor(t.leagueId)
            val m = if (G.week < fx.size) fx[G.week].firstOrNull { it.first == t.id || it.second == t.id } else null
            Panel {
                Text("بازی بعدی", fontWeight = FontWeight.Bold)
                if (m != null) {
                    val h = G.team(m.first)
                    val a = G.team(m.second)
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Logo(h, 44.dp)
                            Text(h.name, fontSize = 13.sp)
                        }
                        Text("VS", fontWeight = FontWeight.Bold)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Logo(a, 44.dp)
                            Text(a.name, fontSize = 13.sp)
                        }
                    }
                } else {
                    Text("این هفته استراحت دارید")
                }
            }
            Button(
                onClick = {
                    playWeek(true)
                    G.touch()
                    if (G.live != null) G.go("live")
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
            ) { Text("▶️ بازی زنده - هفته ${G.week + 1}") }
            B("⚡ شبیه‌سازی سریع هفته ${G.week + 1}", Modifier.fillMaxWidth()) {
                playWeek()
                G.touch()
            }
            B("شبیه‌سازی تا پایان فصل", Modifier.fillMaxWidth()) {
                while (G.week < totalWeeks()) playWeek()
                G.touch()
            }
        } else {
            Panel {
                Text("فصل ${G.season} تمام شد!", fontWeight = FontWeight.Bold)
                if (tb.isNotEmpty()) Text("قهرمان لیگ شما: ${tb[0].name}")
            }
            B("پایان فصل و شروع فصل بعد", Modifier.fillMaxWidth()) {
                endSeason()
                G.touch()
            }
        }
        if (G.msg.isNotEmpty()) {
            Panel {
                Text("نتایج فصل قبل", fontWeight = FontWeight.Bold)
                Text(G.msg)
            }
        }
        if (G.report.isNotEmpty()) {
            Panel {
                Text("گزارش آخرین بازی", fontWeight = FontWeight.Bold)
                for (l in G.report) Text(l)
            }
        }
    }
}

@Composable
fun Players() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id).sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))
    Page("بازیکنان", scroll = false) {
        Text("${t.name} - ${sq.size} بازیکن", fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(sq) { p -> PlayerRow(p) }
        }
    }
}

@Composable
fun Tactics() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id).sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))
    val sel = G.lineup.filter { id -> sq.any { it.id == id } }
    Page("تاکتیک و ترکیب", scroll = false) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Shirt(t, 44.dp)
            Text("  بازیکنان انتخابی: ${sel.size}/11 (کمبود به‌صورت خودکار پر می‌شود)", fontSize = 13.sp)
        }
        Text("فرمیشن", fontWeight = FontWeight.Bold)
        Chips(FORMS, G.formation) { f ->
            G.formation = f
            G.lineup = ArrayList(autoLineup(t.id, f).map { p -> p.id })
            G.touch()
        }
        Text("سبک بازی", fontWeight = FontWeight.Bold)
        Chips(STY, STY[G.style]) { s ->
            G.style = STY.indexOf(s)
            G.touch()
        }
        B("ترکیب خودکار", Modifier.fillMaxWidth()) {
            G.lineup = ArrayList(autoLineup(t.id, G.formation).map { p -> p.id })
            G.touch()
        }
        LazyColumn(Modifier.weight(1f)) {
            items(sq) { p ->
                PlayerRow(p) {
                    Checkbox(
                        checked = p.id in sel,
                        onCheckedChange = { on ->
                            val l = ArrayList(sel)
                            if (on) {
                                if (l.size < 11) l.add(p.id)
                            } else {
                                l.remove(p.id)
                            }
                            G.lineup = l
                            G.touch()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun Count() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id)
    Page("تعداد بازیکنان", scroll = false) {
        Panel {
            Text("مجموع: ${sq.size} نفر (حداکثر ${G.ppt + 8})", fontWeight = FontWeight.Bold)
            Text("دروازه‌بان: ${sq.count { it.pos == "GK" }}  |  مدافع: ${sq.count { it.pos == "DF" }}")
            Text("هافبک: ${sq.count { it.pos == "MF" }}  |  مهاجم: ${sq.count { it.pos == "FW" }}")
            if (sq.isNotEmpty()) {
                Text("میانگین سن: ${String.format("%.1f", sq.map { it.age }.average())} | میانگین قدرت: ${String.format("%.1f", sq.map { it.rating }.average())}")
            }
            Text("ارزش کل: ${money(sq.sumOf { it.value })}")
        }
        Text("آزاد کردن بازیکن (حداقل ۱۵ نفر باید بماند)", modifier = Modifier.padding(4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(sq.sortedBy { it.rating }) { p ->
                PlayerRow(p) {
                    OutlinedButton(onClick = {
                        if (squad(t.id).size > 15) {
                            G.players.remove(p)
                            G.touch()
                        }
                    }) { Text("آزاد") }
                }
            }
        }
    }
}

@Composable
fun Live() {
    val m = G.live
    if (m == null) {
        LaunchedEffect(Unit) { if (G.screen == "live") G.back() }
        return
    }
    var minute by remember { mutableStateOf(0) }
    var speed by remember { mutableStateOf("×۱") }
    LaunchedEffect(speed) {
        while (minute < 90) {
            delay(
                when (speed) {
                    "×۱" -> 450L
                    "×۲" -> 220L
                    else -> 80L
                }
            )
            minute++
        }
    }
    val hs = m.ev.count { it.side == 0 && it.min <= minute }
    val aS = m.ev.count { it.side == 1 && it.min <= minute }
    val shown = m.ev.filter { it.min <= minute }.reversed()
    val status = if (minute >= 90) "پایان بازی" else if (minute < 45) "نیمه اول" else "نیمه دوم"
    Page("بازی زنده", scroll = false) {
        Panel {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(m.h, 48.dp)
                    Text(m.h.name, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$hs - $aS", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("$status | ${minute}'", fontSize = 13.sp, color = Color.Gray)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(m.a, 48.dp)
                    Text(m.a.name, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
            LinearProgressIndicator(progress = { minute / 90f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("سرعت: ", fontWeight = FontWeight.Bold)
            Chips(listOf("×۱", "×۲", "×۴"), speed) { speed = it }
        }
        if (minute < 90) {
            OutlinedButton(onClick = { minute = 90 }, modifier = Modifier.fillMaxWidth()) { Text("⏩ رفتن به پایان بازی") }
        } else {
            B("بازگشت", Modifier.fillMaxWidth()) { G.back() }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { e ->
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${e.min}'", Modifier.width(36.dp), color = Color.Gray, fontSize = 12.sp)
                        Text(
                            e.text, Modifier.weight(1f),
                            fontWeight = if (e.side < 2) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (e.side < 2) 16.sp else 13.sp
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun Transfers() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var mode by remember { mutableStateOf("خرید") }
    var pos by remember { mutableStateOf("همه") }
    var cty by remember { mutableStateOf("همه") }
    var q by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    val modes = listOf("خرید", "فروش", "پیشنهادها (${G.offers.size})", "اخبار")
    Page("نقل و انتقالات", scroll = false) {
        Text("بودجه: ${money(t.budget)} | بازیکنان: ${squad(t.id).size}", fontWeight = FontWeight.Bold)
        Chips(modes, modes.first { it.startsWith(mode) }) { mode = it.substringBefore(" (") }
        if (info.isNotEmpty()) Text(info, color = MaterialTheme.colorScheme.primary)
        if (mode == "اخبار") {
            if (G.news.isEmpty()) Text("هنوز خبری نیست. پس از پایان هر فصل بازار نقل و انتقالات باز می‌شود.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.news.reversed()) { n ->
                    Column {
                        Text(n, Modifier.padding(8.dp), fontSize = 13.sp)
                        HorizontalDivider()
                    }
                }
            }
        } else if (mode == "پیشنهادها") {
            if (G.offers.isEmpty()) Text("پیشنهادی برای بازیکنان شما نیست.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.offers.toList()) { o ->
                    val p = G.players.firstOrNull { it.id == o.pid }
                    val b = G.teamOrNull(o.from)
                    if (p != null && b != null) {
                        PlayerRow(p) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(b.name.take(10), fontSize = 11.sp, color = Color.Gray)
                                Row {
                                    Button(onClick = {
                                        if (p.teamId != t.id) {
                                            G.offers.remove(o)
                                            info = "این بازیکن دیگر در تیم شما نیست"
                                        } else if (squad(t.id).size <= 15) {
                                            info = "حداقل ۱۵ بازیکن لازم است"
                                        } else if (b.budget < o.price) {
                                            info = "باشگاه خریدار بودجه ندارد"
                                        } else {
                                            t.budget += o.price
                                            b.budget -= o.price
                                            p.teamId = b.id
                                            G.offers.remove(o)
                                            addNews("🔁 ${p.name} از ${t.name} به ${b.name} فروخته شد - ${money(o.price)}")
                                            info = "${p.name} فروخته شد"
                                        }
                                        G.touch()
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(money(o.price), fontSize = 12.sp) }
                                    Spacer(Modifier.width(4.dp))
                                    OutlinedButton(onClick = {
                                        G.offers.remove(o)
                                        G.touch()
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("رد", fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Chips(listOf("همه") + POS, pos) { pos = it }
            if (mode == "خرید") {
                Chips(listOf("همه") + COUNTRIES, cty) { cty = it }
                TextF("جستجوی نام بازیکن", q, { q = it }, Modifier.fillMaxWidth())
            }
            val list: List<Player> = if (mode == "خرید") {
                G.players.filter {
                    it.teamId != t.id && (pos == "همه" || it.pos == pos) && (q.isBlank() || it.name.contains(q.trim())) &&
                        (cty == "همه" || G.teamOrNull(it.teamId)?.let { tm -> cntryOf(tm) == cty } == true)
                }.sortedByDescending { it.rating }.take(40)
            } else {
                squad(t.id).filter { pos == "همه" || it.pos == pos }.sortedByDescending { it.rating }
            }
            LazyColumn(Modifier.weight(1f)) {
                items(list) { p ->
                    val price = if (mode == "خرید") p.value * 12 / 10 else p.value * 8 / 10
                    val from = G.teamOrNull(p.teamId)
                    PlayerRow(p) {
                        if (mode == "خرید") {
                            Text((from?.name ?: "").take(9), fontSize = 11.sp, color = Color.Gray)
                        }
                        Button(onClick = {
                            if (mode == "خرید") {
                                if (t.budget < price) {
                                    info = "بودجه کافی نیست"
                                } else if (squad(t.id).size >= G.ppt + 8) {
                                    info = "سقف تعداد بازیکنان پر است"
                                } else if (from != null && squad(from.id).size <= 15) {
                                    info = "تیم فروشنده این بازیکن را نمی‌فروشد"
                                } else {
                                    t.budget -= price
                                    if (from != null) from.budget += price
                                    p.teamId = t.id
                                    addNews("🛒 ${t.name} ${p.name} را از ${from?.name ?: "بازار آزاد"} خرید - ${money(price)}")
                                    info = "${p.name} خریداری شد"
                                    G.touch()
                                }
                            } else {
                                if (squad(t.id).size <= 15) {
                                    info = "حداقل ۱۵ بازیکن لازم است"
                                } else {
                                    t.budget += price
                                    val c = G.teams.filter { it.id != t.id && squad(it.id).size < G.ppt + 4 }
                                    if (c.isEmpty()) G.players.remove(p) else p.teamId = c.random().id
                                    info = "${p.name} فروخته شد"
                                    G.touch()
                                }
                            }
                        }) { Text(money(price), fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun Settings() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var dlg by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var nm by remember { mutableStateOf(t.name) }
    Page("تنظیمات") {
        Panel {
            Text("سطح سختی", fontWeight = FontWeight.Bold)
            Chips(DIFFS, DIFFS[G.diff]) { d ->
                G.diff = DIFFS.indexOf(d)
                G.touch()
            }
        }
        Panel {
            TextF("نام تیم من", nm, { nm = it }, Modifier.fillMaxWidth())
            B("ذخیره نام") {
                if (nm.isNotBlank()) {
                    t.name = nm.trim()
                    G.touch()
                }
            }
        }
        Panel {
            Text("پنل ادمین", fontWeight = FontWeight.Bold)
            B("ورود به پنل ادمین", Modifier.fillMaxWidth()) {
                pw = ""
                err = false
                dlg = "admin"
            }
        }
        Panel {
            OutlinedButton(onClick = { dlg = "new" }, modifier = Modifier.fillMaxWidth()) { Text("شروع بازی جدید (حذف همه‌چیز)") }
        }
    }
    if (dlg == "admin") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("رمز ادمین") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pw,
                        onValueChange = { pw = it },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        label = { Text("رمز") }
                    )
                    if (err) Text("رمز اشتباه است", color = Color.Red)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pw == ADMIN_PASS) {
                        dlg = ""
                        G.go("admin")
                    } else {
                        err = true
                    }
                }) { Text("ورود") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("لغو") } }
        )
    }
    if (dlg == "new") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("شروع بازی جدید؟") },
            text = { Text("همه اطلاعات فعلی پاک می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = ""
                    newWorld()
                    G.touch()
                }) { Text("بله") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("لغو") } }
        )
    }
}

@Composable
fun TableScr() {
    val rv = G.rev
    val me = G.team(G.userTeam)
    var lid by remember { mutableStateOf(me.leagueId) }
    var cty by remember { mutableStateOf(G.leagues.firstOrNull { it.id == me.leagueId }?.country ?: "ایران") }
    var tab by remember { mutableStateOf("جدول") }
    val sorted = lgSorted().filter { it.country == cty }.ifEmpty { lgSorted() }
    val lg = sorted.firstOrNull { it.id == lid } ?: sorted.first()
    val maxLevel = sorted.maxOf { it.level }
    val tb = table(lg.id)
    Page("رتبه‌بندی لیگ", scroll = false) {
        Chips(COUNTRIES.filter { c -> G.leagues.any { it.country == c } }, lg.country) { c ->
            cty = c
            lid = lgSorted().first { it.country == c }.id
        }
        Text("🏆 لیگ کشور ${lg.country}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
        Chips(sorted.map { it.name }, lg.name) { n -> lid = sorted.first { it.name == n }.id }
        Chips(listOf("جدول", "آقای گل"), tab) { tab = it }
        if (tab == "جدول") {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Cell("#", 24.dp, true)
                Spacer(Modifier.width(24.dp))
                Text("تیم", Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Cell("بازی", 28.dp, true)
                Cell("برد", 28.dp, true)
                Cell("مس", 28.dp, true)
                Cell("باخت", 28.dp, true)
                Cell("+/-", 30.dp, true)
                Cell("امتیاز", 34.dp, true)
            }
            HorizontalDivider()
            LazyColumn(Modifier.weight(1f)) {
                items(tb.size) { i ->
                    val t = tb[i]
                    val bg = when {
                        t.id == me.id -> Color(0x33FFC107)
                        lg.level > 1 && i < G.promo -> Color(0x3300C853)
                        lg.level < maxLevel && i >= tb.size - G.promo -> Color(0x33F44336)
                        else -> Color.Transparent
                    }
                    Column {
                        Row(
                            Modifier.fillMaxWidth().background(bg).padding(vertical = 5.dp, horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cell("${i + 1}", 24.dp)
                            Logo(t, 24.dp)
                            Text(t.name, Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, maxLines = 1)
                            Cell("${t.p}", 28.dp)
                            Cell("${t.w}", 28.dp)
                            Cell("${t.d}", 28.dp)
                            Cell("${t.l}", 28.dp)
                            Cell("${t.gf - t.ga}", 30.dp)
                            Cell("${t.pts}", 34.dp, true)
                        }
                        HorizontalDivider()
                    }
                }
            }
            Text("سبز: صعود | قرمز: سقوط | زرد: تیم شما", fontSize = 11.sp, color = Color.Gray)
        } else {
            val sc = G.players.filter { p -> tb.any { it.id == p.teamId } }.sortedByDescending { it.goals }.take(15)
            LazyColumn(Modifier.weight(1f)) {
                items(sc.size) { i ->
                    val p = sc[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(G.teamOrNull(p.teamId)?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text("${p.goals} گل", fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun Overall() {
    val rv = G.rev
    var tab by remember { mutableStateOf("تیم‌ها") }
    Page("رتبه‌بندی کلی", scroll = false) {
        Chips(listOf("تیم‌ها", "گلزنان", "تاریخچه"), tab) { tab = it }
        if (tab == "تیم‌ها") {
            val l = G.teams.sortedByDescending { it.allPts + it.pts }
            LazyColumn(Modifier.weight(1f)) {
                items(l.size) { i ->
                    val t = l[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp))
                            Logo(t, 30.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.name, fontWeight = if (t.id == G.userTeam) FontWeight.Bold else FontWeight.Normal)
                                Text(G.leagues.firstOrNull { it.id == t.leagueId }?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${t.allPts + t.pts} امتیاز")
                                Text("🏆 ${t.titles}", fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        } else if (tab == "گلزنان") {
            val sc = G.players.sortedByDescending { it.total }.take(20)
            LazyColumn(Modifier.weight(1f)) {
                items(sc.size) { i ->
                    val p = sc[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(G.teamOrNull(p.teamId)?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text("${p.total} گل", fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
            }
        } else {
            if (G.history.isEmpty()) Text("هنوز فصلی تمام نشده است.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.history.reversed()) { h ->
                    Column {
                        Text(h, Modifier.padding(8.dp), fontSize = 13.sp)
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

// ======================= پنل ادمین =======================

@Composable
fun Admin() {
    val rv = G.rev
    var tpl by remember { mutableStateOf(G.tpl.toString()) }
    var ppt by remember { mutableStateOf(G.ppt.toString()) }
    var promo by remember { mutableStateOf(G.promo.toString()) }
    var msg by remember { mutableStateOf("") }
    var rename by remember { mutableStateOf(-1) }
    Page("پنل ادمین") {
        Panel {
            Text("تنظیمات کلی", fontWeight = FontWeight.Bold)
            NumField("تعداد تیم هر لیگ", tpl, { tpl = it }, Modifier.fillMaxWidth())
            NumField("تعداد بازیکن هر تیم", ppt, { ppt = it }, Modifier.fillMaxWidth())
            NumField("تعداد تیم صعود/سقوط", promo, { promo = it }, Modifier.fillMaxWidth())
            B("اعمال تغییرات (فصل از اول شروع می‌شود)", Modifier.fillMaxWidth()) {
                val a = tpl.toIntOrNull()
                val b = ppt.toIntOrNull()
                val c = promo.toIntOrNull()
                if (a == null || b == null || c == null || a < 2 || a > 40 || b < 16 || b > 40) {
                    msg = "مقدار نامعتبر (تیم: ۲ تا ۴۰ | بازیکن: ۱۶ تا ۴۰)"
                } else {
                    G.tpl = a
                    G.ppt = b
                    G.promo = c
                    applyAdmin()
                    msg = "اعمال شد"
                    G.touch()
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
        }
        for (lg in lgSorted()) {
            Panel {
                Text("${lg.country} - سطح ${lg.level}: ${lg.name} (${G.teams.count { it.leagueId == lg.id }} تیم)", fontWeight = FontWeight.Bold)
                Text("کشور لیگ (برای نام بازیکنان جدید):", fontSize = 12.sp)
                Chips(COUNTRIES, lg.country) { c ->
                    lg.country = c
                    G.touch()
                }
                Row {
                    OutlinedButton(onClick = {
                        rename = lg.id
                    }) { Text("نام", fontSize = 12.sp) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = {
                        newTeam(lg)
                        resetSeason()
                        G.touch()
                    }) { Text("+ تیم", fontSize = 12.sp) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = {
                        if (deleteLeague(lg)) {
                            msg = ""
                            G.touch()
                        } else {
                            msg = "این لیگ قابل حذف نیست (تنها لیگ یا شامل تیم شما)"
                        }
                    }) { Text("حذف لیگ", fontSize = 12.sp) }
                }
                for (t in G.teams.filter { it.leagueId == lg.id }) {
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            G.editTeam = t.id
                            G.go("adminTeam")
                        }.padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Logo(t, 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(t.name, Modifier.weight(1f))
                        Shirt(t, 28.dp)
                    }
                }
            }
        }
        B("افزودن لیگ جدید", Modifier.fillMaxWidth()) {
            addLeague()
            G.touch()
        }
        B("شروع دوباره فصل (ریست جدول‌ها)", Modifier.fillMaxWidth()) {
            resetSeason()
            G.touch()
        }
    }
    if (rename >= 0) {
        val lg = G.leagues.firstOrNull { it.id == rename }
        if (lg == null) {
            rename = -1
        } else {
            Prompt("نام لیگ", lg.name, { n ->
                if (n.isNotBlank()) {
                    lg.name = n.trim()
                    G.touch()
                }
                rename = -1
            }, { rename = -1 })
        }
    }
}

@Composable
fun AdminTeam() {
    val rv = G.rev
    val t = G.teamOrNull(G.editTeam)
    if (t == null) {
        LaunchedEffect(Unit) { if (G.screen == "adminTeam") G.back() }
        return
    }
    var nm by remember(t.id) { mutableStateOf(t.name) }
    var cnt by remember { mutableStateOf("5") }
    var gc by remember(t.id) { mutableStateOf(t.country) }
    var pn by remember { mutableStateOf("") }
    var pr by remember { mutableStateOf("65") }
    var pa by remember { mutableStateOf("24") }
    var pp by remember { mutableStateOf("FW") }
    var msg by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val p = copyLogo(uri, t.id)
            if (p != null) {
                t.logo = p
                G.touch()
            }
        }
    }
    Page("ویرایش تیم") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 64.dp)
                Spacer(Modifier.width(12.dp))
                Shirt(t, 64.dp)
            }
            TextF("نام تیم", nm, { nm = it }, Modifier.fillMaxWidth())
            B("ذخیره نام") {
                if (nm.isNotBlank()) {
                    t.name = nm.trim()
                    G.touch()
                }
            }
            Text("کشور تیم", fontWeight = FontWeight.Bold)
            Chips(COUNTRIES, t.country) { c ->
                t.country = c
                G.touch()
            }
            Text("لیگ تیم", fontWeight = FontWeight.Bold)
            val lgs = lgSorted()
            Chips(lgs.map { it.name }, lgs.firstOrNull { it.id == t.leagueId }?.name ?: "") { n ->
                t.leagueId = lgs.first { it.name == n }.id
                resetSeason()
                G.touch()
            }
        }
        Panel {
            Text("پیراهن", fontWeight = FontWeight.Bold)
            Text("رنگ اصلی")
            ColorRow(t.c1) { c ->
                t.c1 = c
                G.touch()
            }
            Text("رنگ دوم")
            ColorRow(t.c2) { c ->
                t.c2 = c
                G.touch()
            }
            Chips(SHIRTS, SHIRTS[t.style]) { s ->
                t.style = SHIRTS.indexOf(s)
                G.touch()
            }
        }
        Panel {
            Text("لوگو", fontWeight = FontWeight.Bold)
            B("انتخاب لوگو از حافظه گوشی", Modifier.fillMaxWidth()) { pick.launch("image/*") }
            OutlinedButton(onClick = {
                t.logo = null
                G.touch()
            }, modifier = Modifier.fillMaxWidth()) { Text("لوگوی خودکار (بر اساس رنگ تیم)") }
        }
        Panel {
            Text("بازیکنان (${squad(t.id).size})", fontWeight = FontWeight.Bold)
            Text("ساخت بازیکن تصادفی بر اساس کشور:")
            Chips(COUNTRIES, gc) { gc = it }
            NumField("تعداد", cnt, { cnt = it }, Modifier.fillMaxWidth())
            B("ساخت بازیکنان تصادفی", Modifier.fillMaxWidth()) {
                val n = (cnt.toIntOrNull() ?: 0).coerceIn(0, 30)
                val base = squadAvg(t)
                val kinds = listOf("GK", "DF", "DF", "DF", "MF", "MF", "MF", "FW", "FW")
                repeat(n) { G.players.add(genPlayer(t.id, gc, kinds.random(), base)) }
                msg = "$n بازیکن ساخته شد"
                G.touch()
            }
            OutlinedButton(onClick = {
                val base = squadAvg(t)
                G.players.removeAll { it.teamId == t.id }
                for (pos in posPlan(G.ppt)) G.players.add(genPlayer(t.id, gc, pos, base))
                msg = "کل بازیکنان با کشور $gc ساخته شد"
                G.touch()
            }, modifier = Modifier.fillMaxWidth()) { Text("ساخت مجدد کل بازیکنان این تیم") }
            Text("افزودن بازیکن دستی:", modifier = Modifier.padding(top = 8.dp))
            TextF("نام بازیکن", pn, { pn = it }, Modifier.fillMaxWidth())
            Chips(POS, pp) { pp = it }
            Row {
                NumField("قدرت", pr, { pr = it }, Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                NumField("سن", pa, { pa = it }, Modifier.weight(1f))
            }
            B("افزودن بازیکن", Modifier.fillMaxWidth()) {
                val r = pr.toIntOrNull()
                val a = pa.toIntOrNull()
                if (pn.isBlank() || r == null || a == null) {
                    msg = "اطلاعات ناقص است"
                } else {
                    val rr = r.coerceIn(30, 99)
                    val aa = a.coerceIn(15, 45)
                    G.players.add(Player(G.nid(), pn.trim(), pp, rr, aa, t.id, worth(rr, aa)))
                    pn = ""
                    msg = "بازیکن اضافه شد"
                    G.touch()
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
        }
        Panel {
            Text("لیست بازیکنان", fontWeight = FontWeight.Bold)
            for (p in squad(t.id).sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))) {
                PlayerRow(p) {
                    OutlinedButton(onClick = {
                        G.players.remove(p)
                        G.touch()
                    }) { Text("حذف", fontSize = 12.sp) }
                }
            }
        }
        if (t.id != G.userTeam) {
            OutlinedButton(onClick = { confirmDel = true }, modifier = Modifier.fillMaxWidth()) { Text("حذف این تیم") }
        }
    }
    if (confirmDel) {
        AlertDialog(
            onDismissRequest = { confirmDel = false },
            title = { Text("حذف تیم ${t.name}؟") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDel = false
                    removeTeam(t)
                    resetSeason()
                    G.touch()
                    G.back()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("لغو") } }
        )
    }
}

// ======================= ریشه برنامه =======================

@Composable
fun App() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Color(0xFFB8860B), secondary = Color(0xFFFFC107),
                secondaryContainer = Color(0xFFFFE9A8), onSecondaryContainer = Color(0xFF1A1400)
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFFF6F3EA)) {
                val s = if (G.teamOrNull(G.userTeam) == null) "pick" else G.screen
                BackHandler(enabled = s != "home" && s != "pick") { G.back() }
                when (s) {
                    "pick" -> Pick()
                    "home" -> Home()
                    "play" -> Play()
                    "players" -> Players()
                    "tactics" -> Tactics()
                    "count" -> Count()
                    "transfers" -> Transfers()
                    "settings" -> Settings()
                    "table" -> TableScr()
                    "overall" -> Overall()
                    "admin" -> Admin()
                    "adminTeam" -> AdminTeam()
                    "live" -> Live()
                    else -> Home()
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        G.ctx = applicationContext
        if (!load()) {
            newWorld()
            save()
        }
        setContent { App() }
    }
}
