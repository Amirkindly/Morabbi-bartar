package com.mmd.morabbi

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.random.Random

// ======================= مرکز قابلیت‌های جدید =======================
// الماس، باشگاه تمرین، بازی دوستانه، جام دوستانه و پیش‌بینی نتایج لیگ.
// همه‌چیز آفلاین است و در همان فایل ذخیره بازی نگهداری می‌شود.

class FCupState(
    var name: String, var size: Int, var fee: Long, var prize: Long, var gems: Int
) {
    var round = 0
    var finished = false
    var userAlive = true
    var champion = -1
    val alive = ArrayList<Int>()
    val log = ArrayList<String>()
}

class OpenCup(val name: String, val size: Int, val fee: Long, val gems: Int)

class Pred(val season: Int, val week: Int, val hid: Int, val aid: Int, val pick: Int) // pick: 1 میزبان، 0 مساوی، 2 میهمان

object Hub {
    var gems = 10

    // باشگاه تمرین
    var trLevel = 0
    var trWeeksLeft = 0
    var trStampS = 0
    var trStampW = -1
    var trCountSeason = 0
    val trCount = HashMap<Int, Int>()

    // بازی دوستانه
    var frStampS = 0
    var frStampW = -1
    val frLog = ArrayList<String>()
    val frOpp = ArrayList<Int>()
    var frOppS = 0
    var frOppW = -1

    // جام دوستانه
    var cup: FCupState? = null
    var cupStampS = 0
    var cupStampW = -1
    var cupTitles = 0
    val openCups = ArrayList<OpenCup>()
    var openS = 0
    var openW = -1

    // پیش‌بینی
    val preds = ArrayList<Pred>()
    val predHist = ArrayList<String>()
    var predTotal = 0
    var predRight = 0

    val RENT_COST = longArrayOf(3_000_000L, 6_000_000L, 11_000_000L, 18_000_000L, 30_000_000L)
    val RENT_GEMS = intArrayOf(0, 0, 1, 3, 5)
    val CAPS = intArrayOf(3, 4, 5, 6, 8)
    val GAIN = intArrayOf(1, 1, 1, 2, 2)
    const val RENT_WEEKS = 12
    const val MAX_TRAIN_PER_SEASON = 5

    fun reset() {
        gems = 10
        trLevel = 0; trWeeksLeft = 0; trStampS = 0; trStampW = -1; trCountSeason = 0; trCount.clear()
        frStampS = 0; frStampW = -1; frLog.clear(); frOpp.clear(); frOppS = 0; frOppW = -1
        cup = null; cupStampS = 0; cupStampW = -1; cupTitles = 0; openCups.clear(); openS = 0; openW = -1
        preds.clear(); predHist.clear(); predTotal = 0; predRight = 0
    }

    // ---------- ذخیره و بارگذاری ----------
    fun toJson(): String {
        val o = JSONObject()
        o.put("gems", gems)
        o.put("trL", trLevel); o.put("trW", trWeeksLeft); o.put("trS", trStampS); o.put("trSW", trStampW)
        o.put("trCS", trCountSeason)
        val tc = JSONArray()
        for ((k, v) in trCount) tc.put("$k:$v")
        o.put("trC", tc)
        o.put("frS", frStampS); o.put("frW", frStampW)
        val fl = JSONArray(); for (x in frLog) fl.put(x); o.put("frLog", fl)
        o.put("cupT", cupTitles); o.put("cupS", cupStampS); o.put("cupW", cupStampW)
        val c = cup
        if (c != null) {
            val co = JSONObject()
            co.put("name", c.name); co.put("size", c.size); co.put("fee", c.fee); co.put("prize", c.prize)
            co.put("gems", c.gems); co.put("round", c.round); co.put("fin", c.finished)
            co.put("ua", c.userAlive); co.put("champ", c.champion)
            val al = JSONArray(); for (x in c.alive) al.put(x); co.put("alive", al)
            val lg = JSONArray(); for (x in c.log) lg.put(x); co.put("log", lg)
            o.put("cup", co)
        }
        val pa = JSONArray()
        for (p in preds) pa.put("${p.season},${p.week},${p.hid},${p.aid},${p.pick}")
        o.put("preds", pa)
        val ph = JSONArray(); for (x in predHist) ph.put(x); o.put("predHist", ph)
        o.put("predT", predTotal); o.put("predR", predRight)
        return o.toString()
    }

    fun fromJson(o: JSONObject?) {
        reset()
        if (o == null) return
        try {
            gems = o.optInt("gems", 10)
            trLevel = o.optInt("trL", 0).coerceIn(0, 5); trWeeksLeft = o.optInt("trW", 0)
            trStampS = o.optInt("trS", 0); trStampW = o.optInt("trSW", -1); trCountSeason = o.optInt("trCS", 0)
            o.optJSONArray("trC")?.let { a ->
                for (i in 0 until a.length()) {
                    val sp = a.getString(i).split(":")
                    if (sp.size == 2) trCount[sp[0].toInt()] = sp[1].toInt()
                }
            }
            frStampS = o.optInt("frS", 0); frStampW = o.optInt("frW", -1)
            o.optJSONArray("frLog")?.let { a -> for (i in 0 until a.length()) frLog.add(a.getString(i)) }
            cupTitles = o.optInt("cupT", 0); cupStampS = o.optInt("cupS", 0); cupStampW = o.optInt("cupW", -1)
            o.optJSONObject("cup")?.let { co ->
                val c = FCupState(co.getString("name"), co.getInt("size"), co.getLong("fee"), co.getLong("prize"), co.getInt("gems"))
                c.round = co.optInt("round", 0); c.finished = co.optBoolean("fin", false)
                c.userAlive = co.optBoolean("ua", true); c.champion = co.optInt("champ", -1)
                co.optJSONArray("alive")?.let { a -> for (i in 0 until a.length()) c.alive.add(a.getInt(i)) }
                co.optJSONArray("log")?.let { a -> for (i in 0 until a.length()) c.log.add(a.getString(i)) }
                cup = c
            }
            o.optJSONArray("preds")?.let { a ->
                for (i in 0 until a.length()) {
                    val p = a.getString(i).split(",")
                    if (p.size == 5) preds.add(Pred(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt()))
                }
            }
            o.optJSONArray("predHist")?.let { a -> for (i in 0 until a.length()) predHist.add(a.getString(i)) }
            predTotal = o.optInt("predT", 0); predRight = o.optInt("predR", 0)
        } catch (e: Exception) {
        }
    }

    // ---------- کمکی ----------
    fun userTeam(): Team? = G.teamOrNull(G.userTeam)

    fun addGems(n: Int) { gems = (gems + n).coerceAtLeast(0) }

    // هر بار که هفته‌ای بازی می‌شود صدا زده می‌شود.
    fun onWeekPlayed() {
        if (trWeeksLeft > 0) {
            trWeeksLeft--
            if (trWeeksLeft == 0) trLevel = 0
        }
    }

    fun friendlyScore(h: Team, a: Team): Pair<Int, Int> {
        val r = goalRates(h, a)
        return Pair(poisson(r.first), poisson(r.second))
    }

    // ---------- باشگاه تمرین ----------
    fun trainCap(age: Int): Int = when {
        age <= 21 -> 92
        age <= 25 -> 88
        age <= 29 -> 84
        else -> 80
    }

    fun trainedThisSeason(pid: Int): Int {
        if (trCountSeason != G.season) { trCount.clear(); trCountSeason = G.season }
        return trCount[pid] ?: 0
    }

    // null یعنی قابل تمرین است؛ در غیر این صورت دلیل
    fun trainBlock(p: Player): String? = when {
        p.age >= 31 -> "سن بالا"
        p.rating >= trainCap(p.age) -> "سقف رشد"
        trainedThisSeason(p.id) >= MAX_TRAIN_PER_SEASON -> "سهمیه فصل"
        else -> null
    }

    fun trainedThisWeek(): Boolean = trStampS == G.season && trStampW == G.week

    fun rent(level: Int): String {
        val t = userTeam() ?: return ""
        if (level !in 1..5) return ""
        val i = level - 1
        if (trLevel > 0 && level < trLevel) return "برای کاهش سطح باید قرارداد فعلی تمام شود."
        if (t.budget < RENT_COST[i]) return "بودجه کافی نیست."
        if (gems < RENT_GEMS[i]) return "الماس کافی نیست."
        t.budget -= RENT_COST[i]
        gems -= RENT_GEMS[i]
        val extend = trLevel == level && trWeeksLeft > 0
        trWeeksLeft = if (extend) trWeeksLeft + RENT_WEEKS else RENT_WEEKS
        trLevel = level
        return if (extend) "قرارداد باشگاه تمرین ${RENT_WEEKS} هفته تمدید شد." else "باشگاه تمرین سطح $level برای $RENT_WEEKS هفته اجاره شد."
    }

    fun trainPlayers(ids: Set<Int>): String {
        if (trLevel == 0 || trWeeksLeft <= 0) return "ابتدا باشگاه تمرین را اجاره کنید."
        if (trainedThisWeek()) return "تمرین این هفته انجام شده است."
        val t = userTeam() ?: return ""
        val cap = CAPS[trLevel - 1]
        val chosen = squad(t.id).filter { it.id in ids }.take(cap)
        var n = 0
        var total = 0
        for (p in chosen) {
            if (trainBlock(p) != null) continue
            val g = GAIN[trLevel - 1].coerceAtMost(trainCap(p.age) - p.rating).coerceAtLeast(0)
            if (g <= 0) continue
            p.rating = (p.rating + g).coerceAtMost(MAX_RATING)
            p.value = worth(p.rating, p.age)
            trCount[p.id] = trainedThisSeason(p.id) + 1
            n++; total += g
        }
        trStampS = G.season; trStampW = G.week
        return if (n == 0) "هیچ بازیکنی قابل تمرین نبود." else "تمرین $n بازیکن انجام شد (مجموع +$total اورال)."
    }

    // ---------- بازی دوستانه ----------
    fun friendlyDoneThisWeek(): Boolean = frStampS == G.season && frStampW == G.week

    fun refreshOpponents() {
        if (frOppS == G.season && frOppW == G.week && frOpp.isNotEmpty()) return
        val t = userTeam() ?: return
        val sm = strengthsByTeam()
        val me = sm[t.id] ?: 60
        val pool = G.teams.filter { it.id != t.id }
        frOpp.clear()
        // دو حریف ضعیف‌تر، دو هم‌سطح، یک قوی‌تر
        val sorted = pool.sortedBy { (sm[it.id] ?: 0) - me }
        fun pickNear(delta: Int, n: Int) {
            val l = pool.sortedBy { abs((sm[it.id] ?: 0) - (me + delta)) }.take(12).shuffled().take(n)
            for (x in l) if (x.id !in frOpp) frOpp.add(x.id)
        }
        if (sorted.isNotEmpty()) { pickNear(-6, 2); pickNear(0, 2); pickNear(6, 1) }
        frOppS = G.season; frOppW = G.week
    }

    fun friendlyReward(me: Int, opp: Int): Long =
        (800_000L + (opp - me).coerceIn(-10, 15) * 60_000L).coerceAtLeast(300_000L)

    fun playFriendly(oppId: Int): String {
        val t = userTeam() ?: return ""
        if (friendlyDoneThisWeek()) return "این هفته بازی دوستانه انجام داده‌اید."
        val o = G.teamOrNull(oppId) ?: return ""
        val home = Random.nextBoolean()
        val h = if (home) t else o
        val a = if (home) o else t
        val sc = friendlyScore(h, a)
        val my = if (home) sc.first else sc.second
        val op = if (home) sc.second else sc.first
        val sm = strengthsByTeam()
        val base = friendlyReward(sm[t.id] ?: 60, sm[o.id] ?: 60)
        val reward: Long
        var gemMsg = ""
        val res: String
        when {
            my > op -> {
                reward = base; res = "پیروزی"
                if (Random.nextInt(100) < 20) { addGems(1); gemMsg = " + ۱ الماس" }
            }
            my == op -> { reward = base * 4 / 10; res = "مساوی" }
            else -> { reward = base / 5; res = "شکست" }
        }
        t.budget += reward
        frStampS = G.season; frStampW = G.week
        val line = "${h.name} ${sc.first} - ${sc.second} ${a.name} • $res • +${money(reward)}$gemMsg"
        frLog.add(0, line)
        while (frLog.size > 15) frLog.removeAt(frLog.size - 1)
        return "🏁 $line"
    }

    // ---------- جام دوستانه ----------
    private val cupNames = listOf(
        "جام دوستی", "جام بهار", "جام ستارگان", "جام شب‌های فوتبال", "جام آزادی", "جام طلایی",
        "جام نقره‌ای", "جام پیروزی", "جام کلاسیکو", "جام یلدا", "جام پایتخت", "جام جوانان"
    )

    fun refreshOpenCups() {
        if (openS == G.season && openW == G.week && openCups.isNotEmpty()) return
        openCups.clear()
        val names = cupNames.shuffled()
        for (i in 0 until 8) {
            val size = if (i % 3 == 2) 16 else 8
            val fee = longArrayOf(0L, 250_000L, 500_000L, 1_000_000L, 2_000_000L, 3_000_000L).random()
            val g = if (fee >= 2_000_000L) Random.nextInt(2, 5) else if (fee >= 500_000L) Random.nextInt(1, 3) else Random.nextInt(0, 2)
            openCups.add(OpenCup("${names[i % names.size]} ${Random.nextInt(2, 99)}", size, fee, g))
        }
        openS = G.season; openW = G.week
    }

    fun cupPrize(size: Int, fee: Long): Long = maxOf(fee * size * 9 / 10, size * 300_000L)

    fun cupActive(): Boolean { val c = cup; return c != null && !c.finished }

    fun startCup(name: String, size: Int, fee: Long, gemPrize: Int): String {
        val t = userTeam() ?: return ""
        if (cupActive()) return "ابتدا جام فعلی را تمام کنید."
        if (name.isBlank()) return "نام جام را وارد کنید."
        if (t.budget < fee) return "بودجه کافی برای ورودی جام نیست."
        t.budget -= fee
        val c = FCupState(name.trim(), size, fee, cupPrize(size, fee), gemPrize)
        val sm = strengthsByTeam()
        val me = sm[t.id] ?: 60
        val opp = G.teams.filter { it.id != t.id }
            .sortedBy { abs((sm[it.id] ?: 0) - me) }
            .take(size * 3).shuffled().take(size - 1)
        c.alive.addAll((listOf(t) + opp).map { it.id }.shuffled())
        c.log.add("🏆 شروع ${c.name} با ${c.size} تیم • جایزه قهرمانی ${money(c.prize)}" + if (c.gems > 0) " + ${c.gems} الماس" else "")
        cup = c
        cupStampS = 0; cupStampW = -1
        return "ثبت‌نام انجام شد. اولین دور را از همین صفحه بازی کنید."
    }

    fun roundName(n: Int): String = when (n) {
        2 -> "فینال"
        4 -> "نیمه‌نهایی"
        8 -> "یک‌چهارم نهایی"
        16 -> "یک‌هشتم نهایی"
        else -> "دور ${n / 2} بازی"
    }

    fun cupRoundDoneThisWeek(): Boolean = cupStampS == G.season && cupStampW == G.week

    private fun playOneRound(c: FCupState, t: Team) {
        val teams = c.alive.toList()
        val stage = roundName(teams.size)
        c.log.add("— $stage —")
        val next = ArrayList<Int>()
        var i = 0
        while (i + 1 < teams.size) {
            val h = G.team(teams[i])
            val a = G.team(teams[i + 1])
            val sc = friendlyScore(h, a)
            var winner: Team
            var pen = ""
            if (sc.first != sc.second) {
                winner = if (sc.first > sc.second) h else a
            } else {
                val sm = strengthsByTeam()
                val edge = ((sm[h.id] ?: 60) - (sm[a.id] ?: 60)).coerceIn(-10, 10)
                val homeWins = Random.nextInt(100) < 50 + edge
                winner = if (homeWins) h else a
                val wp = Random.nextInt(3, 6)
                val lp = (wp - Random.nextInt(1, 3)).coerceAtLeast(0)
                pen = if (homeWins) " (پنالتی $wp-$lp)" else " (پنالتی $lp-$wp)"
            }
            val mark = if (h.id == t.id || a.id == t.id) "⭐ " else ""
            c.log.add("$mark${h.name} ${sc.first} - ${sc.second} ${a.name}$pen")
            next.add(winner.id)
            i += 2
        }
        val wasFinal = teams.size == 2
        val userWasIn = t.id in teams
        c.alive.clear(); c.alive.addAll(next)
        c.round++
        c.userAlive = t.id in next
        if (next.size == 1) {
            c.finished = true
            c.champion = next[0]
            if (next[0] == t.id) {
                t.budget += c.prize
                addGems(c.gems)
                cupTitles++
                c.log.add("🏆 قهرمان: ${t.name}! جایزه ${money(c.prize)}" + if (c.gems > 0) " + ${c.gems} الماس" else "")
            } else {
                c.log.add("🏆 قهرمان: ${G.team(next[0]).name}")
                if (wasFinal && userWasIn) {
                    val consolation = c.prize / 4
                    t.budget += consolation
                    c.log.add("🥈 نایب‌قهرمانی: ${money(consolation)} پاداش")
                }
            }
        }
    }

    // یک دور برای کاربر؛ اگر کاربر حذف شود بقیه جام فوری شبیه‌سازی می‌شود.
    fun playCupRound(): String {
        val c = cup ?: return ""
        val t = userTeam() ?: return ""
        if (c.finished) return "جام تمام شده است."
        if (cupRoundDoneThisWeek() && c.userAlive) return "این هفته دور جام را بازی کرده‌اید؛ هفته بعد ادامه دهید."
        playOneRound(c, t)
        cupStampS = G.season; cupStampW = G.week
        while (!c.finished && !c.userAlive) playOneRound(c, t)
        return if (c.finished) (if (c.champion == t.id) "🏆 تبریک! قهرمان ${c.name} شدید." else "جام تمام شد.")
        else if (c.userAlive) "✅ به دور بعد صعود کردید." else "❌ از جام حذف شدید."
    }

    // ---------- خرید و فروش با الماس (داخل بازار نقل‌وانتقالات) ----------
    const val GEM_RATE = 2_000_000L

    // بعضی از بازیکنان (به‌صورت ثابت در هر فصل) گزینه خرید با الماس دارند.
    fun gemBuyOk(p: Player): Boolean = p.rating <= 88 && (p.id + G.season) % 3 == 0

    // قیمت الماسی ۱۰٪ ارزان‌تر از معادل سکه‌ای (قیمت خرید = ۱۲۰٪ ارزش)
    fun gemBuyPrice(p: Player): Int = ((p.value * 12 / 10 * 9 / 10 + GEM_RATE - 1) / GEM_RATE).toInt().coerceAtLeast(1)

    // فروش با الماس: هر ۳ میلیون از قیمت فروش (۸۰٪ ارزش) = ۱ الماس
    fun gemSellPrice(p: Player): Int = (p.value * 8 / 10 / 3_000_000L).toInt()

    fun buyWithGems(pid: Int): String {
        val t = userTeam() ?: return ""
        val p = G.players.firstOrNull { it.id == pid } ?: return "بازیکن پیدا نشد."
        if (p.teamId == t.id) return "این بازیکن از قبل در تیم شماست."
        if (squad(t.id).size >= G.ppt + 8) return "سقف تعداد بازیکنان پر است"
        val seller = G.teamOrNull(p.teamId)
        if (seller != null && squad(seller.id).size <= 15) return "تیم فروشنده این بازیکن را نمی‌فروشد"
        val price = gemBuyPrice(p)
        if (gems < price) return "الماس کافی نیست (نیاز: $price)."
        gems -= price
        seller?.let { it.budget += p.value / 2 }
        addNews("💎 ${p.name} (${p.rating}) | مبدا: ${seller?.name ?: "بازار آزاد"} ← مقصد: ${t.name} | $price الماس")
        p.teamId = t.id
        return "✅ ${p.name} با $price الماس خریداری شد."
    }

    fun sellForGems(pid: Int): String {
        val t = userTeam() ?: return ""
        val p = G.players.firstOrNull { it.id == pid && it.teamId == t.id } ?: return "این بازیکن در تیم شما نیست."
        if (squad(t.id).size <= 15) return "حداقل ۱۵ بازیکن لازم است"
        val g = gemSellPrice(p)
        if (g < 1) return "ارزش این بازیکن برای فروش با الماس کم است."
        val c = G.teams.filter { it.id != t.id && squad(it.id).size < G.ppt + 4 }
        if (c.isEmpty()) G.players.remove(p) else p.teamId = c.random().id
        gems += g
        return "${p.name} فروخته شد (+$g الماس)."
    }

    fun exchangeGem(): String {
        val t = userTeam() ?: return ""
        if (t.budget < GEM_RATE) return "بودجه کافی نیست."
        t.budget -= GEM_RATE
        gems += 1
        return "۱ الماس با ${money(GEM_RATE)} خریداری شد."
    }

    // ---------- پیش‌بینی ----------
    fun upcomingMatches(): List<Pair<Int, Int>> {
        val t = userTeam() ?: return emptyList()
        val fx = fixturesFor(t.leagueId)
        return if (G.week < fx.size && G.week < totalWeeks()) fx[G.week] else emptyList()
    }

    fun hasPredictionThisWeek(): Boolean = preds.any { it.season == G.season && it.week == G.week }

    fun submitPredictions(picks: Map<Int, Int>): String {
        if (hasPredictionThisWeek()) return "برای این هفته قبلاً پیش‌بینی ثبت کرده‌اید."
        val ms = upcomingMatches()
        var n = 0
        for ((idx, pick) in picks) {
            if (idx in ms.indices) { preds.add(Pred(G.season, G.week, ms[idx].first, ms[idx].second, pick)); n++ }
        }
        return if (n == 0) "حداقل یک بازی را پیش‌بینی کنید." else "$n پیش‌بینی ثبت شد؛ نتیجه پس از بازی این هفته مشخص می‌شود."
    }

    // نتیجه پیش‌بینی‌هایی که بازی‌شان انجام شده را حساب می‌کند. در صورت وجود پیام برمی‌گرداند.
    fun resolvePreds(): String? {
        if (preds.isEmpty()) return null
        val t = userTeam() ?: return null
        val lv = G.live
        if (G.pendingPenaltyMatch != null) return null
        if (lv != null && !lv.tableApplied) return null
        val groups = preds.groupBy { it.season * 1000 + it.week }
        val msgs = ArrayList<String>()
        for ((key, list) in groups) {
            val s = list[0].season
            val w = list[0].week
            val played = G.season > s || (G.season == s && G.week > w)
            if (!played) continue
            var right = 0
            var counted = 0
            for (p in list) {
                val rec = G.matchLog.firstOrNull { it.season == s && it.week == w + 1 && it.comp == 0 && it.hid == p.hid && it.aid == p.aid }
                if (rec != null) {
                    counted++
                    val real = if (rec.hg > rec.ag) 1 else if (rec.hg == rec.ag) 0 else 2
                    if (real == p.pick) right++
                }
            }
            preds.removeAll(list.toSet())
            if (counted == 0) continue
            val coins = right * 300_000L
            var g = 0
            if (right >= 7) g = 1
            if (counted >= 5 && right == counted) g = 3
            t.budget += coins
            addGems(g)
            predTotal += counted; predRight += right
            val line = "فصل $s هفته ${w + 1}: $right از $counted درست • +${money(coins)}" + if (g > 0) " + $g الماس" else ""
            predHist.add(0, line)
            while (predHist.size > 12) predHist.removeAt(predHist.size - 1)
            msgs.add("🎯 $line")
        }
        return if (msgs.isEmpty()) null else msgs.joinToString("\n")
    }
}

// ======================= اجزای ظاهری مشترک =======================

val HubGreen = Color(0xFF0E5A22)
val HubGreenLight = Color(0xFF1B8A33)
val HubGold = Color(0xFFE0A800)

@Composable
fun Banner(emoji: String, title: String, sub: String) {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(HubGreen, HubGreenLight)))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 34.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color(0xFFFFEB3B), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(sub, color = Color.White, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun Tile(emoji: String, label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(color).clickable { onClick() }.padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 24.sp)
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
fun CurrencyChips(t: Team) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B3A1E)).padding(horizontal = 6.dp, vertical = 3.dp)) {
            Text("🪙 ${money(t.budget)}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        Spacer(Modifier.width(6.dp))
        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF12305A)).padding(horizontal = 6.dp, vertical = 3.dp)) {
            Text("💎 ${Hub.gems}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

// ======================= باشگاه تمرین =======================

@Composable
fun TrainCenter() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var info by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<Int>()) }
    val lvl = Hub.trLevel
    val active = lvl > 0 && Hub.trWeeksLeft > 0
    val cap = if (active) Hub.CAPS[lvl - 1] else 0
    val gain = if (active) Hub.GAIN[lvl - 1] else 0
    Page("باشگاه تمرین") {
        Banner("🏋️", if (active) "باشگاه تمرین سطح $lvl" else "باشگاه تمرین",
            if (active) "هفته‌ای $cap بازیکن • هر بازیکن +$gain اورال • ${Hub.trWeeksLeft} هفته تا پایان قرارداد"
            else "برای تمرین دادن بازیکنان، باشگاه را اجاره کنید.")
        if (info.isNotEmpty()) Panel { Text(info, fontWeight = FontWeight.SemiBold) }
        Panel {
            Text("اجاره / ارتقای باشگاه (${Hub.RENT_WEEKS} هفته)", fontWeight = FontWeight.Bold)
            for (l in 1..5) {
                val i = l - 1
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("سطح $l" + if (active && lvl == l) "  ✅ فعال" else "", fontWeight = FontWeight.SemiBold)
                        Text("${Hub.CAPS[i]} بازیکن در هفته • +${Hub.GAIN[i]} اورال", fontSize = 12.sp, color = Color.Gray)
                        Text("هزینه: ${money(Hub.RENT_COST[i])}" + if (Hub.RENT_GEMS[i] > 0) " + ${Hub.RENT_GEMS[i]} 💎" else "", fontSize = 12.sp, color = Color.Gray)
                    }
                    val label = if (active && lvl == l) "تمدید" else if (active && l > lvl) "ارتقا" else "اجاره"
                    B(label, enabled = !(active && l < lvl)) {
                        info = Hub.rent(l); G.touch()
                    }
                }
                HorizontalDivider()
            }
        }
        if (active) {
            val done = Hub.trainedThisWeek()
            Panel {
                Text("تمرین بازیکنان", fontWeight = FontWeight.Bold)
                Text("انتخاب‌شده: ${selected.size} از $cap • هر بازیکن در هر فصل حداکثر ${Hub.MAX_TRAIN_PER_SEASON} بار تمرین می‌کند.", fontSize = 12.sp, color = Color.Gray)
                B(if (done) "✅ تمرین این هفته انجام شده" else "🎯 شروع تمرین", Modifier.fillMaxWidth(), !done && selected.isNotEmpty() && selected.size <= cap) {
                    info = Hub.trainPlayers(selected); selected = emptySet(); G.touch()
                }
            }
            val sq = squad(t.id).sortedWith(compareBy<Player> { it.age }.thenByDescending { it.rating })
            Panel {
                for (p in sq) {
                    val block = Hub.trainBlock(p)
                    val used = Hub.trainedThisSeason(p.id)
                    Row(
                        Modifier.fillMaxWidth().clickable(enabled = block == null && !done) {
                            selected = if (p.id in selected) selected - p.id else if (selected.size < cap) selected + p.id else selected
                        }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = p.id in selected, onCheckedChange = null, enabled = block == null && !done)
                        Spacer(Modifier.width(6.dp))
                        Text(p.pos, Modifier.width(34.dp), color = posColor(p.pos), fontWeight = FontWeight.Bold)
                        Column(Modifier.weight(1f)) {
                            Text(p.name)
                            Text("سن ${p.age} • تمرین فصل: $used/${Hub.MAX_TRAIN_PER_SEASON}" + (if (block != null) " • $block" else ""), fontSize = 12.sp, color = if (block != null) Color(0xFFC62828) else Color.Gray)
                        }
                        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(HubGold).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("${p.rating}", fontWeight = FontWeight.Bold)
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ======================= بازی دوستانه =======================

@Composable
fun FriendlyMatch() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var info by remember { mutableStateOf("") }
    LaunchedEffect(G.week, G.season) { Hub.refreshOpponents(); G.touch() }
    val sm = strengthsByTeam()
    val me = sm[t.id] ?: 60
    val done = Hub.friendlyDoneThisWeek()
    Page("بازی دوستانه") {
        Banner("🤝", "بازی دوستانه", "هفته‌ای یک بازی دوستانه؛ نتیجه روی جدول لیگ اثری ندارد ولی پاداش دارد.")
        if (info.isNotEmpty()) Panel { Text(info, fontWeight = FontWeight.Bold) }
        if (done) Panel { Text("✅ این هفته بازی دوستانه انجام داده‌اید. هفته بعد حریف‌های جدید می‌آیند.") }
        Panel {
            Text("حریف‌های پیشنهادی (قدرت شما: $me)", fontWeight = FontWeight.Bold)
            for (id in Hub.frOpp.toList()) {
                val o = G.teamOrNull(id) ?: continue
                val os = sm[o.id] ?: 60
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Logo(o, 36.dp)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(o.name, fontWeight = FontWeight.SemiBold)
                        Text("قدرت $os • پاداش پیروزی ${money(Hub.friendlyReward(me, os))}", fontSize = 12.sp, color = Color.Gray)
                    }
                    B("بازی", enabled = !done) { info = Hub.playFriendly(o.id); G.touch() }
                }
                HorizontalDivider()
            }
        }
        if (Hub.frLog.isNotEmpty()) Panel {
            Text("نتایج اخیر", fontWeight = FontWeight.Bold)
            for (l in Hub.frLog) Text(l, fontSize = 13.sp)
        }
    }
}

// ======================= جام دوستانه =======================

@Composable
fun FriendlyCup() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var info by remember { mutableStateOf("") }
    var section by remember { mutableStateOf(if (Hub.cup != null) "mine" else "search") }
    var search by remember { mutableStateOf("") }
    var onlyJoinable by remember { mutableStateOf(true) }
    var newName by remember { mutableStateOf("") }
    var newSize by remember { mutableStateOf("8") }
    var newFee by remember { mutableStateOf("500000") }
    LaunchedEffect(G.week, G.season) { Hub.refreshOpenCups(); G.touch() }
    Page("جام دوستانه") {
        Banner("🏆", "جام دوستانه", "در جام‌ها شرکت کنید یا جام جدید بسازید.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            B("🔍 جستجو", Modifier.weight(1f)) { section = "search" }
            B("➕ ساخت جام", Modifier.weight(1f)) { section = "create" }
            B("📋 جام من", Modifier.weight(1f)) { section = "mine" }
        }
        if (info.isNotEmpty()) Panel { Text(info, fontWeight = FontWeight.SemiBold) }
        when (section) {
            "search" -> {
                Panel {
                    TextF("نام جام", search, { search = it }, Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = onlyJoinable, onCheckedChange = { onlyJoinable = it })
                        Text("فقط نمایش جام‌های قابل شرکت")
                    }
                }
                val list = Hub.openCups.filter { search.isBlank() || it.name.contains(search.trim()) }
                    .filter { !onlyJoinable || t.budget >= it.fee }
                if (list.isEmpty()) Panel { Text("جامی پیدا نشد.") }
                for (c in list) {
                    Panel {
                        Text(c.name, fontWeight = FontWeight.Bold)
                        Text("${c.size} تیم • ورودی ${if (c.fee == 0L) "رایگان" else money(c.fee)} • جایزه ${money(Hub.cupPrize(c.size, c.fee))}" + if (c.gems > 0) " + ${c.gems} 💎" else "", fontSize = 12.sp, color = Color.Gray)
                        B("شرکت در جام", Modifier.fillMaxWidth(), t.budget >= c.fee && !Hub.cupActive()) {
                            info = Hub.startCup(c.name, c.size, c.fee, c.gems)
                            if (Hub.cupActive()) { Hub.openCups.remove(c); section = "mine" }
                            G.touch()
                        }
                    }
                }
                if (Hub.cupActive()) Text("هم‌زمان فقط در یک جام می‌توانید شرکت کنید.", fontSize = 12.sp, color = Color.Gray)
            }
            "create" -> Panel {
                Text("ساخت جام جدید", fontWeight = FontWeight.Bold)
                TextF("نام جام", newName, { newName = it }, Modifier.fillMaxWidth())
                Text("تعداد تیم‌ها", fontSize = 13.sp)
                Chips(listOf("8", "16"), newSize) { newSize = it }
                Text("ورودی (سکه)", fontSize = 13.sp)
                Chips(listOf("0", "250000", "500000", "1000000", "2000000"), newFee) { newFee = it }
                val size = newSize.toIntOrNull() ?: 8
                val fee = newFee.toLongOrNull() ?: 0L
                Text("جایزه قهرمان: ${money(Hub.cupPrize(size, fee))} • ورودی از بودجه کم می‌شود.", fontSize = 12.sp, color = Color.Gray)
                B("ساخت و شرکت", Modifier.fillMaxWidth(), !Hub.cupActive() && t.budget >= fee) {
                    info = Hub.startCup(newName, size, fee, if (size == 16) 2 else 1)
                    if (Hub.cupActive()) section = "mine"
                    G.touch()
                }
            }
            else -> {
                val c = Hub.cup
                if (c == null) Panel { Text("در هیچ جامی شرکت نکرده‌اید. از بخش جستجو یک جام انتخاب کنید یا جام بسازید.") }
                else {
                    Panel {
                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${c.size} تیم • ${if (c.finished) "پایان‌یافته" else "مرحله بعد: ${Hub.roundName(c.alive.size)}"}")
                        if (!c.finished) {
                            val done = Hub.cupRoundDoneThisWeek() && c.userAlive
                            B(if (done) "⏳ دور بعد هفته آینده" else "▶️ بازی ${Hub.roundName(c.alive.size)}", Modifier.fillMaxWidth(), !done) {
                                info = Hub.playCupRound(); G.touch()
                            }
                        } else {
                            Text(if (c.champion == t.id) "🏆 شما قهرمان شدید!" else "قهرمان: ${G.teamOrNull(c.champion)?.name ?: ""}", fontWeight = FontWeight.Bold)
                            B("بستن جام", Modifier.fillMaxWidth()) { Hub.cup = null; info = ""; G.touch() }
                        }
                    }
                    Panel {
                        Text("گزارش جام", fontWeight = FontWeight.Bold)
                        for (l in c.log) Text(l, fontSize = 13.sp)
                    }
                }
                Text("🏆 قهرمانی‌های جام دوستانه: ${Hub.cupTitles}", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

// ======================= پیش‌بینی =======================

@Composable
fun Predict() {
    val rv = G.rev
    var info by remember { mutableStateOf("") }
    val picks = remember { mutableStateMapOf<Int, Int>() }
    LaunchedEffect(G.week, G.season) {
        val m = Hub.resolvePreds()
        if (m != null) { info = m; G.touch() }
    }
    val ms = Hub.upcomingMatches()
    val locked = Hub.hasPredictionThisWeek()
    Page("پیش‌بینی") {
        Banner("🎯", "پیش‌بینی نتایج", "نتیجه بازی‌های لیگ این هفته را حدس بزنید. هر حدس درست ۳۰۰ هزار؛ ۷ درست = ۱ الماس؛ همه درست = ۳ الماس.")
        if (info.isNotEmpty()) Panel { Text(info, fontWeight = FontWeight.SemiBold) }
        if (Hub.predTotal > 0) Text("دقت کل پیش‌بینی‌ها: ${Hub.predRight} از ${Hub.predTotal}", fontSize = 12.sp, color = Color.Gray)
        if (ms.isEmpty()) Panel { Text("این هفته بازی لیگ برای پیش‌بینی وجود ندارد.") }
        else {
            if (locked) Panel { Text("✅ پیش‌بینی این هفته ثبت شده؛ بعد از بازی نتیجه اعلام می‌شود.") }
            Panel {
                for ((idx, m) in ms.withIndex()) {
                    val h = G.team(m.first)
                    val a = G.team(m.second)
                    val mine = Hub.preds.firstOrNull { it.season == G.season && it.week == G.week && it.hid == m.first && it.aid == m.second }
                    val cur = mine?.pick ?: picks[idx]
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${h.name} - ${a.name}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                        val opts = listOf(1 to "۱", 0 to "x", 2 to "۲")
                        for ((v, lab) in opts) {
                            val sel = cur == v
                            Box(
                                Modifier.padding(start = 4.dp).clip(RoundedCornerShape(8.dp))
                                    .background(if (sel) HubGreenLight else Color(0xFFE0E0E0))
                                    .clickable(enabled = !locked) { picks[idx] = v }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) { Text(lab, color = if (sel) Color.White else Color.Black, fontWeight = FontWeight.Bold) }
                        }
                    }
                    HorizontalDivider()
                }
            }
            if (!locked) B("ثبت پیش‌بینی‌ها (${picks.size})", Modifier.fillMaxWidth(), picks.isNotEmpty()) {
                info = Hub.submitPredictions(picks.toMap()); picks.clear(); G.touch()
            }
        }
        if (Hub.predHist.isNotEmpty()) Panel {
            Text("تاریخچه", fontWeight = FontWeight.Bold)
            for (l in Hub.predHist) Text(l, fontSize = 13.sp)
        }
    }
}
