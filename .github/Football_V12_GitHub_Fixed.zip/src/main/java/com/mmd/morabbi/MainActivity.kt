package com.mmd.morabbi

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.exp
import kotlin.math.pow
import kotlin.random.Random

// ======================= داده‌ها =======================

val POS = listOf("GK", "DF", "MF", "FW")
val FORMS = listOf("4-4-2", "4-3-3", "3-5-2", "4-5-1", "5-3-2")
val STY = listOf("دفاعی", "متعادل", "تهاجمی")
val DIFFS = listOf("آسان", "متوسط", "سخت")
val SHIRTS = listOf("ساده", "راه‌راه", "دو نیمه", "کمربند")
val ADMIN_PASS = "MMD#2000"

val PAL: List<Long> = listOf(
    0xFFD32F2F, 0xFF1565C0, 0xFF2E7D32, 0xFFFBC02D, 0xFF6A1B9A, 0xFFEF6C00,
    0xFF212121, 0xFFFFFFFF, 0xFF00ACC1, 0xFFE91E63, 0xFF5D4037, 0xFF90A4AE
)

val FIRST = mapOf(
    "ایران" to listOf("علی", "رضا", "مهدی", "حسین", "امیر", "سعید", "پوریا", "کاوه"),
    "انگلیس" to listOf("جیمز", "جک", "هری", "جورج", "ویلیام", "چارلی", "تام", "لوک"),
    "اسپانیا" to listOf("کارلوس", "خاویر", "پدرو", "دیگو", "مانوئل", "آلوارو", "ایکر", "رائول"),
    "ایتالیا" to listOf("مارکو", "لوکا", "آندرئا", "جووانی", "فدریکو", "ماتئو", "لورنتزو", "الساندرو"),
    "آلمان" to listOf("یوناس", "مارکوس", "توماس", "فلیکس", "لوکاس", "کای", "یان", "مانوئل"),
    "فرانسه" to listOf("کیلیان", "آنتوان", "اوسمان", "هوگو", "تئو", "نیکولا", "پل", "ژولیان"),
    "برزیل" to listOf("ویتور", "رودریگو", "گابریل", "ماتئوس", "لوکاس", "فرناندو", "دانیلو", "کائو"),
    "آرژانتین" to listOf("لیونل", "خولیان", "نیکولاس", "لاوتارو", "فرانکو", "آنخل", "پائولو", "تیاگو"),
    "ترکیه" to listOf("امره", "عثمان", "مراد", "کریم", "یوسف", "برکی", "اردا", "جان"),
    "پرتغال" to listOf("کریستیانو", "برونو", "ژوائو", "رافائل", "دیگو", "پدرو", "تیاگو", "گونچالو"),
    "هلند" to listOf("فرنکی", "ممفیس", "کودی", "ژاوی", "ماتیاس", "دانی", "یورین", "استیون")
)
val LAST = mapOf(
    "ایران" to listOf("احمدی", "رضایی", "کریمی", "موسوی", "حسینی", "جعفری", "صادقی", "نوری"),
    "انگلیس" to listOf("اسمیت", "جونز", "تیلور", "براون", "ویلسون", "اوانز", "واکر", "رایت"),
    "اسپانیا" to listOf("گارسیا", "مارتینز", "لوپز", "سانچز", "پرز", "فرناندز", "رومرو", "نوارو"),
    "ایتالیا" to listOf("روسی", "روسو", "فرارا", "بیانکی", "کوستا", "ریچی", "گالو", "مورو"),
    "آلمان" to listOf("مولر", "شمیت", "فیشر", "وبر", "واگنر", "بکر", "هافمن", "کراوس"),
    "فرانسه" to listOf("مارتن", "برنار", "دوبوآ", "موریس", "لوران", "میشل", "فونتن", "گارنیه"),
    "برزیل" to listOf("سیلوا", "سانتوس", "اولیویرا", "سوزا", "لیما", "پریرا", "کاستا", "ریبیرو"),
    "آرژانتین" to listOf("گونزالس", "رودریگز", "آکوستا", "مدینا", "سوسا", "بنیتز", "ایبارا", "پاز"),
    "ترکیه" to listOf("یلماز", "کایا", "دمیر", "چلیک", "شاهین", "آیدین", "ازتورک", "آرسلان"),
    "پرتغال" to listOf("سیلوا", "سانتوس", "فریرا", "پریرا", "کوستا", "اولیویرا", "مارتینز", "کاروالیو"),
    "هلند" to listOf("دی‌یونگ", "دیپای", "گاکپو", "سیمونز", "فن‌دایک", "آکه", "مالن", "بروبی")
)
val COUNTRIES: List<String> = FIRST.keys.toList()

val NAME_A = listOf(
    "شاهین", "ستاره", "آتش", "فولاد", "پارس", "طوفان", "آریا", "سپهر", "کاوه", "ققنوس",
    "سیمرغ", "نسیم", "البرز", "دریا", "پیروزی", "ماهان", "آرمان", "شهاب", "هیرمند", "زاگرس"
)
val NAME_B = listOf(
    "تهران", "شیراز", "تبریز", "اصفهان", "مشهد", "اهواز", "رشت", "کرمان", "یزد", "ساری", "قم", "همدان"
)

val CLUB_A = mapOf(
    "انگلیس" to listOf("رویال", "یونایتد", "کینگز", "رورز", "اتلتیک", "ولز", "دیوک", "کرون"),
    "اسپانیا" to listOf("رئال", "اتلتیکو", "دپورتیوو", "اسپورتینگ", "کلوب", "یونیون", "سلتا", "ریال"),
    "ایتالیا" to listOf("اینترنو", "یونیون", "کالچو", "ویرتوس", "آزورا", "فورتیتودو", "رومولو", "سانتا"),
    "آلمان" to listOf("بروسیا", "آیندراخت", "فورتونا", "ویکتوریا", "ترو", "ریزن", "اشتورم", "هانزا"),
    "فرانسه" to listOf("اولمپیک", "ستاد", "ایگل", "لوکوک", "فلور", "رویال", "اتوال", "راسینگ"),
    "برزیل" to listOf("اسپورت", "اتلتیکو", "آمریکا", "گوارانی", "اونیاو", "ایتوانو", "ناسیونال", "رئال"),
    "ترکیه" to listOf("ینی", "بلدیه", "گنج", "اتلتیک", "آنادولو", "دمیر"),
    "آرژانتین" to listOf("سان", "کلوب", "اتلتیکو", "دپورتیوو", "سنترال", "یونیون"),
    "پرتغال" to listOf("اسپورتیو", "اتلتیکو", "گرمیو", "یونیائو", "کلوب"),
    "هلند" to listOf("اف‌سی", "فورتونا", "ویتسه", "اس‌سی", "وی‌وی‌وی")
)
val CLUB_B = mapOf(
    "انگلیس" to listOf("لندن", "منچستر", "لیورپول", "لیدز", "بریستول", "شفیلد", "نیوکاسل", "لستر", "ناتینگهام", "برایتون"),
    "اسپانیا" to listOf("مادرید", "بارسلونا", "سویا", "والنسیا", "بیلبائو", "مالاگا", "گرانادا", "ویگو", "ساراگوسا", "مایورکا"),
    "ایتالیا" to listOf("میلان", "تورین", "رم", "ناپل", "ژنوا", "فلورانس", "بولونیا", "پالرمو", "باری", "ورونا"),
    "آلمان" to listOf("برلین", "مونیخ", "هامبورگ", "کلن", "دورتموند", "اشتوتگارت", "لایپزیگ", "برمن", "دوسلدورف", "فرانکفورت"),
    "فرانسه" to listOf("پاریس", "مارسی", "لیون", "لیل", "نیس", "رن", "نانت", "تولوز", "بوردو", "استراسبورگ"),
    "برزیل" to listOf("ریو", "سائوپائولو", "کوریتیبا", "سالوادور", "رسیف", "بلو هوریزونته", "مانائوس", "بلم", "گویانیا", "فلوریانوپولیس"),
    "ترکیه" to listOf("بورسا", "ازمیر", "مالاتیا", "مرسین", "دیاربکر", "ترابزون", "سامسون", "اردو", "ایسپارتا", "آدیامان"),
    "آرژانتین" to listOf("مندوسا", "سالتا", "کوردوبا", "لاپلاتا", "ویلا", "خوخوی", "نیوکن", "ریسیستنسیا"),
    "پرتغال" to listOf("ویزئو", "لیریا", "اوئیراش", "ماتوزینیوش", "سیتوبال", "پورتالگره", "لاگوش", "آویرو"),
    "هلند" to listOf("لیدن", "هارلم", "بریدا", "ماستریخت", "دلفت", "آمستردام", "روتردام", "زوله")
)

// لیگ‌های پایه: کشور و دسته‌ها (ایران همیشه اول)
val LEAGUE_DEFS: List<Pair<String, List<String>>> = listOf(
    "ایران" to listOf("لیگ برتر ایران", "لیگ دسته یک ایران", "لیگ دسته دو ایران", "لیگ دسته سه ایران"),
    "انگلیس" to listOf("لیگ برتر انگلیس", "چمپیونشیپ انگلیس", "لیگ یک انگلیس", "لیگ دو انگلیس"),
    "اسپانیا" to listOf("لالیگا", "لالیگا ۲", "دسته سه اسپانیا"),
    "ایتالیا" to listOf("سری آ", "سری بی", "سری سی"),
    "آلمان" to listOf("بوندسلیگا", "بوندسلیگا ۲", "لیگا ۳"),
    "فرانسه" to listOf("لیگ ۱ فرانسه", "لیگ ۲ فرانسه", "ملی فرانسه"),
    "برزیل" to listOf("سری آ برزیل", "سری بی برزیل", "سری سی برزیل"),
    "ترکیه" to listOf("سوپر لیگ ترکیه", "لیگ یک ترکیه", "لیگ دو ترکیه"),
    "آرژانتین" to listOf("لیگ برتر آرژانتین", "دسته یک آرژانتین"),
    "پرتغال" to listOf("لیگ برتر پرتغال", "لیگ دسته یک پرتغال"),
    "هلند" to listOf("اردیویسه", "ارسته دیویسه")
)

// باشگاه‌های واقعی در اولویت اول هر لیگ قرار می‌گیرند؛ در صورت نیاز، تیم‌های تولیدی تکمیل‌کننده‌اند.
val REAL_CLUBS: Map<String, List<String>> = mapOf(
    "ایران" to listOf("پرسپولیس", "استقلال", "سپاهان", "تراکتور", "فولاد", "گل‌گهر", "ملوان", "ذوب‌آهن", "آلومینیوم اراک", "شمس‌آذر", "خیبر خرم‌آباد", "چادرملو", "مس رفسنجان", "نساجی", "پیکان", "صنعت نفت آبادان", "سایپا", "فجر سپاسی", "نفت مسجدسلیمان", "هوادار"),
    "انگلیس" to listOf("منچسترسیتی", "آرسنال", "لیورپول", "منچستریونایتد", "چلسی", "تاتنهام", "نیوکاسل یونایتد", "استون ویلا", "وستهم", "برایتون", "کریستال پالاس", "برنتفورد", "فولام", "اورتون", "ناتینگهام فارست", "بورنموث", "ولورهمپتون", "لسترسیتی", "ساوتهمپتون", "ایپسویچ تاون"),
    "اسپانیا" to listOf("رئال مادرید", "بارسلونا", "اتلتیکو مادرید", "اتلتیک بیلبائو", "رئال سوسیداد", "ویارئال", "رئال بتیس", "سویا", "والنسیا", "خیرونا", "ختافه", "اوساسونا", "سلتاویگو", "مایورکا", "لاس پالماس", "رایو وایکانو", "آلاوس", "گرانادا", "کادیس", "رئال وایادولید"),
    "ایتالیا" to listOf("اینتر", "آث میلان", "یوونتوس", "ناپولی", "آتالانتا", "رم", "لاتزیو", "فیورنتینا", "بولونیا", "تورینو", "مونزا", "اودینزه", "جنوا", "کالیاری", "امپولی", "ورونا", "ساسولو", "لچه", "پارما", "کومو"),
    "آلمان" to listOf("بایرن مونیخ", "بروسیا دورتموند", "بایر لورکوزن", "لایپزیگ", "اشتوتگارت", "آینتراخت فرانکفورت", "وولفسبورگ", "فرایبورگ", "هوفنهایم", "وردربرمن", "آگزبورگ", "ماینتس", "مونشن‌گلادباخ", "یونیون برلین", "بوخوم", "هایدنهایم", "سن پائولی", "هولشتاین کیل", "هامبورگ", "هرتابرلین"),
    "فرانسه" to listOf("پاری سن ژرمن", "مارسی", "موناکو", "لیون", "لیل", "نیس", "رن", "لانس", "استراسبورگ", "نانت", "تولوز", "مون‌پلیه", "برست", "لوهاور", "متز", "لوریان", "سن‌اتین", "اوسر", "آنژه", "ریمز"),
    "برزیل" to listOf("فلامینگو", "پالمیراس", "سائوپائولو", "کورینتیانس", "سانتوس", "گرمیو", "اینترناسیونال", "اتلتیکو مینیرو", "فلومیننزه", "بوتافوگو", "کروزیرو", "واسکو دا گاما", "باهیا", "فورتالزا", "براگانتی‌نو", "اتلتیکو پارانائنزه", "کویابا", "ویتوریا", "گوییاس", "کوریتیبا"),
    "ترکیه" to listOf("گالاتاسرای", "فنرباغچه", "بشیکتاش", "ترابزون‌اسپور", "باشاک‌شهیر", "آدانا دمیرسپور", "سیواس‌اسپور", "کاسیم‌پاشا", "آلانیااسپور", "قونیه‌اسپور", "قیصریه‌اسپور", "آنتالیااسپور", "ریزه‌اسپور", "هاتای‌اسپور", "غازی‌عنتاب", "سامسون‌اسپور", "ایوب‌اسپور", "گوزتپه", "بودروم‌اسپور", "کوجائلی‌اسپور"),
    "آرژانتین" to listOf("بوکا جونیورز", "ریور پلاته", "ایندیپندینته", "راسیینگ کلاب", "سن لورنزو", "استودیانتس", "لانوس", "ولز سارسفیلد", "روساریو سنترال", "نیوولز اولد بویز", "تالرز", "آرژنتینوس جونیورز", "دفاع و خوستیسیا", "بلگرانو", "هوراکان", "پلاتنسه", "گودوی کروز", "بانفیلد", "تایرس", "اتلتیکو توکومان"),
    "پرتغال" to listOf("بنفیکا", "پورتو", "اسپورتینگ لیسبون", "براگا", "ویتوریا گیمارش", "موریرنزه", "فامالیکائو", "آروکا", "ژیل ویسنته", "ریو آوه", "بوآویشتا", "اشتوریل", "کاسا پیا", "فارنسه", "ناسیونال", "سانتا کلارا", "چاوز", "پورتیموننزه", "پاکوش فریرا", "توندلا"),
    "هلند" to listOf("آژاکس", "پی‌اس‌وی آیندهوون", "فاینورد", "آلکمار", "توئنته", "اوترخت", "گو اهد ایگلز", "اسپارتا روتردام", "هیرنفین", "نایمخن", "فورتونا سیتارد", "هراکلز", "زووله", "ویلم دوم", "گرونینگن", "والویک", "اکسلسیور", "کامبور", "دن هاخ", "بردا")
)


class Player(
    var id: Int, var name: String, var pos: String, var rating: Int, var age: Int,
    teamId: Int, var value: Long, var goals: Int = 0, var total: Int = 0, var country: String = "ایران"
) {
    // تغییر تیم بازیکن، کش ترکیب تیم‌ها را باطل می‌کند.
    var teamId: Int = teamId
        set(v) {
            if (field != v) {
                field = v
                G.squadVer++
            }
        }
}

// لیستی که هر تغییر ساختاری آن را اطلاع می‌دهد (برای باطل کردن کش‌ها).
class TrackedList<T>(private val onChange: () -> Unit) : ArrayList<T>() {
    override fun add(element: T): Boolean { onChange(); return super.add(element) }
    override fun add(index: Int, element: T) { onChange(); super.add(index, element) }
    override fun addAll(elements: Collection<T>): Boolean { onChange(); return super.addAll(elements) }
    override fun remove(element: T): Boolean { onChange(); return super.remove(element) }
    override fun removeAt(index: Int): T { onChange(); return super.removeAt(index) }
    override fun removeAll(elements: Collection<T>): Boolean { onChange(); return super.removeAll(elements.toSet()) }
    override fun removeIf(filter: java.util.function.Predicate<in T>): Boolean { onChange(); return super.removeIf(filter) }
    override fun set(index: Int, element: T): T { onChange(); return super.set(index, element) }
    override fun clear() { onChange(); super.clear() }
}

class AcademyPlayer(
    var id: Int, var name: String, var pos: String, var rating: Int, var age: Int,
    var teamId: Int, var potential: Int, var country: String
)

class Team(
    var id: Int, var name: String, var country: String, var leagueId: Int,
    var c1: Long, var c2: Long, var style: Int, var logo: String?, var budget: Long
) {
    var p = 0
    var w = 0
    var d = 0
    var l = 0
    var gf = 0
    var ga = 0
    var pts = 0
    var allPts = 0
    var titles = 0
}

class League(var id: Int, var name: String, var level: Int, var country: String)

class Offer(val pid: Int, val from: Int, val price: Long)
class Ev(val min: Int, val text: String, val side: Int) // side: 0 گل میزبان، 1 گل میهمان، 2 رویداد
class MatchRes(val h: Team, val a: Team, var hg: Int, var ag: Int, var ev: List<Ev>)

object G {
    var rev by mutableIntStateOf(0)
    var ready by mutableStateOf(false)
    var screen by mutableStateOf("pick")
    val stack = ArrayList<String>()
    val leagues = ArrayList<League>()
    var worldVer = 0
    var teamVer = 0
    var squadVer = 0
    val teams: ArrayList<Team> = TrackedList { teamVer++ }
    val players: ArrayList<Player> = TrackedList { squadVer++ }
    val academy = ArrayList<AcademyPlayer>()
    val history = ArrayList<String>()
    var lineup = ArrayList<Int>()
    var report = ArrayList<String>()
    var live: MatchRes? = null
    var pendingPenaltyMatch: MatchRes? = null
    var penaltySide: Int = 0
    var penaltyReturnScreen: String = "play"
    val news = ArrayList<String>()
    val offers = ArrayList<Offer>()
    var msg by mutableStateOf("")
    var userTeam by mutableIntStateOf(-1)
    var tpl = 20
    var ppt = 22
    var promo = 3
    var season = 1
    var week = 0
    var diff = 1
    var academyCoachLevel = 0
    var formation = "4-4-2"
    var style = 1
    var nextId = 1
    var editTeam = -1
    lateinit var ctx: Context

    fun nid(): Int = nextId++
    private var tmap = HashMap<Int, Team>()
    private var tmapVer = -1
    private var tmapSize = -1
    private fun idx(): HashMap<Int, Team> {
        if (tmapVer != teamVer || tmapSize != teams.size) {
            val m = HashMap<Int, Team>(teams.size * 2)
            for (t in teams) m[t.id] = t
            tmap = m; tmapVer = teamVer; tmapSize = teams.size
        }
        return tmap
    }
    fun team(id: Int): Team = idx()[id] ?: throw NoSuchElementException("team $id")
    fun teamOrNull(id: Int): Team? = idx()[id]

    // کش ترکیب هر تیم: به جای فیلتر کل بازیکنان برای هر تیم، یک‌بار گروه‌بندی می‌شود.
    private var sq = HashMap<Int, List<Player>>()
    private var sqVer = -1
    private var sqSize = -1
    fun squadOf(tid: Int): List<Player> {
        if (sqVer != squadVer || sqSize != players.size) {
            val m = HashMap<Int, ArrayList<Player>>()
            for (p in players) m.getOrPut(p.teamId) { ArrayList() }.add(p)
            @Suppress("UNCHECKED_CAST")
            sq = m as HashMap<Int, List<Player>>
            sqVer = squadVer; sqSize = players.size
        }
        return sq[tid] ?: emptyList()
    }
    fun go(s: String) {
        stack.add(screen)
        screen = s
    }
    fun back() {
        screen = if (stack.isEmpty()) "home" else stack.removeAt(stack.size - 1)
    }
    private val main = Handler(Looper.getMainLooper())
    private val saveTask = Runnable { saveNow() }
    fun touch() {
        rev++
        main.removeCallbacks(saveTask)
        main.postDelayed(saveTask, 1200)
    }
    fun flush() {
        main.removeCallbacks(saveTask)
        saveNow()
    }
}

// ======================= ذخیره و بارگذاری =======================

private val saveExec = Executors.newSingleThreadExecutor()

// ساخت JSON روی ترد اصلی ولی سریع (بدون JSONObject)، نوشتن فایل در پس‌زمینه و به‌صورت اتمیک.
fun saveNow() {
    try {
        val q = { x: String -> JSONObject.quote(x) }
        val sb = StringBuilder(1 shl 20)
        sb.append("{\"nid\":").append(G.nextId)
            .append(",\"tpl\":").append(G.tpl)
            .append(",\"ppt\":").append(G.ppt)
            .append(",\"promo\":").append(G.promo)
            .append(",\"season\":").append(G.season)
            .append(",\"week\":").append(G.week)
            .append(",\"diff\":").append(G.diff)
            .append(",\"user\":").append(G.userTeam)
            .append(",\"form\":").append(q(G.formation))
            .append(",\"style\":").append(G.style)
            .append(",\"coach\":").append(G.academyCoachLevel)
            .append(",\"wv\":").append(G.worldVer)
        sb.append(",\"leagues\":[")
        for ((i, l) in G.leagues.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(l.id).append(",\"name\":").append(q(l.name))
                .append(",\"level\":").append(l.level).append(",\"country\":").append(q(l.country)).append('}')
        }
        sb.append("],\"teams\":[")
        for ((i, t) in G.teams.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(t.id).append(",\"name\":").append(q(t.name))
                .append(",\"country\":").append(q(t.country)).append(",\"lg\":").append(t.leagueId)
                .append(",\"c1\":").append(t.c1).append(",\"c2\":").append(t.c2)
                .append(",\"st\":").append(t.style).append(",\"logo\":").append(q(t.logo ?: ""))
                .append(",\"bud\":").append(t.budget).append(",\"p\":").append(t.p)
                .append(",\"w\":").append(t.w).append(",\"d\":").append(t.d).append(",\"l\":").append(t.l)
                .append(",\"gf\":").append(t.gf).append(",\"ga\":").append(t.ga)
                .append(",\"pts\":").append(t.pts).append(",\"ap\":").append(t.allPts)
                .append(",\"ti\":").append(t.titles).append('}')
        }
        sb.append("],\"players\":[")
        for ((i, p) in G.players.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(p.id).append(",\"n\":").append(q(p.name))
                .append(",\"pos\":").append(q(p.pos)).append(",\"r\":").append(p.rating)
                .append(",\"a\":").append(p.age).append(",\"t\":").append(p.teamId)
                .append(",\"v\":").append(p.value).append(",\"g\":").append(p.goals)
                .append(",\"tg\":").append(p.total).append(",\"c\":").append(q(p.country)).append('}')
        }
        sb.append("],\"academy\":[")
        for ((i, p) in G.academy.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(p.id).append(",\"n\":").append(q(p.name))
                .append(",\"pos\":").append(q(p.pos)).append(",\"r\":").append(p.rating)
                .append(",\"a\":").append(p.age).append(",\"t\":").append(p.teamId)
                .append(",\"pot\":").append(p.potential).append(",\"c\":").append(q(p.country)).append('}')
        }
        sb.append("],\"hist\":[")
        for ((i, h) in G.history.withIndex()) { if (i > 0) sb.append(','); sb.append(q(h)) }
        sb.append("],\"lineup\":[")
        for ((i, x) in G.lineup.withIndex()) { if (i > 0) sb.append(','); sb.append(x) }
        sb.append("],\"news\":[")
        for ((i, n) in G.news.withIndex()) { if (i > 0) sb.append(','); sb.append(q(n)) }
        sb.append("],\"offers\":[")
        for ((i, f) in G.offers.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append("{\"p\":").append(f.pid).append(",\"f\":").append(f.from).append(",\"v\":").append(f.price).append('}')
        }
        sb.append("]}")
        val data = sb.toString()
        val dir = G.ctx.filesDir
        saveExec.execute {
            try {
                val tmp = File(dir, "save.json.tmp")
                tmp.writeText(data)
                val dst = File(dir, "save.json")
                if (!tmp.renameTo(dst)) {
                    dst.delete()
                    tmp.renameTo(dst)
                }
            } catch (e: Exception) {
            }
        }
    } catch (e: Exception) {
    }
}

fun load(): Boolean {
    try {
        val f = File(G.ctx.filesDir, "save.json")
        if (!f.exists()) return false
        val o = JSONObject(f.readText())
        G.leagues.clear(); G.teams.clear(); G.players.clear(); G.academy.clear(); G.history.clear(); G.lineup = ArrayList()
        G.nextId = o.getInt("nid")
        G.tpl = o.getInt("tpl")
        G.ppt = o.getInt("ppt")
        G.promo = o.getInt("promo")
        G.season = o.getInt("season")
        G.week = o.getInt("week")
        G.diff = o.getInt("diff")
        G.userTeam = o.getInt("user")
        G.formation = o.getString("form")
        G.style = o.getInt("style")
        G.academyCoachLevel = o.optInt("coach", 0).coerceIn(0, 5)
        G.worldVer = o.optInt("wv", 0)
        val la = o.getJSONArray("leagues")
        for (i in 0 until la.length()) {
            val j = la.getJSONObject(i)
            G.leagues.add(League(j.getInt("id"), j.getString("name"), j.getInt("level"), j.getString("country")))
        }
        val ta = o.getJSONArray("teams")
        for (i in 0 until ta.length()) {
            val j = ta.getJSONObject(i)
            val lg = j.optString("logo", "")
            val t = Team(
                j.getInt("id"), j.getString("name"), j.getString("country"), j.getInt("lg"),
                j.getLong("c1"), j.getLong("c2"), j.getInt("st"),
                if (lg.isEmpty()) null else lg, j.getLong("bud")
            )
            t.p = j.getInt("p")
            t.w = j.getInt("w")
            t.d = j.getInt("d")
            t.l = j.getInt("l")
            t.gf = j.getInt("gf")
            t.ga = j.getInt("ga")
            t.pts = j.getInt("pts")
            t.allPts = j.getInt("ap")
            t.titles = j.getInt("ti")
            G.teams.add(t)
        }
        val pa = o.getJSONArray("players")
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i)
            G.players.add(
                Player(
                    j.getInt("id"), j.getString("n"), j.getString("pos"), j.getInt("r"), j.getInt("a"),
                    j.getInt("t"), j.getLong("v"), j.getInt("g"), j.getInt("tg"), j.optString("c", G.teamOrNull(j.getInt("t"))?.country ?: "ایران")
                )
            )
        }
        o.optJSONArray("academy")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                G.academy.add(AcademyPlayer(j.getInt("id"), j.getString("n"), j.getString("pos"), j.getInt("r"), j.getInt("a"), j.getInt("t"), j.getInt("pot"), j.getString("c")))
            }
        }
        val ha = o.getJSONArray("hist")
        for (i in 0 until ha.length()) G.history.add(ha.getString(i))
        val lu = o.getJSONArray("lineup")
        for (i in 0 until lu.length()) G.lineup.add(lu.getInt(i))
        G.news.clear(); G.offers.clear(); G.live = null
        o.optJSONArray("news")?.let { a -> for (i in 0 until a.length()) G.news.add(a.getString(i)) }
        o.optJSONArray("offers")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                G.offers.add(Offer(j.getInt("p"), j.getInt("f"), j.getLong("v")))
            }
        }
        G.screen = if (G.teamOrNull(G.userTeam) == null) "pick" else "home"
        G.stack.clear()
        return G.leagues.isNotEmpty()
    } catch (e: Exception) {
        return false
    }
}

// ======================= ساخت دنیا =======================

fun worth(r: Int, age: Int): Long {
    // قیمت‌گذاری متعادل‌تر: اورال و سن هر دو اثر محسوس دارند.
    val b = (r - 32).coerceAtLeast(1).toLong()
    val base = b * b * 5_500L
    val ageFactor = when {
        age < 21 -> 150L
        age < 24 -> 135L
        age <= 29 -> 115L
        age <= 32 -> 95L
        else -> 70L
    }
    return (base * ageFactor / 100L).coerceAtLeast(100_000L)
}

fun posPlan(n: Int): List<String> {
    val cyc = listOf("DF", "MF", "FW", "DF", "MF", "DF", "MF", "FW")
    val out = ArrayList<String>()
    repeat(if (n >= 20) 3 else 2) { out.add("GK") }
    var i = 0
    while (out.size < n) {
        out.add(cyc[i % cyc.size])
        i++
    }
    return out
}

fun genPlayer(tid: Int, country: String, pos: String, base: Int): Player {
    val f = FIRST[country] ?: FIRST.getValue("ایران")
    val l = LAST[country] ?: LAST.getValue("ایران")
    val r = (base + Random.nextInt(-8, 9)).coerceIn(40, 92)
    val age = Random.nextInt(18, 35)
    return Player(G.nid(), "${f.random()} ${l.random()}", pos, r, age, tid, worth(r, age), country = country)
}

fun genAcademyPlayer(t: Team, age: Int = Random.nextInt(14, 18)): AcademyPlayer {
    val f = FIRST[t.country] ?: FIRST.getValue("ایران")
    val l = LAST[t.country] ?: LAST.getValue("ایران")
    val pos = listOf("GK", "DF", "MF", "FW").random()
    val rating = Random.nextInt(55, 71)
    val potential = (rating + Random.nextInt(8, 25)).coerceIn(65, 91)
    return AcademyPlayer(G.nid(), "${f.random()} ${l.random()}", pos, rating, age, t.id, potential, t.country)
}

val OLD_STAR_NAMES = setOf(
    "Kylian Mbappe", "Erling Haaland", "Lionel Messi", "Cristiano Ronaldo", "Lamine Yamal", "Jude Bellingham",
    "Vinicius Junior", "Kevin De Bruyne", "Mohamed Salah", "Virgil van Dijk", "Harry Kane", "Robert Lewandowski"
)

// ستاره‌های واقعی را در باشگاه واقعی خودشان قرار می‌دهد (بازیکن بدون باشگاه: بازار آزاد)
fun addRealStars() {
    val byName = HashMap<String, Team>()
    for (t in G.teams) {
        val lg = G.leagues.firstOrNull { it.id == t.leagueId }
        if (lg != null && lg.level == 1) byName[t.name] = t
    }
    val existing = G.players.mapTo(HashSet()) { it.name }
    for (st in REAL_STARS) {
        if (st.name in existing) continue
        var tid = -1
        if (st.club != "-") {
            val t = byName[st.club] ?: continue
            tid = t.id
            val sq = squad(t.id)
            val minKeep = if (st.pos == "GK") 2 else 3
            if (sq.size >= G.ppt && sq.count { it.pos == st.pos } > minKeep) {
                sq.filter { it.pos == st.pos && it.name !in STAR_NAMES }.minByOrNull { it.rating }?.let { G.players.remove(it) }
            }
        }
        G.players.add(Player(G.nid(), st.name, st.pos, st.rating, st.age, tid, worth(st.rating, st.age), country = st.nat))
        existing.add(st.name)
    }
}

val LOWER_CLUBS: Map<String, List<String>> = mapOf(
    "ایران" to listOf("مس کرمان","مس شهربابک","مس سونگون","پارس جنوبی جم","داماش گیلان","چوکا تالش","نیروی زمینی","استقلال ملاثانی","آریو اسلامشهر","سپیدرود رشت","پاس همدان","شاهین بوشهر","ماشین‌سازی تبریز","گیتی‌پسند","نفت و گاز گچساران","شهرداری آستارا","فولاد نوین","ایرانجوان بوشهر","شهرداری نوشهر","نفت مسجدسلیمان"),
    "انگلیس" to listOf("لیدز یونایتد","برنلی","شفیلد یونایتد","وست برومویچ","نوریچ سیتی","میدلزبرو","کاونتری سیتی","ساندرلند","واتفورد","بلاکبرن روورز","بولتون واندررز","چارلتون اتلتیک","دربی کانتی","پورتسموث","ردینگ","ویگان اتلتیک","بارنزلی","لوتون تاون","هال سیتی","پلیموث آرگایل"),
    "اسپانیا" to listOf("لگانس","اسپانیول","رئال اویدو","لوانته","الچه","ایبار","تنریف","زاراگوزا","اسپورتینگ خیخون","بورگوس","آلباسته","هوئسکا","میراندس","کوردوبا","دپورتیوو لاکرونیا","مالاگا","کاستیون","راسینگ سانتاندر","ویارئال ب","آندورا"),
    "ایتالیا" to listOf("سمپدوریا","پالرمو","کرمونزه","ونتزیا","پیزا","کاتانزارو","برشا","مودنا","رجیانا","باری","چزنا","اسپتزیا","ترنانا","آسکولی","پروجا","پادوا","ویچنزا","آولینو","کروتونه","مانتوا"),
    "آلمان" to listOf("شالکه ۰۴","هرتابرلین","هامبورگ","هانوفر ۹۶","فورتونا دوسلدورف","پادربورن","کارلسروهه","نورنبرگ","کایزرسلاوترن","مگدبورگ","هولشتاین کیل","دارمشتات","دینامو درسدن","آلمانیا آخن","اسن","وهن ویسبادن","یان رگنسبورگ","ساندهاوزن","انرژی کوتبوس","هانزا روستوک"),
    "فرانسه" to listOf("بوردو","سنت‌اتین","اوکسر","آنژه","کاین","گنگام","آمیان","پاری اف‌سی","گرونوبل","بستیا","تروا","والنسین","دانکرک","رد استار","نانسی","سوشو","لو مان","اورلئان","بولون","شاتورو"),
    "برزیل" to listOf("اسپورت رسیف","سیارا","آمریکا مینیرو","آوای","پونته پرتا","گوارانی","ویلا نوا","نووتیزونتینو","میراسول","کریسیوما","ژوونتوده","اتلتیکو گویانینسه","ناوتیکو","پارانا","لوندرینا","سنتا کروز","اوپراتاریو","ویتوریا","گوییاس","کوریتیبا"),
    "ترکیه" to listOf("ارزوروم‌اسپور","آلتای","گنچلربیرلیغی","بولوسپور","آدناسپور","آمد اسپور","ساکاریاسپور","چوروم اف‌کی","اومرانیه‌اسپور","کچی‌اورنگوچو","باندیرماسپور","شانلی‌اورفا","دنیزلی‌اسپور","اسکی‌شهیرسپور","گوزتپه","کاراگومروک","مانیساسپور","وان‌اسپور","قونیه‌اسپور","سیواس‌اسپور"),
    "آرژانتین" to listOf("کویلمس","فرروکاریل اوئسته","چاکاریتا جونیورز","سان مارتین توکومان","سان مارتین سن خوان","آرسنال ساراندی","آلماگرو","آتلتیکو رافائلا","دپورتیوو مورون","پاتروناتو","آلدو‌سیوی","گیلرمو براون","آگروپکواریو","براون آدرگه","تیمپلی","دیفنسورز","کلون سانتا فه","سنترال کوردوبا","بلگرانو","هوراکان"),
    "پرتغال" to listOf("آکادمیکا کویمبرا","پنافیل","لایشوئش","فیرنزه","ماریتیمو","فارو","ویلافرانکنزه","پورتو بی","بنفیکا بی","اسپورتینگ بی","پورتیموننزه","آکادمیکو ویزئو","اولیوییرنزه","مافرا","وارزیم","فلگوئیراس","سانتا کلارا","آلورکا","چاوز","توندلا"),
    "هلند" to listOf("ویلم دوم","دن هاخ","رودا جی‌سی","کامبور","دی گرافشاپ","ناک بردا","ام‌وی‌وی ماستریخت","تلستار","دوردراخت","اف‌سی آیندهوون","هلموند اسپورت","دن بوش","آلمره سیتی","والویک","اکسلسیور","ونلو","اوس","یانگ آژاکس","یانگ پی‌اس‌وی","یانگ اوترخت")
)

fun uniqueName(country: String, leagueId: Int): String {
    val league = G.leagues.firstOrNull { it.id == leagueId }
    val clubs = if (league?.level == 1) REAL_CLUBS[country].orEmpty() else LOWER_CLUBS[country].orEmpty()
    val usedNames = G.teams.map { it.name }.toSet()
    clubs.firstOrNull { it !in usedNames }?.let { return it }
    val a = CLUB_A[country] ?: NAME_A
    val b = CLUB_B[country] ?: NAME_B
    repeat(300) {
        val n = "${a.random()} ${b.random()}"
        if (G.teams.none { it.name == n }) return n
    }
    return "باشگاه ${G.nextId}"
}

fun newTeam(lg: League): Team {
    val t = Team(G.nid(), uniqueName(lg.country, lg.id), lg.country, lg.id, PAL.random(), PAL.random(), Random.nextInt(4), null, 20_000_000L)
    while (t.c2 == t.c1) t.c2 = PAL.random()
    G.teams.add(t)
    val bonus = if (lg.country == "ایران") 0 else 5
    val boost = realisticClubBoost(t.name, lg.country, lg.level)
    val base = 70 + bonus - (lg.level - 1) * 5 + boost + (if (boost > 0) Random.nextInt(-2, 3) else Random.nextInt(-7, 8))
    for (pos in posPlan(G.ppt)) G.players.add(genPlayer(t.id, t.country, pos, base))
    repeat(5) { G.academy.add(genAcademyPlayer(t, Random.nextInt(14, 18))) }
    return t
}

fun lgSorted(): List<League> = G.leagues.sortedWith(compareBy({ COUNTRIES.indexOf(it.country) }, { it.level }))

// برای باشگاه‌هایی که در فهرست ستاره‌های اختصاصی نیستند نیز قدرت پایه بر اساس جایگاه واقعی‌شان تنظیم می‌شود.
fun realisticClubBoost(name: String, country: String, level: Int): Int {
    if (level == 1) {
        CLUB_BOOST[name]?.let { return it }
        val rank = REAL_CLUBS[country].orEmpty().indexOf(name)
        return when {
            rank in 0..2 -> 5
            rank in 3..5 -> 3
            rank in 6..9 -> 2
            rank in 10..13 -> 1
            else -> 0
        }
    }
    if (level == 2) {
        val rank = LOWER_CLUBS[country].orEmpty().indexOf(name)
        return when {
            rank in 0..2 -> 3
            rank in 3..6 -> 2
            rank in 7..11 -> 1
            else -> 0
        }
    }
    // در دسته‌های پایین‌تر، اختلاف قدرت عمدتاً از سطح لیگ می‌آید.
    return 0
}

fun cntryOf(t: Team): String = G.leagues.firstOrNull { it.id == t.leagueId }?.country ?: t.country

fun addNews(x: String) {
    G.news.add(x)
    while (G.news.size > 80) G.news.removeAt(0)
}

fun newWorld() {
    G.leagues.clear(); G.teams.clear(); G.players.clear(); G.academy.clear(); G.history.clear()
    G.lineup = ArrayList(); G.report.clear(); G.stack.clear()
    G.news.clear(); G.offers.clear(); G.live = null
    G.msg = ""; G.userTeam = -1; G.season = 1; G.week = 0; G.nextId = 1
    G.academyCoachLevel = 0
    G.tpl = 20; G.ppt = 25; G.promo = 3
    for ((country, names) in LEAGUE_DEFS) {
        for ((i, n) in names.withIndex()) {
            val lg = League(G.nid(), n, i + 1, country)
            G.leagues.add(lg)
            repeat(G.tpl) { newTeam(lg) }
        }
    }
    addRealStars()
    G.worldVer = 3
    G.screen = "pick"
}

// ======================= منطق بازی =======================

fun squad(tid: Int): List<Player> = G.squadOf(tid)

fun squadAvg(t: Team): Int {
    val sq = squad(t.id)
    return if (sq.isEmpty()) 62 else sq.map { it.rating }.average().toInt()
}

fun strengthOf(t: Team): Int {
    val top = squad(t.id).map { it.rating }.sortedDescending().take(14)
    return if (top.isEmpty()) 0 else top.average().toInt()
}

// محاسبه قدرت همه تیم‌ها با یک بار گروه‌بندی بازیکنان؛ از فیلتر کردن کل بازیکنان برای تک‌تک تیم‌ها جلوگیری می‌کند.
fun strengthsByTeam(): Map<Int, Int> {
    return G.teams.associate { team ->
        val top = squad(team.id).map { it.rating }.sortedDescending().take(14)
        team.id to if (top.isEmpty()) 0 else top.average().toInt()
    }
}

fun autoLineup(tid: Int, fm: String): List<Player> {
    val n = fm.split("-").map { it.toInt() }
    val sq = squad(tid).sortedByDescending { it.rating }
    val res = ArrayList<Player>()
    res.addAll(sq.filter { it.pos == "GK" }.take(1))
    res.addAll(sq.filter { it.pos == "DF" }.take(n[0]))
    res.addAll(sq.filter { it.pos == "MF" }.take(n[1]))
    res.addAll(sq.filter { it.pos == "FW" }.take(n[2]))
    if (res.size < 11) {
        val rest = sq.filter { it !in res }.take(11 - res.size)
        res.addAll(rest)
    }
    return res
}

fun lineupOf(t: Team): List<Player> {
    if (t.id != G.userTeam) return autoLineup(t.id, FORMS[t.id % 3])
    val mine = squad(t.id)
    val l = G.lineup.mapNotNull { id -> mine.firstOrNull { it.id == id } }.take(11)
    if (l.size == 11) return l
    return l + autoLineup(t.id, G.formation).filter { it !in l }.take(11 - l.size)
}

fun styleOf(t: Team): Int = if (t.id == G.userTeam) G.style else 1

fun strength(lu: List<Player>, style: Int): DoubleArray {
    fun avg(a: String, b: String): Double {
        val l = lu.filter { it.pos == a || it.pos == b }
        return if (l.isEmpty()) 50.0 else l.map { it.rating }.average()
    }
    val att = avg("FW", "FW") * 0.6 + avg("MF", "MF") * 0.4
    val def = avg("GK", "DF") * 0.7 + avg("MF", "MF") * 0.3
    val sa = 1.0 + (style - 1) * 0.05
    val sd = 1.0 - (style - 1) * 0.05
    return doubleArrayOf(att * sa, def * sd)
}

fun poisson(l: Double): Int {
    val lim = exp(-l)
    var k = 0
    var p = 1.0
    do {
        k++
        p *= Random.nextDouble()
    } while (p > lim)
    return k - 1
}

fun pickScorer(lu: List<Player>): Player {
    val ws = lu.map {
        val w = when (it.pos) {
            "FW" -> 6.0
            "MF" -> 3.0
            "DF" -> 1.0
            else -> 0.05
        }
        w * it.rating
    }
    var r = Random.nextDouble() * ws.sum()
    for (i in lu.indices) {
        r -= ws[i]
        if (r <= 0) return lu[i]
    }
    return lu.last()
}

fun playMatch(h: Team, a: Team, live: Boolean = false, deferTableUpdate: Boolean = false): MatchRes {
    val hl = lineupOf(h)
    val al = lineupOf(a)
    val hs = strength(hl, styleOf(h))
    val aw = strength(al, styleOf(a))
    val f = doubleArrayOf(1.15, 1.0, 0.87)[G.diff]
    var hx = 1.35 * 1.1 * (hs[0] / aw[1]).pow(3.0)
    var ax = 1.35 * (aw[0] / hs[1]).pow(3.0)
    if (h.id == G.userTeam) {
        hx *= f; ax /= f
    } else if (a.id == G.userTeam) {
        ax *= f; hx /= f
    }
    hx = hx.coerceIn(0.2, 4.5)
    ax = ax.coerceIn(0.2, 4.5)
    val hg = poisson(hx)
    val ag = poisson(ax)
    val ev = ArrayList<Ev>()
    repeat(hg) {
        val s = pickScorer(hl)
        s.goals++; s.total++
        ev.add(Ev(Random.nextInt(1, 91), "⚽ گل! ${s.name} (${h.name})", 0))
    }
    repeat(ag) {
        val s = pickScorer(al)
        s.goals++; s.total++
        ev.add(Ev(Random.nextInt(1, 91), "⚽ گل! ${s.name} (${a.name})", 1))
    }
    if (live) {
        ev.add(Ev(0, "▶️ سوت شروع بازی", 2))
        ev.add(Ev(45, "⏸ پایان نیمه اول", 2))
        ev.add(Ev(90, "🏁 سوت پایان بازی", 2))
        repeat(Random.nextInt(7, 12)) {
            val home = Random.nextBoolean()
            val tm = if (home) h else a
            val lu = if (home) hl else al
            val txt = when (Random.nextInt(4)) {
                0 -> "🔥 موقعیت خطرناک برای ${tm.name}"
                1 -> "🟨 کارت زرد برای ${lu.random().name} (${tm.name})"
                2 -> "🧤 واکنش زیبای دروازه‌بان ${tm.name}"
                else -> "💨 شوت ${pickScorer(lu).name} به بیرون رفت"
            }
            ev.add(Ev(Random.nextInt(2, 90), txt, 2))
        }
    }
    val result = MatchRes(h, a, hg, ag, ev.sortedBy { it.min })
    if (!deferTableUpdate) applyMatchTableResult(result)
    return result
}

fun applyMatchTableResult(m: MatchRes) {
    val h = m.h
    val a = m.a
    h.p++; a.p++
    h.gf += m.hg; h.ga += m.ag
    a.gf += m.ag; a.ga += m.hg
    if (m.hg > m.ag) { h.w++; h.pts += 3; a.l++ }
    else if (m.hg < m.ag) { a.w++; a.pts += 3; h.l++ }
    else { h.d++; a.d++; h.pts++; a.pts++ }
}

fun resolveInteractivePenalty(target: Int, power: Float) {
    val m = G.pendingPenaltyMatch ?: return
    val keeperTarget = Random.nextInt(1, 10)
    val side = G.penaltySide
    val team = if (side == 0) m.h else m.a
    val opponent = if (side == 0) m.a else m.h
    val keeper = lineupOf(opponent).firstOrNull { it.pos == "GK" }
    val keeperRating = keeper?.rating ?: 60
    val shooter = lineupOf(team).filter { it.pos == "FW" || it.pos == "MF" }.maxByOrNull { it.rating }
        ?: lineupOf(team).first()
    val keeperReach = (keeperRating - 60).coerceAtLeast(0) / 100f
    val scored = if (target == keeperTarget) {
        Random.nextFloat() > (0.58f + keeperReach).coerceAtMost(0.82f) * (0.55f + power * 0.45f)
    } else {
        Random.nextFloat() < (0.76f - keeperReach * 0.18f) * (1.05f - power * 0.12f)
    }
    val minute = Random.nextInt(12, 89)
    if (scored) {
        if (side == 0) m.hg++ else m.ag++
        shooter.goals++; shooter.total++
        m.ev = (m.ev + Ev(minute, "⚽ پنالتی گل شد! ${shooter.name}", side)).sortedBy { it.min }
        G.report.add("⚽ پنالتی گل شد؛ ${shooter.name} موفق شد.")
    } else {
        m.ev = (m.ev + Ev(minute, "🧤 پنالتی مهار شد؛ ${keeper?.name ?: "دروازه‌بان"} توپ را گرفت", 2)).sortedBy { it.min }
        G.report.add("🧤 پنالتی مهار شد؛ دروازه‌بان ${opponent.name} موفق بود.")
    }
    applyMatchTableResult(m)
    if (G.report.isNotEmpty()) G.report[0] = "${m.h.name}  ${m.hg} - ${m.ag}  ${m.a.name}"
    G.live = m
    G.msg = "🏁 نتیجه مسابقه شما: ${m.h.name} ${m.hg} - ${m.ag} ${m.a.name}"
    G.pendingPenaltyMatch = null
    if (G.stack.isNotEmpty()) G.stack.removeAt(G.stack.lastIndex)
    G.screen = G.penaltyReturnScreen
    G.touch()
}

private val fixCache = HashMap<Int, Pair<List<Int>, List<List<Pair<Int, Int>>>>>()

fun fixturesFor(lid: Int): List<List<Pair<Int, Int>>> {
    val key = G.teams.filter { it.leagueId == lid }.map { it.id }.sorted()
    val c = fixCache[lid]
    if (c != null && c.first == key) return c.second
    val r = buildFixtures(key)
    fixCache[lid] = key to r
    return r
}

private fun buildFixtures(sortedIds: List<Int>): List<List<Pair<Int, Int>>> {
    val ids = sortedIds.toMutableList()
    if (ids.size % 2 == 1) ids.add(-1)
    val n = ids.size
    val rounds = ArrayList<List<Pair<Int, Int>>>()
    val arr = ids.toMutableList()
    for (r in 0 until n - 1) {
        val m = ArrayList<Pair<Int, Int>>()
        for (i in 0 until n / 2) {
            val a = arr[i]
            val b = arr[n - 1 - i]
            if (a != -1 && b != -1) m.add(if (r % 2 == 0) Pair(a, b) else Pair(b, a))
        }
        rounds.add(m)
        val last = arr.removeAt(n - 1)
        arr.add(1, last)
    }
    val second = rounds.map { rd -> rd.map { Pair(it.second, it.first) } }
    return rounds + second
}

fun totalWeeks(): Int {
    var best = 0
    for (lg in G.leagues) {
        val n = G.teams.count { it.leagueId == lg.id }
        val m = if (n % 2 == 0) n else n + 1
        val w = 2 * (m - 1)
        if (w > best) best = w
    }
    return best
}

fun table(lid: Int): List<Team> =
    G.teams.filter { it.leagueId == lid }.sortedWith(
        compareByDescending<Team> { it.pts }
            .thenByDescending { it.gf - it.ga }
            .thenByDescending { it.gf }
            .thenBy { it.name }
    )

fun playWeek(live: Boolean = false) {
    G.report.clear()
    G.msg = ""
    G.live = null
    G.pendingPenaltyMatch = null
    for (lg in G.leagues.toList()) {
        val fx = fixturesFor(lg.id)
        if (G.week < fx.size) {
            for ((hid, aid) in fx[G.week]) {
                val h = G.team(hid)
                val a = G.team(aid)
                val isU = hid == G.userTeam || aid == G.userTeam
                val r = playMatch(h, a, live && isU, deferTableUpdate = isU)
                if (isU) {
                    G.live = r
                    G.penaltyReturnScreen = if (live) "live" else "play"
                    if (Random.nextInt(100) < 11) {
                        G.pendingPenaltyMatch = r
                        G.penaltySide = if (hid == G.userTeam) 0 else 1
                        G.report.add("⚠️ داور برای تیم شما پنالتی اعلام کرد!")
                    } else applyMatchTableResult(r)
                    G.report.add("${h.name}  ${r.hg} - ${r.ag}  ${a.name}")
                    for (e in r.ev) if (e.side < 2) G.report.add("${e.min}' ${e.text}")
                }
            }
        }
    }
    G.week++
    val userScore = G.report.firstOrNull { it.contains(" - ") }
    G.msg = if (userScore != null) "🏁 نتیجه مسابقه شما: $userScore" else "هفته ${G.week} شبیه‌سازی شد؛ تیم شما این هفته مسابقه نداشت."
    if (Random.nextInt(100) < 12) genOffers(1)
}

// ======================= نقل و انتقالات =======================

fun aiTransfers() {
    addNews("📢 پنجره نقل و انتقالات فصل ${G.season} باز شد")
    repeat(30) {
        val seller = G.teams.filter { it.id != G.userTeam }.randomOrNull() ?: return@repeat
        val sq = squad(seller.id)
        if (sq.size <= 16) return@repeat
        val p = sq.sortedByDescending { it.rating }.take(6).random()
        val price = p.value * 11 / 10
        val buyer = G.teams.filter {
            it.id != G.userTeam && it.id != seller.id && it.budget >= price && squad(it.id).size < G.ppt + 4
        }.randomOrNull() ?: return@repeat
        buyer.budget -= price
        seller.budget += price
        p.teamId = buyer.id
        addNews("🔁 ${p.name} (${p.rating}) | مبدا: ${seller.name} ← مقصد: ${buyer.name} | ${money(price)}")
    }
}

fun genOffers(n: Int) {
    val t = G.teamOrNull(G.userTeam) ?: return
    val top = squad(t.id).sortedByDescending { it.rating }.take(6)
    repeat(n) {
        val p = top.randomOrNull() ?: return@repeat
        if (G.offers.size >= 6 || G.offers.any { it.pid == p.id }) return@repeat
        val price = p.value * 13 / 10
        val b = G.teams.filter { it.id != t.id && it.budget >= price && squad(it.id).size < G.ppt + 4 }.randomOrNull() ?: return@repeat
        G.offers.add(Offer(p.id, b.id, price))
    }
}

fun resetSeason() {
    for (t in G.teams) {
        t.p = 0; t.w = 0; t.d = 0; t.l = 0; t.gf = 0; t.ga = 0; t.pts = 0
    }
    for (p in G.players) {
        p.total -= p.goals
        p.goals = 0
    }
    G.week = 0
    G.report.clear()
    G.msg = ""
}


// جام حذفی هر کشور؛ شرکت‌کنندگان از چند سطح لیگ انتخاب می‌شوند و تعداد تیم‌های لیگ تغییر نمی‌کند.
fun domesticCupName(country: String): String = when (country) {
    "انگلیس" -> "جام حذفی انگلیس (FA Cup)"
    "اسپانیا" -> "کوپا دل‌ری"
    "آلمان" -> "جام حذفی آلمان (DFB-Pokal)"
    "ایتالیا" -> "کوپا ایتالیا"
    "فرانسه" -> "جام حذفی فرانسه"
    "پرتغال" -> "جام حذفی پرتغال"
    "هلند" -> "جام حذفی هلند"
    "برزیل" -> "کوپا دو برزیل"
    "ترکیه" -> "جام حذفی ترکیه"
    "آرژانتین" -> "کوپا آرژانتین"
    "ایران" -> "جام حذفی ایران"
    else -> "جام حذفی $country"
}

fun simulateDomesticCup(country: String, powers: Map<Int, Int>): Team? {
    val countryLeagues = G.leagues.filter { it.country == country }.sortedBy { it.level }
    if (countryLeagues.isEmpty()) return null
    val entrants = countryLeagues.flatMap { lg ->
        val ranked = table(lg.id)
        when (country) {
            "انگلیس", "ایران", "فرانسه" -> ranked
            "اسپانیا" -> when (lg.level) { 1, 2 -> ranked; 3 -> ranked.take(8); else -> emptyList() }
            "آلمان" -> when (lg.level) { 1, 2 -> ranked; 3 -> ranked.take(4); else -> emptyList() }
            "ایتالیا" -> when (lg.level) { 1 -> ranked; 2 -> ranked.take(8); 3 -> ranked.take(4); else -> emptyList() }
            "پرتغال", "هلند", "آرژانتین" -> if (lg.level <= 2) ranked else emptyList()
            "برزیل", "ترکیه" -> if (lg.level <= 3) ranked else emptyList()
            else -> if (lg.level <= 3) ranked else emptyList()
        }
    }.distinctBy { it.id }.toMutableList()
    if (entrants.size < 2) return null
    fun seed(t: Team): Int {
        val tier = countryLeagues.firstOrNull { it.id == t.leagueId }?.level ?: 9
        val rank = table(t.leagueId).indexOfFirst { it.id == t.id }.coerceAtLeast(0)
        return tier * 100 + rank
    }
    fun power(t: Team): Double {
        val tier = countryLeagues.firstOrNull { it.id == t.leagueId }?.level ?: 3
        val rank = table(t.leagueId).indexOfFirst { it.id == t.id }.coerceAtLeast(0)
        return (powers[t.id] ?: 55).toDouble() + (4 - tier).coerceAtLeast(0) * 1.5 + (20 - rank).coerceAtLeast(0) * 0.12
    }
    var round = entrants.sortedBy { seed(it) }.toMutableList()
    var roundNo = 0
    while (round.size > 1) {
        val bracketSize = Integer.highestOneBit(round.size - 1)
        val byeCount = (2 * bracketSize - round.size).coerceAtLeast(0)
        val seeded = round.sortedBy { seed(it) }
        val winners = ArrayList<Team>()
        winners.addAll(seeded.take(byeCount))
        val playing = seeded.drop(byeCount).shuffled().toMutableList()
        while (playing.size >= 2) {
            val home = playing.removeAt(0)
            val otherLeague = if (roundNo == 0) playing.indexOfFirst { it.leagueId != home.leagueId } else -1
            val away = playing.removeAt(if (otherLeague >= 0) otherLeague else 0)
            val ph = power(home) + 1.2 // امتیاز میزبانی در بازی تک‌حذفی
            val pa = power(away)
            val chanceHome = (ph / (ph + pa)).coerceIn(0.16, 0.84)
            winners.add(if (Random.nextDouble() < chanceHome) home else away)
        }
        if (playing.isNotEmpty()) winners.add(playing.removeAt(0))
        round = winners
        roundNo++
    }
    return round.firstOrNull()
}

fun simulateAllDomesticCups(summary: MutableList<String>) {
    val powers = strengthsByTeam()
    for (country in G.leagues.map { it.country }.distinct()) {
        val winner = simulateDomesticCup(country, powers) ?: continue
        val cupName = domesticCupName(country)
        G.history.add("فصل ${G.season} - $cupName: قهرمان ${winner.name}")
        summary.add("🏆 $cupName: قهرمان ${winner.name}")
        winner.titles++
        // پاداش قهرمانی جام حذفی
        winner.budget += 2_000_000L
    }
}

fun leaguePrize(lg: League, ranked: List<Team>): Map<Int, Long> {
    val firstPrize = when (lg.level) { 1 -> 18_000_000L; 2 -> 9_000_000L; 3 -> 4_500_000L; else -> 2_500_000L }
    val total = ranked.size.coerceAtLeast(1)
    return ranked.mapIndexed { index, team ->
        val factor = (1.0 - index.toDouble() / total * 0.78).coerceAtLeast(0.22)
        team.id to (firstPrize * factor).toLong()
    }.toMap()
}

fun endSeason() {
    val sb = ArrayList<String>()
    val moves = ArrayList<Pair<Team, Int>>()
    for ((country, list) in G.leagues.groupBy { it.country }.toList().sortedBy { COUNTRIES.indexOf(it.first) }) {
        val lgs = list.sortedBy { it.level }
        val tables = lgs.map { table(it.id) }
        for ((i, lg) in lgs.withIndex()) {
            val tb = tables[i]
            if (tb.isNotEmpty()) {
                val prizes = leaguePrize(lg, tb)
                for (club in tb) club.budget += prizes[club.id] ?: 0L
                sb.add("💰 پاداش ${lg.name}: " + tb.take(3).mapIndexed { idx, club ->
                    "${idx + 1}. ${club.name} (${money(prizes[club.id] ?: 0L)})"
                }.joinToString(" | "))
                // رتبه افتخارات فقط قهرمانی سطح اول و جام حذفی را حساب می‌کند.
                if (lg.level == 1) tb[0].titles++
                val sc = tb.asSequence().flatMap { squad(it.id).asSequence() }.maxByOrNull { it.goals }
                var line = "فصل ${G.season} - ${lg.name}: قهرمان ${tb[0].name}"
                if (sc != null && sc.goals > 0) line += " | آقای گل: ${sc.name} (${sc.goals} گل)"
                G.history.add(line)
                sb.add(line)
            }
        }
        // صعود و سقوط فقط بین دسته‌های «همین کشور» (هیچ تیمی از کشوری به کشور دیگر نمی‌رود)
        for (i in 0 until lgs.size - 1) {
            val up = tables[i].filter { it.leagueId == lgs[i].id }
            val lo = tables[i + 1].filter { it.leagueId == lgs[i + 1].id }
            val k = minOf(G.promo, up.size / 2, lo.size / 2)
            if (k > 0) {
                val down = up.takeLast(k)
                val rise = lo.take(k)
                for (t in down) moves.add(Pair(t, lgs[i + 1].id))
                for (t in rise) moves.add(Pair(t, lgs[i].id))
                sb.add("⬆️ صعود به ${lgs[i].name}: " + rise.joinToString("، ") { it.name })
                sb.add("⬇️ سقوط به ${lgs[i + 1].name}: " + down.joinToString("، ") { it.name })
            }
        }
    }
    simulateAllDomesticCups(sb)
    for (t in G.teams) t.allPts += t.pts
    for ((t, id) in moves) t.leagueId = id
    for (t in G.teams) {
        t.p = 0; t.w = 0; t.d = 0; t.l = 0; t.gf = 0; t.ga = 0; t.pts = 0
    }
    for (p in G.players.toList()) {
        p.goals = 0
        p.age++
        val ch = when {
            p.age < 24 -> Random.nextInt(0, 4)
            p.age > 31 -> -Random.nextInt(0, 4)
            else -> Random.nextInt(-1, 2)
        }
        p.rating = (p.rating + ch).coerceIn(35, 95)
        p.value = worth(p.rating, p.age)
        if (p.age >= 43) {
            val t = G.teamOrNull(p.teamId)
            G.players.remove(p)
            if (t != null) {
                val y = genPlayer(t.id, t.country, p.pos, (p.rating - 3).coerceIn(55, 82))
                y.age = Random.nextInt(17, 19)
                // بازیکن جایگزین می‌تواند استعداد بالایی داشته باشد؛ امتیاز ۸۲ نادر است.
                if (Random.nextInt(100) < 12) y.rating = Random.nextInt(78, 83)
                y.value = worth(y.rating, y.age)
                G.players.add(y)
                addNews("🌟 نسل جدید: ${y.name} (${y.age} سال، اورال ${y.rating}) جایگزین ${p.name} شد")
            }
        }
    }
    for (ap in G.academy.toList()) {
        ap.age++
        ap.rating = (ap.rating + Random.nextInt(0, 4)).coerceAtMost(ap.potential)
        if (ap.age >= 18) {
            val t = G.teamOrNull(ap.teamId)
            G.academy.remove(ap)
            if (t != null) {
                val rating = if (Random.nextInt(100) < 8) Random.nextInt(80, 84) else ap.rating.coerceAtLeast(55)
                val promoted = Player(G.nid(), ap.name, ap.pos, rating, 18, t.id, worth(rating, 18), country = ap.country)
                G.players.add(promoted)
                addNews("🎓 فارغ‌التحصیل آکادمی ${t.name}: ${promoted.name} با اورال ${promoted.rating}")
            }
        }
    }
    val acCount = HashMap<Int, Int>()
    for (a in G.academy) acCount[a.teamId] = (acCount[a.teamId] ?: 0) + 1
    for (t in G.teams) repeat((5 - (acCount[t.id] ?: 0)).coerceAtLeast(0)) { if ((acCount[t.id] ?: 0) < 15) G.academy.add(genAcademyPlayer(t)) }
    G.season++
    G.week = 0
    G.report.clear()
    G.live = null
    G.offers.clear()
    aiTransfers()
    genOffers(3)
    G.msg = sb.joinToString("\n")
}

// ======================= توابع ادمین =======================

fun removeTeam(t: Team) {
    G.players.removeAll { it.teamId == t.id }
    G.academy.removeAll { it.teamId == t.id }
    G.teams.remove(t)
}

fun adjustTeams(lg: League) {
    var n = G.teams.count { it.leagueId == lg.id }
    while (n < G.tpl) {
        newTeam(lg)
        n++
    }
    while (n > G.tpl) {
        val v = G.teams.filter { it.leagueId == lg.id && it.id != G.userTeam }.minByOrNull { strengthOf(it) } ?: break
        removeTeam(v)
        n--
    }
}

fun adjustPlayers(t: Team) {
    val plan = posPlan(G.ppt)
    while (squad(t.id).size < G.ppt) {
        val cur = squad(t.id).groupBy { it.pos }
        val pos = POS.maxByOrNull { p -> plan.count { it == p } - (cur[p]?.size ?: 0) } ?: "MF"
        G.players.add(genPlayer(t.id, t.country, pos, squadAvg(t)))
    }
    while (squad(t.id).size > G.ppt) {
        val sq = squad(t.id)
        val gk = sq.count { it.pos == "GK" }
        val w = sq.filter { it.pos != "GK" || gk > 2 }.minByOrNull { it.rating } ?: break
        G.players.remove(w)
    }
}

fun applyAdmin() {
    for (lg in G.leagues.toList()) adjustTeams(lg)
    for (t in G.teams.toList()) adjustPlayers(t)
    resetSeason()
}

fun addLeague(c: String = "ایران") {
    val lv = (G.leagues.filter { it.country == c }.maxOfOrNull { it.level } ?: 0) + 1
    val lg = League(G.nid(), "لیگ سطح $lv $c", lv, c)
    G.leagues.add(lg)
    repeat(G.tpl) { newTeam(lg) }
    resetSeason()
}

fun deleteLeague(lg: League): Boolean {
    if (G.leagues.size <= 1) return false
    if (G.teams.any { it.leagueId == lg.id && it.id == G.userTeam }) return false
    for (t in G.teams.filter { it.leagueId == lg.id }) removeTeam(t)
    G.leagues.remove(lg)
    for ((i, l) in G.leagues.filter { it.country == lg.country }.sortedBy { it.level }.withIndex()) l.level = i + 1
    resetSeason()
    return true
}

fun copyLogo(uri: Uri, id: Int): String? = try {
    val f = File(G.ctx.filesDir, "logo_${id}_${System.currentTimeMillis()}.img")
    G.ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    if (f.exists() && f.length() > 0) f.absolutePath else null
} catch (e: Exception) {
    null
}

val bmpCache = HashMap<String, ImageBitmap?>()

fun loadBmp(path: String): ImageBitmap? = try {
    val o = BitmapFactory.Options()
    o.inJustDecodeBounds = true
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (o.outWidth / s > 256 || o.outHeight / s > 256) s *= 2
    val o2 = BitmapFactory.Options()
    o2.inSampleSize = s
    BitmapFactory.decodeFile(path, o2)?.asImageBitmap()
} catch (e: Exception) {
    null
}

fun money(v: Long): String =
    if (v >= 1_000_000L) String.format("%.1f میلیون", v / 1_000_000.0) else "${v / 1000} هزار"

fun posColor(p: String): Color = when (p) {
    "GK" -> Color(0xFFF9A825)
    "DF" -> Color(0xFF1565C0)
    "MF" -> Color(0xFF2E7D32)
    else -> Color(0xFFC62828)
}

// ======================= اجزای رابط =======================

@Composable
fun Logo(t: Team, sz: Dp = 32.dp) {
    val path = t.logo
    val bmp = if (path != null) remember(path) { bmpCache.getOrPut(path) { loadBmp(path) } } else null
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(sz))
    } else {
        val shape = when (t.id % 3) {
            0 -> CircleShape
            1 -> RoundedCornerShape(8.dp)
            else -> RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
        }
        Box(
            Modifier.size(sz).clip(shape).background(Color(t.c1)).border(2.dp, Color(t.c2), shape),
            contentAlignment = Alignment.Center
        ) {
            Text(t.name.take(1), color = Color(t.c2), fontWeight = FontWeight.Bold, fontSize = (sz.value * 0.5f).sp)
        }
    }
}

@Composable
fun Shirt(t: Team, sz: Dp = 56.dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.3f, 0f)
            lineTo(w * 0.7f, 0f)
            lineTo(w, h * 0.25f)
            lineTo(w * 0.85f, h * 0.4f)
            lineTo(w * 0.75f, h * 0.32f)
            lineTo(w * 0.75f, h)
            lineTo(w * 0.25f, h)
            lineTo(w * 0.25f, h * 0.32f)
            lineTo(w * 0.15f, h * 0.4f)
            lineTo(0f, h * 0.25f)
            close()
        }
        drawPath(path, Color(t.c1))
        clipPath(path) {
            when (t.style) {
                1 -> {
                    for (i in 0 until 5) {
                        if (i % 2 == 1) drawRect(Color(t.c2), Offset(w * i * 0.2f, 0f), Size(w * 0.2f, h))
                    }
                }
                2 -> {
                    drawRect(Color(t.c2), Offset(w * 0.5f, 0f), Size(w * 0.5f, h))
                }
                3 -> {
                    drawRect(Color(t.c2), Offset(0f, h * 0.45f), Size(w, h * 0.18f))
                }
                else -> {
                }
            }
        }
        drawPath(path, Color(0x55000000), style = Stroke(width = 3f))
    }
}

@Composable
fun Page(title: String, scroll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF0B0B0B))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (G.screen != "home" && G.screen != "pick") {
                Text(if (I18n.lang == "en") "←" else "→", color = Color(0xFFFFC107), fontSize = 26.sp, modifier = Modifier.clickable { G.back() }.padding(end = 12.dp))
            }
            val logoPainter = painterResource(R.drawable.app_logo)
            Image(logoPainter, null, Modifier.size(34.dp).clip(CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color(0xFFFFC107), fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        val m = if (scroll) Modifier.fillMaxSize().verticalScroll(rememberScrollState()) else Modifier.fillMaxSize()
        Column(m.padding(10.dp), content = content)
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(10.dp), content = content)
    }
}

@Composable
fun B(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier) { Text(text) }
}

@Composable
fun Chips(opts: List<String>, sel: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for (o in opts) {
            FilterChip(
                selected = o == sel,
                onClick = { onSel(o) },
                label = { Text(o) },
                modifier = Modifier.padding(end = 6.dp)
            )
        }
    }
}

@Composable
fun NumField(label: String, v: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = { s -> onChange(s.filter { c -> c.isDigit() }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier
    )
}

@Composable
fun TextF(label: String, v: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = v,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier
    )
}

@Composable
fun Prompt(title: String, init: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var s by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { TextF("", s, { s = it }, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onOk(s) }) { Text("تأیید") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("لغو") } }
    )
}

@Composable
fun ColorRow(sel: Long, onPick: (Long) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for (c in PAL) {
            Box(
                Modifier.padding(end = 6.dp).size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == sel) 3.dp else 1.dp, if (c == sel) Color.Black else Color.Gray, CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun PlayerRow(p: Player, extra: @Composable RowScope.() -> Unit = {}) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(p.pos, Modifier.width(34.dp), color = posColor(p.pos), fontWeight = FontWeight.Bold)
            Column(Modifier.weight(1f)) {
                Text(p.name)
                Text("سن ${p.age} | گل ${p.goals} | ارزش ${money(p.value)}", fontSize = 12.sp, color = Color.Gray)
            }
            Text("${p.rating}", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 6.dp))
            extra()
        }
        HorizontalDivider()
    }
}

@Composable
fun Cell(text: String, w: Dp, bold: Boolean = false) {
    Text(
        text, Modifier.width(w), fontSize = 12.sp, textAlign = TextAlign.Center,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
    )
}

// ======================= صفحه‌ها =======================

@Composable
fun Pick() {
    val rv = G.rev
    var cty by remember { mutableStateOf("ایران") }
    var startDifficulty by remember { mutableStateOf("متوسط") }
    val countries = COUNTRIES.filter { c -> G.leagues.any { it.country == c } }
    val pickRows = remember(rv, cty) {
        val powers = strengthsByTeam()
        G.leagues.filter { it.country == cty }.associate { lg ->
            lg.id to G.teams.filter { it.leagueId == lg.id }.map { it to (powers[it.id] ?: 0) }.sortedByDescending { it.second }
        }
    }
    Page("تیم خود را انتخاب کنید", scroll = false) {
        Chips(listOf("فارسی", "English"), if (I18n.lang == "en") "English" else "فارسی") { l ->
            I18n.changeLang(if (l == "English") "en" else "fa")
            G.ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString("lang", I18n.lang).apply()
        }
        Chips(countries, cty) { cty = it }
        Text("درجه سختی و بودجه شروع", fontWeight = FontWeight.Bold)
        Chips(DIFFS, startDifficulty) { startDifficulty = it }
        Text(when (startDifficulty) {
            "آسان" -> "بودجه شروع باشگاه انتخابی: ۱۵۰ میلیون"
            "متوسط" -> "بودجه شروع باشگاه انتخابی: ۸۵ میلیون"
            else -> "بودجه شروع باشگاه انتخابی: ۴۵ میلیون | فقط دسته دوم و سوم"
        }, color = Color.Gray)
        Button(onClick = { G.go("createTeam") }, modifier = Modifier.fillMaxWidth()) { Text("➕ ساخت تیم اختصاصی؛ شروع از دسته دوم") }
        Button(onClick = { G.go("worldRank") }, modifier = Modifier.fillMaxWidth()) { Text("🌍 رتبه‌بندی جهانی باشگاه‌ها") }
        Text("🏆 لیگ کشور $cty", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(6.dp))
        LazyColumn(Modifier.weight(1f)) {
            for (lg in G.leagues.filter { it.country == cty && (startDifficulty != "سخت" || it.level in 2..3) }.sortedBy { it.level }) {
                item {
                    Text(lg.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp))
                }
                val rows = pickRows[lg.id].orEmpty()
                items(rows, key = { it.first.id }) { (t, st) ->
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                G.userTeam = t.id
                                G.diff = DIFFS.indexOf(startDifficulty).coerceIn(0, 2)
                                // بودجه شروع بر اساس سختی انتخاب‌شده تعیین می‌شود.
                                if (G.week == 0 && G.season == 1) t.budget = when (G.diff) {
                                    0 -> 150_000_000L
                                    1 -> 85_000_000L
                                    else -> 45_000_000L
                                }
                                G.academyCoachLevel = 0
                                G.lineup = ArrayList(autoLineup(t.id, G.formation).map { p -> p.id })
                                G.stack.clear()
                                G.screen = "home"
                                G.touch()
                            }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Logo(t, 36.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(t.name, Modifier.weight(1f))
                            Text("قدرت $st")
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun CreateTeam() {
    var name by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("ایران") }
    var difficulty by remember { mutableStateOf("سخت") }
    var kit by remember { mutableIntStateOf(0) }
    Page("ساخت تیم اختصاصی") {
        Text("نام تیم", fontWeight = FontWeight.Bold)
        OutlinedTextField(value = name, onValueChange = { name = it.take(28) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("مثلاً ستاره تهران") }, singleLine = true)
        Text("کشور", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Chips(COUNTRIES, country) { country = it }
        Text("سطح شروع", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Chips(listOf("آسان", "متوسط", "سخت"), difficulty) { difficulty = it }
        Text(when(difficulty) {
            "آسان" -> "قدرت شروع حدود ۶۰ | بودجه شروع: ۱۲۰ میلیون"
            "متوسط" -> "قدرت شروع حدود ۴۸ | بودجه شروع: ۶۵ میلیون"
            else -> "قدرت شروع حدود ۳۷ | بودجه شروع: ۲۲ میلیون | شروع از دسته سوم"
        }, color = Color.Gray)
        Text("در سختی دشوار از دسته سوم (در صورت نبود، دسته دوم) شروع می‌کنید؛ تعداد تیم‌های لیگ افزایش نمی‌یابد.")
        Button(onClick = {
            val n = name.trim()
            if (n.isEmpty() || G.teams.any { it.name.equals(n, true) }) {
                G.msg = if (n.isEmpty()) "نام تیم را وارد کنید" else "این نام قبلاً استفاده شده است"
            } else {
                val startLevel = if (difficulty == "سخت" && G.leagues.any { it.country == country && it.level == 3 }) 3 else 2
                val league = G.leagues.firstOrNull { it.country == country && it.level == startLevel } ?: G.leagues.first { it.level == 2 }
                val powers = strengthsByTeam()
                val weakest = G.teams.asSequence().filter { it.leagueId == league.id }
                    .minByOrNull { powers[it.id] ?: 0 }
                val base = when(difficulty) { "آسان" -> 60; "متوسط" -> 48; else -> 37 }
                val startingBudget = when (difficulty) {
                    "آسان" -> 120_000_000L
                    "متوسط" -> 65_000_000L
                    else -> 22_000_000L
                }
                G.diff = when (difficulty) { "آسان" -> 0; "متوسط" -> 1; else -> 2 }
                val team = Team(G.nid(), n, league.country, league.id, PAL[kit % PAL.size], PAL[(kit + 3) % PAL.size], kit % 4, null, startingBudget)
                if (weakest != null) {
                    val oldId = weakest.id
                    G.players.removeAll { it.teamId == oldId }
                    G.academy.removeAll { it.teamId == oldId }
                    G.teams.remove(weakest)
                }
                G.teams.add(team)
                for (pos in posPlan(G.ppt)) G.players.add(genPlayer(team.id, team.country, pos, base + Random.nextInt(-3, 4)))
                repeat(5) { G.academy.add(genAcademyPlayer(team)) }
                G.academyCoachLevel = 0
                G.userTeam = team.id
                G.lineup = ArrayList(autoLineup(team.id, G.formation).map { it.id })
                G.msg = ""
                G.stack.clear(); G.screen = "home"; G.touch()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ساخت تیم و شروع بازی") }
        if (G.msg.isNotBlank()) Text(G.msg, color = Color.Red)
    }
}

@Composable
fun WorldRank() {
    var mode by remember { mutableStateOf("قدرت تیم") }
    // رتبه‌بندی فقط هنگام تغییر داده‌های بازی یا فیلتر دوباره محاسبه می‌شود.
    val powers = remember(G.rev) { strengthsByTeam() }
    val ranked = remember(G.rev, mode) {
        if (mode == "قدرت تیم") {
            G.teams.sortedWith(compareByDescending<Team> { powers[it.id] ?: 0 }.thenBy { it.name })
        } else {
            G.teams.sortedWith(compareByDescending<Team> { it.titles }
                .thenByDescending { powers[it.id] ?: 0 }.thenBy { it.name })
        }
    }
    Page("رتبه‌بندی جهانی", scroll = false) {
        Chips(listOf("قدرت تیم", "افتخارات"), mode) { mode = it }
        Text(if (mode == "قدرت تیم") "بر اساس قدرت و اورال ترکیب" else "افتخارات لیگ برتر و جام حذفی؛ سپس قدرت تیم", color = Color.Gray)
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(ranked, key = { _, team -> team.id }) { index, team ->
                val rank = index + 1
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("$rank", modifier = Modifier.width(32.dp), fontWeight = FontWeight.Bold)
                    Logo(team, 34.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(team.name, fontWeight = FontWeight.Medium)
                        Text("${team.country} • ${G.leagues.firstOrNull { it.id == team.leagueId }?.name ?: ""}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(if (mode == "قدرت تیم") "${powers[team.id] ?: 0} OVR" else "🏆 ${team.titles}")
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun Home() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val lg = G.leagues.firstOrNull { it.id == t.leagueId }
    Page("مربی برتر") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 56.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${lg?.name ?: ""} | فصل ${G.season} - هفته ${G.week}")
                    Text("بودجه: ${money(t.budget)}")
                }
                Shirt(t, 56.dp)
            }
        }
        Panel {
            Text("مرکز مدیریت باشگاه", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("از نوار پایین برای ورود مستقیم به خانه، بازیکنان، بازار نقل‌وانتقالات، آکادمی و جدول لیگ استفاده کن.")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp)) {
                Text("قدرت تیم", fontWeight = FontWeight.SemiBold)
                Text("${strengthOf(t)}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp)) {
                Text("بازیکنان", fontWeight = FontWeight.SemiBold)
                Text("${squad(t.id).size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        B("⚽ رفتن به مسابقه", Modifier.fillMaxWidth()) { G.go("play") }
        B("📋 تاکتیک و ترکیب", Modifier.fillMaxWidth()) { G.go("tactics") }
        B("🌍 جدول لیگ", Modifier.fillMaxWidth()) { G.go("table") }
        B("🏆 رتبه‌بندی جهانی باشگاه‌ها", Modifier.fillMaxWidth()) { G.go("worldRank") }
        B("🏆 جام‌های حذفی کشورها", Modifier.fillMaxWidth()) { G.go("cups") }
        B("⚙️ تنظیمات باشگاه", Modifier.fillMaxWidth()) { G.go("settings") }
    }
}

@Composable
fun Cups() {
    val rv = G.rev
    val countries = G.leagues.map { it.country }.distinct().sortedBy { COUNTRIES.indexOf(it) }
    Page("جام‌های حذفی کشورها") {
        Panel {
            Text("🏆 رقابت‌های حذفی داخلی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("جام هر کشور در پایان فصل شبیه‌سازی می‌شود؛ تیم‌های دسته‌های مختلف طبق سهمیه و سیدبندی وارد جدول حذفی می‌شوند. تیم‌های قوی‌تر در دورهای آغازین امتیاز سید و احتمال استراحت بیشتری دارند.")
        }
        for (country in countries) {
            val cupName = domesticCupName(country)
            val champion = G.history.lastOrNull { it.contains(cupName) }
            val levels = G.leagues.filter { it.country == country }.size
            Panel {
                Text(cupName, fontWeight = FontWeight.Bold)
                Text("کشور: $country • لیگ‌های شبیه‌سازی‌شده: $levels")
                Text(champion ?: "هنوز قهرمانی ثبت نشده؛ نتیجه در پایان فصل اعلام می‌شود.", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun Play() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val lg = G.leagues.firstOrNull { it.id == t.leagueId }
    val tw = totalWeeks()
    val tb = table(t.leagueId)
    Page("بازی") {
        Panel {
            Text("${lg?.name ?: ""} - فصل ${G.season}", fontWeight = FontWeight.Bold)
            Text("هفته ${G.week} از $tw")
            Text("رتبه شما: ${tb.indexOfFirst { it.id == t.id } + 1} از ${tb.size} | امتیاز ${t.pts}")
        }
        if (G.week < tw) {
            val fx = fixturesFor(t.leagueId)
            val m = if (G.week < fx.size) fx[G.week].firstOrNull { it.first == t.id || it.second == t.id } else null
            Panel {
                Text("بازی بعدی", fontWeight = FontWeight.Bold)
                if (m != null) {
                    val h = G.team(m.first)
                    val a = G.team(m.second)
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Logo(h, 44.dp)
                            Text(h.name, fontSize = 13.sp)
                        }
                        Text("VS", fontWeight = FontWeight.Bold)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Logo(a, 44.dp)
                            Text(a.name, fontSize = 13.sp)
                        }
                    }
                } else {
                    Text("این هفته استراحت دارید")
                }
            }
            Button(
                onClick = {
                    playWeek(true)
                    G.touch()
                    if (G.pendingPenaltyMatch != null) G.go("penalty") else if (G.live != null) G.go("live")
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
            ) { Text("▶️ بازی زنده - هفته ${G.week + 1}") }
            B("⚡ شبیه‌سازی سریع هفته ${G.week + 1}", Modifier.fillMaxWidth()) {
                playWeek()
                G.touch()
                if (G.pendingPenaltyMatch != null) G.go("penalty")
            }
            B("شبیه‌سازی تا پایان فصل", Modifier.fillMaxWidth()) {
                var lastUserResult = ""
                while (G.week < totalWeeks() && G.pendingPenaltyMatch == null) {
                    playWeek()
                    if (G.report.isNotEmpty()) lastUserResult = G.report.firstOrNull { it.contains(" - ") } ?: G.report.first()
                }
                if (G.pendingPenaltyMatch != null) {
                    G.msg = "⚽ برای تیم شما پنالتی اعلام شده؛ ابتدا ضربه را بزنید."
                    G.go("penalty")
                } else {
                    G.msg = if (lastUserResult.isNotBlank()) "🏁 شبیه‌سازی فصل تمام شد. آخرین نتیجه تیم شما: $lastUserResult" else "فصل شبیه‌سازی شد؛ تیم شما مسابقه‌ای نداشت."
                }
                G.touch()
            }
        } else {
            Panel {
                Text("فصل ${G.season} تمام شد!", fontWeight = FontWeight.Bold)
                if (tb.isNotEmpty()) Text("قهرمان لیگ شما: ${tb[0].name}")
            }
            B("پایان فصل و شروع فصل بعد", Modifier.fillMaxWidth()) {
                endSeason()
                G.touch()
            }
        }
        if (G.msg.isNotEmpty()) {
            Panel {
                Text("🏁 اعلام نتیجه", fontWeight = FontWeight.Bold)
                Text(G.msg, fontWeight = FontWeight.SemiBold)
            }
        }
        if (G.report.isNotEmpty()) {
            Panel {
                Text("گزارش آخرین بازی", fontWeight = FontWeight.Bold)
                for (l in G.report) Text(l)
            }
        }
    }
}

@Composable
fun Academy() {
    val rv = G.rev
    val team = G.team(G.userTeam)
    val youth = G.academy.filter { it.teamId == team.id }.sortedWith(compareBy({ it.age }, { -it.potential }))
    var info by remember { mutableStateOf("") }
    val coachCosts = listOf(0L, 8_000_000L, 16_000_000L, 28_000_000L, 45_000_000L, 70_000_000L)
    fun youthPrice(p: AcademyPlayer): Long {
        val base = ((p.rating - 35).coerceAtLeast(1).toLong().let { it * it } * 9_000L)
        val ageFactor = if (p.age <= 15) 90L else 100L
        return base * (100L + (p.potential - p.rating).coerceAtLeast(0)) * ageFactor / 10_000L
    }
    Page("آکادمی جوانان", scroll = false) {
        Panel {
            Text("🎓 آکادمی ${team.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("ظرفیت آکادمی: ${youth.size} از ۱۵ بازیکن")
            Text("بازیکنان ۱۴ تا ۱۸ سال؛ در ۱۸ سالگی به تیم اصلی منتقل می‌شوند.")
            LinearProgressIndicator(progress = { youth.size / 15f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        Panel {
            Text("👨‍🏫 مربی آکادمی", fontWeight = FontWeight.Bold)
            Text(if (G.academyCoachLevel == 0) "هنوز مربی استخدام نکرده‌اید؛ برای آموزش بازیکنان مربی لازم است." else "سطح مربی فعلی: ${G.academyCoachLevel} از ۵")
            if (G.academyCoachLevel < 5) {
                val next = G.academyCoachLevel + 1
                B("استخدام / ارتقای مربی به سطح $next • ${money(coachCosts[next])}", Modifier.fillMaxWidth(), team.budget >= coachCosts[next]) {
                    if (team.budget >= coachCosts[next]) {
                        team.budget -= coachCosts[next]
                        G.academyCoachLevel = next
                        info = "مربی آکادمی به سطح $next ارتقا یافت."
                        G.touch()
                    } else info = "بودجه کافی نیست."
                }
            } else Text("⭐ مربی شما در بالاترین سطح قرار دارد.", color = Color(0xFF2E7D32))
            if (G.academyCoachLevel > 0) {
                B("🎯 آموزش بازیکنان آکادمی", Modifier.fillMaxWidth()) {
                    var trained = 0
                    for (p in youth) {
                        if (p.rating < p.potential) {
                            val gain = Random.nextInt(1, G.academyCoachLevel + 2).coerceAtMost(p.potential - p.rating)
                            p.rating += gain
                            trained++
                        }
                    }
                    info = if (trained > 0) "آموزش ${trained} بازیکن با مربی سطح ${G.academyCoachLevel} انجام شد." else "همه بازیکنان به سقف پتانسیل خود رسیده‌اند."
                    G.touch()
                }
                Text("هرچه سطح مربی بالاتر باشد، رشد تمرینی بیشتری دریافت می‌کنید.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        Panel {
            Text("➕ جذب استعداد", fontWeight = FontWeight.Bold)
            Text("هزینه جذب هر بازیکن: ۲ میلیون")
            B("جذب بازیکن جوان", Modifier.fillMaxWidth(), youth.size < 15 && team.budget >= 2_000_000L) {
                if (youth.size >= 15) info = "ظرفیت آکادمی تکمیل است."
                else if (team.budget < 2_000_000L) info = "بودجه کافی نیست."
                else {
                    team.budget -= 2_000_000L
                    G.academy.add(genAcademyPlayer(team))
                    info = "استعداد جدید به آکادمی اضافه شد."
                    G.touch()
                }
            }
        }
        if (info.isNotBlank()) Text(info, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(6.dp))
        LazyColumn(Modifier.weight(1f)) {
            if (youth.isEmpty()) item { Text("در حال حاضر بازیکنی در آکادمی نیست.") }
            items(youth, key = { it.id }) { p ->
                val price = youthPrice(p)
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("${p.age} سال | ${p.country} | ${p.pos}")
                            Text("اورال ${p.rating} • پتانسیل ${p.potential}")
                        }
                        Text(if (p.potential >= 85) "⭐ استعداد ویژه" else "🎓 جوان", color = Color(0xFF2E7D32))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        B("فروش • ${money(price * 8 / 10)}", Modifier.weight(1f)) {
                            val sale = price * 8 / 10
                            val buyer = G.teams.filter { it.id != team.id && it.budget >= sale && G.academy.count { a -> a.teamId == it.id } < 15 }.maxByOrNull { it.budget }
                            if (buyer == null) info = "باشگاه خریدار دارای بودجه کافی پیدا نشد."
                            else {
                                buyer.budget -= sale
                                team.budget += sale
                                p.teamId = buyer.id
                                info = "${p.name} به ${buyer.name} فروخته شد."
                                G.touch()
                            }
                        }
                    }
                }
            }
            val otherYouth = G.academy.filter { it.teamId != team.id }.sortedByDescending { it.potential }.take(60)
            items(otherYouth, key = { "market-${it.id}" }) { p ->
                val price = youthPrice(p) * 12 / 10
                Panel {
                    Text("🛒 ${p.name}", fontWeight = FontWeight.Bold)
                    Text("${p.age} سال | ${p.pos} | اورال ${p.rating} | پتانسیل ${p.potential}")
                    B("خرید از ${G.teamOrNull(p.teamId)?.name ?: "باشگاه دیگر"} • ${money(price)}", Modifier.fillMaxWidth(), youth.size < 15 && team.budget >= price) {
                        val seller = G.teamOrNull(p.teamId)
                        if (youth.size >= 15) info = "ظرفیت آکادمی شما پر است."
                        else if (team.budget < price) info = "بودجه کافی نیست."
                        else {
                            team.budget -= price
                            if (seller != null) seller.budget += price
                            p.teamId = team.id
                            info = "${p.name} به آکادمی شما پیوست."
                            G.touch()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Players() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var ageFilter by remember { mutableStateOf("همه سنین") }
    var ratingFilter by remember { mutableStateOf("همه قدرت‌ها") }
    var nationality by remember { mutableStateOf("همه ملیت‌ها") }
    var position by remember { mutableStateOf("همه") }
    val all = squad(t.id)
    val sq = all.filter { p ->
        (ageFilter == "همه سنین" || when (ageFilter) { "زیر ۱۸" -> p.age < 18; "۱۸ تا ۲۳" -> p.age in 18..23; "۲۴ تا ۳۰" -> p.age in 24..30; "۳۱ به بالا" -> p.age >= 31; else -> true }) &&
        (ratingFilter == "همه قدرت‌ها" || when (ratingFilter) { "زیر ۶۰" -> p.rating < 60; "۶۰ تا ۶۹" -> p.rating in 60..69; "۷۰ تا ۷۹" -> p.rating in 70..79; "۸۰ به بالا" -> p.rating >= 80; else -> true }) &&
        (nationality == "همه ملیت‌ها" || p.country == nationality) &&
        (position == "همه" || p.pos == position)
    }.sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))
    Page("ترکیب و بازیکنان", scroll = false) {
        Text("${t.name} - ${all.size} بازیکن | نمایش ${sq.size}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
        Text("فیلتر پست", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه") + POS, position) { position = it }
        Text("فیلتر سن", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه سنین", "زیر ۱۸", "۱۸ تا ۲۳", "۲۴ تا ۳۰", "۳۱ به بالا"), ageFilter) { ageFilter = it }
        Text("فیلتر اورال", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه قدرت‌ها", "زیر ۶۰", "۶۰ تا ۶۹", "۷۰ تا ۷۹", "۸۰ به بالا"), ratingFilter) { ratingFilter = it }
        Text("ملیت", fontWeight = FontWeight.SemiBold)
        Chips(listOf("همه ملیت‌ها") + COUNTRIES, nationality) { nationality = it }
        LazyColumn(Modifier.weight(1f)) { items(sq, key = { it.id }) { p -> PlayerRow(p) } }
    }
}

// مختصات جایگاه‌ها روی زمین عمودی: first = موقعیت عرضی، second = عمق (بالا: حمله، پایین: دروازه)
private fun formationSlots(formation: String): List<Pair<Float, Float>> {
    val parts = formation.split("-").mapNotNull { it.toIntOrNull() }
    val defenders = parts.getOrElse(0) { 4 }
    val midfielders = parts.getOrElse(1) { 4 }
    val forwards = parts.getOrElse(2) { 2 }
    val result = mutableListOf(0.5f to 0.90f)
    fun line(count: Int, y: Float) {
        for (i in 0 until count) {
            val x = if (count == 1) 0.5f else 0.11f + (0.78f * i / (count - 1))
            result.add(x to y)
        }
    }
    line(defenders, 0.71f)
    line(midfielders, 0.46f)
    line(forwards, 0.19f)
    return result.take(11)
}

@Composable
fun Tactics() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id).sortedByDescending { it.rating }
    val current = G.lineup.mapNotNull { id -> sq.firstOrNull { it.id == id } }.take(11).toMutableList()
    val starters = (current + autoLineup(t.id, G.formation).filter { p -> current.none { it.id == p.id } })
        .take(11)
    val starterIds = starters.map { it.id }
    val bench = sq.filter { it.id !in starterIds }
    var selectedSlot by remember(t.id) { mutableIntStateOf(0) }
    val slots = formationSlots(G.formation)

    Page("ترکیب و تاکتیک") {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("بازیکن انتخاب‌شده: ${selectedSlot + 1}/11", color = Color.Gray, fontSize = 12.sp)
            }
            B("ترکیب خودکار") {
                G.lineup = ArrayList(autoLineup(t.id, G.formation).map { it.id })
                selectedSlot = 0
                G.touch()
            }
        }
        Text("آرایش تیم", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Chips(FORMS, G.formation) { f ->
            G.formation = f
            G.lineup = ArrayList(autoLineup(t.id, f).map { it.id })
            selectedSlot = 0
            G.touch()
        }

        // زمین عمودی: دروازه‌بان پایین، مهاجم‌ها بالا؛ مستقل از RTL
        val gkTeam = remember { Team(-1, "", "", 0, 0xFFF9A825, 0xFF212121, 0, null, 0L) }
        val maxLine = (FORMS.firstOrNull { it == G.formation } ?: "4-4-2").split("-").mapNotNull { it.toIntOrNull() }.maxOrNull() ?: 4
        val nodeW = if (maxLine >= 5) 62.dp else 78.dp
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            BoxWithConstraints(
                Modifier.fillMaxWidth().height(480.dp).clip(RoundedCornerShape(14.dp))
                    .border(2.dp, Color(0xFFB8D9B7), RoundedCornerShape(14.dp))
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val stripes = 10
                    for (i in 0 until stripes) {
                        drawRect(
                            if (i % 2 == 0) Color(0xFF1B7A43) else Color(0xFF17703C),
                            Offset(0f, h * i / stripes), Size(w, h / stripes + 1f)
                        )
                    }
                    val lc = Color(0xCCFFFFFF)
                    val sw = 2.dp.toPx()
                    val m = 8.dp.toPx()
                    drawRect(lc, Offset(m, m), Size(w - 2 * m, h - 2 * m), style = Stroke(sw))
                    drawLine(lc, Offset(m, h / 2f), Offset(w - m, h / 2f), sw)
                    drawCircle(lc, radius = w * 0.14f, center = Offset(w / 2f, h / 2f), style = Stroke(sw))
                    drawCircle(lc, radius = 3.dp.toPx(), center = Offset(w / 2f, h / 2f))
                    val bw = w * 0.58f
                    val bh = h * 0.15f
                    val gw = w * 0.28f
                    val gh = h * 0.055f
                    drawRect(lc, Offset((w - bw) / 2f, m), Size(bw, bh), style = Stroke(sw))
                    drawRect(lc, Offset((w - gw) / 2f, m), Size(gw, gh), style = Stroke(sw))
                    drawRect(lc, Offset((w - bw) / 2f, h - m - bh), Size(bw, bh), style = Stroke(sw))
                    drawRect(lc, Offset((w - gw) / 2f, h - m - gh), Size(gw, gh), style = Stroke(sw))
                    drawCircle(lc, radius = 2.dp.toPx(), center = Offset(w / 2f, m + h * 0.105f))
                    drawCircle(lc, radius = 2.dp.toPx(), center = Offset(w / 2f, h - m - h * 0.105f))
                }
                slots.forEachIndexed { index, point ->
                    val player = starters.getOrNull(index) ?: return@forEachIndexed
                    val sel = index == selectedSlot
                    val shown = if (nodeW < 70.dp) player.name.substringAfterLast(' ') else player.name
                    Column(
                        Modifier.absoluteOffset(x = maxWidth * point.first - nodeW / 2, y = maxHeight * point.second - 36.dp)
                            .width(nodeW).clip(RoundedCornerShape(8.dp))
                            .clickable { selectedSlot = index },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                            if (sel) Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0x99FFC107)))
                            Shirt(if (player.pos == "GK") gkTeam else t, 38.dp)
                            Text(
                                player.pos, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopStart).clip(RoundedCornerShape(4.dp))
                                    .background(posColor(player.pos)).padding(horizontal = 3.dp)
                            )
                            Text(
                                "${player.rating}", fontSize = 9.sp, color = Color(0xFFFFE082), fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopEnd).clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xE60B1F17)).padding(horizontal = 3.dp)
                            )
                        }
                        Text(
                            shown, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center,
                            color = if (sel) Color.Black else Color.White, fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                                .background(if (sel) Color(0xFFFFC107) else Color(0xCC0B1F17))
                                .border(1.dp, if (sel) Color.White else Color(0xFF4ADE80), RoundedCornerShape(6.dp))
                                .padding(horizontal = 3.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
        Text("برای تغییر ترکیب، یک جایگاه روی زمین و سپس بازیکن ذخیره را لمس کن.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 5.dp, bottom = 3.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ذخیره‌ها (${bench.size})", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("سبک بازی", fontSize = 12.sp)
        }
        Chips(STY, STY[G.style]) { s -> G.style = STY.indexOf(s); G.touch() }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            bench.forEach { p ->
                Column(
                    Modifier.width(94.dp).clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF202A32)).border(1.dp, Color(0xFF64748B), RoundedCornerShape(8.dp))
                        .clickable {
                            val ids = starters.map { it.id }.toMutableList()
                            val existing = ids.indexOf(p.id)
                            if (existing >= 0) {
                                val old = ids[selectedSlot]
                                ids[selectedSlot] = p.id
                                ids[existing] = old
                            } else if (selectedSlot in ids.indices) {
                                ids[selectedSlot] = p.id
                            }
                            G.lineup = ArrayList(ids.distinct().let { distinct ->
                                if (distinct.size < 11) distinct + autoLineup(t.id, G.formation).map { it.id }.filter { it !in distinct }.take(11 - distinct.size) else distinct
                            }.take(11))
                            selectedSlot = (selectedSlot + 1).coerceAtMost(10)
                            G.touch()
                        }.padding(7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Shirt(if (p.pos == "GK") gkTeam else t, 34.dp)
                    Text(p.name, color = Color.White, fontSize = 11.sp, maxLines = 1)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.pos, color = posColor(p.pos), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Spacer(Modifier.width(6.dp))
                        Text("${p.rating}", color = Color(0xFFFFD54F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun Count() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    val sq = squad(t.id)
    Page("تعداد بازیکنان", scroll = false) {
        Panel {
            Text("مجموع: ${sq.size} نفر (حداکثر ${G.ppt + 8})", fontWeight = FontWeight.Bold)
            Text("دروازه‌بان: ${sq.count { it.pos == "GK" }}  |  مدافع: ${sq.count { it.pos == "DF" }}")
            Text("هافبک: ${sq.count { it.pos == "MF" }}  |  مهاجم: ${sq.count { it.pos == "FW" }}")
            if (sq.isNotEmpty()) {
                Text("میانگین سن: ${String.format("%.1f", sq.map { it.age }.average())} | میانگین قدرت: ${String.format("%.1f", sq.map { it.rating }.average())}")
            }
            Text("ارزش کل: ${money(sq.sumOf { it.value })}")
        }
        Text("آزاد کردن بازیکن (حداقل ۱۵ نفر باید بماند)", modifier = Modifier.padding(4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(sq.sortedBy { it.rating }, key = { it.id }) { p ->
                PlayerRow(p) {
                    OutlinedButton(onClick = {
                        if (squad(t.id).size > 15) {
                            G.players.remove(p)
                            G.touch()
                        }
                    }) { Text("آزاد") }
                }
            }
        }
    }
}

@Composable
fun Penalty() {
    val match = G.pendingPenaltyMatch
    if (match == null) { LaunchedEffect(Unit) { G.back() }; return }
    var power by remember { mutableFloatStateOf(0.72f) }
    val shooterTeam = if (G.penaltySide == 0) match.h else match.a
    val keeperTeam = if (G.penaltySide == 0) match.a else match.h
    val shooter = lineupOf(shooterTeam).filter { it.pos == "FW" || it.pos == "MF" }.maxByOrNull { it.rating }
        ?: lineupOf(shooterTeam).first()
    val zones = listOf("چپ بالا", "وسط بالا", "راست بالا", "چپ", "وسط", "راست", "چپ پایین", "وسط پایین", "راست پایین")
    Page("ضربه پنالتی", scroll = false) {
        Panel {
            Text("⚽ پنالتی برای ${shooterTeam.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("زننده: ${shooter.name}  •  دروازه‌بان: ${keeperTeam.name}")
            Text("جهت شوت را انتخاب کن؛ سپس نتیجه مهار یا گل شدن مشخص می‌شود.")
        }
        Canvas(Modifier.fillMaxWidth().weight(1f).padding(8.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF267A3D))) {
            val w = size.width; val h = size.height
            drawRect(Color(0xFF267A3D))
            drawRect(Color.White, Offset(w * 0.13f, h * 0.12f), Size(w * 0.74f, h * 0.72f), style = Stroke(3f))
            drawRect(Color.White, Offset(w * 0.30f, h * 0.12f), Size(w * 0.40f, h * 0.30f), style = Stroke(3f))
            drawCircle(Color.White, radius = 7f, center = Offset(w * 0.5f, h * 0.53f))
            drawRect(Color(0xFFEEEEEE), Offset(w * 0.28f, h * 0.08f), Size(w * 0.44f, h * 0.035f))
        }
        Text("گوشه‌ی شوت را انتخاب کن", fontWeight = FontWeight.Bold)
        for (row in 0..2) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (col in 0..2) {
                val idx = row * 3 + col + 1
                OutlinedButton(onClick = { resolveInteractivePenalty(idx, power) }, modifier = Modifier.weight(1f)) {
                    Text(zones[idx - 1], fontSize = 11.sp)
                }
            }
        }
        Text("قدرت ضربه: ${(power * 100).toInt()}٪")
        Slider(value = power, onValueChange = { power = it }, valueRange = 0.35f..1f)
        Text("قدرت بیشتر سرعت شوت را بالا می‌برد؛ قدرت خیلی زیاد کنترل ضربه را دشوارتر می‌کند.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun Live() {
    val m = G.live
    if (m == null) {
        LaunchedEffect(Unit) { if (G.screen == "live") G.back() }
        return
    }
    var minute by remember { mutableStateOf(0) }
    var speed by remember { mutableStateOf("×۱") }
    LaunchedEffect(speed) {
        while (minute < 90) {
            delay(
                when (speed) {
                    "×۱" -> 450L
                    "×۲" -> 220L
                    else -> 80L
                }
            )
            minute++
        }
    }
    val hs = m.ev.count { it.side == 0 && it.min <= minute }
    val aS = m.ev.count { it.side == 1 && it.min <= minute }
    val shown = m.ev.filter { it.min <= minute }.reversed()
    val status = if (minute >= 90) "پایان بازی" else if (minute < 45) "نیمه اول" else "نیمه دوم"
    Page("بازی زنده", scroll = false) {
        Panel {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(m.h, 48.dp)
                    Text(m.h.name, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$hs - $aS", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("$status | ${minute}'", fontSize = 13.sp, color = Color.Gray)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(m.a, 48.dp)
                    Text(m.a.name, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
            LinearProgressIndicator(progress = { minute / 90f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("سرعت: ", fontWeight = FontWeight.Bold)
            Chips(listOf("×۱", "×۲", "×۴"), speed) { speed = it }
        }
        if (minute < 90) {
            OutlinedButton(onClick = { minute = 90 }, modifier = Modifier.fillMaxWidth()) { Text("⏩ رفتن به پایان بازی") }
        } else {
            Panel {
                Text("🏁 نتیجه نهایی مسابقه", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("${m.h.name}  $hs - $aS  ${m.a.name}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("مسابقه به پایان رسید.", color = Color.Gray)
            }
            B("مشاهده نتیجه و بازگشت", Modifier.fillMaxWidth()) { G.back() }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { e ->
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${e.min}'", Modifier.width(36.dp), color = Color.Gray, fontSize = 12.sp)
                        Text(
                            e.text, Modifier.weight(1f),
                            fontWeight = if (e.side < 2) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (e.side < 2) 16.sp else 13.sp
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun Transfers() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var mode by remember { mutableStateOf("خرید") }
    var pos by remember { mutableStateOf("همه") }
    var cty by remember { mutableStateOf("همه") }
    var ageFilter by remember { mutableStateOf("همه سنین") }
    var ratingFilter by remember { mutableStateOf("همه قدرت‌ها") }
    var q by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    val modes = listOf("خرید", "فروش", "پیشنهادها (${G.offers.size})", "اخبار")
    Page("نقل و انتقالات", scroll = false) {
        Text("بودجه: ${money(t.budget)} | بازیکنان: ${squad(t.id).size}", fontWeight = FontWeight.Bold)
        Chips(modes, modes.first { it.startsWith(mode) }) { mode = it.substringBefore(" (") }
        if (info.isNotEmpty()) Text(info, color = MaterialTheme.colorScheme.primary)
        if (mode == "اخبار") {
            if (G.news.isEmpty()) Text("هنوز خبری نیست. پس از پایان هر فصل بازار نقل و انتقالات باز می‌شود.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.news.reversed()) { n ->
                    Column {
                        Text(n, Modifier.padding(8.dp), fontSize = 13.sp)
                        HorizontalDivider()
                    }
                }
            }
        } else if (mode == "پیشنهادها") {
            if (G.offers.isEmpty()) Text("پیشنهادی برای بازیکنان شما نیست.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.offers.toList()) { o ->
                    val p = G.players.firstOrNull { it.id == o.pid }
                    val b = G.teamOrNull(o.from)
                    if (p != null && b != null) {
                        PlayerRow(p) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(b.name.take(10), fontSize = 11.sp, color = Color.Gray)
                                Row {
                                    Button(onClick = {
                                        if (p.teamId != t.id) {
                                            G.offers.remove(o)
                                            info = "این بازیکن دیگر در تیم شما نیست"
                                        } else if (squad(t.id).size <= 15) {
                                            info = "حداقل ۱۵ بازیکن لازم است"
                                        } else if (b.budget < o.price) {
                                            info = "باشگاه خریدار بودجه ندارد"
                                        } else {
                                            t.budget += o.price
                                            b.budget -= o.price
                                            p.teamId = b.id
                                            G.offers.remove(o)
                                            addNews("🔁 ${p.name} | مبدا: ${t.name} ← مقصد: ${b.name} | ${money(o.price)}")
                                            info = "${p.name} فروخته شد"
                                        }
                                        G.touch()
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(money(o.price), fontSize = 12.sp) }
                                    Spacer(Modifier.width(4.dp))
                                    OutlinedButton(onClick = {
                                        G.offers.remove(o)
                                        G.touch()
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("رد", fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Chips(listOf("همه") + POS, pos) { pos = it }
            if (mode == "خرید") {
                Chips(listOf("همه") + COUNTRIES, cty) { cty = it }
                TextF("جستجوی نام بازیکن", q, { q = it }, Modifier.fillMaxWidth())
            }
            Text("فیلتر سن", fontWeight = FontWeight.SemiBold)
            Chips(listOf("همه سنین", "زیر ۱۸", "۱۸ تا ۲۳", "۲۴ تا ۳۰", "۳۱ به بالا"), ageFilter) { ageFilter = it }
            Text("فیلتر اورال", fontWeight = FontWeight.SemiBold)
            Chips(listOf("همه قدرت‌ها", "زیر ۶۰", "۶۰ تا ۶۹", "۷۰ تا ۷۹", "۸۰ به بالا"), ratingFilter) { ratingFilter = it }
            fun fitsFilters(p: Player): Boolean =
                (ageFilter == "همه سنین" || when (ageFilter) { "زیر ۱۸" -> p.age < 18; "۱۸ تا ۲۳" -> p.age in 18..23; "۲۴ تا ۳۰" -> p.age in 24..30; "۳۱ به بالا" -> p.age >= 31; else -> true }) &&
                (ratingFilter == "همه قدرت‌ها" || when (ratingFilter) { "زیر ۶۰" -> p.rating < 60; "۶۰ تا ۶۹" -> p.rating in 60..69; "۷۰ تا ۷۹" -> p.rating in 70..79; "۸۰ به بالا" -> p.rating >= 80; else -> true })
            val list: List<Player> = remember(G.rev, mode, pos, cty, ageFilter, ratingFilter, q) {
                if (mode == "خرید") {
                    G.players.filter { p -> p.teamId != t.id && fitsFilters(p) && (pos == "همه" || p.pos == pos) && (q.isBlank() || p.name.contains(q.trim(), ignoreCase = true)) &&
                        (cty == "همه" || p.country == cty)
                    }.sortedByDescending { it.rating }
                } else {
                    squad(t.id).filter { fitsFilters(it) && (pos == "همه" || it.pos == pos) }.sortedByDescending { it.rating }
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.id }) { p ->
                    val price = if (mode == "خرید") p.value * 12 / 10 else p.value * 8 / 10
                    val from = G.teamOrNull(p.teamId)
                    PlayerRow(p) {
                        if (mode == "خرید") {
                            Text((from?.name ?: "").take(9), fontSize = 11.sp, color = Color.Gray)
                        }
                        Button(onClick = {
                            if (mode == "خرید") {
                                if (t.budget < price) {
                                    info = "بودجه کافی نیست"
                                } else if (squad(t.id).size >= G.ppt + 8) {
                                    info = "سقف تعداد بازیکنان پر است"
                                } else if (from != null && squad(from.id).size <= 15) {
                                    info = "تیم فروشنده این بازیکن را نمی‌فروشد"
                                } else {
                                    t.budget -= price
                                    if (from != null) from.budget += price
                                    p.teamId = t.id
                                    addNews("🛒 ${p.name} | مبدا: ${from?.name ?: "بازار آزاد"} ← مقصد: ${t.name} | ${money(price)}")
                                    info = "${p.name} خریداری شد"
                                    G.touch()
                                }
                            } else {
                                if (squad(t.id).size <= 15) {
                                    info = "حداقل ۱۵ بازیکن لازم است"
                                } else {
                                    t.budget += price
                                    val c = G.teams.filter { it.id != t.id && squad(it.id).size < G.ppt + 4 }
                                    if (c.isEmpty()) G.players.remove(p) else p.teamId = c.random().id
                                    info = "${p.name} فروخته شد"
                                    G.touch()
                                }
                            }
                        }) { Text(money(price), fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun Settings() {
    val rv = G.rev
    val t = G.team(G.userTeam)
    var dlg by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var nm by remember { mutableStateOf(t.name) }
    Page("تنظیمات") {
        Panel {
            Text("🌐 زبان", fontWeight = FontWeight.Bold)
            Chips(listOf("فارسی", "English"), if (I18n.lang == "en") "English" else "فارسی") { l ->
            I18n.changeLang(if (l == "English") "en" else "fa")
            G.ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString("lang", I18n.lang).apply()
        }
        }
        Panel {
            Text("سطح سختی", fontWeight = FontWeight.Bold)
            Chips(DIFFS, DIFFS[G.diff]) { d ->
                G.diff = DIFFS.indexOf(d)
                G.touch()
            }
        }
        Panel {
            TextF("نام تیم من", nm, { nm = it }, Modifier.fillMaxWidth())
            B("ذخیره نام") {
                if (nm.isNotBlank()) {
                    t.name = nm.trim()
                    G.touch()
                }
            }
        }
        Panel {
            Text("پنل ادمین", fontWeight = FontWeight.Bold)
            B("ورود به پنل ادمین", Modifier.fillMaxWidth()) {
                pw = ""
                err = false
                dlg = "admin"
            }
        }
        Panel {
            OutlinedButton(onClick = { dlg = "new" }, modifier = Modifier.fillMaxWidth()) { Text("شروع بازی جدید (حذف همه‌چیز)") }
        }
    }
    if (dlg == "admin") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("رمز ادمین") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pw,
                        onValueChange = { pw = it },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        label = { Text("رمز") }
                    )
                    if (err) Text("رمز اشتباه است", color = Color.Red)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pw == ADMIN_PASS) {
                        dlg = ""
                        G.go("admin")
                    } else {
                        err = true
                    }
                }) { Text("ورود") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("لغو") } }
        )
    }
    if (dlg == "new") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("شروع بازی جدید؟") },
            text = { Text("همه اطلاعات فعلی پاک می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    dlg = ""
                    newWorld()
                    G.touch()
                }) { Text("بله") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("لغو") } }
        )
    }
}

@Composable
fun TableScr() {
    val rv = G.rev
    val me = G.team(G.userTeam)
    var lid by remember { mutableStateOf(me.leagueId) }
    var cty by remember { mutableStateOf(G.leagues.firstOrNull { it.id == me.leagueId }?.country ?: "ایران") }
    var tab by remember { mutableStateOf("جدول") }
    val sorted = lgSorted().filter { it.country == cty }.ifEmpty { lgSorted() }
    val lg = sorted.firstOrNull { it.id == lid } ?: sorted.first()
    val maxLevel = sorted.maxOf { it.level }
    val tb = table(lg.id)
    Page("رتبه‌بندی لیگ", scroll = false) {
        Chips(COUNTRIES.filter { c -> G.leagues.any { it.country == c } }, lg.country) { c ->
            cty = c
            lid = lgSorted().first { it.country == c }.id
        }
        Text("🏆 لیگ کشور ${lg.country}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
        Chips(sorted.map { it.name }, lg.name) { n -> lid = sorted.first { it.name == n }.id }
        Chips(listOf("جدول", "آقای گل"), tab) { tab = it }
        if (tab == "جدول") {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Cell("#", 24.dp, true)
                Spacer(Modifier.width(24.dp))
                Text("تیم", Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Cell("مسابقه", 28.dp, true)
                Cell("برد", 28.dp, true)
                Cell("مس", 28.dp, true)
                Cell("باخت", 28.dp, true)
                Cell("+/-", 30.dp, true)
                Cell("امتیاز", 34.dp, true)
            }
            HorizontalDivider()
            LazyColumn(Modifier.weight(1f)) {
                items(tb.size) { i ->
                    val t = tb[i]
                    val bg = when {
                        t.id == me.id -> Color(0x33FFC107)
                        lg.level > 1 && i < G.promo -> Color(0x3300C853)
                        lg.level < maxLevel && i >= tb.size - G.promo -> Color(0x33F44336)
                        else -> Color.Transparent
                    }
                    Column {
                        Row(
                            Modifier.fillMaxWidth().background(bg).padding(vertical = 5.dp, horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cell("${i + 1}", 24.dp)
                            Logo(t, 24.dp)
                            Text(t.name, Modifier.weight(1f).padding(horizontal = 4.dp), fontSize = 12.sp, maxLines = 1)
                            Cell("${t.p}", 28.dp)
                            Cell("${t.w}", 28.dp)
                            Cell("${t.d}", 28.dp)
                            Cell("${t.l}", 28.dp)
                            Cell("${t.gf - t.ga}", 30.dp)
                            Cell("${t.pts}", 34.dp, true)
                        }
                        HorizontalDivider()
                    }
                }
            }
            Text("سبز: صعود | قرمز: سقوط | زرد: تیم شما", fontSize = 11.sp, color = Color.Gray)
        } else {
            val sc = remember(G.rev, lg.id) { tb.flatMap { squad(it.id) }.sortedByDescending { it.goals }.take(15) }
            LazyColumn(Modifier.weight(1f)) {
                items(sc.size) { i ->
                    val p = sc[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(G.teamOrNull(p.teamId)?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text("${p.goals} گل", fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
fun Overall() {
    val rv = G.rev
    var tab by remember { mutableStateOf("تیم‌ها") }
    Page("رتبه‌بندی کلی", scroll = false) {
        Chips(listOf("تیم‌ها", "گلزنان", "تاریخچه"), tab) { tab = it }
        if (tab == "تیم‌ها") {
            val l = remember(G.rev) { G.teams.sortedByDescending { it.allPts + it.pts } }
            LazyColumn(Modifier.weight(1f)) {
                items(l.size) { i ->
                    val t = l[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp))
                            Logo(t, 30.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.name, fontWeight = if (t.id == G.userTeam) FontWeight.Bold else FontWeight.Normal)
                                Text(G.leagues.firstOrNull { it.id == t.leagueId }?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${t.allPts + t.pts} امتیاز")
                                Text("🏆 ${t.titles}", fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        } else if (tab == "گلزنان") {
            val sc = remember(G.rev) { G.players.sortedByDescending { it.total }.take(20) }
            LazyColumn(Modifier.weight(1f)) {
                items(sc.size) { i ->
                    val p = sc[i]
                    Column {
                        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", Modifier.width(30.dp), fontWeight = FontWeight.Bold)
                            Column(Modifier.weight(1f)) {
                                Text(p.name)
                                Text(G.teamOrNull(p.teamId)?.name ?: "", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text("${p.total} گل", fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
            }
        } else {
            if (G.history.isEmpty()) Text("هنوز فصلی تمام نشده است.", modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(G.history.reversed()) { h ->
                    Column {
                        Text(h, Modifier.padding(8.dp), fontSize = 13.sp)
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

// ======================= پنل ادمین =======================

@Composable
fun Admin() {
    val rv = G.rev
    var tpl by remember { mutableStateOf(G.tpl.toString()) }
    var ppt by remember { mutableStateOf(G.ppt.toString()) }
    var promo by remember { mutableStateOf(G.promo.toString()) }
    var msg by remember { mutableStateOf("") }
    var rename by remember { mutableStateOf(-1) }
    var expanded by remember { mutableStateOf(setOf<Int>()) }
    val counts = HashMap<Int, Int>()
    for (t in G.teams) counts[t.leagueId] = (counts[t.leagueId] ?: 0) + 1
    Page("پنل ادمین") {
        Panel {
            Text("تنظیمات کلی", fontWeight = FontWeight.Bold)
            NumField("تعداد تیم هر لیگ", tpl, { tpl = it }, Modifier.fillMaxWidth())
            NumField("تعداد بازیکن هر تیم", ppt, { ppt = it }, Modifier.fillMaxWidth())
            NumField("تعداد تیم صعود/سقوط", promo, { promo = it }, Modifier.fillMaxWidth())
            B("اعمال تغییرات (فصل از اول شروع می‌شود)", Modifier.fillMaxWidth()) {
                val a = tpl.toIntOrNull()
                val b = ppt.toIntOrNull()
                val c = promo.toIntOrNull()
                if (a == null || b == null || c == null || a < 2 || a > 40 || b < 16 || b > 40) {
                    msg = "مقدار نامعتبر (تیم: ۲ تا ۴۰ | بازیکن: ۱۶ تا ۴۰)"
                } else {
                    G.tpl = a
                    G.ppt = b
                    G.promo = c
                    applyAdmin()
                    msg = "اعمال شد"
                    G.touch()
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
        }
        for (lg in lgSorted()) {
            Panel {
                Text("${lg.country} - سطح ${lg.level}: ${lg.name} (${counts[lg.id] ?: 0} تیم)", fontWeight = FontWeight.Bold)
                Text("کشور لیگ (برای نام بازیکنان جدید):", fontSize = 12.sp)
                Chips(COUNTRIES, lg.country) { c ->
                    lg.country = c
                    G.touch()
                }
                Row {
                    OutlinedButton(onClick = {
                        rename = lg.id
                    }) { Text("نام", fontSize = 12.sp) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = {
                        newTeam(lg)
                        resetSeason()
                        G.touch()
                    }) { Text("+ تیم", fontSize = 12.sp) }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = {
                        if (deleteLeague(lg)) {
                            msg = ""
                            G.touch()
                        } else {
                            msg = "این لیگ قابل حذف نیست (تنها لیگ یا شامل تیم شما)"
                        }
                    }) { Text("حذف لیگ", fontSize = 12.sp) }
                }
                val isOpen = lg.id in expanded
                OutlinedButton(
                    onClick = { expanded = if (isOpen) expanded - lg.id else expanded + lg.id },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (isOpen) "▲ بستن لیست تیم‌ها" else "▼ نمایش تیم‌ها", fontSize = 12.sp) }
                if (isOpen) for (t in G.teams.filter { it.leagueId == lg.id }) {
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            G.editTeam = t.id
                            G.go("adminTeam")
                        }.padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Logo(t, 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(t.name, Modifier.weight(1f))
                        Shirt(t, 28.dp)
                    }
                }
            }
        }
        B("افزودن لیگ جدید", Modifier.fillMaxWidth()) {
            addLeague()
            G.touch()
        }
        B("شروع دوباره فصل (ریست جدول‌ها)", Modifier.fillMaxWidth()) {
            resetSeason()
            G.touch()
        }
    }
    if (rename >= 0) {
        val lg = G.leagues.firstOrNull { it.id == rename }
        if (lg == null) {
            rename = -1
        } else {
            Prompt("نام لیگ", lg.name, { n ->
                if (n.isNotBlank()) {
                    lg.name = n.trim()
                    G.touch()
                }
                rename = -1
            }, { rename = -1 })
        }
    }
}

@Composable
fun AdminTeam() {
    val rv = G.rev
    val t = G.teamOrNull(G.editTeam)
    if (t == null) {
        LaunchedEffect(Unit) { if (G.screen == "adminTeam") G.back() }
        return
    }
    var nm by remember(t.id) { mutableStateOf(t.name) }
    var cnt by remember { mutableStateOf("5") }
    var gc by remember(t.id) { mutableStateOf(t.country) }
    var pn by remember { mutableStateOf("") }
    var pr by remember { mutableStateOf("65") }
    var pa by remember { mutableStateOf("24") }
    var pp by remember { mutableStateOf("FW") }
    var msg by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val p = copyLogo(uri, t.id)
            if (p != null) {
                t.logo = p
                G.touch()
            }
        }
    }
    Page("ویرایش تیم") {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(t, 64.dp)
                Spacer(Modifier.width(12.dp))
                Shirt(t, 64.dp)
            }
            TextF("نام تیم", nm, { nm = it }, Modifier.fillMaxWidth())
            B("ذخیره نام") {
                if (nm.isNotBlank()) {
                    t.name = nm.trim()
                    G.touch()
                }
            }
            Text("کشور تیم", fontWeight = FontWeight.Bold)
            Chips(COUNTRIES, t.country) { c ->
                t.country = c
                G.touch()
            }
            Text("لیگ تیم", fontWeight = FontWeight.Bold)
            val lgs = lgSorted()
            Chips(lgs.map { it.name }, lgs.firstOrNull { it.id == t.leagueId }?.name ?: "") { n ->
                t.leagueId = lgs.first { it.name == n }.id
                resetSeason()
                G.touch()
            }
        }
        Panel {
            Text("پیراهن", fontWeight = FontWeight.Bold)
            Text("رنگ اصلی")
            ColorRow(t.c1) { c ->
                t.c1 = c
                G.touch()
            }
            Text("رنگ دوم")
            ColorRow(t.c2) { c ->
                t.c2 = c
                G.touch()
            }
            Chips(SHIRTS, SHIRTS[t.style]) { s ->
                t.style = SHIRTS.indexOf(s)
                G.touch()
            }
        }
        Panel {
            Text("لوگو", fontWeight = FontWeight.Bold)
            B("انتخاب لوگو از حافظه گوشی", Modifier.fillMaxWidth()) { pick.launch("image/*") }
            OutlinedButton(onClick = {
                t.logo = null
                G.touch()
            }, modifier = Modifier.fillMaxWidth()) { Text("لوگوی خودکار (بر اساس رنگ تیم)") }
        }
        Panel {
            Text("بازیکنان (${squad(t.id).size})", fontWeight = FontWeight.Bold)
            Text("ساخت بازیکن تصادفی بر اساس کشور:")
            Chips(COUNTRIES, gc) { gc = it }
            NumField("تعداد", cnt, { cnt = it }, Modifier.fillMaxWidth())
            B("ساخت بازیکنان تصادفی", Modifier.fillMaxWidth()) {
                val n = (cnt.toIntOrNull() ?: 0).coerceIn(0, 30)
                val base = squadAvg(t)
                val kinds = listOf("GK", "DF", "DF", "DF", "MF", "MF", "MF", "FW", "FW")
                repeat(n) { G.players.add(genPlayer(t.id, gc, kinds.random(), base)) }
                msg = "$n بازیکن ساخته شد"
                G.touch()
            }
            OutlinedButton(onClick = {
                val base = squadAvg(t)
                G.players.removeAll { it.teamId == t.id }
                for (pos in posPlan(G.ppt)) G.players.add(genPlayer(t.id, gc, pos, base))
                msg = "کل بازیکنان با کشور $gc ساخته شد"
                G.touch()
            }, modifier = Modifier.fillMaxWidth()) { Text("ساخت مجدد کل بازیکنان این تیم") }
            Text("افزودن بازیکن دستی:", modifier = Modifier.padding(top = 8.dp))
            TextF("نام بازیکن", pn, { pn = it }, Modifier.fillMaxWidth())
            Chips(POS, pp) { pp = it }
            Row {
                NumField("قدرت", pr, { pr = it }, Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                NumField("سن", pa, { pa = it }, Modifier.weight(1f))
            }
            B("افزودن بازیکن", Modifier.fillMaxWidth()) {
                val r = pr.toIntOrNull()
                val a = pa.toIntOrNull()
                if (pn.isBlank() || r == null || a == null) {
                    msg = "اطلاعات ناقص است"
                } else {
                    val rr = r.coerceIn(30, 99)
                    val aa = a.coerceIn(15, 45)
                    G.players.add(Player(G.nid(), pn.trim(), pp, rr, aa, t.id, worth(rr, aa), country = t.country))
                    pn = ""
                    msg = "بازیکن اضافه شد"
                    G.touch()
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.primary)
        }
        Panel {
            Text("لیست بازیکنان", fontWeight = FontWeight.Bold)
            for (p in squad(t.id).sortedWith(compareBy<Player>({ POS.indexOf(it.pos) }, { -it.rating }))) {
                PlayerRow(p) {
                    OutlinedButton(onClick = {
                        G.players.remove(p)
                        G.touch()
                    }) { Text("حذف", fontSize = 12.sp) }
                }
            }
        }
        if (t.id != G.userTeam) {
            OutlinedButton(onClick = { confirmDel = true }, modifier = Modifier.fillMaxWidth()) { Text("حذف این تیم") }
        }
    }
    if (confirmDel) {
        AlertDialog(
            onDismissRequest = { confirmDel = false },
            title = { Text("حذف تیم ${t.name}؟") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDel = false
                    removeTeam(t)
                    resetSeason()
                    G.touch()
                    G.back()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("لغو") } }
        )
    }
}


// ساختاردهی/مهاجرت سیوهای قدیمی به کشورها و لیگ‌های جدید
fun ensureWorldStructure() {
    G.ppt = maxOf(G.ppt, 25)
    for ((country, names) in LEAGUE_DEFS) {
        for ((idx, leagueName) in names.withIndex()) {
            val level = idx + 1
            var league = G.leagues.firstOrNull { it.country == country && it.level == level }
            if (league == null) {
                league = League(G.nid(), leagueName, level, country)
                G.leagues.add(league)
            } else {
                league.name = leagueName
                league.country = country
            }
            val existing = G.teams.filter { it.leagueId == league.id }
            existing.forEach { it.country = country }
            if (level == 1) {
                val real = REAL_CLUBS[country].orEmpty()
                existing.take(real.size).forEachIndexed { i, team -> team.name = real[i] }
            }
            var n = existing.size
            while (n < G.tpl) { newTeam(league); n++ }
        }
    }
    if (G.worldVer < 3) {
        // مهاجرت سیوهای قدیمی: ستاره‌های تصادفی حذف، نام‌های ایرانیِ تیم‌های خارجی اصلاح، باشگاه‌های بزرگ تقویت، ستاره‌های واقعی اضافه
        G.players.removeAll { it.name in OLD_STAR_NAMES }
        for (t in G.teams.toList()) {
            if (t.country == "ایران") continue
            val w = t.name.split(" ")
            if (w.size == 2 && w[0] in NAME_A && w[1] in NAME_B) t.name = uniqueName(t.country, t.leagueId)
        }
        val grp = G.players.groupBy { it.teamId }
        for (t in G.teams) {
            val lv = G.leagues.firstOrNull { it.id == t.leagueId }?.level ?: 9
            val b = realisticClubBoost(t.name, t.country, lv)
            for (p in grp[t.id].orEmpty()) {
                if (b > 0) p.rating = (p.rating + b * 8 / 10).coerceIn(40, 95)
                p.value = worth(p.rating, p.age)
            }
        }
        addRealStars()
        G.worldVer = 3
    }
    val plan = posPlan(G.ppt)
    for (t in G.teams) {
        val over = G.academy.filter { it.teamId == t.id }.sortedByDescending { it.potential }.drop(15)
        if (over.isNotEmpty()) G.academy.removeAll(over.toSet())
    }
    val acCount = HashMap<Int, Int>()
    for (a in G.academy) acCount[a.teamId] = (acCount[a.teamId] ?: 0) + 1
    val grouped = G.players.groupBy { it.teamId }
    for (t in G.teams.toList()) {
        val sq = grouped[t.id].orEmpty()
        if (sq.size < G.ppt) {
            val avg = if (sq.isEmpty()) 62 else sq.map { it.rating }.average().toInt()
            for (i in sq.size until G.ppt) G.players.add(genPlayer(t.id, t.country, plan[i % plan.size], avg))
        }
        repeat((5 - (acCount[t.id] ?: 0)).coerceAtLeast(0)) { if ((acCount[t.id] ?: 0) < 15) G.academy.add(genAcademyPlayer(t)) }
    }
    // نگاشت ملیت بازیکنان سیو قدیمی به کشور باشگاه به‌عنوان مقدار پیش‌فرض
    for (p in G.players) if (p.country.isBlank()) p.country = G.teamOrNull(p.teamId)?.country ?: "ایران"
}

// ======================= ریشه برنامه =======================

@Composable
fun App() {
    if (!G.ready) {
        Box(Modifier.fillMaxSize().background(Color(0xFFF6F3EA)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color(0xFFB8860B))
        }
        LaunchedEffect(Unit) {
            // بارگذاری/ساخت دنیا خارج از ترد اصلی انجام می‌شود تا اپ هنگام باز شدن قفل نکند.
            withContext(Dispatchers.Default) {
                if (!load()) newWorld()
                ensureWorldStructure()
            }
            G.ready = true
            G.flush()
        }
        return
    }
    CompositionLocalProvider(LocalLayoutDirection provides (if (I18n.lang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl)) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Color(0xFFB8860B), secondary = Color(0xFFFFC107),
                secondaryContainer = Color(0xFFFFE9A8), onSecondaryContainer = Color(0xFF1A1400)
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFFF6F3EA)) {
                // هر دو state همیشه خوانده می‌شوند تا با تغییرشان همین‌جا دوباره رسم شود
                val curScreen = G.screen
                val hasTeam = G.teamOrNull(G.userTeam) != null
                // بدون تیم فقط این سه صفحه مجازند (قبلاً ساخت تیم و رتبه‌بندی جهانی هرگز باز نمی‌شدند)
                val s = if (!hasTeam && curScreen != "createTeam" && curScreen != "worldRank") "pick" else curScreen
                BackHandler(enabled = s != "home" && s != "pick") { G.back() }
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (s) {
                            "pick" -> Pick()
                            "createTeam" -> CreateTeam()
                            "worldRank" -> WorldRank()
                            "home" -> Home()
                            "play" -> Play()
                            "cups" -> Cups()
                            "players" -> Players()
                            "academy" -> Academy()
                            "tactics" -> Tactics()
                            "count" -> Count()
                            "transfers" -> Transfers()
                            "settings" -> Settings()
                            "table" -> TableScr()
                            "overall" -> Overall()
                            "admin" -> Admin()
                            "adminTeam" -> AdminTeam()
                            "live" -> Live()
                            "penalty" -> Penalty()
                            else -> Home()
                        }
                    }
                    if (hasTeam && s != "pick" && s != "live" && s != "admin" && s != "adminTeam") {
                        NavigationBar(containerColor = Color(0xFF101820), contentColor = Color(0xFFFFC107), tonalElevation = 8.dp) {
                            val nav = listOf(
                                Triple("home", "⌂", "خانه"), Triple("players", "♟", "بازیکنان"),
                                Triple("transfers", "⇄", "بازار"), Triple("academy", "★", "آکادمی"),
                                Triple("table", "🏆", "لیگ"), Triple("worldRank", "🌍", "جهانی")
                            )
                            nav.forEach { (key, iconText, label) ->
                                NavigationBarItem(
                                    selected = s == key,
                                    onClick = { if (s != key) G.go(key) },
                                    icon = { Text(iconText, fontSize = 20.sp) },
                                    label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFFFC107), selectedTextColor = Color(0xFFFFC107),
                                        indicatorColor = Color(0xFF3B3421), unselectedIconColor = Color(0xFFCFD8DC),
                                        unselectedTextColor = Color(0xFFCFD8DC)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        G.ctx = applicationContext
        I18n.changeLang(getSharedPreferences("prefs", MODE_PRIVATE).getString("lang", "fa") ?: "fa")
        setContent { App() }
    }

    override fun onStop() {
        super.onStop()
        if (G.ready) G.flush()
    }
}
