package com.mmd.morabbi

class RealStar(val club: String, val name: String, val pos: String, val rating: Int, val age: Int, val nat: String)

// باشگاه "-" یعنی بازیکن آزاد (در بازار نقل‌وانتقالات)
val REAL_STARS: List<RealStar> by lazy {
    STARS_RAW.split("\n").filter { it.count { c -> c == '|' } == 5 }.map {
        val p = it.split("|")
        RealStar(p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim().toInt(), p[4].trim().toInt(), p[5].trim())
    }
}

val STAR_NAMES: Set<String> by lazy { REAL_STARS.map { it.name }.toSet() }

// تقویت پایه‌ی قدرت بازیکنان باشگاه‌های بزرگ در سطح اول لیگ
val CLUB_BOOST: Map<String, Int> = mapOf(
    "رئال مادرید" to 9,
    "بارسلونا" to 8,
    "منچسترسیتی" to 9,
    "لیورپول" to 8,
    "آرسنال" to 8,
    "بایرن مونیخ" to 9,
    "پاری سن ژرمن" to 8,
    "اینتر" to 8,
    "چلسی" to 6,
    "منچستریونایتد" to 5,
    "تاتنهام" to 5,
    "نیوکاسل یونایتد" to 4,
    "اتلتیکو مادرید" to 6,
    "بروسیا دورتموند" to 5,
    "بایر لورکوزن" to 5,
    "آث میلان" to 5,
    "یوونتوس" to 5,
    "ناپولی" to 5,
    "استون ویلا" to 3,
    "رم" to 3,
    "آتالانتا" to 4,
    "لایپزیگ" to 4,
    "بنفیکا" to 3,
    "پورتو" to 3,
    "اسپورتینگ لیسبون" to 3,
    "آژاکس" to 2,
    "پی‌اس‌وی آیندهوون" to 2,
    "گالاتاسرای" to 3,
    "فنرباغچه" to 3,
    "فلامینگو" to 3,
    "پالمیراس" to 3,
    "بوکا جونیورز" to 2,
    "ریور پلاته" to 2,
    "مارسی" to 2,
    "موناکو" to 2,
    "اتلتیک بیلبائو" to 2,
    "رئال سوسیداد" to 2,
    "ویارئال" to 2,
    "لاتزیو" to 2,
    "فیورنتینا" to 2,
    "فاینورد" to 2,
    "بشیکتاش" to 2
)

private const val STARS_RAW = """رئال مادرید|Thibaut Courtois|GK|88|33|بلژیک
رئال مادرید|Kylian Mbappe|FW|91|27|فرانسه
رئال مادرید|Vinicius Junior|FW|90|25|برزیل
رئال مادرید|Jude Bellingham|MF|89|23|انگلیس
رئال مادرید|Federico Valverde|MF|88|27|اروگوئه
رئال مادرید|Trent Alexander-Arnold|DF|85|27|انگلیس
رئال مادرید|Antonio Rudiger|DF|85|33|آلمان
رئال مادرید|Rodrygo|FW|85|25|برزیل
رئال مادرید|Aurelien Tchouameni|MF|84|26|فرانسه
رئال مادرید|Eduardo Camavinga|MF|83|23|فرانسه
رئال مادرید|Arda Guler|MF|82|21|ترکیه
رئال مادرید|Dean Huijsen|DF|82|20|اسپانیا
رئال مادرید|Endrick|FW|79|19|برزیل
بارسلونا|Lamine Yamal|FW|90|18|اسپانیا
بارسلونا|Raphinha|FW|88|29|برزیل
بارسلونا|Pedri|MF|88|23|اسپانیا
بارسلونا|Marc-Andre ter Stegen|GK|86|33|آلمان
بارسلونا|Robert Lewandowski|FW|86|37|لهستان
بارسلونا|Frenkie de Jong|MF|85|28|هلند
بارسلونا|Jules Kounde|DF|85|27|فرانسه
بارسلونا|Ronald Araujo|DF|84|26|اروگوئه
بارسلونا|Dani Olmo|MF|84|27|اسپانیا
بارسلونا|Pau Cubarsi|DF|83|18|اسپانیا
بارسلونا|Gavi|MF|83|21|اسپانیا
بارسلونا|Marcus Rashford|FW|83|28|انگلیس
بارسلونا|Fermin Lopez|MF|82|22|اسپانیا
بارسلونا|Alejandro Balde|DF|82|22|اسپانیا
اتلتیکو مادرید|Jan Oblak|GK|88|32|اسلوونی
اتلتیکو مادرید|Antoine Griezmann|FW|87|34|فرانسه
اتلتیکو مادرید|Julian Alvarez|FW|87|25|آرژانتین
اتلتیکو مادرید|Marcos Llorente|MF|83|30|اسپانیا
اتلتیکو مادرید|Koke|MF|82|33|اسپانیا
اتلتیکو مادرید|Robin Le Normand|DF|82|29|اسپانیا
اتلتیکو مادرید|Alexander Sorloth|FW|81|30|نروژ
اتلتیکو مادرید|Conor Gallagher|MF|81|26|انگلیس
اتلتیکو مادرید|Pablo Barrios|MF|80|22|اسپانیا
اتلتیک بیلبائو|Nico Williams|FW|85|23|اسپانیا
اتلتیک بیلبائو|Unai Simon|GK|85|28|اسپانیا
اتلتیک بیلبائو|Oihan Sancet|MF|82|25|اسپانیا
اتلتیک بیلبائو|Inaki Williams|FW|81|31|غنا
رئال سوسیداد|Mikel Oyarzabal|FW|85|28|اسپانیا
رئال سوسیداد|Takefusa Kubo|FW|82|24|ژاپن
رئال سوسیداد|Brais Mendez|MF|80|28|اسپانیا
ویارئال|Alex Baena|MF|82|24|اسپانیا
ویارئال|Gerard Moreno|FW|80|33|اسپانیا
رئال بتیس|Isco|MF|80|33|اسپانیا
رئال بتیس|Antony|FW|80|25|برزیل
رئال بتیس|Giovani Lo Celso|MF|80|29|آرژانتین
منچسترسیتی|Erling Haaland|FW|92|25|نروژ
منچسترسیتی|Rodri|MF|90|29|اسپانیا
منچسترسیتی|Gianluigi Donnarumma|GK|88|26|ایتالیا
منچسترسیتی|Phil Foden|MF|86|25|انگلیس
منچسترسیتی|Bernardo Silva|MF|86|31|پرتغال
منچسترسیتی|Ruben Dias|DF|86|28|پرتغال
منچسترسیتی|Josko Gvardiol|DF|85|24|کرواسی
منچسترسیتی|Omar Marmoush|FW|84|26|مصر
منچسترسیتی|Jeremy Doku|FW|83|23|بلژیک
منچسترسیتی|Tijjani Reijnders|MF|83|27|هلند
منچسترسیتی|Rayan Cherki|FW|83|22|فرانسه
منچسترسیتی|Savinho|FW|82|21|برزیل
لیورپول|Mohamed Salah|FW|90|33|مصر
لیورپول|Virgil van Dijk|DF|88|34|هلند
لیورپول|Alisson|GK|88|33|برزیل
لیورپول|Florian Wirtz|MF|87|23|آلمان
لیورپول|Alexander Isak|FW|87|26|سوئد
لیورپول|Ryan Gravenberch|MF|85|23|هلند
لیورپول|Dominik Szoboszlai|MF|85|25|مجارستان
لیورپول|Alexis Mac Allister|MF|85|26|آرژانتین
لیورپول|Ibrahima Konate|DF|84|26|فرانسه
لیورپول|Cody Gakpo|FW|83|26|هلند
لیورپول|Hugo Ekitike|FW|83|23|فرانسه
لیورپول|Jeremie Frimpong|DF|82|25|هلند
لیورپول|Milos Kerkez|DF|80|22|مجارستان
آرسنال|Bukayo Saka|FW|89|24|انگلیس
آرسنال|Declan Rice|MF|88|26|انگلیس
آرسنال|William Saliba|DF|88|24|فرانسه
آرسنال|Martin Odegaard|MF|87|27|نروژ
آرسنال|Gabriel Magalhaes|DF|86|28|برزیل
آرسنال|David Raya|GK|86|30|اسپانیا
آرسنال|Viktor Gyokeres|FW|86|27|سوئد
آرسنال|Martin Zubimendi|MF|85|26|اسپانیا
آرسنال|Gabriel Martinelli|FW|83|24|برزیل
آرسنال|Eberechi Eze|MF|83|27|انگلیس
آرسنال|Ben White|DF|82|28|انگلیس
آرسنال|Leandro Trossard|FW|82|31|بلژیک
منچستریونایتد|Bruno Fernandes|MF|87|31|پرتغال
منچستریونایتد|Matheus Cunha|FW|84|26|برزیل
منچستریونایتد|Bryan Mbeumo|FW|84|26|کامرون
منچستریونایتد|Lisandro Martinez|DF|83|27|آرژانتین
منچستریونایتد|Benjamin Sesko|FW|82|22|اسلوونی
منچستریونایتد|Casemiro|MF|82|33|برزیل
منچستریونایتد|Diogo Dalot|DF|81|26|پرتغال
منچستریونایتد|Kobbie Mainoo|MF|80|20|انگلیس
منچستریونایتد|Senne Lammens|GK|80|23|بلژیک
چلسی|Cole Palmer|MF|88|23|انگلیس
چلسی|Enzo Fernandez|MF|85|24|آرژانتین
چلسی|Moises Caicedo|MF|85|24|اکوادور
چلسی|Reece James|DF|84|25|انگلیس
چلسی|Joao Pedro|FW|83|24|برزیل
چلسی|Pedro Neto|FW|82|25|پرتغال
چلسی|Levi Colwill|DF|82|22|انگلیس
چلسی|Marc Cucurella|DF|82|27|اسپانیا
چلسی|Estevao|FW|80|18|برزیل
چلسی|Robert Sanchez|GK|80|27|اسپانیا
تاتنهام|Cristian Romero|DF|85|28|آرژانتین
تاتنهام|Micky van de Ven|DF|84|24|هلند
تاتنهام|James Maddison|MF|83|29|انگلیس
تاتنهام|Xavi Simons|MF|83|22|هلند
تاتنهام|Dominic Solanke|FW|82|28|انگلیس
تاتنهام|Mohammed Kudus|FW|82|25|غنا
تاتنهام|Dejan Kulusevski|MF|82|25|سوئد
تاتنهام|Guglielmo Vicario|GK|82|29|ایتالیا
نیوکاسل یونایتد|Bruno Guimaraes|MF|86|27|برزیل
نیوکاسل یونایتد|Sandro Tonali|MF|84|25|ایتالیا
نیوکاسل یونایتد|Anthony Gordon|FW|83|25|انگلیس
نیوکاسل یونایتد|Nick Woltemade|FW|82|23|آلمان
نیوکاسل یونایتد|Sven Botman|DF|82|26|هلند
نیوکاسل یونایتد|Nick Pope|GK|82|33|انگلیس
نیوکاسل یونایتد|Harvey Barnes|FW|80|27|انگلیس
استون ویلا|Emiliano Martinez|GK|87|33|آرژانتین
استون ویلا|Morgan Rogers|MF|84|23|انگلیس
استون ویلا|Ollie Watkins|FW|83|30|انگلیس
استون ویلا|Youri Tielemans|MF|82|28|بلژیک
استون ویلا|Ezri Konsa|DF|82|28|انگلیس
استون ویلا|Amadou Onana|MF|82|24|بلژیک
استون ویلا|John McGinn|MF|81|31|اسکاتلند
وستهم|Jarrod Bowen|FW|82|29|انگلیس
وستهم|Lucas Paqueta|MF|82|28|برزیل
اورتون|Jordan Pickford|GK|83|31|انگلیس
اورتون|Jack Grealish|MF|82|30|انگلیس
اورتون|Iliman Ndiaye|FW|80|25|سنگال
کریستال پالاس|Adam Wharton|MF|82|21|انگلیس
کریستال پالاس|Ismaila Sarr|FW|81|27|سنگال
کریستال پالاس|Jean-Philippe Mateta|FW|81|28|فرانسه
ناتینگهام فارست|Morgan Gibbs-White|MF|82|25|انگلیس
برایتون|Kaoru Mitoma|FW|81|28|ژاپن
فولام|Bernd Leno|GK|82|33|آلمان
اینتر|Lautaro Martinez|FW|89|28|آرژانتین
اینتر|Nicolo Barella|MF|87|28|ایتالیا
اینتر|Alessandro Bastoni|DF|87|26|ایتالیا
اینتر|Hakan Calhanoglu|MF|86|32|ترکیه
اینتر|Marcus Thuram|FW|85|28|فرانسه
اینتر|Federico Dimarco|DF|84|28|ایتالیا
اینتر|Yann Sommer|GK|84|37|سوئیس
اینتر|Denzel Dumfries|DF|83|29|هلند
اینتر|Piotr Zielinski|MF|82|31|لهستان
اینتر|Henrikh Mkhitaryan|MF|80|36|ارمنستان
اینتر|Francesco Acerbi|DF|80|37|ایتالیا
آث میلان|Mike Maignan|GK|87|30|فرانسه
آث میلان|Rafael Leao|FW|86|26|پرتغال
آث میلان|Christian Pulisic|FW|85|27|آمریکا
آث میلان|Adrien Rabiot|MF|84|30|فرانسه
آث میلان|Luka Modric|MF|83|40|کرواسی
آث میلان|Strahinja Pavlovic|DF|82|24|صربستان
آث میلان|Fikayo Tomori|DF|82|28|انگلیس
آث میلان|Christopher Nkunku|FW|82|28|فرانسه
آث میلان|Alexis Saelemaekers|MF|80|26|بلژیک
یوونتوس|Kenan Yildiz|FW|85|20|ترکیه
یوونتوس|Gleison Bremer|DF|85|28|برزیل
یوونتوس|Dusan Vlahovic|FW|83|26|صربستان
یوونتوس|Khephren Thuram|MF|82|24|فرانسه
یوونتوس|Teun Koopmeiners|MF|82|27|هلند
یوونتوس|Jonathan David|FW|82|26|کانادا
یوونتوس|Manuel Locatelli|MF|82|28|ایتالیا
یوونتوس|Federico Gatti|DF|81|27|ایتالیا
یوونتوس|Michele Di Gregorio|GK|80|28|ایتالیا
ناپولی|Kevin De Bruyne|MF|87|34|بلژیک
ناپولی|Scott McTominay|MF|85|29|اسکاتلند
ناپولی|Alessandro Buongiorno|DF|83|26|ایتالیا
ناپولی|Romelu Lukaku|FW|82|32|بلژیک
ناپولی|Amir Rrahmani|DF|82|31|کوزوو
ناپولی|Giovanni Di Lorenzo|DF|82|32|ایتالیا
ناپولی|Stanislav Lobotka|MF|82|31|اسلواکی
ناپولی|Alex Meret|GK|81|28|ایتالیا
ناپولی|Rasmus Hojlund|FW|79|22|دانمارک
آتالانتا|Ademola Lookman|FW|85|28|نیجریه
آتالانتا|Charles De Ketelaere|FW|82|24|بلژیک
آتالانتا|Marco Carnesecchi|GK|82|25|ایتالیا
آتالانتا|Marten de Roon|MF|80|34|هلند
آتالانتا|Gianluca Scamacca|FW|80|27|ایتالیا
آتالانتا|Mario Pasalic|MF|80|31|کرواسی
رم|Paulo Dybala|FW|84|32|آرژانتین
رم|Mile Svilar|GK|83|26|صربستان
رم|Matias Soule|FW|82|22|آرژانتین
رم|Lorenzo Pellegrini|MF|82|29|ایتالیا
رم|Gianluca Mancini|DF|81|29|ایتالیا
رم|Artem Dovbyk|FW|80|28|اوکراین
لاتزیو|Mattia Zaccagni|FW|81|30|ایتالیا
لاتزیو|Ivan Provedel|GK|81|31|ایتالیا
فیورنتینا|Moise Kean|FW|83|25|ایتالیا
فیورنتینا|David de Gea|GK|82|35|اسپانیا
بولونیا|Lewis Ferguson|MF|80|26|اسکاتلند
بایرن مونیخ|Harry Kane|FW|91|32|انگلیس
بایرن مونیخ|Jamal Musiala|MF|88|23|آلمان
بایرن مونیخ|Michael Olise|FW|88|24|فرانسه
بایرن مونیخ|Joshua Kimmich|MF|88|30|آلمان
بایرن مونیخ|Manuel Neuer|GK|86|39|آلمان
بایرن مونیخ|Luis Diaz|FW|85|28|کلمبیا
بایرن مونیخ|Jonathan Tah|DF|84|29|آلمان
بایرن مونیخ|Dayot Upamecano|DF|84|27|فرانسه
بایرن مونیخ|Alphonso Davies|DF|83|25|کانادا
بایرن مونیخ|Kim Min-jae|DF|83|29|کره جنوبی
بایرن مونیخ|Konrad Laimer|MF|82|28|اتریش
بایرن مونیخ|Leon Goretzka|MF|82|31|آلمان
بایرن مونیخ|Serge Gnabry|FW|82|30|آلمان
بایرن مونیخ|Aleksandar Pavlovic|MF|82|22|آلمان
بروسیا دورتموند|Gregor Kobel|GK|87|27|سوئیس
بروسیا دورتموند|Serhou Guirassy|FW|85|29|گینه
بروسیا دورتموند|Nico Schlotterbeck|DF|84|26|آلمان
بروسیا دورتموند|Julian Brandt|MF|83|29|آلمان
بروسیا دورتموند|Waldemar Anton|DF|83|29|آلمان
بروسیا دورتموند|Karim Adeyemi|FW|82|24|آلمان
بروسیا دورتموند|Felix Nmecha|MF|81|25|آلمان
بروسیا دورتموند|Maximilian Beier|FW|80|23|آلمان
بروسیا دورتموند|Emre Can|MF|80|32|آلمان
بایر لورکوزن|Alex Grimaldo|DF|84|30|اسپانیا
بایر لورکوزن|Patrik Schick|FW|83|30|چک
بایر لورکوزن|Exequiel Palacios|MF|82|27|آرژانتین
بایر لورکوزن|Edmond Tapsoba|DF|82|26|بورکینافاسو
بایر لورکوزن|Lukas Hradecky|GK|82|36|فنلاند
بایر لورکوزن|Malik Tillman|MF|81|23|آمریکا
لایپزیگ|Castello Lukeba|DF|83|23|فرانسه
لایپزیگ|Christoph Baumgartner|MF|82|26|اتریش
لایپزیگ|David Raum|DF|81|27|آلمان
لایپزیگ|Willi Orban|DF|81|33|مجارستان
لایپزیگ|Yan Diomande|FW|80|19|ساحل عاج
اشتوتگارت|Deniz Undav|FW|82|29|آلمان
اشتوتگارت|Angelo Stiller|MF|82|24|آلمان
اشتوتگارت|Alexander Nubel|GK|82|29|آلمان
اشتوتگارت|Ermedin Demirovic|FW|81|27|بوسنی
آینتراخت فرانکفورت|Jonathan Burkardt|FW|81|25|آلمان
آینتراخت فرانکفورت|Hugo Larsson|MF|80|21|سوئد
آینتراخت فرانکفورت|Can Uzun|MF|80|20|ترکیه
پاری سن ژرمن|Ousmane Dembele|FW|90|28|فرانسه
پاری سن ژرمن|Vitinha|MF|88|25|پرتغال
پاری سن ژرمن|Achraf Hakimi|DF|87|27|مراکش
پاری سن ژرمن|Marquinhos|DF|87|31|برزیل
پاری سن ژرمن|Khvicha Kvaratskhelia|FW|87|25|گرجستان
پاری سن ژرمن|Joao Neves|MF|86|21|پرتغال
پاری سن ژرمن|Desire Doue|FW|86|20|فرانسه
پاری سن ژرمن|Nuno Mendes|DF|86|23|پرتغال
پاری سن ژرمن|Bradley Barcola|FW|84|23|فرانسه
پاری سن ژرمن|Fabian Ruiz|MF|84|29|اسپانیا
پاری سن ژرمن|Willian Pacho|DF|84|24|اکوادور
پاری سن ژرمن|Lucas Chevalier|GK|82|24|فرانسه
مارسی|Mason Greenwood|FW|83|24|انگلیس
مارسی|Pierre-Emerick Aubameyang|FW|80|36|گابن
مارسی|Matt O'Riley|MF|80|25|دانمارک
مارسی|Geronimo Rulli|GK|80|33|آرژانتین
مارسی|Amine Gouiri|FW|80|26|الجزایر
موناکو|Maghnes Akliouche|MF|82|23|فرانسه
موناکو|Aleksandr Golovin|MF|81|29|روسیه
موناکو|Takumi Minamino|MF|80|30|ژاپن
موناکو|Eliesse Ben Seghir|FW|80|20|مراکش
لیون|Alexandre Lacazette|FW|80|34|فرانسه
بنفیکا|Vangelis Pavlidis|FW|82|27|یونان
بنفیکا|Orkun Kokcu|MF|82|25|ترکیه
بنفیکا|Anatoliy Trubin|GK|82|24|اوکراین
بنفیکا|Richard Rios|MF|81|25|کلمبیا
بنفیکا|Nicolas Otamendi|DF|80|38|آرژانتین
پورتو|Diogo Costa|GK|85|26|پرتغال
پورتو|Samu Aghehowa|FW|82|21|اسپانیا
پورتو|Alan Varela|MF|80|24|آرژانتین
اسپورتینگ لیسبون|Pedro Goncalves|FW|83|27|پرتغال
اسپورتینگ لیسبون|Morten Hjulmand|MF|83|26|دانمارک
اسپورتینگ لیسبون|Francisco Trincao|FW|82|26|پرتغال
اسپورتینگ لیسبون|Ousmane Diomande|DF|81|22|ساحل عاج
اسپورتینگ لیسبون|Maximiliano Araujo|FW|80|25|اروگوئه
اسپورتینگ لیسبون|Rui Silva|GK|80|32|پرتغال
آژاکس|Brian Brobbey|FW|80|23|هلند
آژاکس|Kenneth Taylor|MF|79|23|هلند
پی‌اس‌وی آیندهوون|Ismael Saibari|MF|80|24|مراکش
پی‌اس‌وی آیندهوون|Luuk de Jong|FW|79|35|هلند
پی‌اس‌وی آیندهوون|Jerdy Schouten|MF|79|28|هلند
پی‌اس‌وی آیندهوون|Ricardo Pepi|FW|78|23|آمریکا
فاینورد|Quinten Timber|MF|81|24|هلند
فاینورد|Anis Hadj Moussa|FW|79|23|الجزایر
فلامینگو|Giorgian De Arrascaeta|MF|83|31|اروگوئه
فلامینگو|Gerson|MF|80|28|برزیل
فلامینگو|Jorge Carrascal|MF|80|27|کلمبیا
فلامینگو|Leo Pereira|DF|80|29|برزیل
پالمیراس|Gustavo Gomez|DF|81|32|پاراگوئه
پالمیراس|Vitor Roque|FW|80|21|برزیل
پالمیراس|Raphael Veiga|MF|80|30|برزیل
پالمیراس|Weverton|GK|80|37|برزیل
کورینتیانس|Memphis Depay|FW|80|32|هلند
کورینتیانس|Yuri Alberto|FW|79|25|برزیل
کورینتیانس|Rodrigo Garro|MF|79|27|آرژانتین
سانتوس|Neymar|FW|82|34|برزیل
سائوپائولو|Lucas Moura|FW|78|33|برزیل
بوکا جونیورز|Leandro Paredes|MF|80|31|آرژانتین
بوکا جونیورز|Miguel Merentiel|FW|78|29|اروگوئه
ریور پلاته|Franco Armani|GK|80|39|آرژانتین
ریور پلاته|Sebastian Driussi|FW|80|30|آرژانتین
ریور پلاته|Marcos Acuna|DF|79|34|آرژانتین
گالاتاسرای|Victor Osimhen|FW|86|27|نیجریه
گالاتاسرای|Leroy Sane|FW|83|30|آلمان
گالاتاسرای|Ilkay Gundogan|MF|82|35|آلمان
گالاتاسرای|Mauro Icardi|FW|80|33|آرژانتین
گالاتاسرای|Lucas Torreira|MF|80|30|اروگوئه
گالاتاسرای|Davinson Sanchez|DF|80|29|کلمبیا
گالاتاسرای|Fernando Muslera|GK|80|39|اروگوئه
فنرباغچه|N'Golo Kante|MF|82|35|فرانسه
فنرباغچه|Milan Skriniar|DF|82|31|اسلواکی
فنرباغچه|Jhon Duran|FW|80|22|کلمبیا
فنرباغچه|Youssef En-Nesyri|FW|80|28|مراکش
فنرباغچه|Dominik Livakovic|GK|80|30|کرواسی
بشیکتاش|Rafa Silva|FW|81|32|پرتغال
بشیکتاش|Gedson Fernandes|MF|79|26|پرتغال
بشیکتاش|Vaclav Cerny|FW|79|28|چک
ترابزون‌اسپور|Paul Onuachu|FW|79|31|نیجریه
ترابزون‌اسپور|Trezeguet|FW|78|31|مصر
-|Lionel Messi|FW|88|39|آرژانتین
-|Cristiano Ronaldo|FW|86|41|پرتغال
-|Karim Benzema|FW|82|38|فرانسه
-|Son Heung-min|FW|83|34|کره جنوبی"""
