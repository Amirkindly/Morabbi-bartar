package com.mmd.morabbi

// داده‌های ترجمه‌ی اضافه (نام باشگاه‌ها و متن‌های رابط)؛ توسط اسکریپت ساخته شده است.
internal const val X_LONG = """ساخت تیم اختصاصی؛ شروع از دسته دوم¦Create your own team (starts in Division 2)
رتبه‌بندی جهانی باشگاه‌ها¦World club rankings
رتبه‌بندی جهانی¦World rankings
ساخت تیم اختصاصی¦Create custom team
مثلاً ستاره تهران¦e.g. Setareh Tehran
سطح شروع¦Starting level
قدرت شروع حدود¦Starting strength about
تیم شما جایگزین ضعیف‌ترین تیم دسته دوم می‌شود؛ تعداد تیم‌های لیگ افزایش نمی‌یابد.¦Your team replaces the weakest Division 2 team; the number of league teams does not increase.
نام تیم را وارد کنید¦Enter a team name
این نام قبلاً استفاده شده است¦This name is already used
ساخت تیم و شروع بازی¦Create team & start playing
افتخارات لیگ برتر و جام حذفی؛ سپس قدرت تیم¦Top-flight league and cup titles, then team strength
بر اساس قدرت و اورال ترکیب¦Based on lineup strength & overall
مرکز مدیریت باشگاه¦Club management center
از نوار پایین برای ورود مستقیم به خانه، بازیکنان، بازار نقل‌وانتقالات، آکادمی و جدول لیگ استفاده کن.¦Use the bottom bar to jump straight to Home, Players, the Transfer market, the Academy and the league table.
رفتن به مسابقه¦Go to match
لیگ‌ها و رتبه‌بندی¦Leagues & rankings
آکادمی جوانان¦Youth academy
بازیکنان ۱۴ تا ۱۸ سال | هر فصل رشد می‌کنند و در ۱۸ سالگی به تیم اصلی می‌رسند.¦Players aged 14 to 18 | They grow every season and join the first team at 18.
تعداد استعدادها¦Number of talents
در حال حاضر بازیکنی در آکادمی نیست.¦There are no players in the academy right now.
استعداد ویژه¦Special talent
سیستم رشد¦Growth system
اورال شروع معمولاً ۵۵ تا ۷۰ است. بازیکن‌ها با هر فصل رشد می‌کنند؛ استعدادهای استثنایی ممکن است با اورال ۸۰ یا بیشتر وارد تیم اصلی شوند.¦Starting overall is usually 55 to 70. Players grow each season; exceptional talents may reach the first team with an overall of 80 or more.
ترکیب و بازیکنان¦Lineup & players
فیلتر پست¦Position filter
فیلتر سن¦Age filter
فیلتر اورال¦Rating filter
ترکیب و تاکتیک¦Lineup & tactics
بازیکن انتخاب‌شده¦Selected player
برای تغییر ترکیب، یک جایگاه روی زمین و سپس بازیکن ذخیره را لمس کن.¦To change the lineup, tap a spot on the pitch, then tap a substitute.
نمایش تیم‌ها¦Show teams
بستن لیست تیم‌ها¦Hide teams
نسل جدید¦New generation
فارغ‌التحصیل آکادمی¦Academy graduate
با اورال¦with OVR
جام حذفی انگلیس (FA Cup)¦English FA Cup
کوپا دل‌ری¦Copa del Rey
جام حذفی آلمان (DFB-Pokal)¦German Cup (DFB-Pokal)
کوپا ایتالیا¦Coppa Italia
جام حذفی فرانسه¦French Cup
جام حذفی پرتغال¦Portuguese Cup
جام حذفی هلند¦Dutch Cup (KNVB Cup)
کوپا دو برزیل¦Copa do Brasil
جام حذفی ترکیه¦Turkish Cup
کوپا آرژانتین¦Copa Argentina
جام حذفی ایران¦Hazfi Cup (Iran)
لیگ دو انگلیس¦League Two England
لیگ یک انگلیس¦League One England
لیگ یک ترکیه¦1. Lig Turkey
لیگ دو ترکیه¦2. Lig Turkey
سوپر لیگ ترکیه¦Turkish Super Lig
لیگا ۳¦3. Liga
سری بی برزیل¦Serie B Brazil
سری سی برزیل¦Serie C Brazil
ملی فرانسه¦National France
لیگ برتر پرتغال¦Primeira Liga
ارسته دیویسه¦Eerste Divisie
دسته سه اسپانیا¦Spain Tier 3
سری بی¦Serie B
سری سی¦Serie C"""
internal const val X_CLUBS1 = """پرسپولیس¦Persepolis
استقلال¦Esteghlal
سپاهان¦Sepahan
تراکتور¦Tractor
فولاد¦Foolad
گل‌گهر¦Gol Gohar
ملوان¦Malavan
ذوب‌آهن¦Zob Ahan
آلومینیوم اراک¦Aluminium Arak
شمس‌آذر¦Shams Azar
خیبر خرم‌آباد¦Khaybar Khorramabad
چادرملو¦Chadormalou
مس رفسنجان¦Mes Rafsanjan
نساجی¦Nassaji
پیکان¦Paykan
صنعت نفت آبادان¦Sanat Naft Abadan
سایپا¦Saipa
فجر سپاسی¦Fajr Sepasi
نفت مسجدسلیمان¦Naft Masjed Soleyman
هوادار¦Havadar
منچسترسیتی¦Manchester City
آرسنال¦Arsenal
لیورپول¦Liverpool
منچستریونایتد¦Manchester United
چلسی¦Chelsea
تاتنهام¦Tottenham
نیوکاسل یونایتد¦Newcastle United
استون ویلا¦Aston Villa
وستهم¦West Ham
برایتون¦Brighton
کریستال پالاس¦Crystal Palace
برنتفورد¦Brentford
فولام¦Fulham
اورتون¦Everton
ناتینگهام فارست¦Nottingham Forest
بورنموث¦Bournemouth
ولورهمپتون¦Wolverhampton
لسترسیتی¦Leicester City
ساوتهمپتون¦Southampton
ایپسویچ تاون¦Ipswich Town
رئال مادرید¦Real Madrid
بارسلونا¦Barcelona
اتلتیکو مادرید¦Atletico Madrid
اتلتیک بیلبائو¦Athletic Bilbao
رئال سوسیداد¦Real Sociedad
ویارئال¦Villarreal
رئال بتیس¦Real Betis
سویا¦Sevilla
والنسیا¦Valencia
خیرونا¦Girona
ختافه¦Getafe
اوساسونا¦Osasuna
سلتاویگو¦Celta Vigo
مایورکا¦Mallorca
لاس پالماس¦Las Palmas
رایو وایکانو¦Rayo Vallecano
آلاوس¦Alaves
گرانادا¦Granada
کادیس¦Cadiz
رئال وایادولید¦Real Valladolid
اینتر¦Inter
آث میلان¦AC Milan
یوونتوس¦Juventus
ناپولی¦Napoli
آتالانتا¦Atalanta
رم¦Roma
لاتزیو¦Lazio
فیورنتینا¦Fiorentina
بولونیا¦Bologna
تورینو¦Torino
مونزا¦Monza
اودینزه¦Udinese
جنوا¦Genoa
کالیاری¦Cagliari
امپولی¦Empoli
ورونا¦Verona
ساسولو¦Sassuolo
لچه¦Lecce
پارما¦Parma
کومو¦Como
بایرن مونیخ¦Bayern Munich
بروسیا دورتموند¦Borussia Dortmund
بایر لورکوزن¦Bayer Leverkusen
لایپزیگ¦RB Leipzig
اشتوتگارت¦Stuttgart
آینتراخت فرانکفورت¦Eintracht Frankfurt
وولفسبورگ¦Wolfsburg
فرایبورگ¦Freiburg
هوفنهایم¦Hoffenheim
وردربرمن¦Werder Bremen
آگزبورگ¦Augsburg
ماینتس¦Mainz
مونشن‌گلادباخ¦Monchengladbach
یونیون برلین¦Union Berlin
بوخوم¦Bochum
هایدنهایم¦Heidenheim
سن پائولی¦St. Pauli
هولشتاین کیل¦Holstein Kiel
هامبورگ¦Hamburg
هرتابرلین¦Hertha Berlin
پاری سن ژرمن¦Paris Saint-Germain
مارسی¦Marseille
موناکو¦Monaco
لیون¦Lyon
لیل¦Lille
نیس¦Nice
رن¦Rennes
لانس¦Lens
استراسبورگ¦Strasbourg
نانت¦Nantes
تولوز¦Toulouse
مون‌پلیه¦Montpellier
برست¦Brest
لوهاور¦Le Havre
متز¦Metz
لوریان¦Lorient
سن‌اتین¦Saint-Etienne
اوسر¦Auxerre
آنژه¦Angers
ریمز¦Reims
فلامینگو¦Flamengo
پالمیراس¦Palmeiras
سائوپائولو¦Sao Paulo
کورینتیانس¦Corinthians
سانتوس¦Santos
گرمیو¦Gremio
اینترناسیونال¦Internacional
اتلتیکو مینیرو¦Atletico Mineiro
فلومیننزه¦Fluminense
بوتافوگو¦Botafogo
کروزیرو¦Cruzeiro
واسکو دا گاما¦Vasco da Gama
باهیا¦Bahia
فورتالزا¦Fortaleza
براگانتی‌نو¦Bragantino
اتلتیکو پارانائنزه¦Athletico Paranaense
کویابا¦Cuiaba
ویتوریا¦Vitoria
گوییاس¦Goias
کوریتیبا¦Coritiba
گالاتاسرای¦Galatasaray
فنرباغچه¦Fenerbahce
بشیکتاش¦Besiktas
ترابزون‌اسپور¦Trabzonspor
باشاک‌شهیر¦Basaksehir
آدانا دمیرسپور¦Adana Demirspor
سیواس‌اسپور¦Sivasspor
کاسیم‌پاشا¦Kasimpasa
آلانیااسپور¦Alanyaspor
قونیه‌اسپور¦Konyaspor
قیصریه‌اسپور¦Kayserispor
آنتالیااسپور¦Antalyaspor
ریزه‌اسپور¦Rizespor
هاتای‌اسپور¦Hatayspor
غازی‌عنتاب¦Gaziantep FK
سامسون‌اسپور¦Samsunspor
ایوب‌اسپور¦Eyupspor
گوزتپه¦Goztepe
بودروم‌اسپور¦Bodrumspor
کوجائلی‌اسپور¦Kocaelispor
بوکا جونیورز¦Boca Juniors
ریور پلاته¦River Plate
ایندیپندینته¦Independiente
راسیینگ کلاب¦Racing Club
سن لورنزو¦San Lorenzo
استودیانتس¦Estudiantes
لانوس¦Lanus
ولز سارسفیلد¦Velez Sarsfield
روساریو سنترال¦Rosario Central
نیوولز اولد بویز¦Newell's Old Boys
تالرز¦Talleres
آرژنتینوس جونیورز¦Argentinos Juniors
دفاع و خوستیسیا¦Defensa y Justicia
بلگرانو¦Belgrano
هوراکان¦Huracan
پلاتنسه¦Platense
گودوی کروز¦Godoy Cruz
بانفیلد¦Banfield
تایرس¦Tigre
اتلتیکو توکومان¦Atletico Tucuman
بنفیکا¦Benfica
پورتو¦Porto
اسپورتینگ لیسبون¦Sporting CP
براگا¦Braga
ویتوریا گیمارش¦Vitoria Guimaraes
موریرنزه¦Moreirense
فامالیکائو¦Famalicao
آروکا¦Arouca
ژیل ویسنته¦Gil Vicente
ریو آوه¦Rio Ave
بوآویشتا¦Boavista
اشتوریل¦Estoril
کاسا پیا¦Casa Pia
فارنسه¦Farense
ناسیونال¦Nacional
سانتا کلارا¦Santa Clara
چاوز¦Chaves
پورتیموننزه¦Portimonense
پاکوش فریرا¦Pacos de Ferreira
توندلا¦Tondela
آژاکس¦Ajax
پی‌اس‌وی آیندهوون¦PSV Eindhoven
فاینورد¦Feyenoord
آلکمار¦AZ Alkmaar
توئنته¦Twente
اوترخت¦Utrecht
گو اهد ایگلز¦Go Ahead Eagles
اسپارتا روتردام¦Sparta Rotterdam
هیرنفین¦Heerenveen
نایمخن¦NEC Nijmegen
فورتونا سیتارد¦Fortuna Sittard
هراکلز¦Heracles
زووله¦Zwolle
ویلم دوم¦Willem II
گرونینگن¦Groningen
والویک¦Waalwijk
اکسلسیور¦Excelsior
کامبور¦Cambuur
دن هاخ¦Den Haag
بردا¦Breda
مس کرمان¦Mes Kerman
مس شهربابک¦Mes Shahr-e Babak
مس سونگون¦Mes Sungun
پارس جنوبی جم¦Pars Jonoubi Jam
داماش گیلان¦Damash Gilan
چوکا تالش¦Chooka Talesh
نیروی زمینی¦Niroye Zamini
استقلال ملاثانی¦Esteghlal Molasani
آریو اسلامشهر¦Arya Eslamshahr
سپیدرود رشت¦Sepidrood Rasht
پاس همدان¦Pas Hamedan
شاهین بوشهر¦Shahin Bushehr
ماشین‌سازی تبریز¦Machine Sazi Tabriz
گیتی‌پسند¦Gity Pasand
نفت و گاز گچساران¦Naft va Gaz Gachsaran
شهرداری آستارا¦Shahrdari Astara
فولاد نوین¦Foolad Novin
ایرانجوان بوشهر¦Iranjavan Bushehr
شهرداری نوشهر¦Shahrdari Nowshahr
لیدز یونایتد¦Leeds United
برنلی¦Burnley
شفیلد یونایتد¦Sheffield United
وست برومویچ¦West Bromwich
نوریچ سیتی¦Norwich City"""
internal const val X_CLUBS2 = """میدلزبرو¦Middlesbrough
کاونتری سیتی¦Coventry City
ساندرلند¦Sunderland
واتفورد¦Watford
بلاکبرن روورز¦Blackburn Rovers
بولتون واندررز¦Bolton Wanderers
چارلتون اتلتیک¦Charlton Athletic
دربی کانتی¦Derby County
پورتسموث¦Portsmouth
ردینگ¦Reading
ویگان اتلتیک¦Wigan Athletic
بارنزلی¦Barnsley
لوتون تاون¦Luton Town
هال سیتی¦Hull City
پلیموث آرگایل¦Plymouth Argyle
لگانس¦Leganes
اسپانیول¦Espanyol
رئال اویدو¦Real Oviedo
لوانته¦Levante
الچه¦Elche
ایبار¦Eibar
تنریف¦Tenerife
زاراگوزا¦Zaragoza
اسپورتینگ خیخون¦Sporting Gijon
بورگوس¦Burgos
آلباسته¦Albacete
هوئسکا¦Huesca
میراندس¦Mirandes
کوردوبا¦Cordoba
دپورتیوو لاکرونیا¦Deportivo La Coruna
مالاگا¦Malaga
کاستیون¦Castellon
راسینگ سانتاندر¦Racing Santander
ویارئال ب¦Villarreal B
آندورا¦Andorra
سمپدوریا¦Sampdoria
پالرمو¦Palermo
کرمونزه¦Cremonese
ونتزیا¦Venezia
پیزا¦Pisa
کاتانزارو¦Catanzaro
برشا¦Brescia
مودنا¦Modena
رجیانا¦Reggiana
باری¦Bari
چزنا¦Cesena
اسپتزیا¦Spezia
ترنانا¦Ternana
آسکولی¦Ascoli
پروجا¦Perugia
پادوا¦Padova
ویچنزا¦Vicenza
آولینو¦Avellino
کروتونه¦Crotone
مانتوا¦Mantova
شالکه ۰۴¦Schalke 04
هانوفر ۹۶¦Hannover 96
فورتونا دوسلدورف¦Fortuna Dusseldorf
پادربورن¦Paderborn
کارلسروهه¦Karlsruhe
نورنبرگ¦Nuremberg
کایزرسلاوترن¦Kaiserslautern
مگدبورگ¦Magdeburg
دارمشتات¦Darmstadt
دینامو درسدن¦Dynamo Dresden
آلمانیا آخن¦Alemannia Aachen
اسن¦Essen
وهن ویسبادن¦Wehen Wiesbaden
یان رگنسبورگ¦Jahn Regensburg
ساندهاوزن¦Sandhausen
انرژی کوتبوس¦Energie Cottbus
هانزا روستوک¦Hansa Rostock
بوردو¦Bordeaux
سنت‌اتین¦Saint-Etienne
اوکسر¦Auxerre
کاین¦Caen
گنگام¦Guingamp
آمیان¦Amiens
پاری اف‌سی¦Paris FC
گرونوبل¦Grenoble
بستیا¦Bastia
تروا¦Troyes
والنسین¦Valenciennes
دانکرک¦Dunkerque
رد استار¦Red Star
نانسی¦Nancy
سوشو¦Sochaux
لو مان¦Le Mans
اورلئان¦Orleans
بولون¦Boulogne
شاتورو¦Chateauroux
اسپورت رسیف¦Sport Recife
سیارا¦Ceara
آمریکا مینیرو¦America Mineiro
آوای¦Avai
پونته پرتا¦Ponte Preta
گوارانی¦Guarani
ویلا نوا¦Vila Nova
نووتیزونتینو¦Novorizontino
میراسول¦Mirassol
کریسیوما¦Criciuma
ژوونتوده¦Juventude
اتلتیکو گویانینسه¦Atletico Goianiense
ناوتیکو¦Nautico
پارانا¦Parana
لوندرینا¦Londrina
سنتا کروز¦Santa Cruz
اوپراتاریو¦Operario
ارزوروم‌اسپور¦Erzurumspor
آلتای¦Altay
گنچلربیرلیغی¦Genclerbirligi
بولوسپور¦Boluspor
آدناسپور¦Adanaspor
آمد اسپور¦Amed Spor
ساکاریاسپور¦Sakaryaspor
چوروم اف‌کی¦Corum FK
اومرانیه‌اسپور¦Umraniyespor
کچی‌اورنگوچو¦Keciorengucu
باندیرماسپور¦Bandirmaspor
شانلی‌اورفا¦Sanliurfaspor
دنیزلی‌اسپور¦Denizlispor
اسکی‌شهیرسپور¦Eskisehirspor
کاراگومروک¦Karagumruk
مانیساسپور¦Manisaspor
وان‌اسپور¦Vanspor
کویلمس¦Quilmes
فرروکاریل اوئسته¦Ferro Carril Oeste
چاکاریتا جونیورز¦Chacarita Juniors
سان مارتین توکومان¦San Martin de Tucuman
سان مارتین سن خوان¦San Martin de San Juan
آرسنال ساراندی¦Arsenal de Sarandi
آلماگرو¦Almagro
آتلتیکو رافائلا¦Atletico Rafaela
دپورتیوو مورون¦Deportivo Moron
پاتروناتو¦Patronato
آلدو‌سیوی¦Aldosivi
گیلرمو براون¦Guillermo Brown
آگروپکواریو¦Agropecuario
براون آدرگه¦Brown de Adrogue
تیمپلی¦Temperley
دیفنسورز¦Defensores
کلون سانتا فه¦Colon de Santa Fe
سنترال کوردوبا¦Central Cordoba
آکادمیکا کویمبرا¦Academica Coimbra
پنافیل¦Penafiel
لایشوئش¦Leixoes
فیرنزه¦Fiaes
ماریتیمو¦Maritimo
فارو¦Faro
ویلافرانکنزه¦Vilafranquense
پورتو بی¦Porto B
بنفیکا بی¦Benfica B
اسپورتینگ بی¦Sporting B
آکادمیکو ویزئو¦Academico Viseu
اولیوییرنزه¦Oliveirense
مافرا¦Mafra
وارزیم¦Varzim
فلگوئیراس¦Felgueiras
آلورکا¦Alverca
رودا جی‌سی¦Roda JC
دی گرافشاپ¦De Graafschap
ناک بردا¦NAC Breda
ام‌وی‌وی ماستریخت¦MVV Maastricht
تلستار¦Telstar
دوردراخت¦Dordrecht
اف‌سی آیندهوون¦FC Eindhoven
هلموند اسپورت¦Helmond Sport
دن بوش¦Den Bosch
آلمره سیتی¦Almere City
ونلو¦VVV-Venlo
اوس¦Oss
یانگ آژاکس¦Jong Ajax
یانگ پی‌اس‌وی¦Jong PSV
یانگ اوترخت¦Jong Utrecht
اسپورت¦Sport
اتلتیکو¦Atletico
آمریکا¦America
گوارانی¦Guarani
اونیاو¦Uniao
ایتوانو¦Ituano
ناسیونال¦Nacional
رئال¦Real
ریو¦Rio
سائوپائولو¦Sao Paulo
کوریتیبا¦Curitiba
سالوادور¦Salvador
رسیف¦Recife
بلو هوریزونته¦Belo Horizonte
مانائوس¦Manaus
بلم¦Belem
گویانیا¦Goiania
فلوریانوپولیس¦Florianopolis
ینی¦Yeni
بلدیه¦Belediye
گنج¦Genc
اتلتیک¦Atletik
آنادولو¦Anadolu
دمیر¦Demir
بورسا¦Bursa
ازمیر¦Izmir
مالاتیا¦Malatya
مرسین¦Mersin
دیاربکر¦Diyarbakir
ترابزون¦Trabzon
سامسون¦Samsun
اردو¦Ordu
ایسپارتا¦Isparta
آدیامان¦Adiyaman
سان¦San
کلوب¦Club
دپورتیوو¦Deportivo
سنترال¦Central
یونیون¦Union
مندوسا¦Mendoza
سالتا¦Salta
کوردوبا¦Cordoba
لاپلاتا¦La Plata
ویلا¦Villa
خوخوی¦Jujuy
نیوکن¦Neuquen
ریسیستنسیا¦Resistencia
اسپورتیو¦Sporting
گرمیو¦Gremio
یونیائو¦Uniao
ویزئو¦Viseu
لیریا¦Leiria
اوئیراش¦Oeiras
ماتوزینیوش¦Matosinhos
سیتوبال¦Setubal
پورتالگره¦Portalegre
لاگوش¦Lagos
آویرو¦Aveiro
اف‌سی¦FC
فورتونا¦Fortuna
ویتسه¦Vitesse
اس‌سی¦SC
وی‌وی‌وی¦VVV
لیدن¦Leiden
هارلم¦Haarlem
بریدا¦Breda
ماستریخت¦Maastricht
دلفت¦Delft
آمستردام¦Amsterdam
روتردام¦Rotterdam
زوله¦Zwolle"""
internal const val X_SHORT = """سال¦yrs
سالگی¦years old
تا¦to
زیر¦Under
به بالا¦and above
جوان¦Youth
بازگشت¦Back
خانه¦Home
بازار¦Market
آکادمی¦Academy
افتخارات¦Honours
ملیت¦Nationality
ملیت‌ها¦nationalities
قدرت‌ها¦ratings
سنین¦ages
همه¦All
اورال¦OVR
پتانسیل¦Potential
شد¦
جایگزین¦replaces
نمایش¦Showing
بازیکن¦players
نروژ¦Norway
بلژیک¦Belgium
مصر¦Egypt
لهستان¦Poland
پرتغال¦Portugal
هلند¦Netherlands
اروگوئه¦Uruguay
کرواسی¦Croatia
سوئد¦Sweden
مجارستان¦Hungary
کامرون¦Cameroon
اسلوونی¦Slovenia
اکوادور¦Ecuador
اسکاتلند¦Scotland
مراکش¦Morocco
کره جنوبی¦South Korea
کانادا¦Canada
اتریش¦Austria
کلمبیا¦Colombia
نیجریه¦Nigeria
گرجستان¦Georgia
صربستان¦Serbia
آمریکا¦USA
سوئیس¦Switzerland
غنا¦Ghana
گینه¦Guinea
ژاپن¦Japan
چک¦Czechia
گابن¦Gabon
روسیه¦Russia
یونان¦Greece
بورکینافاسو¦Burkina Faso
فنلاند¦Finland
ساحل عاج¦Ivory Coast
بوسنی¦Bosnia
اوکراین¦Ukraine
الجزایر¦Algeria
پاراگوئه¦Paraguay
سنگال¦Senegal
نیوزیلند¦New Zealand
ارمنستان¦Armenia
کوزوو¦Kosovo
اسلواکی¦Slovakia
دانمارک¦Denmark
ذخیره‌ها¦Substitutes
آرایش تیم¦Formation
فارسی¦Persian
جام حذفی¦Cup
کریستیانو¦Cristiano
برونو¦Bruno
ژوائو¦Joao
ممفیس¦Memphis
فریرا¦Ferreira
رافائل¦Rafael
گونچالو¦Goncalo
کاروالیو¦Carvalho
دیپای¦Depay
فن‌دایک¦Van Dijk
دی‌یونگ¦De Jong
گاکپو¦Gakpo
ژاوی¦Xavi
کودی¦Cody
آکه¦Ake
مالن¦Malen
بروبی¦Brobbey
سیمونز¦Simons
فرنکی¦Frenkie
ماتیاس¦Matthijs
دانی¦Danny
یورین¦Jurrien
استیون¦Steven
اردیویسه¦Eredivisie"""
