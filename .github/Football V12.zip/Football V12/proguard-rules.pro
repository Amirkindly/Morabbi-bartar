# قوانین R8 — برنامه از reflection استفاده نمی‌کند و org.json بخشی از اندروید است.
-dontwarn org.jetbrains.annotations.**
