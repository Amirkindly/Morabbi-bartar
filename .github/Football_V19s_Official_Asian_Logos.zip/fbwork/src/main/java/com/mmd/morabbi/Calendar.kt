package com.mmd.morabbi

import kotlin.random.Random

// ======================= تقویم یکپارچه فصل (۵۲ هفته) =======================
// هفته‌های ۱ تا ۳۸: لیگ داخلی (آخر هفته) + بازی‌های میان‌هفته جام حذفی / لیگ قهرمانان
// هفته‌های پایانی ابتدا برای مراحل حذفی داخلی/جهانی و سپس ۷ هفته مستقل جام قهرمانان آسیا رزرو می‌شوند.
// اگر تیم کاربر از جام یا لیگ قهرمانان حذف شده باشد (یا در آن نباشد)، در هفته‌های آن رقابت استراحت می‌کند.
// نکته: شماره‌های داخلی از ۰ شروع می‌شوند؛ در نمایش به کاربر یکی اضافه می‌شود (G.week + 1).
object Cal {
    const val MIN_WEEKS = 45
    const val FINAL_BLOCK = 7

    // بیشترین تعداد هفته‌های لیگ بین همه لیگ‌ها (برای ۲۰ تیم = ۳۸)
    fun leagueRounds(): Int {
        var best = 0
        for (lg in G.leagues) {
            val n = G.teams.count { it.leagueId == lg.id }
            val m = if (n % 2 == 0) n else n + 1
            val w = 2 * (m - 1)
            if (w > best) best = w
        }
        return best
    }

    private fun domesticWorldTotal(): Int = maxOf(MIN_WEEKS, leagueRounds() + FINAL_BLOCK)
    // هفت هفته پایانی پس از پایان تمام مسابقات داخلی و لیگ قهرمانان جهان، فقط برای جام آسیا
    fun total(): Int = domesticWorldTotal() + 7
    fun blockStart(): Int = domesticWorldTotal() - FINAL_BLOCK
    fun asianWeek(round: Int): Int = domesticWorldTotal() + round.coerceIn(0, 6)

    // لیگ قهرمانان: مرحله لیگ ۱۱ هفته (هر ۳ هفته یک‌بار): ۲، ۵، ... ، ۳۲
    fun clLeagueWeek(round: Int): Int = 2 + 3 * round

    // مراحل حذفی لیگ قهرمانان: پلی‌آف، یک‌هشتم، یک‌چهارم، نیمه‌نهایی، فینال
    fun clKoWeek(stage: Int): Int {
        val offsets = intArrayOf(0, 1, 3, 5, 6)
        return blockStart() + offsets[stage.coerceIn(0, 4)]
    }

    // جام حذفی: سه دور مقدماتی (۱، ۴، ۷)
    fun cupQualWeek(round: Int): Int = 1 + 3 * round

    // جام حذفی: دورهای اصلی (۱۰، ۱۹، ۲۸، نیمه‌نهایی و فینال در بلوک پایانی)
    fun cupMainWeek(round: Int): Int = when {
        round <= 0 -> 10
        round == 1 -> 19
        round == 2 -> 28
        round == 3 -> blockStart() + 2
        else -> blockStart() + 4
    }

    // شماره هفته برای نمایش به کاربر (۱ تا ۵۲)
    fun show(week: Int): Int = week + 1
}

// ======================= مسابقات حذفی (پنالتی و ثبت نتیجه) =======================

fun shootoutSuffix(m: MatchRes): String =
    if (m.penH >= 0 && m.penA >= 0) " (پنالتی ${m.penH}-${m.penA})" else ""

// ضربات پنالتی بعد از تساوی در مسابقه حذفی (۵ ضربه برای هر تیم، سپس ضربه‌های تک‌به‌تک)
fun resolveShootout(m: MatchRes) {
    if (m.penH >= 0) return
    val diff = (strengthOf(m.h) - strengthOf(m.a)) * 0.004
    val ph = (0.74 + diff).coerceIn(0.62, 0.86)
    val pa = (0.74 - diff).coerceIn(0.62, 0.86)
    var h = 0
    var a = 0
    repeat(5) {
        if (Random.nextDouble() < ph) h++
        if (Random.nextDouble() < pa) a++
    }
    var guard = 0
    while (h == a && guard < 30) {
        if (Random.nextDouble() < ph) h++
        if (Random.nextDouble() < pa) a++
        guard++
    }
    if (h == a) { if (Random.nextBoolean()) h++ else a++ }
    m.penH = h
    m.penA = a
    m.ev = (m.ev + Ev(90, "🥅 ضربات پنالتی: ${m.h.name} $h - $a ${m.a.name}", 2)).sortedBy { it.min }
}

fun addUserMatchReport(label: String, m: MatchRes) {
    G.report.add("$label: ${m.h.name}  ${m.hg} - ${m.ag}  ${m.a.name}${shootoutSuffix(m)}")
    for (e in m.ev) if (e.side < 2) G.report.add("${e.min}' ${e.text}")
}

// اجرای مجموعه‌ای از مسابقات حذفی یک دور.
// - مسابقه‌های غیرکاربر همان لحظه شبیه‌سازی می‌شوند.
// - اگر live = true و تیم کاربر بازی دارد، بازی زنده به صف بازی‌های هفته اضافه می‌شود و
//   نتیجه دور (onDone) بعد از پایان بازی زنده نهایی می‌شود؛ اگر زنده نباشد همه چیز همان لحظه تمام می‌شود.
// - onTie برای ثبت نتیجه هر مسابقه (لاگ/تاریخچه) و onDone با فهرست برندگان صدا زده می‌شود.
fun runKnockoutTies(
    ties: List<Pair<Team, Team>>,
    label: String,
    live: Boolean,
    onTie: (Team, Team, MatchRes, Team) -> Unit,
    onDone: (List<Team>) -> Unit
) {
    val winners = arrayOfNulls<Team>(ties.size)
    var userMatch: MatchRes? = null
    var userIdx = -1
    for ((i, tie) in ties.withIndex()) {
        val h = tie.first
        val a = tie.second
        val isUser = h.id == G.userTeam || a.id == G.userTeam
        if (isUser && live) {
            val m = playMatch(h, a, live = true, deferTableUpdate = true)
            m.knockout = true
            m.tag = label
            userMatch = m
            userIdx = i
            G.report.add("$label: ${h.name}  0 - 0  ${a.name}")
        } else {
            val m = playMatch(h, a, live = false, deferTableUpdate = true)
            m.knockout = true
            if (m.hg == m.ag) resolveShootout(m)
            val w = m.winner()
            winners[i] = w
            onTie(h, a, m, w)
            if (isUser) addUserMatchReport(label, m)
        }
    }
    val um = userMatch
    if (um == null) {
        onDone(winners.filterNotNull())
        return
    }
    val idx = userIdx
    um.onFinal = { fm ->
        val w = fm.winner()
        winners[idx] = w
        onTie(fm.h, fm.a, fm, w)
        onDone(winners.filterNotNull())
    }
    G.liveQueue.add(um)
}

fun logMatchW(comp: String, week1: Int, h: Team, a: Team, hg: Int, ag: Int) {
    G.matchLog.add(MatchRec(G.season, week1, compIdx(comp), h.id, a.id, hg, ag))
}

// ======================= برنامه این هفته برای تیم کاربر =======================

fun userWeekPlan(): List<String> {
    val out = ArrayList<String>()
    val wk = G.week
    cupPlanLine(wk)?.let { out.add(it) }
    worldCupPlanLine(wk)?.let { out.add(it) }
    asianCupPlanLine(wk)?.let { out.add(it) }
    return out
}
