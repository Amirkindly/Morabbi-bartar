package com.mmd.morabbi

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit

object I18n {
    var lang by mutableStateOf("fa")
    // کش با سقف مشخص تا با نام بازیکنان بی‌نهایت بزرگ نشود
    private val cache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 3000
    }

    fun changeLang(l: String) {
        cache.clear()
        lang = l
    }

    private fun parse(raw: String): List<Pair<String, String>> =
        raw.split("\n").filter { it.contains("¦") }.map {
            val i = it.indexOf("¦")
            Pair(it.substring(0, i), it.substring(i + 1))
        }

    private val phrases: List<Pair<String, String>> by lazy { parse(PH_RAW).sortedByDescending { it.first.length } }
    private val words: Map<String, String> by lazy { parse(W_RAW).toMap() }
    // ترجمه‌ی با مرز واژه برای نام باشگاه‌ها و جمله‌های رابط (قبل از عبارت‌های عمومی اعمال می‌شود)
    private val xLong: Map<String, String> by lazy { parse(X_LONG + "\n" + X_CLUBS1 + "\n" + X_CLUBS2 + "\n" + X_CLUBS3).toMap() }
    private val xShort: Map<String, String> by lazy { parse(X_SHORT).toMap() }
    private fun boundRe(keys: Collection<String>): Regex {
        val alt = keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        return Regex("(?<![\u0621-\u06FF\u200C])(?:$alt)(?![\u0621-\u06FF\u200C])")
    }
    private val xLongRe: Regex by lazy { boundRe(xLong.keys) }
    private val xShortRe: Regex by lazy { boundRe(xShort.keys) }

    private val tl = mapOf(
        'ا' to "a", 'آ' to "a", 'ب' to "b", 'پ' to "p", 'ت' to "t", 'ث' to "s", 'ج' to "j", 'چ' to "ch", 'ح' to "h",
        'خ' to "kh", 'د' to "d", 'ذ' to "z", 'ر' to "r", 'ز' to "z", 'ژ' to "zh", 'س' to "s", 'ش' to "sh", 'ص' to "s",
        'ض' to "z", 'ط' to "t", 'ظ' to "z", 'ع' to "", 'غ' to "gh", 'ف' to "f", 'ق' to "q", 'ک' to "k", 'ك' to "k",
        'گ' to "g", 'ل' to "l", 'م' to "m", 'ن' to "n", 'و' to "o", 'ه' to "e", 'ة' to "e", 'ی' to "i", 'ي' to "i",
        'ئ' to "e", 'ء' to "", '\u200C' to ""
    )
    private val vowels = setOf('ا', 'آ', 'و', 'ی', 'ي', 'ع', 'ء', 'ئ', 'ه')

    // آوانگاری ساده برای هر واژه‌ی فارسی که در فرهنگ‌لغت نیست (تا هیچ متن فارسی در حالت انگلیسی نماند)
    private fun translit(w: String): String {
        val sb = StringBuilder()
        var prevCons = false
        for ((i, c) in w.withIndex()) {
            var piece = tl[c] ?: continue
            if (c == 'و' && i == 0) piece = "v"
            if (c == 'ی' && i == 0) piece = "y"
            if (c == 'ه' && i < w.length - 1) piece = "h"
            val isCons = c !in vowels
            if (isCons && prevCons && piece.isNotEmpty()) sb.append('a')
            sb.append(piece)
            if (piece.isNotEmpty()) prevCons = isCons
        }
        val r = sb.toString()
        return if (r.isEmpty()) w else r.replaceFirstChar { it.uppercaseChar() }
    }

    private val wordRe = Regex("[\u0621-\u064A\u067E\u0686\u0698\u06A9\u06AF\u06CC\u200C]+")

    private fun hasFa(s: String): Boolean {
        for (c in s) if (c.code in 0x0600..0x06FF) return true
        return false
    }

    fun tr(s: String): String {
        if (lang == "fa") return s
        cache[s]?.let { return it }
        if (!hasFa(s)) return s
        var r = s.filter { it.code !in 0x064B..0x0652 }
        r = xLongRe.replace(r) { m -> xLong[m.value] ?: m.value }
        for ((k, v) in phrases) if (r.contains(k)) r = r.replace(k, v)
        r = xShortRe.replace(r) { m -> xShort[m.value] ?: m.value }
        r = wordRe.replace(r) { m -> words[m.value] ?: translit(m.value) }
        val sb = StringBuilder()
        for (c in r) {
            sb.append(
                when (c) {
                    in '\u06F0'..'\u06F9' -> ('0' + (c - '\u06F0'))
                    '\u060C' -> ','
                    '\u061F' -> '?'
                    else -> c
                }
            )
        }
        val out = sb.toString()
        cache[s] = out
        return out
    }
}

@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE
) {
    androidx.compose.material3.Text(
        I18n.tr(text), modifier = modifier, color = color, fontSize = fontSize,
        fontWeight = fontWeight, textAlign = textAlign, maxLines = maxLines
    )
}

private const val PH_RAW = """آزاد کردن بازیکن (حداقل ۱۵ نفر باید بماند)¦Release a player (at least 15 must remain)
آقای گل¦Top scorer
ارزش کل: ¦Total value: 
اطلاعات ناقص است¦Incomplete information
اعمال تغییرات (فصل از اول شروع می‌شود)¦Apply changes (season restarts)
اعمال شد¦Applied
افزودن بازیکن دستی:¦Add a player manually:
افزودن بازیکن¦Add player
افزودن لیگ جدید¦Add new league
انتخاب لوگو از حافظه گوشی¦Choose logo from phone
این بازیکن دیگر در تیم شما نیست¦This player is no longer on your team
این لیگ قابل حذف نیست (تنها لیگ یا شامل تیم شما)¦This league cannot be deleted (only league or contains your team)
این هفته استراحت دارید¦You have a rest this week
بازی بعدی¦Next match
بازی زنده¦Live match
بازیکن اضافه شد¦Player added
بازیکنان (¦Players (
باشگاه خریدار بودجه ندارد¦The buying club has no budget
بودجه کافی نیست¦Not enough budget
بودجه: ¦Budget: 
تاکتیک و ترکیب¦Tactics & lineup
ترکیب خودکار¦Auto lineup
تعداد بازیکن هر تیم¦Players per team
تعداد بازیکنان¦Squad size
تعداد تیم صعود/سقوط¦Promotion/relegation teams
تعداد تیم هر لیگ¦Teams per league
تنظیمات کلی¦General settings
تیم خود را انتخاب کنید¦Choose your team
تیم فروشنده این بازیکن را نمی‌فروشد¦The selling team will not sell this player
جستجوی نام بازیکن¦Search player name
حداقل ۱۵ بازیکن لازم است¦At least 15 players are required
حذف این تیم¦Delete this team
حذف تیم ¦Delete team 
حذف لیگ¦Delete league
دسته یک¦Division 1
دسته دو¦Division 2
دسته سه¦Division 3
لیگ برتر انگلیس¦English Premier League
چمپیونشیپ انگلیس¦English Championship
لیگ ۱ فرانسه¦Ligue 1 (France)
لیگ برتر¦Premier League
لالیگا¦La Liga
سری آ¦Serie A
بوندسلیگا¦Bundesliga
دو نیمه¦Halves
راه‌راه¦Striped
رتبه شما: ¦Your rank: 
رتبه‌بندی لیگ¦League table
رتبه‌بندی کلی¦Overall ranking
رمز ادمین¦Admin password
رمز اشتباه است¦Wrong password
رنگ اصلی¦Main color
رنگ دوم¦Second color
ساخت بازیکن تصادفی بر اساس کشور:¦Generate random players by country:
ساخت بازیکنان تصادفی¦Generate random players
ساخت مجدد کل بازیکنان این تیم¦Regenerate all players of this team
سبز: صعود | قرمز: سقوط | زرد: تیم شما¦Green: promotion | Red: relegation | Yellow: your team
سبک بازی¦Play style
سرعت: ¦Speed: 
سطح سختی¦Difficulty
سقف تعداد بازیکنان پر است¦Squad limit reached
شبیه‌سازی تا پایان فصل¦Simulate to end of season
شروع بازی جدید (حذف همه‌چیز)¦New game (delete everything)
شروع بازی جدید؟¦Start a new game?
شروع دوباره فصل (ریست جدول‌ها)¦Restart season (reset tables)
همه اطلاعات فعلی پاک می‌شود.¦All current data will be erased.
ذخیره نام¦Save name
نام تیم من¦My team name
نام تیم¦Team name
نام بازیکن¦Player name
نام لیگ¦League name
نتایج فصل قبل¦Last season results
نقل و انتقالات¦Transfers
نیمه اول¦First half
نیمه دوم¦Second half
هنوز خبری نیست. پس از پایان هر فصل بازار نقل و انتقالات باز می‌شود.¦No news yet. The transfer market opens after each season.
هنوز فصلی تمام نشده است.¦No season has finished yet.
ورود به پنل ادمین¦Enter admin panel
ویرایش تیم¦Edit team
پنل ادمین¦Admin panel
پایان بازی¦Full time
پایان فصل و شروع فصل بعد¦End season & start next
پیشنهادی برای بازیکنان شما نیست.¦No offers for your players.
کشور تیم¦Team country
کشور لیگ (برای نام بازیکنان جدید):¦League country (for new player names):
لیگ تیم¦Team league
گزارش آخرین بازی¦Last match report
لوگوی خودکار (بر اساس رنگ تیم)¦Auto logo (from team colors)
لیست بازیکنان¦Player list
لیگ سطح ¦League level 
مجموع: ¦Total: 
مقدار نامعتبر (تیم: ۲ تا ۴۰ | بازیکن: ۱۶ تا ۴۰)¦Invalid value (teams: 2-40 | players: 16-40)
مربی برتر¦Top Coach
قهرمان لیگ شما: ¦Your league champion: 
⏩ رفتن به پایان بازی¦⏩ Skip to full time
⏸ پایان نیمه اول¦⏸ Half time
▶️ بازی زنده - هفته ¦▶️ Live match - week 
▶️ سوت شروع بازی¦▶️ Kick-off
⚙️ تنظیمات¦⚙️ Settings
⚡ شبیه‌سازی سریع هفته ¦⚡ Quick sim week 
⚽ بازی¦⚽ Play
⚽ گل! ¦⚽ GOAL! 
🌍 رتبه‌بندی کلی¦🌍 Overall ranking
🏁 سوت پایان بازی¦🏁 Full time whistle
🏆 رتبه‌بندی لیگ¦🏆 League table
🏆 لیگ کشور ¦🏆 League of 
👥 بازیکنان¦👥 Players
💰 نقل و انتقالات (¦💰 Transfers (
💰 نقل و انتقالات¦💰 Transfers
📋 تاکتیک و ترکیب¦📋 Tactics & lineup
🔢 تعداد بازیکنان¦🔢 Squad size
📢 پنجره نقل و انتقالات فصل ¦📢 Transfer window open - season 
 باز شد¦
🔥 موقعیت خطرناک برای ¦🔥 Dangerous chance for 
🟨 کارت زرد برای ¦🟨 Yellow card for 
🧤 واکنش زیبای دروازه‌بان ¦🧤 Great save by the keeper of 
💨 شوت ¦💨 Shot by 
 به بیرون رفت¦ goes wide
 پیشنهاد)¦ offers)
پیشنهادها (¦Offers (
 بازیکن ساخته شد¦ players generated
کل بازیکنان با کشور ¦All players regenerated for country 
 ساخته شد¦
 تمام شد!¦ is over!
 خریداری شد¦ purchased
 فروخته شد¦ sold
 نفر (حداکثر ¦ players (max 
 گل)¦ goals)
 تیم)¦ teams)
+ تیم¦+ Team
 | آقای گل: ¦ | Top scorer: 
 | ارزش ¦ | Value 
 | امتیاز ¦ | Pts 
 | بازیکنان: ¦ | Players: 
 | گل ¦ | Goals 
  |  مدافع: ¦  |  Defenders: 
  |  مهاجم: ¦  |  Forwards: 
 | میانگین قدرت: ¦ | Avg strength: 
میانگین سن: ¦Avg age: 
دروازه‌بان: ¦Goalkeepers: 
هافبک: ¦Midfielders: 
: قهرمان ¦: Champion 
 - سطح ¦ - Level 
 - فصل ¦ - Season 
 | فصل ¦ | Season 
 - هفته ¦ - Week 
صعود به ¦Promoted to 
سقوط به ¦Relegated to 
مبدا: ¦From: 
مقصد: ¦To: 
بازار آزاد¦free agents
 ← ¦  →  
بازیکنان انتخابی: ¦Selected players: 
/11 (کمبود به‌صورت خودکار پر می‌شود)¦/11 (missing slots are filled automatically)
، ¦, 
؟¦?"""

private const val W_RAW = """آزاد¦Release
آسان¦Easy
اخبار¦News
برد¦W
باخت¦L
مس¦D
مسابقه¦P
بازی¦Play
بازیکن¦players
بازیکنان¦Players
بله¦Yes
تأیید¦OK
تاریخچه¦History
تعداد¦Count
تنظیمات¦Settings
تهاجمی¦Attacking
تیم¦Team
تیم‌ها¦Teams
جدول¦Table
حذف¦Delete
خرید¦Buy
دفاعی¦Defensive
رد¦Reject
رمز¦Password
ساده¦Plain
سخت¦Hard
سن¦Age
فروش¦Sell
قدرت¦Strength
لغو¦Cancel
متعادل¦Balanced
متوسط¦Medium
نام¦Name
همه¦All
ورود¦Login
پیراهن¦Kit
پیشنهادها¦Offers
کمربند¦Sash
گلزنان¦Scorers
هفته¦Week
فصل¦Season
گل¦goals
فرمیشن¦Formation
لوگو¦Logo
از¦of
به¦to
باشگاه¦Club
سطح¦Level
لیگ¦League
کشور¦Country
بودجه¦Budget
زبان¦Language
هزار¦K
میلیون¦M
پیوست¦joined
امتیاز¦Pts
قهرمان¦Champion
ایران¦Iran
انگلیس¦England
اسپانیا¦Spain
ایتالیا¦Italy
آلمان¦Germany
فرانسه¦France
برزیل¦Brazil
آرژانتین¦Argentina
ترکیه¦Turkey
علی¦Ali
رضا¦Reza
مهدی¦Mehdi
حسین¦Hossein
امیر¦Amir
سعید¦Saeed
پوریا¦Pouria
کاوه¦Kaveh
احمدی¦Ahmadi
رضایی¦Rezaei
کریمی¦Karimi
موسوی¦Mousavi
حسینی¦Hosseini
جعفری¦Jafari
صادقی¦Sadeghi
نوری¦Nouri
جیمز¦James
جک¦Jack
هری¦Harry
جورج¦George
ویلیام¦William
چارلی¦Charlie
تام¦Tom
لوک¦Luke
اسمیت¦Smith
جونز¦Jones
تیلور¦Taylor
براون¦Brown
ویلسون¦Wilson
اوانز¦Evans
واکر¦Walker
رایت¦Wright
کارلوس¦Carlos
خاویر¦Javier
پدرو¦Pedro
دیگو¦Diego
مانوئل¦Manuel
آلوارو¦Alvaro
ایکر¦Iker
رائول¦Raul
گارسیا¦Garcia
مارتینز¦Martinez
لوپز¦Lopez
سانچز¦Sanchez
پرز¦Perez
فرناندز¦Fernandez
رومرو¦Romero
نوارو¦Navarro
مارکو¦Marco
لوکا¦Luca
آندرئا¦Andrea
جووانی¦Giovanni
فدریکو¦Federico
ماتئو¦Matteo
لورنتزو¦Lorenzo
الساندرو¦Alessandro
روسی¦Rossi
روسو¦Russo
فرارا¦Ferrara
بیانکی¦Bianchi
کوستا¦Costa
ریچی¦Ricci
گالو¦Gallo
مورو¦Moro
یوناس¦Jonas
مارکوس¦Markus
توماس¦Thomas
فلیکس¦Felix
لوکاس¦Lucas
کای¦Kai
یان¦Jan
مولر¦Muller
شمیت¦Schmidt
فیشر¦Fischer
وبر¦Weber
واگنر¦Wagner
بکر¦Becker
هافمن¦Hoffmann
کراوس¦Kraus
کیلیان¦Kylian
آنتوان¦Antoine
اوسمان¦Ousmane
هوگو¦Hugo
تئو¦Theo
نیکولا¦Nicolas
پل¦Paul
ژولیان¦Julien
مارتن¦Martin
برنار¦Bernard
دوبوآ¦Dubois
موریس¦Maurice
لوران¦Laurent
میشل¦Michel
فونتن¦Fontaine
گارنیه¦Garnier
ویتور¦Vitor
رودریگو¦Rodrigo
گابریل¦Gabriel
ماتئوس¦Matheus
فرناندو¦Fernando
دانیلو¦Danilo
کائو¦Caio
سیلوا¦Silva
سانتوس¦Santos
اولیویرا¦Oliveira
سوزا¦Souza
لیما¦Lima
پریرا¦Pereira
کاستا¦Costa
ریبیرو¦Ribeiro
لیونل¦Lionel
خولیان¦Julian
نیکولاس¦Nicolas
لاوتارو¦Lautaro
فرانکو¦Franco
آنخل¦Angel
پائولو¦Paulo
تیاگو¦Thiago
گونزالس¦Gonzalez
رودریگز¦Rodriguez
آکوستا¦Acosta
مدینا¦Medina
سوسا¦Sosa
بنیتز¦Benitez
ایبارا¦Ibarra
پاز¦Paz
امره¦Emre
عثمان¦Osman
مراد¦Murat
کریم¦Kerim
یوسف¦Yusuf
برکی¦Berke
اردا¦Arda
جان¦Can
یلماز¦Yilmaz
کایا¦Kaya
دمیر¦Demir
چلیک¦Celik
شاهین¦Shahin
آیدین¦Aydin
ازتورک¦Ozturk
آرسلان¦Arslan
ستاره¦Setareh
آتش¦Atash
فولاد¦Foolad
پارس¦Pars
طوفان¦Toofan
آریا¦Arya
سپهر¦Sepehr
ققنوس¦Ghoghnoos
سیمرغ¦Simorgh
نسیم¦Nasim
البرز¦Alborz
دریا¦Darya
پیروزی¦Piroozi
ماهان¦Mahan
آرمان¦Arman
شهاب¦Shahab
هیرمند¦Hirmand
زاگرس¦Zagros
تهران¦Tehran
شیراز¦Shiraz
تبریز¦Tabriz
اصفهان¦Isfahan
مشهد¦Mashhad
اهواز¦Ahvaz
رشت¦Rasht
کرمان¦Kerman
یزد¦Yazd
ساری¦Sari
قم¦Qom
همدان¦Hamedan
رویال¦Royal
یونایتد¦United
کینگز¦Kings
رورز¦Rovers
اتلتیک¦Athletic
ولز¦Wells
دیوک¦Duke
کرون¦Crown
رئال¦Real
اتلتیکو¦Atletico
دپورتیوو¦Deportivo
اسپورتینگ¦Sporting
کلوب¦Club
یونیون¦Union
سلتا¦Celta
ریال¦Rial
اینترنو¦Interno
کالچو¦Calcio
ویرتوس¦Virtus
آزورا¦Azzurra
فورتیتودو¦Fortitudo
رومولو¦Romulo
سانتا¦Santa
بروسیا¦Borussia
آیندراخت¦Eintracht
فورتونا¦Fortuna
ویکتوریا¦Viktoria
ترو¦Treu
ریزن¦Riesen
اشتورم¦Sturm
هانزا¦Hansa
اولمپیک¦Olympique
ستاد¦Stade
ایگل¦Aigle
لوکوک¦Lecoq
فلور¦Fleur
اتوال¦Etoile
راسینگ¦Racing
لندن¦London
منچستر¦Manchester
لیورپول¦Liverpool
لیدز¦Leeds
بریستول¦Bristol
شفیلد¦Sheffield
نیوکاسل¦Newcastle
لستر¦Leicester
ناتینگهام¦Nottingham
برایتون¦Brighton
مادرید¦Madrid
بارسلونا¦Barcelona
سویا¦Seville
والنسیا¦Valencia
بیلبائو¦Bilbao
مالاگا¦Malaga
گرانادا¦Granada
ویگو¦Vigo
ساراگوسا¦Zaragoza
مایورکا¦Mallorca
میلان¦Milan
تورین¦Turin
رم¦Rome
ناپل¦Naples
ژنوا¦Genoa
فلورانس¦Florence
بولونیا¦Bologna
پالرمو¦Palermo
باری¦Bari
ورونا¦Verona
برلین¦Berlin
مونیخ¦Munich
هامبورگ¦Hamburg
کلن¦Cologne
دورتموند¦Dortmund
اشتوتگارت¦Stuttgart
لایپزیگ¦Leipzig
برمن¦Bremen
دوسلدورف¦Dusseldorf
فرانکفورت¦Frankfurt
پاریس¦Paris
مارسی¦Marseille
لیون¦Lyon
لیل¦Lille
نیس¦Nice
رن¦Rennes
نانت¦Nantes
تولوز¦Toulouse
بوردو¦Bordeaux
استراسبورگ¦Strasbourg"""
