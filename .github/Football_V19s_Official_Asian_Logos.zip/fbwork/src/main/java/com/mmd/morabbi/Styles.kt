package com.mmd.morabbi

import kotlin.math.pow

// سبک‌های بازی: ضرایب حمله/دفاع، نقش خط میانی، تعداد گل کلی و وزن مهاجم‌ها در حمله.
class StyleFx(
    val name: String, val atk: Double, val def: Double, val ctrl: Double, val tempo: Double,
    val wf: Double, val dd: Double, val desc: String
)

// ترتیب سه سبک اول مثل نسخه‌های قبل است تا سیوهای قدیمی سالم بمانند.
val STYLE_FX = listOf(
    StyleFx("دفاعی", 0.95, 1.05, 0.7, 0.93, 0.6, 0.80, "دفاع محکم‌تر، گل کمتر. مقابل تیم قوی‌تر مناسب است."),
    StyleFx("متعادل", 1.00, 1.00, 1.0, 1.00, 0.6, 0.70, "بدون نقطه قوت یا ضعف خاص."),
    StyleFx("تهاجمی", 1.05, 0.95, 1.0, 1.07, 0.6, 0.70, "گل بیشتر می‌زنی و بیشتر هم می‌خوری."),
    StyleFx("مالکیت توپ", 1.00, 1.00, 1.9, 0.97, 0.4, 0.60, "به خط میانی قوی و برتری میانه‌میدان وابسته است. مقابل ضدحمله و پرس ضعیفه."),
    StyleFx("ضدحمله", 1.00, 1.02, 0.5, 0.98, 0.7, 0.75, "مقابل تیم قوی‌تر پاداش می‌گیرد؛ مهاجم‌های قوی لازم دارد."),
    StyleFx("پرس بالا", 1.04, 0.98, 1.3, 1.05, 0.5, 0.60, "فشار روی حریف. مالکیت‌محورها و توپ‌بلندها را اذیت می‌کند، مقابل ضدحمله آسیب‌پذیر است."),
    StyleFx("بازی کناری", 1.03, 0.99, 1.0, 1.03, 0.55, 0.70, "عرضی و کناره‌ها. مقابل دفاع‌های فشرده خوب کار می‌کند."),
    StyleFx("توپ بلند", 1.02, 0.99, 0.4, 1.00, 0.8, 0.70, "تکیه روی مهاجم‌ها و میانه‌میدان را دور می‌زند. مقابل دفاع فشرده خوب است."),
    StyleFx("دفاع فشرده", 0.90, 1.10, 0.5, 0.85, 0.7, 0.80, "اتوبوس جلوی دروازه: کم‌گل، پر از مساوی. مقابل پرس و تهاجمی خوب است."),
    StyleFx("هوشمند", 1.00, 1.00, 1.1, 1.00, 0.6, 0.70, "خودش را با حریف تطبیق می‌دهد: از قوی‌تر دفاع می‌کند، مقابل ضعیف‌تر حمله می‌کند.")
)

// (الف، ب) یعنی سبک الف روی سبک ب برتری دارد.
private val STYLE_EDGE = setOf(
    4 to 2, 4 to 5, 4 to 3, 5 to 3, 5 to 7, 6 to 8, 6 to 0, 7 to 8, 7 to 4, 8 to 5, 8 to 2, 3 to 0, 3 to 6
)

fun styleEdge(a: Int, b: Int): Int = if ((a to b) in STYLE_EDGE) 1 else if ((b to a) in STYLE_EDGE) -1 else 0

fun aiStyle(t: Team): Int = (((t.id.toLong() + 11L) * 2654435761L ushr 9) % STYLE_FX.size).toInt()

// آرایش تیم‌های رایانه‌ای: از ۸ آرایش اول، ثابت برای هر تیم
fun aiFormation(t: Team): String = FORMS[((t.id * 7 + 3) % 8)]

// [حمله، دفاع، کنترل میانه‌میدان] بر اساس اورال بازیکنان، آرایش (تعداد هر خط) و سبک بازی
fun strength(lu: List<Player>, style: Int): DoubleArray {
    val fx = STYLE_FX[style.coerceIn(0, STYLE_FX.size - 1)]
    fun avg(p: String): Double {
        val l = lu.filter { it.pos == p }
        return if (l.isEmpty()) 50.0 else l.map { it.rating }.average()
    }
    val gk = avg("GK"); val df = avg("DF"); val mf = avg("MF"); val fw = avg("FW")
    val nD = lu.count { it.pos == "DF" }; val nM = lu.count { it.pos == "MF" }; val nF = lu.count { it.pos == "FW" }
    var att = fw * fx.wf + mf * (1 - fx.wf)
    var def = (gk * 0.2 + df * 0.8) * fx.dd + mf * (1 - fx.dd)
    att *= 1.0 + 0.025 * (nF + 0.5 * nM - 4.0)
    def *= 1.0 + 0.02 * (nD + 0.4 * nM - 5.6)
    val ctrl = mf * (1.0 + 0.06 * (nM - 4))
    return doubleArrayOf(att * fx.atk, def * fx.def, ctrl)
}

fun styleGoalAdjust(hx0: Double, ax0: Double, hs: DoubleArray, aw: DoubleArray, sh: Int, sa: Int): Pair<Double, Double> {
    var hx = hx0; var ax = ax0
    val fh = STYLE_FX[sh]; val fa = STYLE_FX[sa]
    val cs = (hs[2] / aw[2] - 1.0).coerceIn(-0.25, 0.25)
    hx *= 1 + cs * 0.8 * fh.ctrl
    ax *= 1 - cs * 0.8 * fa.ctrl
    val e = styleEdge(sh, sa)
    hx *= 1 + 0.04 * e; ax *= 1 - 0.04 * e
    val hp = hs[0] + hs[1]; val ap = aw[0] + aw[1]
    if (sh == 4 && ap > hp) hx *= 1.05
    if (sa == 4 && hp > ap) ax *= 1.05
    if (sh == 9) { if (hp >= ap) hx *= 1.03 else ax /= 1.03 }
    if (sa == 9) { if (ap >= hp) ax *= 1.03 else hx /= 1.03 }
    val tp = (fh.tempo * fa.tempo).pow(0.5)
    return Pair(hx * tp, ax * tp)
}
